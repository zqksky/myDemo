﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using AMAT.R2R.Server.Base.Repository;
using AMAT.R2R.Server.Etch.Entities;
using AMAT.R2R.Server.Etch.Services;
using AMAT.R2R.Shared.Base.DTO;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Configuration.EnvironmentVariables;
using Oracle.EntityFrameworkCore;
using Oracle.EntityFrameworkCore.Infrastructure;
using Oracle.ManagedDataAccess.Client;
using BaseEntities = AMAT.R2R.Server.Base.Entities;

namespace AMAT.R2R.Server.Etch.Repository
{
    public class EtchDBContext : E3suiteDBContext
    {
        public DbSet<InputDefinition> InputDefinitionRepository { get; set; }
        public DbSet<LinearConstraint> LinearConstraintRepository { get; set; }
        public DbSet<StrategyConstant> StrategyConstantRepository { get; set; }
        public DbSet<ProcessSetting> ProcessSettingRepository { get; set; }
        public DbSet<Context> ContextRepository { get; set; }
        public DbSet<Process> ProcessRepository { get; set; }
        public DbSet<ProcessMetrology> ProcessMetrologyRepository { get; set; }
        public DbSet<PostMetrologySetting> PostMetrologySettingRepository { get; set; }
        public DbSet<PreMetrologySetting> PreMetrologySettingRepository { get; set; }
        public DbSet<SpecialJob> SpecialJobRepository { get; set; }
        public DbSet<SpecialJobParameter> SpecialJobParameterRepository { get; set; }
        public DbSet<AutoStates> AutoStatesRepository { get; set; }
        public DbSet<HznMaterialized> HznMaterializedRepository { get; set; }
        public DbSet<PreMetrologyLineAvg> PreMetrologyLineAvgRepository { get; set; }
        public DbSet<MetrologyRecord> MetrologyRecordSettingRepository { get; set; }
        public DbSet<ChamberOffset> ChamberOffsetRepository { get; set; }
        public EtchDBContext() : base()
        {
            Setup();
        }


        public EtchDBContext(DbContextOptions options) : base(options)
        {
            Setup();
        }

        private void Setup()
        {
            InputDefinitionRepository = Set<InputDefinition>();
            LinearConstraintRepository = Set<LinearConstraint>();
            StrategyConstantRepository = Set<StrategyConstant>();
            ProcessSettingRepository = Set<ProcessSetting>();
            ContextRepository = Set<Context>();
            ProcessRepository = Set<Process>();
            ProcessMetrologyRepository = Set<ProcessMetrology>();
            PostMetrologySettingRepository = Set<PostMetrologySetting>();
            PreMetrologySettingRepository = Set<PreMetrologySetting>();
            SpecialJobRepository = Set<SpecialJob>();
            SpecialJobParameterRepository = Set<SpecialJobParameter>();
            AutoStatesRepository = Set<AutoStates>();
            HznMaterializedRepository = Set<HznMaterialized>();
            PreMetrologyLineAvgRepository = Set<PreMetrologyLineAvg>();
            MetrologyRecordSettingRepository = Set<MetrologyRecord>();
            ChamberOffsetRepository = Set<ChamberOffset>();
            if (!Database.GetDbConnection().State.Equals(System.Data.ConnectionState.Open))
            {
                Database.OpenConnection();
            }
        }


        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                optionsBuilder.UseOracle(ConnectionHelper.ConnectionString).UseLoggerFactory(LoggerFactory).EnableSensitiveDataLogging();
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Process>().HasKey(t => new { t.ProcessId });
            modelBuilder.Entity<ProcessMetrology>().HasKey(t => new { t.Fab, t.ProductId, t.Stage, t.Recipe, t.StepName, t.StepNumber, t.MetroFab, t.MetroRecipe, t.MetroStage, t.MetroStepName, t.MetroStepNumber });

            modelBuilder.Entity<PostMetrologySetting>().HasKey(t => new { t.PostMetroId });
            modelBuilder.Entity<PreMetrologySetting>().HasKey(t => new { t.PreMetroId });

            modelBuilder.Entity<Context>().HasKey(t => new { t.ContextId });
            modelBuilder.Entity<InputDefinition>().HasKey(t => new { t.ContextId, t.InputParameterName });
            modelBuilder.Entity<ProcessSetting>().HasKey(t => new { t.ContextId });
            modelBuilder.Entity<StrategyConstant>().HasKey(t => new { t.ContextId });

            modelBuilder.Entity<SpecialJob>().HasKey(t => new { t.JobId });
            modelBuilder.Entity<SpecialJobParameter>().HasKey(t => new { t.JobId, t.ParameterName });
            modelBuilder.Entity<LinearConstraint>().HasKey(t => t.ContextId);
            modelBuilder.Entity<AutoStates>().HasKey(t => t.ContextId);
            modelBuilder.Entity<AutoStatesHist>().HasKey(t => new { t.ContextId, t.UpdateTimestamp });

            modelBuilder.Entity<AutoStates>().HasKey(t => new { t.ContextId });
            modelBuilder.Entity<HznMaterialized>().HasKey(t => new { t.Fab, t.Tool, t.Chamber, t.ContextGroup, t.ProductId, t.Stage, t.Recipe, t.StepName, t.StepNumber, t.LotId, t.HznKey });
            modelBuilder.Entity<PreMetrologyLineAvg>().HasKey(t => new { t.Fab, t.Tool, t.Chamber, t.ContextGroup, t.ProductId, t.Stage, t.Recipe, t.StepName, t.StepNumber });
            modelBuilder.Entity<MetrologyRecord>().HasKey(t => new { t.Fab, t.MetroStage, t.MetroRecipe, t.MetroStepName, t.MetroSteNum, t.MeasDataItemName, t.TxId });
            modelBuilder.Entity<ChamberOffset>().HasKey(t => new { t.ToolId, t.ChamberId, t.ParameterName });

            base.OnModelCreating(modelBuilder);
        }
    }
}
