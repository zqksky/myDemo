﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AMAT.R2R.Server.Base;
using AMAT.R2R.Server.Base.Constants;
using AMAT.R2R.Server.Base.Exceptions;
using AMAT.R2R.Server.Etch.Services;
using AMAT.R2R.Shared.Base.Constants;
using AMAT.R2R.Shared.Etch.DTO;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace AMAT.R2R.Server.Etch.Controllers
{
#if RELEASE
    [Authorize]
#endif
#if DEBUG
    [EnableBodyRewind]
#endif
    [Route("api/[controller]")]
    [ApiController]
    public class MaterializedController : ControllerBase
    {
        public IMaterializedService MaterializedService { get; }

        public MaterializedController(IMaterializedService materializedService)
        {
            MaterializedService = materializedService;
        }

        // GET: api/MaterializedView
        [HttpGet]
        public ActionResult<IEnumerable<MaterializedView>> GetMaterializedViewList()
        {
            return MaterializedService.GetMaterializedViewList(HttpContext.Request.Query);
        }

        // get count
        [HttpGet(QueryWords.ItemsCountEndpoint)]
        public ActionResult<int> GetMaterializedViewCount()
        {
            return MaterializedService.GetMaterializedViewCount(HttpContext.Request.Query);
        }

        // get unique value list.
        [HttpGet(QueryWords.ValueListEndpoint + "/{propertyName}")]
        public ActionResult<object[]> GetValueList(string propertyName)
        {
            return MaterializedService.GetMaterializedViewValueList(HttpContext.Request.Query, propertyName);
        }



        // GET: api/MaterializedView/5
        [HttpGet("{contextId}")]
        public ActionResult<MaterializedView> GetMaterializedView(int contextId)
        {
            var materializedView = MaterializedService.GetMaterializedView(contextId);
            if (materializedView != null)
            {
                return materializedView;
            }
            else
            {
                throw new ApiException(GeneralErrorCode.ResourceNotFound);
            }
        }

        [HttpGet("{contextId}/input")]
        public ActionResult<IEnumerable<MaterializeViewParameter>> GetMaterializeViewParameterList(int contextId)
        {
            return MaterializedService.GetMaterializeViewParameters(contextId);
        }

        [HttpGet("{contextId}/run")]
        public ActionResult<IEnumerable<RunHist>> GetMaterializeViewRunHistory(int contextId)
        {
            return MaterializedService.GetMaterializedViewRunHist(contextId);
        }

        [HttpPut("{contextId}/change")]
        public IActionResult ChangeStatus(MaterializedView materializedView, int contextId)
        {
            if (contextId != materializedView.ContextId)
            {
                throw new ApiException(GeneralErrorCode.IdMismatch);
            }

            MaterializedService.ChangeContextThreadStatus(contextId, materializedView.ThreadStatus, materializedView.BookedPiLotId);
            return NoContent();
        }

        [HttpPut("{contextId}/reset")]
        public IActionResult ResetStatus(MaterializedView materializedView, int contextId)
        {
            MaterializedService.ResetControlThreadByContext(contextId);
            return NoContent();
        }
    }
}
