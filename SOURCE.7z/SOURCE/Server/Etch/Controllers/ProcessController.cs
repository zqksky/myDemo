﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Threading;
using System.Threading.Tasks;
using AMAT.R2R.Server.Base;
using AMAT.R2R.Server.Base.Constants;
using AMAT.R2R.Server.Base.Exceptions;
using AMAT.R2R.Server.Base.Extensions;
using AMAT.R2R.Server.Etch.Services;
using AMAT.R2R.Shared.Base.Constants;
using AMAT.R2R.Shared.Etch.DTO;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using DTO = AMAT.R2R.Shared.Etch.DTO;

namespace AMAT.R2R.Server.Etch.Controllers
{
#if RELEASE
    [Authorize]
#endif
#if DEBUG
    [EnableBodyRewind]
#endif
    [Route("api/[controller]")]
    [ApiController]
    public class ProcessController : R2RControllerBase
    {
        public IProcessService ProcessService { get; }

        public ProcessController(IProcessService processService)
        {
            ProcessService = processService;
        }

        #region Process
        // GET: api/Process
        [HttpGet]
        public ActionResult<IEnumerable<Process>> GetProcessList()
        {
            return ProcessService.GetProcessList(HttpContext.Request.Query);
        }

        // get count
        [HttpGet(QueryWords.ItemsCountEndpoint)]
        public ActionResult<int> GetProcessCount()
        {
            return ProcessService.GetProcessCount(HttpContext.Request.Query);
        }

        // get unique value list.
        [HttpGet(QueryWords.ValueListEndpoint + "/{propertyName}")]
        public ActionResult<object[]> GetValueList(string propertyName)
        {
            return ProcessService.GetProcessValueList(HttpContext.Request.Query, propertyName);
        }

        //// GET: api/Process
        //[HttpGet]
        //public async Task<ActionResult<IEnumerable<Process>>> GetProcessListAsync()
        //{
        //    return await ProcessService.GetProcessListAsync(HttpContext.Request.Query);
        //}


        // GET: api/Process/5
        [HttpGet("{processId}")]
        public ActionResult<Process> GetProcess(int processId)
        {
            var process = ProcessService.GetProcessInfoByID(processId);
            if (process != null)
            {
                return process;
            }
            else
            {
                throw new ApiException(GeneralErrorCode.ResourceNotFound);
            }
        }

        [HttpPost]
        public ActionResult<Process> CreateProcess(Process process)
        {
            var createdProcess = ProcessService.CreateProcess(process);

            return CreatedAtAction(nameof(GetProcess), new { processId = createdProcess.ProcessId }, createdProcess);
        }

        [HttpPut("{processId}")]
        public IActionResult UpdateProcess(Process process, int processId)
        {
            if (processId != process.ProcessId)
            {
                throw new ApiException(GeneralErrorCode.IdMismatch);
            }

            // TODO: update process.

            ProcessService.UpdateProcess(process);

            return NoContent();
        }

        [HttpDelete("{processId}")]
        public IActionResult DeleteProcess(int processId)
        {
            ProcessService.DeleteProcess(processId);

            return NoContent();
        } 
        #endregion

        #region Feedforward Settings
        [HttpGet("{processId}/FeedforwardSetting")]
        public ActionResult<IEnumerable<FeedforwardSetting>> GetFeedforwardSettingList(int processId)
        {
            return ProcessService.GetFeedforwardSettingList(processId);
        }

        [HttpGet("{processId}/FeedforwardSetting/{settingId}")]
        public ActionResult<FeedforwardSetting> GetFeedforwardSetting(int processId, int settingId)
        {
            return ProcessService.GetFeedforwardSetting(processId, settingId);
        }

        [HttpPost("{processId}/FeedforwardSetting")]
        public ActionResult<FeedforwardSetting> CreateFeedforwardSetting(FeedforwardSetting feedforwardSetting)
        {
            var createdFeedforwardSetting = ProcessService.CreateFeedforwardSetting(feedforwardSetting);

            return CreatedAtAction(nameof(GetFeedforwardSetting),
                new
                {
                    processId = createdFeedforwardSetting.ProcessId,
                    settingId = createdFeedforwardSetting.PreMetroId
                },
                createdFeedforwardSetting);
        }

        [HttpPut("{processId}/FeedforwardSetting/{settingId}")]
        public IActionResult UpdateFeedforwardSetting(FeedforwardSetting feedforwardSetting, int processId, int settingId)
        {
            if (settingId != feedforwardSetting.PreMetroId || feedforwardSetting.ProcessId != processId)
            {
                throw new ApiException(GeneralErrorCode.IdMismatch);
            }

            // TODO: update process.

            ProcessService.UpdateFeedforwardSetting(feedforwardSetting);

            return NoContent();
        }

        [HttpDelete("{processId}/FeedforwardSetting/{settingId}")]
        public IActionResult DeleteFeedforwardSetting(int processId, int settingId)
        {
            ProcessService.DeleteFeedforwardSetting(processId, settingId);

            return NoContent();
        } 
        #endregion

        #region Output Settings

        [HttpGet("{processId}/OutputSetting")]
        public ActionResult<IEnumerable<OutputSetting>> GetOutputSettingList(int processId)
        {
            return ProcessService.GetOutputSettingList(processId);
        }

        [HttpGet("{processId}/OutputSetting/{settingId}")]
        public ActionResult<OutputSetting> GetOutputSetting(int processId, int settingId)
        {
            return ProcessService.GetOutputSetting(processId, settingId);
        }

        [HttpPost("{processId}/OutputSetting")]
        public ActionResult<OutputSetting> CreateOutputSetting(OutputSetting outputSetting)
        {
            var createdOutputSetting = ProcessService.CreateOutputSetting(outputSetting);

            return CreatedAtAction(nameof(GetOutputSetting),
                new
                {
                    processId = createdOutputSetting.ProcessId,
                    settingId = outputSetting.PostMetroId
                },
                createdOutputSetting);
        }

        [HttpPut("{processId}/OutputSetting/{settingId}")]
        public IActionResult UpdateOutputSetting(OutputSetting outputSetting, int processId, int settingId)
        {
            if (settingId != outputSetting.PostMetroId || processId != outputSetting.ProcessId)
            {
                throw new ApiException(GeneralErrorCode.IdMismatch);
            }

            // TODO: update process.

            ProcessService.UpdateOutputSetting(outputSetting);

            return NoContent();
        }

        [HttpDelete("{processId}/OutputSetting/{settingId}")]
        public IActionResult DeleteOutputSetting(int processId, int settingId)
        {
            ProcessService.DeleteOutputSetting(processId, settingId);

            return NoContent();
        } 
        #endregion

        #region PreMetrology
        [HttpGet("{processId}/PreMetrology")]
        public ActionResult<IEnumerable<PreMetrology>> GetPreMetrologyList(int processId)
        {
            return ProcessService.GetPreMetrologyList(processId);
        }
        [HttpGet("{processId}/PreMetrology/{metrologyKey}")]
        public ActionResult<PreMetrology> GetPreMetrology(int processId, string metrologyKey)
        {
            // TODO: add get method to ProcessService
            return ProcessService.GetPreMetrologyList(processId).FirstOrDefault(m => m.MetrologyKey == metrologyKey);
        }

        [HttpPost("{processId}/PreMetrology")]
        public ActionResult<PreMetrology> CreatePreMetrology(PreMetrology preMetrology)
        {
            var createdPreMetrology = ProcessService.CreatePreMetrology(preMetrology);

            return CreatedAtAction(nameof(GetPreMetrology),
                new
                {
                    processId = createdPreMetrology.ProcessId,
                    metrologyKey = createdPreMetrology.MetrologyKey
                },
                createdPreMetrology);
        }

        [HttpDelete("{processId}/PreMetrology/{metrologyKey}")]
        public IActionResult DeletePreMetrology(int processId, string metrologyKey)
        {
            ProcessService.DeletePreMetrology(processId, metrologyKey);

            return NoContent();
        }
        #endregion

        #region PostMetrology
        [HttpGet("{processId}/PostMetrology")]
        public ActionResult<IEnumerable<PostMetrology>> GetPostMetrologyList(int processId)
        {
            return ProcessService.GetPostMetrologyList(processId);
        }

        [HttpGet("{processId}/PostMetrology/{metrologyKey}")]
        public ActionResult<PostMetrology> GetPostMetrology(int processId, string metrologyKey)
        {
            return ProcessService.GetPostMetrologyList(processId).FirstOrDefault(m => m.MetrologyKey == metrologyKey);
        }

        [HttpPost("{processId}/PostMetrology")]
        public ActionResult<PostMetrology> CreatePostMetrology(PostMetrology postMetrology)
        {
            var createdPostMetrology = ProcessService.CreatePostMetrology(postMetrology);

            return CreatedAtAction(nameof(GetPostMetrology), new { processId = createdPostMetrology.ProcessId, metrologyKey = createdPostMetrology.MetrologyKey }, createdPostMetrology);
        }

        [HttpDelete("{processId}/PostMetrology/{metrologyKey}")]
        public IActionResult DeletePostMetrology(int processId, string metrologyKey)
        {
            ProcessService.DeletePostMetrology(processId, metrologyKey);

            return NoContent();
        }
        #endregion

        #region Manual Pre Metrology Item
        [HttpGet("{processId}/ManualPreMetrologyItem")]
        public ActionResult<ManualPreMetrology> GetManualPreMetrology(int processId)
        {
            return ProcessService.GetManualPreMetrologyInfo(processId);
        }

        [HttpGet("{processId}/ManualPreMetrologyItem/{uniqueId}")]
        public ActionResult<ManualPreMetrologyItem> GetManualPreMetrologyItem(int processId, string uniqueId)
        {
            return ProcessService.GetManualPreMetrologyInfo(processId).ManualPreMetrologyItems.FirstOrDefault(m => m.uniqueId == uniqueId);
        }

        [HttpPost("{processId}/ManualPreMetrologyItem")]
        public ActionResult<ManualPreMetrologyItem> CreateManualPreMetrologyItem(ManualPreMetrologyItem manualPreMetrologyItem, int processId)
        {
            var createdItem = ProcessService.AddManualPreMetrologyItem(manualPreMetrologyItem);

            return CreatedAtAction(nameof(GetManualPreMetrologyItem), new { processId = processId, uniqueId = createdItem.uniqueId }, createdItem);
        }

        [HttpDelete("{processId}/ManualPreMetrologyItem/{uniqueId}")]
        public IActionResult DeleteManualPreMetrologyItem(int processId, string uniqueId)
        {
            ProcessService.DeleteManualPreMetrologyItem(processId, uniqueId);

            return NoContent();
        }
        #endregion

    }
}
