﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AMAT.R2R.Server.Base;
using AMAT.R2R.Server.Base.Constants;
using AMAT.R2R.Server.Base.Exceptions;
using AMAT.R2R.Server.Etch.Services;
using AMAT.R2R.Shared.Base.Constants;
using AMAT.R2R.Shared.Etch.DTO;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace AMAT.R2R.Server.Etch.Controllers
{
#if RELEASE
    [Authorize]
#endif
#if DEBUG
    [EnableBodyRewind]
#endif
    [Route("api/[controller]")]
    [ApiController]
    public class SpecialJobController : ControllerBase
    {
        public IContextService SpecialJobService { get; }

        public SpecialJobController(IContextService service)
        {
            SpecialJobService = service;
        }


        // GET: api/SpecialJob
        [HttpGet]
        public ActionResult<IEnumerable<SpecialJob>> GetSpecialJobList()
        {
            return SpecialJobService.GetSpecialJobList(HttpContext.Request.Query);
        }

        // get count
        [HttpGet(QueryWords.ItemsCountEndpoint)]
        public ActionResult<int> GetContextCount()
        {
            return SpecialJobService.GetSpecialJobCount(HttpContext.Request.Query);
        }

        // get unique value list.
        [HttpGet(QueryWords.ValueListEndpoint + "/{propertyName}")]
        public ActionResult<object[]> GetValueList(string propertyName)
        {
            return SpecialJobService.GetSpecialJobValueList(HttpContext.Request.Query, propertyName);
        }


        // GET: api/SpecialJob/5
        [HttpGet("{specialJobId}")]
        public ActionResult<SpecialJob> GetSpecialJob(string specialJobId)
        {
            var specialJob = SpecialJobService.GetSpecialJobInfo(specialJobId);
            if (specialJob != null)
            {
                return specialJob;
            }
            else
            {
                throw new ApiException(GeneralErrorCode.ResourceNotFound);
            }
        }


        [HttpPost]
        public ActionResult<SpecialJob> CreateSpecialJob(SpecialJob specialJob)
        {
            var createdSpecialJob = SpecialJobService.CreateSpecialJob(specialJob);

            return CreatedAtAction(nameof(GetSpecialJob), new { specialJobId = createdSpecialJob.JobId }, createdSpecialJob);
        }

        [HttpPut("{specialJobId}")]
        public IActionResult UpdateSpecialJob(SpecialJob specialJob, string specialJobId)
        {
            if (specialJobId != specialJob.JobId)
            {
                throw new ApiException(GeneralErrorCode.IdMismatch);
            }

            // TODO: update specialJob.

            SpecialJobService.UpdateSpecialJob(specialJob);

            return NoContent();
        }

        [HttpDelete("{specialJobId}")]
        public IActionResult DeleteSpecialJob(string specialJobId)
        {
            SpecialJobService.DeleteSpecialJob(specialJobId);

            return NoContent();
        }
    }
}
