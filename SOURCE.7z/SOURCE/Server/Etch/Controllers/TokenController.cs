﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using AMAT.R2R.Server.Base;
using AMAT.R2R.Server.Base.Extensions;
using AMAT.R2R.Server.Base.Repository;
using AMAT.R2R.Server.Base.Service;
using AMAT.R2R.Server.Etch.Services;
using AMAT.R2R.Shared.Base.DTO;
using AMAT.R2R.Shared.Etch.DTO;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using Oracle.ManagedDataAccess.Client;

namespace AMAT.R2R.Server.Etch.Controllers
{
#if DEBUG
    [EnableBodyRewind]
#endif
    [Route("api/[controller]")]
    [ApiController]
    public class TokenController : R2RControllerBase
    {
        public IConfiguration _appSettings;

        public IAuthenticationService AuthenticationService { get; }

        public TokenController(IConfiguration config, IAuthenticationService authenticationService)
        {
            _appSettings = config;
            AuthenticationService = authenticationService;
        }

        [HttpPost]
        public ActionResult<LoginInfo> Login(LoginInfo loginInfo)
        {
            loginInfo = AuthenticationService.LoginUser(loginInfo);

            loginInfo.ServerVersion = FileVersionInfo.GetVersionInfo(Assembly.GetExecutingAssembly().Location).FileVersion;
            loginInfo.DBInfo = ConnectionHelper.GetDBInfo();

            //loginInfo.DBInfo = $"{conn.HostName}/{conn.ServiceName}";

            //    "etch": "Data Source=(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=152.135.69.42)(PORT=1521))(CONNECT_DATA=(SERVICE_NAME=qar2rdb3)));User Id=e3suite;Password=e3suite;Enlist=false;Pooling=true;Min Pool Size=20;Max Pool Size=50;Connection Lifetime=0",


            //create claims details based on the user information
            var claims = new[]
            {
                new Claim(JwtRegisteredClaimNames.Sub, _appSettings["Jwt:Subject"]),
                new Claim(SessionIdClaimType, loginInfo.SessionId),
                new Claim(UsernameClaimType, loginInfo.UserName),
            };

            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_appSettings["Jwt:Key"]));
            var signIn = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

            // create token.
            var token = new JwtSecurityToken(_appSettings["Jwt:Issuer"], _appSettings["Jwt:Audience"], claims, expires: DateTime.UtcNow.AddDays(1), signingCredentials: signIn);
            loginInfo.Token = new JwtSecurityTokenHandler().WriteToken(token);
            return loginInfo;
        }

    }
}
