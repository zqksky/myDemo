﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AMAT.R2R.Server.Base;
using AMAT.R2R.Server.Base.Constants;
using AMAT.R2R.Server.Base.Exceptions;
using AMAT.R2R.Server.Etch.Services;
using AMAT.R2R.Shared.Base.Constants;
using AMAT.R2R.Shared.Etch.DTO;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace AMAT.R2R.Server.Etch.Controllers
{
#if RELEASE
    [Authorize]
#endif
    [Route("api/[controller]")]
    [ApiController]
    [EnableBodyRewind]
    public class LotHistoryController : ControllerBase
    {
        public ILotHistoryService LotHistoryService { get; }

        public LotHistoryController(ILotHistoryService service)
        {
            LotHistoryService = service;
        }

        // GET: api/LotHistory
        [HttpGet]
        public ActionResult<IEnumerable<LotRunHistory>> GetLotHistoryList()
        {
            return LotHistoryService.GetLotRunHistoryList(HttpContext.Request.Query);
        }


        // get unique value list.
        // e.g. api/LotHistory/~valueList~/Recipe
        [HttpGet(QueryWords.ValueListEndpoint + "/{propertyName}")]
        public ActionResult<object[]> GetValueList(string propertyName)
        {
            return LotHistoryService.GetFilterValueList(HttpContext.Request.Query, propertyName);
        }

    }
}
