﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading;
using System.Threading.Tasks;
using AMAT.R2R.Server.Base;
using AMAT.R2R.Server.Base.Constants;
using AMAT.R2R.Server.Base.Exceptions;
using AMAT.R2R.Server.Base.Extensions;
using AMAT.R2R.Server.Base.Service;
using AMAT.R2R.Server.Etch.Services;
using AMAT.R2R.Shared.Base.DTO;
using AMAT.R2R.Shared.Etch.DTO;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using DTO = AMAT.R2R.Shared.Etch.DTO;

namespace AMAT.R2R.Server.Etch.Controllers
{
#if RELEASE
    [Authorize]
#endif
#if DEBUG
    [EnableBodyRewind]
#endif
    [Route("api/[controller]")]
    [ApiController]
    public class ToolController : R2RControllerBase
    {
        public IMaterializedService MaterializedService { get; }
        public IGlobalService GlobalService { get; }

        public ToolController(IGlobalService globalService, IMaterializedService materializedService)
        {
            MaterializedService = materializedService;
            GlobalService = globalService;
        }

        // GET: api/Tool
        [HttpGet]
        public ActionResult<IEnumerable<Tool>> GetToolList()
        {
            return GlobalService.GetToolList();
        }

        // GET: api/Tool/{toolId}/Chamber
        [HttpGet("{toolId}/chamber")]
        public ActionResult<IEnumerable<Chamber>> GetChamberList(string toolId)
        {
            return GlobalService.GetChamberList(toolId);
        }

        // GET: api/Tool/{toolId}/Chamber/{chamberId}/parameter
        [HttpGet("{toolId}/chamber/{chamberId}/parameter")]
        public ActionResult<IEnumerable<Parameter>> GetProcessParameterList(string toolId, string chamberId)
        {
            return GlobalService.GetProcessParameterList(toolId, chamberId);
        }


        [HttpGet("{toolId}/chamber/{chamberId}/offset")]
        public ActionResult<IEnumerable<ChamberOffsetItem>> GetChamberOffsetItemList(string toolId, string chamberId)
        {
            return MaterializedService.GetChamberOffset(toolId, chamberId)?.ChamberOffsetItems;
        }

        [HttpPut("{toolId}/chamber/{chamberId}/offset/{parameterName}")]
        public IActionResult UpdateChamberOffset(ChamberOffsetItem chamberOffsetItem, string toolId, string chamberId, string parameterName)
        {
            if (toolId != chamberOffsetItem.Tool || chamberId != chamberOffsetItem.Chamber || parameterName != chamberOffsetItem.ParameterName)
            {
                throw new ApiException(GeneralErrorCode.IdMismatch);
            }

            MaterializedService.UpdateChamberOffsetItem(chamberOffsetItem);

            return NoContent();
        }

        [HttpDelete("{toolId}/chamber/{chamberId}/offset/{parameterName}")]
        public IActionResult DeleteChamberOffset(string toolId, string chamberId, string parameterName)
        {
            MaterializedService.DeleteChamberOffsetItem(toolId, chamberId, parameterName);

            return NoContent();
        }


        // GET: api/tool/1
        [HttpGet("{toolId}")]
        public ActionResult<Tool> GetTool(string toolId)
        {
            var tool = GlobalService.GetTool(toolId);
            if (tool != null)
            {
                return tool;
            }
            else
            {
                throw new ApiException(GeneralErrorCode.ResourceNotFound);
            }
        }

        [HttpPost]
        public ActionResult<Tool> CreateTool(Tool tool)
        {
            var createdTool = GlobalService.CreateTool(tool);

            return CreatedAtAction(nameof(GetTool), new { toolId = createdTool.ToolId }, createdTool);
        }

        [HttpPut("{toolId}")]
        public IActionResult UpdateTool(Tool tool, string toolId)
        {
            if (toolId != tool.ToolId)
            {
                throw new ApiException(GeneralErrorCode.IdMismatch);
            }

            GlobalService.UpdateTool(tool);

            return NoContent();
        }


        [HttpDelete("{toolId}")]
        public IActionResult DeleteTool(string toolId)
        {
            GlobalService.DeleteTool(toolId);

            return NoContent();
        }


        // GET: api/tool/1/chamber/A
        [HttpGet("{toolId}/chamber/{chamberId}")]
        public ActionResult<Chamber> GetChamber(string toolId, string chamberId)
        {
            var tool = GlobalService.GetChamber(toolId, chamberId);
            if (tool != null)
            {
                return tool;
            }
            else
            {
                throw new ApiException(GeneralErrorCode.ResourceNotFound);
            }
        }

        [HttpPost("{toolId}/chamber")]
        public ActionResult<Chamber> CreateChamber(Chamber chamber, string toolId)
        {
            var createdChamber = GlobalService.CreateChamber(chamber);

            return CreatedAtAction(nameof(GetChamber), new { toolId, chamberId = createdChamber.ChamberId }, createdChamber);
        }

        [HttpPut("{toolId}/chamber/{chamberId}")]
        public IActionResult UpdateChamber(Chamber chamber, string toolId, string chamberId)
        {
            if (toolId != chamber.ToolId || chamberId != chamber.ChamberId)
            {
                throw new ApiException(GeneralErrorCode.IdMismatch);
            }

            GlobalService.UpdateChamber(chamber);

            return NoContent();
        }


        [HttpDelete("{toolId}/chamber/{chamberId}")]
        public IActionResult DeleteChamber(string toolId, string chamberId)
        {
            GlobalService.DeleteChamber(toolId, chamberId);

            return NoContent();
        }


        // GET: api/tool/1/chamber/A
        [HttpGet("{toolId}/chamber/{chamberId}/parameter/{parameterName}")]
        public ActionResult<Parameter> GetParameter(string toolId, string chamberId, string parameterName)
        {
            var parameter = GlobalService.GetParameter(toolId, chamberId, parameterName);
            if (parameter != null)
            {
                return parameter;
            }
            else
            {
                throw new ApiException(GeneralErrorCode.ResourceNotFound);
            }
        }

        [HttpPost("{toolId}/chamber/{chamberId}/parameter")]
        public ActionResult<Parameter> CreateParameter(Parameter parameter, string toolId, string chamberId)
        {
            var createdParameter = GlobalService.CreateParameter(parameter);

            return CreatedAtAction(nameof(GetParameter), new { toolId, chamberId, parameterName = createdParameter.ParameterName }, createdParameter);
        }

        [HttpPut("{toolId}/chamber/{chamberId}/parameter/{parameterName}")]
        public IActionResult UpdateParameter(Parameter parameter, string toolId, string chamberId, string parameterName)
        {
            if (toolId != parameter.Tool.ToolId || chamberId != parameter.Chamber.ChamberId || parameter.ParameterName != parameterName)
            {
                throw new ApiException(GeneralErrorCode.IdMismatch);
            }

            GlobalService.UpdateParameter(parameter);

            return NoContent();
        }


        [HttpDelete("{toolId}/chamber/{chamberId}/parameter/{parameterName}")]
        public IActionResult DeleteParameter(string toolId, string chamberId, string parameterName)
        {
            GlobalService.DeleteParameter(toolId, chamberId, parameterName);

            return NoContent();
        }

    }
}
