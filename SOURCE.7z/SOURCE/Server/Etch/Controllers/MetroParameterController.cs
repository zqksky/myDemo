﻿using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Security.Claims;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using AMAT.R2R.Server.Base;
using AMAT.R2R.Server.Base.Extensions;
using AMAT.R2R.Server.Base.Service;
using AMAT.R2R.Server.Etch.Services;
using AMAT.R2R.Shared.Base.DTO;
using AMAT.R2R.Shared.Etch.DTO;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;

namespace AMAT.R2R.Server.Etch.Controllers
{
#if RELEASE
    [Authorize]
#endif
#if DEBUG
    [EnableBodyRewind]
#endif
    [Route("api/[controller]")]
    [ApiController]
    public class MetroParameterController : R2RControllerBase
    {
        public IConfiguration _appSettings;

        public IGlobalService GlobalService { get; }

        public MetroParameterController(IConfiguration config, IGlobalService globalService)
        {
            _appSettings = config;
            GlobalService = globalService;
        }


        [HttpGet]
        public ActionResult<IEnumerable<Parameter>> GetMetroParameterList()
        {
            return GlobalService.GetMeasureItemList();
        }

    }
}
