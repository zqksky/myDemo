﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading;
using System.Threading.Tasks;
using AMAT.R2R.Server.Base;
using AMAT.R2R.Server.Base.Constants;
using AMAT.R2R.Server.Base.Exceptions;
using AMAT.R2R.Server.Base.Extensions;
using AMAT.R2R.Server.Base.Service;
using AMAT.R2R.Server.Etch.Services;
using AMAT.R2R.Shared.Base.DTO;
using AMAT.R2R.Shared.Etch.DTO;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using DTO = AMAT.R2R.Shared.Etch.DTO;

namespace AMAT.R2R.Server.Etch.Controllers
{
#if RELEASE
    [Authorize]
#endif
#if DEBUG
    [EnableBodyRewind]
#endif
    [Route("api/[controller]")]
    [ApiController]
    public class ContextGroupController : R2RControllerBase
    {
        public IGlobalService GlobalService { get; }

        public ContextGroupController(IGlobalService globalService)
        {
            GlobalService = globalService;
        }

        // GET: api/Tool
        [HttpGet]
        public ActionResult<IEnumerable<string>> GetContextGroupList()
        {
            return GlobalService.GetLithoToolTypeList();
        }
    }
}
