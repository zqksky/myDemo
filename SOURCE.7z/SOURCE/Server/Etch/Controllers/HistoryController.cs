﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading;
using System.Threading.Tasks;
using AMAT.R2R.Server.Base;
using AMAT.R2R.Server.Base.Constants;
using AMAT.R2R.Server.Base.Exceptions;
using AMAT.R2R.Server.Base.Extensions;
using AMAT.R2R.Server.Base.Service;
using AMAT.R2R.Server.Etch.Services;
using AMAT.R2R.Shared.Base.DTO;
using AMAT.R2R.Shared.Etch.DTO;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using DTO = AMAT.R2R.Shared.Etch.DTO;

namespace AMAT.R2R.Server.Etch.Controllers
{
#if RELEASE
    [Authorize]
#endif
#if DEBUG
    [EnableBodyRewind]
#endif
    [Route("api/[controller]")]
    [ApiController]
    public class HistoryController : R2RControllerBase
    {
        public IGlobalService GlobalService { get; }

        public HistoryController(IGlobalService globalService)
        {
            GlobalService = globalService;
        }

        // GET: api/History
        [HttpGet]
        public ActionResult<IEnumerable<TransactionHistory>> GetHistoryList([FromQuery] string module,
                                                                            [FromQuery] string tableName,
                                                                            [FromQuery] string contextValue,
                                                                            [FromQuery] string contextValue1)
        {
            return GlobalService.GetTransactionHistory(module, tableName, contextValue, contextValue1);
        }
    }
}
