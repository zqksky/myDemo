﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AMAT.R2R.Server.Base;
using AMAT.R2R.Server.Base.Constants;
using AMAT.R2R.Server.Base.Exceptions;
using AMAT.R2R.Server.Etch.Services;
using AMAT.R2R.Shared.Base.Constants;
using AMAT.R2R.Shared.Etch.DTO;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace AMAT.R2R.Server.Etch.Controllers
{
#if RELEASE
    [Authorize]
#endif
#if DEBUG
    [EnableBodyRewind]
#endif
    [Route("api/[controller]")]
    [ApiController]
    public class ContextController : ControllerBase
    {
        public IContextService ContextService { get; }

        public ContextController(IContextService contextService)
        {
            ContextService = contextService;
        }

        // GET: api/Context
        [HttpGet]
        public ActionResult<IEnumerable<Context>> GetContextList()
        {

            return ContextService.GetContextList(HttpContext.Request.Query);
        }

        // get count
        [HttpGet(QueryWords.ItemsCountEndpoint)]
        public ActionResult<int> GetContextCount()
        {
            return ContextService.GetContextCount(HttpContext.Request.Query);
        }

        // get unique value list.
        [HttpGet(QueryWords.ValueListEndpoint + "/{propertyName}")]
        public ActionResult<object[]> GetValueList(string propertyName)
        {
            return ContextService.GetContextValueList(HttpContext.Request.Query, propertyName);
        }


        // GET: api/Context/5
        [HttpGet("{contextId}")]
        public ActionResult<Context> GetContext(int contextId)
        {
            var context = ContextService.GetContext(contextId);
            if (context != null)
            {
                return context;
            }
            else
            {
                throw new ApiException(GeneralErrorCode.ResourceNotFound);
            }
        }


        [HttpPost]
        public ActionResult<Context> CreateContext(Context context)
        {
            var createdContext = ContextService.CreateContext(context);

            return CreatedAtAction(nameof(GetContext), new { contextId = createdContext.ContextId }, createdContext);
        }

        [HttpPut("{contextId}")]
        public IActionResult UpdateContext(Context context, int contextId)
        {
            if (contextId != context.ContextId)
            {
                throw new ApiException(GeneralErrorCode.IdMismatch);
            }

            ContextService.UpdateContext(context);

            return NoContent();
        }

        [HttpDelete("{contextId}")]
        public IActionResult DeleteContext(int contextId)
        {
            ContextService.DeleteContext(contextId);

            return NoContent();
        }

        [HttpGet("{contextId}/input")]
        public ActionResult<ContextInput> GetContextInput(int contextId)
        {
            return ContextService.GetContextInput(contextId);
        }

        [HttpPost("{contextId}/input")]
        public ActionResult<ContextInput> CreateContextInput(ContextInput contextInput, int contextId)
        {
            var createdContextInput = ContextService.CreateContextInput(contextInput);

            return CreatedAtAction(nameof(GetContextInput),
                new
                {
                    contextId = createdContextInput.ContextId
                },
                createdContextInput);
        }

        [HttpPut("{contextId}/input")]
        public IActionResult UpdateContextInput(ContextInput contextInput, int contextId)
        {
            if (contextInput.ContextId != contextId)
            {
                throw new ApiException(GeneralErrorCode.IdMismatch);
            }

            ContextService.UpdateContextInput(contextInput);

            return NoContent();
        }

        [HttpGet("{contextId}/constants")]
        public ActionResult<ContextConstants> GetContextConstants(int contextId)
        {
            return ContextService.GetContextConstants(contextId);
        }

        [HttpPost("{contextId}/constants")]
        public ActionResult<ContextConstants> CreateContextConstants(ContextConstants contextConstants, int contextId)
        {
            var createdContextConstants = ContextService.CreateContextConstants(contextConstants);

            return CreatedAtAction(nameof(GetContextConstants),
            new
            {
                contextId = createdContextConstants.ContextId
            },
                createdContextConstants);
        }

        [HttpPut("{contextId}/constants")]
        public IActionResult UpdateContextConstants(ContextConstants contextConstants, int contextId)
        {
            if (contextConstants.ContextId != contextId)
            {
                throw new ApiException(GeneralErrorCode.IdMismatch);
            }

            ContextService.UpdateContextConstants(contextConstants);

            return NoContent();
        }
    }
}
