﻿using System;
using System.Runtime.Serialization;
using AMAT.R2R.Server.Base.Constants;
using AMAT.R2R.Server.Base.Exceptions;

namespace AMAT.R2R.Server.Etch.Exceptions
{
    public enum ErrorCode
    {
        // process related errors
        InvalidProcessKey = 301,
        CannotDisableProcessWhenUserdByContext = 302,
        NoneOutputSettingFound = 303,
        OutputSettingExisted = 304,
        NotSupportMultiOutputWithZonalOn = 305,
        OutputSettingShouldLessThanThree = 306,
        ValidateFail = 307,
        FeedforwardSettingExisted = 104,
        FeedforwardSettingShouldLessThanThree = 316,
        NothingIsChanged = 317,

        InvalidProcessId = 318,
        InvalidContextId = 319,
        ResourceNotExisted = 320,
        InputParameterExisted = 321,

        NoneStatesFound = 330,

        ThreadResetFail=350,
    }

    public class EtchException : ErrorCodeException
    {
        public EtchException(ErrorCode errorCode) : base((int)errorCode, errorCode.ToString())
        {
        }

        public EtchException(ErrorCode errorCode, string message) : base((int)errorCode, message)
        {
        }
    }
}
