﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Runtime.CompilerServices;
using System.Security.Policy;
using Microsoft.EntityFrameworkCore;

namespace AMAT.R2R.Server.Etch.Entities
{
    [Table("R2R_DE_AUTO_PREMETROLINEAVG")]
    public class PreMetrologyLineAvg
    {

        [Column("FAB")]
        public string Fab { get; set; }


        [Column("PRODUCTID")]
        public string ProductId { get; set; }


        [Column("STAGE")]
        public string Stage { get; set; }


        [Column("RECIPE")]
        public string Recipe { get; set; }


        [Column("STEPNAME")]
        public string StepName { get; set; }


        [Column("STEPNUMBER")]
        public string StepNumber { get; set; }


        [Column("TOOL")]
        public string Tool { get; set; }


        [Column("CHAMBER")]
        public string Chamber { get; set; }


        [Column("CONTEXTGROUP")]
        public string ContextGroup { get; set; }


        [Column("FFDISB")]
        public double/*22,*/ FfDisb { get; set; }


        [Column("LASTUPDATETIME")]
        public DateTime LastUpdateTime { get; set; }


        [Column("PREMETROLINEAVG")]
        public double/*22,*/ PreMetroLineAvg { get; set; }
    }
}
