﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Runtime.CompilerServices;
using System.Security.Policy;
using Microsoft.EntityFrameworkCore;


namespace AMAT.R2R.Server.Etch.Entities
{
    [Table("R2R_DE_CHAMBER_OFFSET")]
    public class ChamberOffset
    {

        [Column("TOOLID")]
        public string ToolId { get; set; }

        [Column("CHAMBERID")]
        public string ChamberId { get; set; }

        [Column("PARAMETERNAME")]
        public string ParameterName { get; set; }

        [Column("OFFSET")]
        public decimal Offset { get; set; }

        [Column("LAST_MODIFY_DATE")]
        public DateTime LastModifyDate { get; set; }

        [Column("LAST_MODIFY_BY")]
        public string LastModifyBy { get; set; }


    }
}
