﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Security.Policy;
using Microsoft.EntityFrameworkCore;

namespace AMAT.R2R.Server.Etch.Entities
{
    [Table("R2R_DE_PROCESS")]
    public class Process
    {
        [Column("FAB")]
        public string Fab { get; set; }

        [Column("PRODUCTID")]
        public string ProductId { get; set; }

        [Column("RECIPE")]
        public string Recipe { get; set; }

        [Column("STAGE")]
        public string Stage { get; set; }

        [Column("STEPNAME")]
        public string StepName { get; set; }

        [Column("STEPNUMBER")]
        public string StepNumber { get; set; }

        [Column("ENABLED")]
        public int/*1,0*/  ProcessEnabled { get; set; }

        [Column("CONTEXTGROUP_ENABLED")]
        public int/*1,0*/ OptContextGroupEnabled { get; set; }

        [Column("LAST_MODIFY_DATE")]
        public DateTime LastModifiedTime { get; set; }

        [Column("LAST_MODIFY_BY")]
        public string LastModifiedBy { get; set; }

        [Column("PROCESS_ID")]
        public int ProcessId { get; set; }
    }
}
