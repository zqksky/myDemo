﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Runtime.CompilerServices;
using System.Security.Policy;
using Microsoft.EntityFrameworkCore;

namespace AMAT.R2R.Server.Etch.Entities
{
    [Table("R2R_DE_CONFIG_INPUTDEFINITION")]
    public class InputDefinition
    {

        [Column("FAB")]
        public string Fab { get; set; }

        [Column("PRODUCTID")]
        public string ProductId { get; set; }

        [Column("STAGE")]
        public string Stage { get; set; }

        [Column("RECIPE")]
        public string Recipe { get; set; }

        [Column("STEPNAME")]
        public string StepName { get; set; }

        [Column("STEPNUMBER")]
        public string StepNumber { get; set; }

        [Column("TOOL")]
        public string Tool { get; set; }

        [Column("CHAMBER")]
        public string Chamber { get; set; }

        [Column("CONTEXTGROUP")]
        public string ContextGroup { get; set; }

        [Column("INPUTINDEX")]
        public int/*2,0*/ InputIndex { get; set; }

        [Column("INPUTDEADBAND")]
        public double/*,*/ InputDeadband { get; set; }

        [Column("INPUTMAX")]
        public double/*,*/ InputMax { get; set; }

        [Column("INPUTMIN")]
        public double/*,*/ InputMin { get; set; }

        [Column("INPUTPARAMETERNAME")]
        public string InputParameterName { get; set; }

        [Column("INPUTPRECISION")]
        public int/*38,0*/ InputPrecision { get; set; }

        [Column("RECVSUSEDLIMIT")]
        public double/*,*/ RecVsUsedLimit { get; set; }

        [Column("DEFAULTRECSETTING")]
        public double/*,*/ DefaultRecSetting { get; set; }

        [Column("USEDCONVERSION")]
        public double/*,*/ UsedConversion { get; set; }

        [Column("SLAVEINPUTPARAMETERNAMES")]
        public string SlaveInputParameterNames { get; set; }

        [Column("SLAVEINPUTPARAMETEROFFSET")]
        public string SlaveInputParameterOffset { get; set; }

        [Column("SLAVEINPUTPARAMETERCOEFFICIENT")]
        public string SlaveInputParameterCoefficient { get; set; }

        [Column("CONTEXT_ID")]
        public int ContextId { get; set; }

        [Column("UNIT")]
        public string Unit { get; set; }

    }
}
