﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Runtime.CompilerServices;
using System.Security.Policy;
using Microsoft.EntityFrameworkCore;

namespace AMAT.R2R.Server.Etch.Entities
{
    [Table("R2R_DE_CONFIG_PROCESSSETTING")]
    public class ProcessSetting
    {

        [Column("FAB")]
        public string Fab { get; set; }

        [Column("PRODUCTID")]
        public string ProductId { get; set; }

        [Column("STAGE")]
        public string Stage { get; set; }

        [Column("RECIPE")]
        public string Recipe { get; set; }

        [Column("STEPNAME")]
        public string StepName { get; set; }

        [Column("STEPNUMBER")]
        public string StepNumber { get; set; }

        [Column("TOOL")]
        public string Tool { get; set; }

        [Column("CHAMBER")]
        public string Chamber { get; set; }

        [Column("CONTEXTGROUP")]
        public string ContextGroup { get; set; }

        [Column("FFNEGDELTA")]
        public string FfNegDelta { get; set; }

        [Column("FBPOSDELTA")]
        public string FbPosDelta { get; set; }

        [Column("FBNEGDELTA")]
        public string FbNegDelta { get; set; }

        [Column("FFPOSDELTA")]
        public string FfPosDelta { get; set; }

        [Column("MODELSLOPE01_CSV")]
        public string ModelSlope01CSV { get; set; }

        [Column("MODELSLOPE02_CSV")]
        public string ModelSlope02CSV { get; set; }

        [Column("MODELSLOPE03_CSV")]
        public string ModelSlope03CSV { get; set; }

        [Column("MODELSLOPE04_CSV")]
        public string ModelSlope04CSV { get; set; }

        [Column("MODELSLOPE05_CSV")]
        public string ModelSlope05CSV { get; set; }

        [Column("MODELSLOPE06_CSV")]
        public string ModelSlope06CSV { get; set; }

        [Column("MODELSLOPE07_CSV")]
        public string ModelSlope07CSV { get; set; }

        [Column("MODELSLOPE08_CSV")]
        public string ModelSlope08CSV { get; set; }

        [Column("MODELSLOPE09_CSV")]
        public string ModelSlope09CSV { get; set; }

        [Column("MODELSLOPE10_CSV")]
        public string ModelSlope10CSV { get; set; }

        [Column("FFCOEFFICIENT")]
        public string FfCoefficient { get; set; }

        [Column("SLOT1COMPENSATION")]
        public string Slot1Compensation { get; set; }

        [Column("SLOT2COMPENSATION")]
        public string Slot2Compensation { get; set; }

        [Column("CHAMBERCALCULATIONINPROGRESS")]
        public int /*1,0*/ ChamberCalculationInProgress { get; set; }

        [Column("QS_STATEEST")]
        public string QsStateEst { get; set; }

        [Column("RS_STATEEST")]
        public string RsStateEst { get; set; }

        [Column("CONTROLLERQ")]
        public string ControllerQ { get; set; }

        [Column("CONTROLLERR")]
        public string ControllerR { get; set; }

        [Column("CONTEXT_ID")]
        public int ContextId { get; set; }
    }
}
