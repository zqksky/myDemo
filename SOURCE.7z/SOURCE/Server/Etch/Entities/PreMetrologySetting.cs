﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Runtime.CompilerServices;
using System.Security.Policy;
using Microsoft.EntityFrameworkCore;

namespace AMAT.R2R.Server.Etch.Entities
{
    [Table("R2R_DE_CONFIG_PREMETROSETTING")]
    public class PreMetrologySetting
    {

        [Column("FAB")]
        public string Fab { get; set; }

        [Column("PRODUCTID")]
        public string ProductId { get; set; }

        [Column("RECIPE")]
        public string Recipe { get; set; }

        [Column("STAGE")]
        public string Stage { get; set; }

        [Column("STEPNAME")]
        public string StepName { get; set; }

        [Column("STEPNUMBER")]
        public string StepNumber { get; set; }

        [Column("METRO_FAB")]
        public string MetroFab { get; set; }

        [Column("METRO_STEPNAME")]
        public string MetroStepName { get; set; }

        [Column("METRO_STEPNUMBER")]
        public string MetroStepNumber { get; set; }

        [Column("METRO_RECIPE")]
        public string MetroRecipe { get; set; }

        [Column("METRO_STAGE")]
        public string MetroStage { get; set; }

        [Column("OUTPUTINDEX")]
        public int/*3,0*/ OutputIndex { get; set; }

        [Column("DATAQUALITYTHRESHOLD")]
        public decimal/*,*/ DataQualityThreshold { get; set; }

        [Column("LOWERISBETTERFILTER")]
        public int /*1,0*/ LowerIsBetterFilter { get; set; }

        [Column("LOWERLIMITS")]
        public decimal/*,*/ LowerLimit { get; set; }

        [Column("MEASDATAITEMNAME")]
        public string MeasDataItemName { get; set; }

        [Column("MINPERCENTREMAINING")]
        public decimal/*,*/ MinPercentRemaining { get; set; }

        [Column("NOOFSITESPERWAFER")]
        public decimal/*,*/ NoOfSitesPerWafer { get; set; }

        [Column("QUALITYDATAITEMNAME")]
        public string QualityDataItemName { get; set; }

        [Column("RANGETHRESHOLD")]
        public decimal/*,*/ RangeThreshold { get; set; }

        [Column("STDDEVTHRESHOLD")]
        public decimal/*,*/ StdDevThreshold { get; set; }

        [Column("TARGETS")]
        public decimal/*,*/ Target { get; set; }

        [Column("UPPERLIMITS")]
        public decimal/*,*/ UpperLimit { get; set; }

        [Column("USEOOLRANGE")]
        public int /*1,0*/ UseOOLRange { get; set; }

        [Column("USEOOLSTDDEV")]
        public int /*1,0*/ UseOOLStdDev { get; set; }

        [Column("USEOOLPREMETRO")]
        public int /*1,0*/ UseOOLPreMetro { get; set; }

        [Column("LAMBDA")]
        public decimal/*,*/ Lambda { get; set; }

        [Column("OFFSETPERSLOTID")]
        public decimal/*,*/ OffsetPerSlotId { get; set; }


        [Column("UNIT")]
        public string /*1,0*/ Unit { get; set; }

        [Column("PROCESS_ID")]
        public int ProcessId { get; set; }

        [Column("PREMETRO_ID")]
        public int PreMetroId { get; set; }
    }
}

