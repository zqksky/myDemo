﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Security.Policy;
using Microsoft.EntityFrameworkCore;

namespace AMAT.R2R.Server.Etch.Entities
{
    [Table("R2R_DE_AUTO_STATES_HIST")]
    public class AutoStatesHist
    {
        [Column("TOOL")]
        public string Tool { get; set; }

        [Column("PRODUCTID")]
        public string ProductId { get; set; }

        [Column("STAGE")]
        public string Stage { get; set; }

        [Column("RECIPE")]
        public string Recpe { get; set; }

        [Column("STEPNUMBER")]
        public string StepNumber { get; set; }

        [Column("STEPNAME")]
        public string SteName { get; set; }

        [Column("FAB")]
        public string Fab { get; set; }

        [Column("CONTEXTGROUP")]
        public string ContextGroup { get; set; }

        [Column("CHAMBER")]
        public string Chamberb { get; set; }

        [Column("BATCHID")]
        public string BatchId { get; set; }

        [Column("LOTID")]
        public string LotId { get; set; }

        [Column("TXID")]
        public string TxId { get; set; }

        [Column("COUNTER_CONSECUTIVE_MAXADJUST")]
        public string CounterConsecutiveMaxAdjust { get; set; }

        [Column("LASTMODELVALUESROW01")]
        public string LastModelValuesRow1 { get; set; }

        [Column("LASTMODELVALUESROW02")]
        public string LastModelValuesRow2 { get; set; }

        [Column("LASTMODELVALUESROW03")]
        public string LastModelValuesRow3 { get; set; }

        [Column("LASTMODELVALUESROW04")]
        public string LastModelValuesRow4 { get; set; }

        [Column("LASTMODELVALUESROW05")]
        public string LastModelValuesRow5 { get; set; }

        [Column("LASTMODELVALUESROW06")]
        public string LastModelValuesRow6 { get; set; }

        [Column("LASTMODELVALUESROW07")]
        public string LastModelValuesRow7 { get; set; }

        [Column("LASTMODELVALUESROW08")]
        public string LastModelValuesRow8 { get; set; }

        [Column("LASTMODELVALUESROW09")]
        public string LastModelValuesRow9 { get; set; }

        [Column("LASTMODELVALUESROW10")]
        public string LastModelValuesRow10 { get; set; }

        [Column("LASTPROCESSINPUTVALUES")]
        public string LastProcessInputValues { get; set; }

        [Column("LASTPROCESSTARGETVALUES")]
        public string LastProcessTargetValues { get; set; }

        [Column("LASTRESETTIME")]
        public DateTime? LastResetTime { get; set; }

        [Column("LASTSTAGETIME")]
        public DateTime? LastStageTime { get; set; }

        [Column("LASTSTATEUPDATETIME")]
        public DateTime? LastStateUpdateTime { get; set; }

        [Column("LOTLISTSINCELASTVALIDMETRO")]
        public string LotListSinceLastValidMetro { get; set; }

        [Column("LOTLIST_CONSECUTIVE_GOF")]
        public string LotlistConsecutiveGof { get; set; }

        [Column("LOTLIST_CONSECUTIVE_OOS")]
        public string LotlistConsecutiveOos { get; set; }

        [Column("PILOTRUNON")]
        public string PilotRunOn { get; set; }

        [Column("PILOTRUNONTIME")]
        public DateTime? PilotRunOnTime { get; set; }

        [Column("THREADSTATUS")]
        public string ThreadStatus { get; set; }

        [Column("SPECIFYPILOT")]
        public string SpecifyLot { get; set; }

        [Column("STATE01")]
        public double State01 { get; set; }

        [Column("STATE02")]
        public double State02 { get; set; }

        [Column("STATE03")]
        public double State03 { get; set; }

        [Column("STATE04")]
        public double State04 { get; set; }

        [Column("STATE05")]
        public double State05 { get; set; }

        [Column("STATE06")]
        public double State06 { get; set; }

        [Column("STATE07")]
        public double State07 { get; set; }

        [Column("STATE08")]
        public double State08 { get; set; }

        [Column("STATE09")]
        public double State09 { get; set; }

        [Column("STATE10")]
        public double State10 { get; set; }

        [Column("STATE11")]
        public double State11 { get; set; }

        [Column("STATE12")]
        public double State12 { get; set; }

        [Column("STATE13")]
        public double State13 { get; set; }

        [Column("STATE14")]
        public double State14 { get; set; }

        [Column("STATE15")]
        public double State15 { get; set; }

        [Column("STATE16")]
        public double State16 { get; set; }

        [Column("STATE17")]
        public double State17 { get; set; }

        [Column("STATE18")]
        public double State18 { get; set; }

        [Column("STATE19")]
        public double State19 { get; set; }

        [Column("STATE20")]
        public double State20 { get; set; }

        [Column("UPDATE_TIMESTAMP")]
        public DateTime UpdateTimestamp { get; set; }

        [Column("LASTSTAGELOT")]
        public string LastStageLot { get; set; }
        [Column("CONTEXT_ID")]
        public int ContextId { get; set; }

        [Column("REMARK")]
        public string Remark { get; set; }

        [Column("ISVALID")]
        public int IsValid { get; set; }

        [Column("DEFAULTRECSETTINGS")]
        public string DefaultRecSettings { get; set; }
    }
}
