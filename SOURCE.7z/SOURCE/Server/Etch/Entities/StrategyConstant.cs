﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Runtime.CompilerServices;
using System.Security.Policy;
using Microsoft.EntityFrameworkCore;

namespace AMAT.R2R.Server.Etch.Entities
{
    [Table("R2R_DE_CONFIG_STRATEGYCONSTANT")]
    public class StrategyConstant
    {

        [Column("FAB")]
        public string Fab { get; set; }

        [Column("PRODUCTID")]
        public string ProductId { get; set; }

        [Column("STAGE")]
        public string Stage { get; set; }

        [Column("RECIPE")]
        public string Recipe { get; set; }

        [Column("STEPNAME")]
        public string StepName { get; set; }

        [Column("STEPNUMBER")]
        public string StepNumber { get; set; }

        [Column("TOOL")]
        public string Tool { get; set; }

        [Column("CHAMBER")]
        public string Chamber { get; set; }

        [Column("CONTEXTGROUP")]
        public string ContextGroup { get; set; }

        [Column("MAXTIMELASTSTATEESTDAYS")]
        public double/*3,0*/ MaxTimeLastStateEstDays { get; set; }

        //[Column("FBNEGDELTA")] 
        //public string FbNegDelta { get; set; }

        //[Column("FFPOSDELTA")] 
        //public string FfPosDelta { get; set; }

        [Column("ALLOWMISSINGPREMETRO")]
        public int /*1,0*/ AllowMissingPreMetro { get; set; }

        [Column("LOTHOLDMISSINGPREMETRO")]
        public int /*1,0*/ LotHoldMissingPreMetro { get; set; }

        [Column("LOTHOLDPREDICTIONOOL")]
        public int /*1,0*/ LotHoldPreDictionOOL { get; set; }

        [Column("LOTHOLDRECOMMENDEDOOL")]
        public int /*1,0*/ LotHoldRecommendedOOL { get; set; }

        [Column("LIMITLOTSWITHOUTMETRO")]
        public int/*2,0*/ LimitLotsWithoutMetro { get; set; }

        [Column("R2RMODE")]
        public string R2RMode { get; set; }

        [Column("INPUTSIZE")]
        public int/*2,0*/ InputSize { get; set; }

        [Column("OUTPUTSIZE")]
        public int/*2,0*/ OutputSize { get; set; }

        [Column("LIMITNOCONSECUTIVEMAXADJUST")]
        public int/*3,0*/ LimitNoConsecutiveMaxAdjust { get; set; }

        [Column("HYDRAFLAG")]
        public int /*1,0*/ HydraFlag { get; set; }

        [Column("TOTALPRESTEPNUMBER")]
        public int/*2,0*/ TotalPreStepNumber { get; set; }

        [Column("TOTALPOSTSTEPNUMBER")]
        public int/*2,0*/ TotalPostStepNumber { get; set; }

        [Column("HYDRAUSEWAFERMEAN")]
        public int /*1,0*/ HydraUseWaferMean { get; set; }

        [Column("HYDRAUSEZONEMEAN")]
        public int /*1,0*/ HydraUseZoneMean { get; set; }

        [Column("HYDRAALLOWMISSINGDATANUMBER")]
        public int/*10,*/ HydraAllowMissingDataNumber { get; set; }

        [Column("HYDRAALLOWMISSINGDATA")]
        public int /*1,0*/ HydraAllowingData { get; set; }

        [Column("LOTSTAGEWAFERUSECALCPRE")]
        public int /*1,0*/ LotStageWaferUseCalcPre { get; set; }

        [Column("HYDRAMANUALDATAENTRY")]
        public int /*1,0*/ HydraManualDataEntry { get; set; }

        [Column("LOTSTAGEWAFERUSECALCOFFSET")]
        public double/*,*/ LotStageWaferUseCalcOffset { get; set; }

        [Column("USETARGET")]
        public int /*1,0*/ UseTarget { get; set; }


        [Column("PRELINEAVG_EXPIRED_DAY")]
        public double PreLineAvgExpiredDay { get; set; }


        [Column("CONTEXT_ID")]
        public int ContextId { get; set; }

        [Column("PREMETROLOGY_EXPIRED_DAY")]
        public double PreMetrologyExpiredDay { get; set; }

        [Column("MAX_CONSECUTIVE_OOS")]
        public int MaxConsecutiveOos { get; set; }

        [Column("MAX_CONSECUTIVE_GOF")]
        public int MaxConsecutiveGof { get; set; }

    }
}
