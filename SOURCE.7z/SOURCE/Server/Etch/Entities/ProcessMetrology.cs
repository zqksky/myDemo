﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Security.Policy;
using Microsoft.EntityFrameworkCore;

namespace AMAT.R2R.Server.Etch.Entities
{
    [Table("R2R_DE_PROCESS_METROLOGY")]
    public class ProcessMetrology
    {
        [Column("FAB")]
        public string Fab { get; set; }

        [Column("PRODUCTID")]
        public string ProductId { get; set; }

        [Column("RECIPE")]
        public string Recipe { get; set; }

        [Column("STAGE")]
        public string Stage { get; set; }

        [Column("STEPNAME")]
        public string StepName { get; set; }

        [Column("STEPNUMBER")]
        public string StepNumber { get; set; }

        [Column("METRO_FAB")]
        public string MetroFab { get; set; }

        [Column("METRO_STEPNAME")]
        public string MetroStepName { get; set; }

        [Column("METRO_STEPNUMBER")]
        public string MetroStepNumber { get; set; }

        [Column("METRO_RECIPE")]
        public string MetroRecipe { get; set; }

        [Column("METRO_STAGE")]
        public string MetroStage { get; set; }

        [Column("METRO_TYPE")]
        public string MetroType { get; set; }

        [Column("PROCESS_ID")]
        public int ProcessId { get; set; }

    }
}
