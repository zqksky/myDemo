﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Security.Policy;
using Microsoft.EntityFrameworkCore;

namespace AMAT.R2R.Server.Etch.Entities
{
    [Table("R2R_DE_HZN_MATERIALIZED")]
    public class HznMaterialized
    {
        [Column("HZN_KEY")]
        public string HznKey { get; set; }

        [Column("CALC_TIMESTAMP")]
        public DateTime? CalcTimesStamp { get; set; }

        [Column("USED_TIMESTAMP")]
        public DateTime? UsedTimeStamp { get; set; }

        [Column("POST_TIMESTAMP")]
        public DateTime? PostTimeStamp { get; set; }

        [Column("TOOL")]
        public string Tool { get; set; }

        [Column("PRODUCTID")]
        public string ProductId { get; set; }

        [Column("STAGE")]
        public string Stage { get; set; }

        [Column("RECIPE")]
        public string Recipe { get; set; }

        [Column("STEPNUMBER")]
        public string StepNumber { get; set; }

        [Column("STEPNAME")]
        public string StepName { get; set; }

        [Column("FAB")]
        public string Fab { get; set; }

        [Column("CONTEXTGROUP")]
        public string ContextGroup { get; set; }

        [Column("CHAMBER")]
        public string Chamber { get; set; }

        [Column("R2RMODE")]
        public string R2RMode { get; set; }

        [Column("CONTEXT_ID")]
        public int ContextId { get; set; }

        [Column("LOTID")]
        public string LotId { get; set; }

        [Column("WAFERSCRIBE")]
        public string WaferScribe { get; set; }

        [Column("WAFER_LIST")]
        public string WaferList { get; set; }

        [Column("PRE_METROLOGY")]
        public string PreMetrology { get; set; }

        [Column("FFDISB")]
        public string FFDisb { get; set; }

        [Column("CHAMBEROFFSET")]
        public string ChamberOffset { get; set; }

        [Column("DEFAULTRECSETTINGS")]
        public string DefaultRecSettings { get; set; }

        [Column("RECSETTINGS")]
        public string RecipeSettings { get; set; }

        [Column("FINALRECSETTINGS")]
        public string FinalRecSettings { get; set; }

        [Column("POST_METROLOGY")]
        public string PostMetrology { get; set; }

        [Column("NEWRECSETTINGS_FB")]
        public string NewRecSettingsFb { get; set; }

        [Column("STATES")]
        public string States { get; set; }

        [Column("MODIFIEDBY")]
        public string ModifiedBy { get; set; }

        [Column("FEEDBACK")]
        public string Feedback { get; set; }

        [Column("REMARK")]
        public string Remark { get; set; }

        [Column("SPECIFYLOT")]
        public string SpecifyLot { get; set; }

        [Column("PILOTFLAG")]
        public string PilotFlag { get; set; }

        [Column("RUNCARDID")]
        public string RunCardId { get; set; }

        [Column("SPLITID")]
        public string SplitId { get; set; }

        [Column("INPUTPARAMETER")]
        public string InputParameter { get; set; }
      
        [Column("PREPARAMETER")]
        public string PreParameter { get; set; }

        [Column("POSTPARAMETER")]
        public string PostParameter { get; set; }

        [Column("USEDSETTINGS")]
        public string UsedSettings { get; set; }

        [Column("MODELINGTICK")]
        public string ModelingTick { get; set; }

        [Column("TXID")]
        public string TxId { get; set; }

    }
    
}


