﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Runtime.CompilerServices;
using System.Security.Policy;
using Microsoft.EntityFrameworkCore;


namespace AMAT.R2R.Server.Etch.Entities
{
    [Table("R2R_DE_AUTO_TRACKING")]
    public class ParameterTracking
    {

        [Column("TOOL")]
        public string Tool { get; set; }

        [Column("PRODUCTID")]
        public string ProductId { get; set; }

        [Column("STAGE")]
        public string Stage { get; set; }

        [Column("RECIPE")]
        public string Recipe { get; set; }

        [Column("STEPNUMBER")]
        public string StepNumber { get; set; }

        [Column("STEPNAME")]
        public string StepName { get; set; }

        [Column("FAB")]
        public string Fab { get; set; }

        [Column("CONTEXTGROUP")]
        public string ContextGroup { get; set; }

        [Column("CHAMBER")]
        public string Chamber { get; set; }

        [Column("LASTFFCOEFFICIENT")]
        public string LastFFCofficient { get; set; }

        [Column("LASTKNOBPARAMETERNAMES")]
        public string LstKnobParameterNames { get; set; }

        [Column("LASTLOTLEVELCONTROL")]
        public string LastLotLevelControl { get; set; }

        [Column("LASTMEASDATAITEMNAME")]
        public string LastMeasDataItemName { get; set; }

        [Column("LASTMODELSLOPE01")]
        public string LastModelSlope01 { get; set; }

        [Column("LASTMODELSLOPE02")]
        public string LastModelSlope02 { get; set; }

        [Column("LASTMODELSLOPE03")]
        public string LastModelSlope03 { get; set; }

        [Column("LASTMODELSLOPE04")]
        public string LastModelSlope04 { get; set; }

        [Column("LASTMODELSLOPE05")]
        public string LastModelSlope05 { get; set; }

        [Column("LASTMODELSLOPE06")]
        public string LastModelSlope06 { get; set; }

        [Column("LASTMODELSLOPE07")]
        public string LastModelSlope07 { get; set; }

        [Column("LASTMODELSLOPE08")]
        public string LastModelSlope08 { get; set; }

        [Column("LASTMODELSLOPE09")]
        public string LastModelSlope09 { get; set; }

        [Column("LASTMODELSLOPE10")]
        public string LastModelSlope10 { get; set; }

        [Column("LASTR2RCONTROLTYPE")]
        public string LastR2RControlType { get; set; }

        [Column("LASTTARGETS")]
        public string LastTargets { get; set; }

        [Column("LASTUSEDCONVERSION")]
        public string LastUdedConversion { get; set; }

        [Column("LASTZONALDEFINITIONOUTPUT01")]
        public string LastZonalDefinitionOutput01 { get; set; }

        [Column("LASTZONALDEFINITIONOUTPUT02")]
        public string LastZonalDefinitionOutput02 { get; set; }

        [Column("LASTZONALDEFINITIONOUTPUT03")]
        public string LastZonalDefinitionOutput03 { get; set; }

        [Column("LASTZONALDEFINITIONOUTPUT04")]
        public string LastZonalDefinitionOutput04 { get; set; }

        [Column("LASTZONALDEFINITIONOUTPUT05")]
        public string LastZonalDefinitionOutput05 { get; set; }

        [Column("LASTZONALDEFINITIONOUTPUT06")]
        public string LastZonalDefinitionOutput06 { get; set; }

        [Column("LASTZONALDEFINITIONOUTPUT07")]
        public string LastZonalDefinitionOutput07 { get; set; }

        [Column("LASTZONALDEFINITIONOUTPUT08")]
        public string LastZonalDefinitionOutput08 { get; set; }

        [Column("LASTZONALDEFINITIONOUTPUT09")]
        public string LastZonalDefinitionOutput09 { get; set; }

        [Column("LASTZONALDEFINITIONOUTPUT10")]
        public string LastZonalDefinitionOutput10 { get; set; }

        [Column("UPDATE_TIMESTAMP")]
        public DateTime UpdateTimeStamp { get; set; }
    }
}
