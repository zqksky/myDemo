﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Runtime.CompilerServices;
using System.Security.Policy;
using Microsoft.EntityFrameworkCore;


namespace AMAT.R2R.Server.Etch.Entities
{
    [Table("R2R_DE_SPECIAL_JOB_PARAMETER")]
    public class SpecialJobParameter
    {

        [Column("JOB_ID")]
        public string JobId { get; set; }

        [Column("PARAMETER_SEQ")]
        public int/*6,0*/ ParameterSeq { get; set; }

        [Column("PARAMETER_NAME")]
        public string ParameterName { get; set; }

        [Column("PARAMETER_VALUE")]
        public string ParameterValue { get; set; }


    }
}
