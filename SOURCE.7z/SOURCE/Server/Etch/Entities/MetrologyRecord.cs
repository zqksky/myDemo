﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Security.Policy;
using Microsoft.EntityFrameworkCore;

namespace AMAT.R2R.Server.Etch.Entities
{
    [Table("R2R_DE_METROLOGYRECORD")]
    public class MetrologyRecord
    {
        [Column("PROCESSSTEPNUM")]
        public string ProcessStepNum { get; set; }
        [Column("LOTID")]
        public string LotId { get; set; }

        [Column("WAFERID")]
        public string WaferId { get; set; }

        [Column("MEASTYPE")]
        public string MeasType { get; set; }

        [Column("MEASDATAITEMNAME")]
        public string MeasDataItemName { get; set; }

        [Column("METROSTEPNUM")]
        public string MetroSteNum { get; set; }

        [Column("METROTOOLID")]
        public string MetroToolId { get; set; }

        [Column("MEASORDERS")]
        public string MeasOrders { get; set; }

        [Column("MEASVALUES")]
        public string MeasValues { get; set; }

        [Column("DATASOURCE")]
        public string DataSource { get; set; }

        [Column("MEASTIME")]
        public string MeasTime { get; set; }

        [Column("USEDFORFB")]
        public string UsedForFb { get; set; }

        [Column("MEASGOFS")]
        public string MeasGofs { get; set; }

        [Column("FAB")]
        public string Fab { get; set; }

        [Column("MEASXCOORD")]
        public string MeasXCoord { get; set; }

        [Column("MEASYCOORD")]
        public string MeasYCoord { get; set; }

        [Column("MEASINDEX")]
        public string MeasIndex { get; set; }

        [Column("METROSTEPNAME")]
        public string MetroStepName { get; set; }

        [Column("METROSTAGE")]
        public string MetroStage { get; set; }

        [Column("METRORECIPE")]
        public string MetroRecipe { get; set; }

        [Column("MEASNAME")]
        public string MeasName { get; set; }

        [Column("TXID")]
        public string TxId { get; set; }

        [Column("DCOLL_TIME")]
        public DateTime DcollTime { get; set; }

        [Column("MEASOOSS")]
        public string MeasOoss { get; set; }

    }
}
