﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Runtime.CompilerServices;
using System.Security.Policy;
using Microsoft.EntityFrameworkCore;

namespace AMAT.R2R.Server.Etch.Entities
{
    [Table("R2R_DE_SPECIAL_JOB")]
    public class SpecialJob
    {

        [Column("JOB_ID")]
        public string JobId { get; set; }

        [Column("RUNCARDID")]
        public string RunCardId { get; set; }

        [Column("SPLITID")]
        public string SplitId { get; set; }

        [Column("LOTID")]
        public string LotId { get; set; }


        [Column("FAB")]
        public string Fab { get; set; }

        [Column("PRODUCTID")]
        public string ProductId { get; set; }

        [Column("STAGE")]
        public string Stage { get; set; }

        [Column("RECIPE")]
        public string Recipe { get; set; }

        [Column("STEPNAME")]
        public string StepName { get; set; }


        [Column("STEPNUMBER")]
        public string StepNumber { get; set; }


        [Column("TOOL")]
        public string Tool { get; set; }

        [Column("CHAMBER")]
        public string Chamber { get; set; }

        [Column("CONTEXTGROUP")]
        public string ContextGroup { get; set; }


        [Column("JOB_COMPLETED")]
        public int /*1,0*/ JobCompleted { get; set; }

        [Column("USERID")]
        public string UserId { get; set; }

        [Column("CREATE_TIME")]
        public DateTime CreateTime { get; set; }

        [Column("USED_TIME")]
        public DateTime? UsedTime { get; set; }

        [Column("CONTEXT_ID")]
        public int ContextId { get; set; }

        [Column("IS_VALID")]
        public int /*1,0*/ IsValid { get; set; }

        [Column("LAST_MODIFY_DATE")]
        public DateTime LastModifiedTime { get; set; }

        [Column("LAST_MODIFY_BY")]
        public string LastModifiedBy { get; set; }
    }
}
