﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Runtime.CompilerServices;
using System.Security.Policy;
using Microsoft.EntityFrameworkCore;

namespace AMAT.R2R.Server.Etch.Entities
{
    [Table("R2R_DE_ADV_LINEARCONSTRAINT")]
    public class LinearConstraint
    {

        [Column("FAB")]
        public string Fab { get; set; }

        [Column("PRODUCTID")]
        public string ProductId { get; set; }

        [Column("STAGE")]
        public string Stage { get; set; }

        [Column("RECIPE")]
        public string Recipe { get; set; }

        [Column("STEPNAME")]
        public string StepName { get; set; }

        [Column("STEPNUMBER")]
        public string StepNumber { get; set; }

        [Column("TOOL")]
        public string Tool { get; set; }

        [Column("CHAMBER")]
        public string Chamber { get; set; }

        [Column("CONTEXTGROUP")]
        public string ContextGroup { get; set; }

        [Column("LINEARCONSTRAINT01_CSV")]
        public string LinearConstraint01CSV { get; set; }

        [Column("LINEARCONSTRAINT02_CSV")]
        public string LinearConstraint02CSV { get; set; }

        [Column("MIN_LINEAR_CSV")]
        public string MinLinearCSV { get; set; }

        [Column("MAX_LINEAR_CSV")]
        public string MaxLinearCSV { get; set; }

        [Column("CONTEXT_ID")]
        public int ContextId { get; set; }
    }
}
