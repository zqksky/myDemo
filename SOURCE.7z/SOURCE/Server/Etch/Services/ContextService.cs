﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Dynamic.Core;
using System.Runtime.InteropServices;
using System.Transactions;
using AMAT.R2R.Server.Base;
using AMAT.R2R.Server.Base.Constants;
using AMAT.R2R.Server.Base.Entities;
using AMAT.R2R.Server.Base.Exceptions;
using AMAT.R2R.Server.Base.Extensions;
using AMAT.R2R.Server.Base.Helpers;
using AMAT.R2R.Server.Base.Repository;
using AMAT.R2R.Server.Base.Service;
using AMAT.R2R.Server.Etch.Entities;
using AMAT.R2R.Server.Etch.Exceptions;
using AMAT.R2R.Server.Etch.Repository;
using AMAT.R2R.Server.Etch.Services;
using AMAT.R2R.Shared.Base.Constants;
using AMAT.R2R.Shared.Etch.DTO;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc.ModelBinding.Metadata;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Internal;
using Microsoft.EntityFrameworkCore.Storage;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Logging.Debug;
using Microsoft.Extensions.Primitives;
using BaseDTO = AMAT.R2R.Shared.Base.DTO;
using BaseEntities = AMAT.R2R.Server.Base.Entities;
using DTO = AMAT.R2R.Shared.Etch.DTO;

namespace AMAT.R2R.Server.Etch.Services
{
    public interface IContextService
    {
        DTO.Context CreateContext(DTO.Context context);

        void UpdateContext(DTO.Context context);

        void DeleteContext(DTO.Context context);

        DTO.Context GetContext(int contextId);

        List<DTO.Context> GetContextList(IQueryCollection query);

        int GetContextCount(IQueryCollection query);

        object[] GetContextValueList(IQueryCollection query, string propertyName);

        DTO.Context GetContextInfo(int contextId);

        public DTO.ContextInput CreateContextInput(DTO.ContextInput contextInput);

        void UpdateContextInput(DTO.ContextInput contextInput);

        void DeleteContextInput(int contextId);

        DTO.ContextInput GetContextInput(int contextId);

        DTO.ContextConstants CreateContextConstants(DTO.ContextConstants contextConstants);

        void UpdateContextConstants(DTO.ContextConstants contextConstants);

        void DeleteContextConstants(int contextId);

        DTO.ContextConstants GetContextConstants(int contextId);

        void DeleteContext(int contextId);

        DTO.SpecialJob CreateSpecialJob(DTO.SpecialJob specialJob);

        void DeleteSpecialJob(string jobId);

        void UpdateSpecialJob(DTO.SpecialJob specialJob);

        DTO.SpecialJob GetSpecialJobInfo(string jobId);

        List<DTO.SpecialJob> GetSpecialJobList(IQueryCollection query);
        object[] GetSpecialJobValueList(IQueryCollection query, string propertyName);
        int GetSpecialJobCount(IQueryCollection query);
        DTO.Context ConvertContextEntityToDTO(Entities.Context entityContext);
        DTO.Context FillContextInfomation(DTO.Context context, DTO.Process process);
    }
    public class ContextService : EtchService, IContextService
    {
        private readonly IProcessService _processService;

        public ContextService(IProcessService processService, IServiceProvider serviceProvider, ILogger<ContextService> logger) : base(serviceProvider, logger)
        {
            _processService = processService;
        }
        private Entities.Context ConvertDTOContextToEntity(DTO.Context dtoContext)
        {
            return dtoContext == null ? null : new Entities.Context()
            {
                Fab = dtoContext.Fab,
                ProductId = dtoContext.ProductId,
                Stage = dtoContext.Stage,
                Recipe = dtoContext.Recipe,
                StepName = dtoContext.StepName,
                StepNumber = dtoContext.StepNumber,
                Tool = dtoContext.Tool,
                Chamber = dtoContext.Chamber,
                ContextGroup = dtoContext.ContextGroup,
                LotLevelControl = dtoContext.ControlLevel.Equals(DTO.ControlLevel.LotLevel) ? 1 : 0,
                ControlFlag = dtoContext.ControlFlag.ToString(),
                ControlType = dtoContext.ControlType.ToString(),
                ProcessId = dtoContext.ProcessId,
                ContextId = dtoContext.ContextId,
                LastModifiedBy = dtoContext.LastModifiedBy,
                LastModifiedTime = dtoContext.LastModifiedTime
            };
        }

        private Entities.Context CopyDTOContexttoEntity(Entities.Context _contextEntity, DTO.Context dtoContext)
        {
            if (_contextEntity == null)
            {
                _contextEntity = new Entities.Context();
            }

            _contextEntity.Fab = dtoContext.Fab;
            _contextEntity.ProductId = dtoContext.ProductId;
            _contextEntity.Stage = dtoContext.Stage;
            _contextEntity.Recipe = dtoContext.Recipe;
            _contextEntity.StepName = dtoContext.StepName;
            _contextEntity.StepNumber = dtoContext.StepNumber;
            _contextEntity.Tool = dtoContext.Tool;
            _contextEntity.Chamber = dtoContext.Chamber;
            _contextEntity.ContextGroup = dtoContext.ContextGroup;
            _contextEntity.LotLevelControl = dtoContext.ControlLevel.Equals(DTO.ControlLevel.LotLevel) ? 1 : 0;
            _contextEntity.ControlFlag = dtoContext.ControlFlag.ToString();
            _contextEntity.ControlType = dtoContext.ControlType.ToString();
            _contextEntity.ProcessId = dtoContext.ProcessId;
            _contextEntity.ContextId = dtoContext.ContextId;
            _contextEntity.LastModifiedBy = dtoContext.LastModifiedBy;
            _contextEntity.LastModifiedTime = dtoContext.LastModifiedTime;

            return _contextEntity;
        }

        private Entities.InputDefinition CopyDTOContextInputPara2EntityInputDefinition(Entities.InputDefinition _inputDefinition, DTO.ContextInputPara dtoInputPara)
        {
            Entities.InputDefinition ip = _inputDefinition;
            if (ip == null)
                ip = new InputDefinition();

            string[] keys = dtoInputPara.ContextKey.Split(':');
            ip.Fab = keys[0];
            ip.ProductId = keys[1];
            ip.Stage = keys[2];
            ip.Recipe = keys[3];
            ip.StepName = keys[4];
            ip.StepNumber = keys[5];
            ip.Tool = keys[6];
            ip.Chamber = keys[7];
            ip.ContextGroup = keys[8];
            ip.InputParameterName = dtoInputPara.ParameterName;
            ip.DefaultRecSetting = (double)dtoInputPara.DefaultRecommandValue;
            ip.InputIndex = dtoInputPara.InputIndex;
            ip.InputMin = (double)dtoInputPara.LowerLimit;
            ip.InputMax = (double)dtoInputPara.UpperLimit;
            ip.InputDeadband = (double)dtoInputPara.Deadband;
            ip.InputPrecision = dtoInputPara.Precision;
            ip.Unit = dtoInputPara.Unit;
            ip.UsedConversion = 1;
            ip.RecVsUsedLimit = dtoInputPara.RecVsUsedLimit;
            ip.ContextId = dtoInputPara.ContextId;

            return ip;
        }

        private string GetParameterAlias(string tool, string chamer, string parameterName)
        {
            using EtchDBContext db = CreateDBContext();
            List<Parameter> parameters = db.ParameterRepository.Where(t => t.ToolId == tool && t.ProcessUnit == chamer && t.ParameterName == parameterName).ToList();
            if (parameters == null || parameters.Count() <= 0)
            {
                return "";
            }
            else return parameters[0].AliasName;
        }


        private string GetParameterNameByAlias(string tool, string chamer, string aliasName)
        {
            using EtchDBContext db = CreateDBContext();
            List<Parameter> parameters = db.ParameterRepository.Where(t => t.ToolId == tool && t.ProcessUnit == chamer && t.AliasName == aliasName).ToList();
            if (parameters == null || parameters.Count() <= 0)
            {
                return "";
            }
            else return parameters[0].ParameterName;
        }
        public DTO.Context ConvertContextEntityToDTO(Entities.Context entityContext)
        {
            return entityContext == null ? null : new DTO.Context()
            {
                Fab = entityContext.Fab,
                ProductId = entityContext.ProductId,
                Stage = entityContext.Stage,
                Recipe = entityContext.Recipe,
                StepName = entityContext.StepName,
                StepNumber = entityContext.StepNumber,
                Tool = entityContext.Tool,
                Chamber = entityContext.Chamber,
                ContextGroup = entityContext.ContextGroup,
                ControlFlag = (DTO.ControlFlag)Convert.ToInt32(Enum.Parse(typeof(DTO.ControlFlag), entityContext.ControlFlag)),
                ControlLevel = 1 == entityContext.LotLevelControl ? DTO.ControlLevel.LotLevel : DTO.ControlLevel.WaferLevel,
                ControlType = (DTO.ControlType)Convert.ToInt32(Enum.Parse(typeof(DTO.ControlType), entityContext.ControlType)),
                ContextId = entityContext.ContextId,
                ProcessId = entityContext.ProcessId,
                LastModifiedTime = entityContext.LastModifiedTime,
                LastModifiedBy = entityContext.LastModifiedBy
            };
        }

        private DTO.Context ExtractContextDTO(DTO.Context dtoContext)
        {
            return new DTO.Context()
            {
                Fab = dtoContext.Fab,
                ProductId = dtoContext.ProductId,
                Stage = dtoContext.Stage,
                Recipe = dtoContext.Recipe,
                StepName = dtoContext.StepName,
                StepNumber = dtoContext.StepNumber,
                Tool = dtoContext.Tool,
                Chamber = dtoContext.Chamber,
                ContextGroup = dtoContext.ContextGroup,
                ControlFlag = dtoContext.ControlFlag,
                ControlLevel = dtoContext.ControlLevel,
                ControlType = dtoContext.ControlType,
                ContextId = dtoContext.ContextId,
                ProcessId = dtoContext.ProcessId,
                LastModifiedTime = dtoContext.LastModifiedTime,
                LastModifiedBy = dtoContext.LastModifiedBy
            };
        }
        public DTO.Context CreateContext(DTO.Context context)
        {
            //this is copy context ,
            if (context.ContextId > 0)
            {
                return CopyContext(context);
            }

            using (EtchDBContext db = CreateDBContext())
            {
                BaseEntities.ChangeRequest cr = TryEditing(TxnContext.Area, ObjectName.Context.ToString(), "CreateContext", TxnContext.UserName, TxnContext.Comment, TxnContext.TxnId, context.ContextKey, "NA");
                Entities.Context contextEntity = null;

                using var transaction = db.Database.BeginTransaction();
                try
                {
                    Entities.Process _process = db.ProcessRepository.Find(context.ProcessId);
                    if (_process == null)
                    {
                        throw new EtchException(ErrorCode.InvalidProcessId);
                    }
                    IList<Entities.Context> _contexts = db.ContextRepository.Where(t => t.Fab == context.Fab && t.ProductId == context.ProductId && t.Stage == context.Stage && t.Recipe == context.Recipe && t.StepName == context.StepName && t.StepNumber == context.StepNumber && t.Tool == context.Tool && t.Chamber == context.Chamber && t.ContextGroup == context.ContextGroup).ToList();
                    if (_contexts != null && _contexts.Count() > 0)
                    {
                        throw new ApiException(GeneralErrorCode.ResourceAlreadyExists);
                    }

                    context.ContextId = GetNextId(TxnContext.Area, ObjectName.Context);
                    if (context.ContextId == 0)
                        throw new EtchException(ErrorCode.ValidateFail, "Fail to generate Id!");

                    if (!context.Validate(out string errorMessage))
                        throw new EtchException(ErrorCode.ValidateFail, errorMessage);

                    context.LastModifiedTime = cr.CrTimeStamp;
                    context.LastModifiedBy = TxnContext.UserName;

                    contextEntity = ConvertDTOContextToEntity(context);
                    //contextEntity = ContextRepository.Add(contextEntity);
                    db.Set<Entities.Context>().Add(contextEntity);

                    //create constrants
                    db.SaveChanges();
                    transaction.Commit();

                    //
                    //cr.Json02 = UtilityHelper.GetJsonByObject(context);
                    cr.ContextGroupValue1 = contextEntity.ContextId.ToString();
                    cr.ContextGroupValue = string.Format("{0}:{1}:{2}:{3}:{4}:{5}:{6}:{7}:{8}", contextEntity.Fab, contextEntity.ProductId, contextEntity.Stage, contextEntity.Recipe, contextEntity.StepName, contextEntity.StepNumber, contextEntity.Tool, contextEntity.Chamber, contextEntity.ContextGroup);
                    cr.ContxtGroup = string.Format("{0}:{1}:{2}:{3}:{4}:{5}:{6}:{7}:{8}", "Fab", "ProductId", "Stage", "Recipe", "StepName", "StepNumber", "Tool", "Chamber", "ContextGroup");

                    EndEditing(cr, true);
                }
                catch (Exception ex)
                {
                    transaction.Rollback();
                    cr.Reason = ex.Message.Substring(0, ex.Message.Length > 255 ? 255 : ex.Message.Length);
                    if (cr != null) EndEditing(cr, false);
                    throw ex;
                }

            }

            return context;

        }

        public DTO.Context CopyContext(DTO.Context context)
        {
            using EtchDBContext db = CreateDBContext();
            BaseEntities.ChangeRequest cr = TryEditing(TxnContext.Area, ObjectName.Context.ToString(), "CopyContext", TxnContext.UserName, TxnContext.Comment, TxnContext.TxnId, context.ContextKey, "NA");

            using var transaction = db.Database.BeginTransaction();
            try
            {
                IList<Entities.Context> _contexts = db.ContextRepository.Where(t => t.Fab == context.Fab && t.ProductId == context.ProductId && t.Stage == context.Stage && t.Recipe == context.Recipe && t.StepName == context.StepName && t.StepNumber == context.StepNumber && t.Tool == context.Tool && t.Chamber == context.Chamber && t.ContextGroup == context.ContextGroup).ToList();
                if (_contexts != null && _contexts.Count() > 0)
                {
                    throw new ApiException(GeneralErrorCode.ResourceAlreadyExists);
                }

                //TODO business log
                int originalContextId = context.ContextId;
                ContextConstants ccs = context.ContextConstants;
                ContextMisc cm = context.ContextMisc;
                ContextInput ci = context.ContextInput;

                if (ci == null || ci.ContextInputParas == null || ci.ContextInputParas.Count == 0)
                {
                    throw new EtchException(ErrorCode.ValidateFail, "None InputParamter found , Fail to copy");
                }

                if (ccs == null || string.IsNullOrEmpty(ccs.ContextKey))
                {
                    throw new EtchException(ErrorCode.ValidateFail, "None Context Key found for Constants , Fail to copy");
                }

                if (cm == null || string.IsNullOrEmpty(cm.ContextKey) || ci == null || string.IsNullOrEmpty(ci.ContextKey))
                {
                    throw new EtchException(ErrorCode.ValidateFail, "The source context is missing configuration , Fail to copy");
                }

                int contextId = GetNextId(TxnContext.Area, ObjectName.Context);
                if (contextId == 0)
                    throw new EtchException(ErrorCode.ValidateFail, "Fail to generate Id!");

                #region Context
                context.ContextId = contextId;
                context.LastModifiedTime = cr.CrTimeStamp;
                context.LastModifiedBy = TxnContext.UserName;

                Entities.Context contextEntity = ConvertDTOContextToEntity(context);
                //contextEntity = ContextRepository.Add(contextEntity);
                db.ContextRepository.Add(contextEntity);
                #endregion

                #region StrategyConstant
                StrategyConstant scEntity = new StrategyConstant();
                scEntity.ContextId = context.ContextId;
                scEntity.Fab = context.Fab;
                scEntity.ProductId = context.ProductId;
                scEntity.Stage = context.Stage;
                scEntity.Recipe = context.Recipe;
                scEntity.StepName = context.StepName;
                scEntity.StepNumber = context.StepNumber;
                scEntity.Tool = context.Tool;
                scEntity.Chamber = context.Chamber;
                scEntity.ContextGroup = context.ContextGroup;
                scEntity.AllowMissingPreMetro = context.ContextConstants.OptAllowMissingPreMetro ? 1 : 0;
                scEntity.LimitLotsWithoutMetro = context.ContextConstants.OptLimitLotsWithoutMetro;
                scEntity.LimitNoConsecutiveMaxAdjust = context.ContextConstants.OptLimitNoConsecutiveMaxAdjust;
                scEntity.LotHoldMissingPreMetro = context.ContextConstants.OptLotHoldMissingPreMet ? 1 : 0;
                scEntity.LotHoldPreDictionOOL = context.ContextConstants.OptLotHoldPredicitonOOL ? 1 : 0;
                scEntity.LotHoldRecommendedOOL = context.ContextConstants.OptLotHoldRecommendedOOL ? 1 : 0;
                scEntity.LotStageWaferUseCalcOffset = context.ContextConstants.OptLotStageWaferUseCalcualteOffset;
                scEntity.LotStageWaferUseCalcPre = context.ContextConstants.OptLotStageWaferUseCalcualtePre ? 1 : 0;
                scEntity.MaxTimeLastStateEstDays = context.ContextConstants.OptMaxTimeLastEstDays;
                scEntity.R2RMode = "L2L";
                scEntity.UseTarget = 1;
                scEntity.TotalPostStepNumber = 0;
                scEntity.TotalPreStepNumber = 0;
                scEntity.InputSize = 0;
                scEntity.OutputSize = 0;
                scEntity.HydraFlag = context.ContextConstants.OptHydraFlag ? 1 : 0;
                scEntity.HydraAllowingData = context.ContextConstants.OptHydraAllowMissingData ? 1 : 0;
                scEntity.HydraAllowMissingDataNumber = (int)context.ContextConstants.OptHydraAllowMissingDataNumber;
                scEntity.HydraManualDataEntry = context.ContextConstants.OptHydraManualDataEntry ? 1 : 0;
                scEntity.HydraUseWaferMean = context.ContextConstants.OptHydraUseWaferMean ? 1 : 0;
                scEntity.HydraUseZoneMean = context.ContextConstants.OptHydraUseZoneMean ? 1 : 0;
                db.StrategyConstantRepository.Add(scEntity);


                #endregion

                #region ContextInput
                List<DTO.ContextInputPara> inputParas = context.ContextInput.ContextInputParas;
                //inputdefinition
                foreach (DTO.ContextInputPara inputPara in inputParas)
                {
                    inputPara.ContextId = context.ContextId;

                    List<Entities.InputDefinition> list = db.InputDefinitionRepository.Where(t => t.ContextId == inputPara.ContextId && t.InputParameterName == inputPara.ParameterName).ToList();
                    if (list.Count() > 0)
                        throw new EtchException(ErrorCode.InputParameterExisted);
                    Entities.InputDefinition id = CopyDTOContextInputPara2EntityInputDefinition(null, inputPara);
                    string oriTool = id.Tool;
                    string oriChamber = id.Chamber;
                    string oriContextGroup = id.ContextGroup;
                    string oriParameterName = id.InputParameterName;
                    id.Tool = context.Tool;
                    id.Chamber = context.Chamber;
                    id.ContextGroup = context.ContextGroup;
                    //convert the parameter name from source chamber to target chamber InputDefinition
                    string alias = GetParameterAlias(oriTool, oriChamber, oriParameterName);
                    string parameterName = GetParameterNameByAlias(id.Tool, id.Chamber, alias);
                    if (!string.IsNullOrEmpty(parameterName))
                    {
                        id.InputParameterName = parameterName;
                    }
                    else
                    {
                        throw new EtchException(ErrorCode.ValidateFail, $"None Parameter:{alias} found for the target chamber:{id.Chamber}");
                    }
                    id.Fab = context.Fab;
                    id.ProductId = context.ProductId;
                    id.Stage = context.Stage;
                    id.Recipe = context.Recipe;
                    id.StepName = context.StepName;
                    id.StepNumber = context.StepNumber;
                    id.Tool = context.Tool;
                    id.Chamber = context.Chamber;
                    id.ContextGroup = context.ContextGroup;
                    db.InputDefinitionRepository.Add(id);
                }
                #endregion

                #region Processsetting
                Entities.ProcessSetting _psEntity = db.ProcessSettingRepository.Find(context.ContextId);
                if (_psEntity != null)
                    throw new EtchException(ErrorCode.InputParameterExisted);

                Entities.ProcessSetting ps = new ProcessSetting();
                ps.Fab = context.Fab;
                ps.ProductId = context.ProductId;
                ps.Stage = context.Stage;
                ps.Recipe = context.Recipe;
                ps.StepName = context.StepName;
                ps.StepNumber = context.StepNumber;
                ps.Tool = context.Tool;
                ps.Chamber = context.Chamber;
                ps.ContextGroup = context.ContextGroup;
                ps.ContextId = context.ContextId;
                ps.ChamberCalculationInProgress = 0;
                ps.FbNegDelta = string.Join(",", context.FBNegDelta);
                ps.FbPosDelta = string.Join(",", context.FBPostDelta);
                ps.FfCoefficient = string.Join(",", context.FFCoefficient);
                ps.FfNegDelta = ps.FbNegDelta;
                ps.FfPosDelta = ps.FbPosDelta;
                ps.QsStateEst = string.Join(",", context.QsStatesEst);
                ps.RsStateEst = string.Join(",", context.RsStatesEst);
                ps.ControllerQ = string.Join(",", context.ControllerQ);
                ps.ControllerR = string.Join(",", context.ControllerQ);
                ps.Slot1Compensation = string.Join(",", context.Slot1Compensation);
                ps.Slot2Compensation = string.Join(",", context.Slot2Compensation);
                ps.ModelSlope01CSV = string.Join(",", context.ModelSlope01);
                ps.ModelSlope02CSV = string.Join(",", context.ModelSlope02);
                ps.ModelSlope03CSV = string.Join(",", context.ModelSlope03);
                ps.ModelSlope04CSV = string.Join(",", context.ModelSlope04);
                ps.ModelSlope05CSV = string.Join(",", context.ModelSlope05);
                ps.ModelSlope06CSV = string.Join(",", context.ModelSlope06);
                ps.ModelSlope07CSV = string.Join(",", context.ModelSlope07);
                ps.ModelSlope08CSV = string.Join(",", context.ModelSlope08);
                ps.ModelSlope09CSV = string.Join(",", context.ModelSlope09);
                ps.ModelSlope10CSV = string.Join(",", context.ModelSlope10);
                db.ProcessSettingRepository.Add(ps);
                #endregion processsetting

                #region contextMisc#linearconstraint
                Entities.LinearConstraint lc = new LinearConstraint();
                DTO.ContextMisc contextMisc = context.ContextMisc;
                if (!IsZero(context.LinearConstraint1Coff) || !IsZero(context.LinearConstraint2Coff))
                {
                    lc.Fab = context.Fab;
                    lc.ProductId = context.ProductId;
                    lc.Stage = context.Stage;
                    lc.Recipe = context.Recipe;
                    lc.StepName = context.StepName;
                    lc.StepNumber = context.StepNumber;
                    lc.Tool = context.Tool;
                    lc.Chamber = context.Chamber;
                    lc.ContextGroup = context.ContextGroup;
                    lc.ContextId = context.ContextId;
                    lc.LinearConstraint01CSV = string.Join(",", context.LinearConstraint1Coff);
                    lc.LinearConstraint02CSV = string.Join(",", context.LinearConstraint2Coff);
                    lc.MinLinearCSV = contextMisc.Linear1Min + "," + contextMisc.Linear2Min;
                    lc.MaxLinearCSV = contextMisc.Linear1Max + "," + contextMisc.Linear2Max;
                    db.LinearConstraintRepository.Add(lc);
                }
                #endregion

                db.SaveChanges();
                transaction.Commit();

                cr.ContextGroupValue1 = "Source Context:" + originalContextId.ToString();
                cr.ContextGroupValue = string.Format("{0}:{1}:{2}:{3}:{4}:{5}:{6}:{7}:{8}", context.Fab,
                    context.ProductId, context.Stage, context.Recipe, context.StepName,
                    context.StepNumber, context.Tool, context.Chamber, context.ContextGroup);
                cr.ContxtGroup = string.Format("{0}:{1}:{2}:{3}:{4}:{5}:{6}:{7}:{8}", "Fab", "ProductId", "Stage",
                    "Recipe", "StepName", "StepNumber", "Tool", "Chamber", "ContextGroup");

                EndEditing(cr, true);
            }
            catch (Exception ex)
            {
                transaction.Rollback();
                cr.Reason = ex.Message.Substring(0, ex.Message.Length > 255 ? 255 : ex.Message.Length);
                if (cr != null) EndEditing(cr, false);
                throw ex;
            }

            return context;

        }
        public void UpdateContext(DTO.Context context)
        {
            using EtchDBContext db = CreateDBContext();
            BaseEntities.ChangeRequest cr = TryEditing(TxnContext.Area, ObjectName.Context.ToString(), "UpdateContext", TxnContext.UserName, TxnContext.Comment, TxnContext.TxnId, context.ContextKey, "NA");

            using var transaction = db.Database.BeginTransaction();
            try
            {
                //TODO business log
                Entities.Process _process = db.ProcessRepository.Find(context.ProcessId);
                if (_process == null)
                {
                    EndEditing(cr, false);
                    throw new EtchException(ErrorCode.InvalidProcessId);
                }

                if (!context.Validate(out string errorMessage))
                    throw new EtchException(ErrorCode.ValidateFail, errorMessage);

                Entities.Context _contextEntity = db.ContextRepository.Find(context.ContextId);
                if (_contextEntity == null)
                {
                    throw new EtchException(ErrorCode.InvalidContextId);
                }
                DTO.Context oldContext = ConvertContextEntityToDTO(_contextEntity);

                context = ExtractContextDTO(context);
                BaseDTO.CompareResult result = context.Compare(oldContext);
                if (!result.IsChange)
                    throw new EtchException(ErrorCode.NothingIsChanged);
                //
                cr.CrDetails = result.ChangeContent;
                cr.Json01 = UtilityHelper.GetJsonByObject(oldContext);
                cr.Json02 = UtilityHelper.GetJsonByObject(context);

                context.LastModifiedBy = TxnContext.UserName;
                context.LastModifiedTime = cr.CrTimeStamp;
                CopyDTOContexttoEntity(_contextEntity, context);
                db.ContextRepository.Update(_contextEntity);
                db.SaveChanges();

                transaction.Commit();

                cr.ContextGroupValue1 = _contextEntity.ContextId.ToString();
                cr.ContextGroupValue = string.Format("{0}:{1}:{2}:{3}:{4}:{5}:{6}:{7}:{8}", _contextEntity.Fab,
                    _contextEntity.ProductId, _contextEntity.Stage, _contextEntity.Recipe, _contextEntity.StepName,
                    _contextEntity.StepNumber, _contextEntity.Tool, _contextEntity.Chamber, _contextEntity.ContextGroup);
                cr.ContxtGroup = string.Format("{0}:{1}:{2}:{3}:{4}:{5}:{6}:{7}:{8}", "Fab", "ProductId", "Stage",
                    "Recipe", "StepName", "StepNumber", "Tool", "Chamber", "ContextGroup");

                EndEditing(cr, true);
            }
            catch (Exception ex)
            {
                transaction.Rollback();
                cr.Reason = ex.Message.Substring(0, ex.Message.Length > 255 ? 255 : ex.Message.Length);
                if (cr != null) EndEditing(cr, false);
                throw ex;
            }

        }
        public void DeleteContext(int contextId)
        {
            using EtchDBContext db = CreateDBContext();
            Entities.Context contextEntity = db.ContextRepository.Find(contextId);
            if (contextEntity == null)
                throw new ApiException(GeneralErrorCode.ResourceNotFound);
            DTO.Context context = ConvertContextEntityToDTO(contextEntity);
            BaseEntities.ChangeRequest cr = TryEditing(TxnContext.Area, ObjectName.Context.ToString(), "DeleteContext", TxnContext.UserName, TxnContext.Comment, TxnContext.TxnId, context.ContextKey, "NA");

            using var transaction = db.Database.BeginTransaction();
            try
            {
                //TODO business log
                List<InputDefinition> inputDefinitions = db.InputDefinitionRepository.Where(t => t.ContextId == context.ContextId).ToList();
                StrategyConstant strategyConstant = db.StrategyConstantRepository.Find(context.ContextId);
                LinearConstraint linearConstraint = db.LinearConstraintRepository.Find(context.ContextId);
                ProcessSetting processSetting = db.ProcessSettingRepository.Find(context.ContextId);
                //delete the context
                db.ContextRepository.Remove(contextEntity);

                if (inputDefinitions != null && inputDefinitions.Count() > 0)
                    db.InputDefinitionRepository.RemoveRange(inputDefinitions);
                if (strategyConstant != null)
                    db.StrategyConstantRepository.RemoveRange(strategyConstant);
                if (linearConstraint != null)
                    db.LinearConstraintRepository.RemoveRange(linearConstraint);
                if (processSetting != null)
                    db.ProcessSettingRepository.RemoveRange(processSetting);
                //
                db.SaveChanges();
                transaction.Commit();
                cr.ContextGroupValue1 = context.ContextId.ToString();
                cr.ContextGroupValue = string.Format("{0}:{1}:{2}:{3}:{4}:{5}:{6}:{7}:{8}", context.Fab, context.ProductId, context.Stage, context.Recipe, context.StepName, context.StepNumber, context.Tool, context.Chamber, context.ContextGroup);
                cr.ContxtGroup = string.Format("{0}:{1}:{2}:{3}:{4}:{5}:{6}:{7}:{8}", "Fab", "ProductId", "Stage", "Recipe", "StepName", "StepNumber", "Tool", "Chamber", "ContextGroup");

                EndEditing(cr, true);
                //
            }
            catch (Exception ex)
            {
                transaction.Rollback();
                cr.Reason = ex.Message.Substring(0, ex.Message.Length > 255 ? 255 : ex.Message.Length);
                if (cr != null) EndEditing(cr, false);
                throw ex;
            }

        }

        public void DeleteContext(DTO.Context context)
        {
            using EtchDBContext db = CreateDBContext();
            BaseEntities.ChangeRequest cr = TryEditing(TxnContext.Area, ObjectName.Context.ToString(), "DeleteContext", TxnContext.UserName, TxnContext.Comment, TxnContext.TxnId, context.ContextKey, "NA");

            using var transaction = db.Database.BeginTransaction();
            try
            {
                //TODO business log
                Entities.Context contextEntity = db.ContextRepository.Find(context.ContextId);
                if (contextEntity == null)
                    throw new ApiException(GeneralErrorCode.ResourceNotFound);

                //here need first check if run existed on the context
                List<InputDefinition> inputDefinitions = db.InputDefinitionRepository.Where(t => t.ContextId == context.ContextId).ToList();
                StrategyConstant strategyConstant = db.StrategyConstantRepository.Find(context.ContextId);
                LinearConstraint linearConstraint = db.LinearConstraintRepository.Find(context.ContextId);
                ProcessSetting processSetting = db.ProcessSettingRepository.Find(context.ContextId);
                //delete the context
                db.ContextRepository.Remove(contextEntity);
                if (inputDefinitions != null && inputDefinitions.Count() > 0)
                    db.InputDefinitionRepository.RemoveRange(inputDefinitions);
                if (strategyConstant != null)
                    db.StrategyConstantRepository.RemoveRange(strategyConstant);
                if (linearConstraint != null)
                    db.LinearConstraintRepository.RemoveRange(linearConstraint);
                if (processSetting != null)
                    db.ProcessSettingRepository.RemoveRange(processSetting);

                db.SaveChanges();
                transaction.Commit();
                //
                cr.ContextGroupValue1 = context.ContextId.ToString();
                cr.ContextGroupValue = string.Format("{0}:{1}:{2}:{3}:{4}:{5}:{6}:{7}:{8}", context.Fab, context.ProductId, context.Stage, context.Recipe, context.StepName, context.StepNumber, context.Tool, context.Chamber, context.ContextGroup);
                cr.ContxtGroup = string.Format("{0}:{1}:{2}:{3}:{4}:{5}:{6}:{7}:{8}", "Fab", "ProductId", "Stage", "Recipe", "StepName", "StepNumber", "Tool", "Chamber", "ContextGroup");
                EndEditing(cr, true);
                //
            }
            catch (Exception ex)
            {
                transaction.Rollback();
                cr.Reason = ex.Message.Substring(0, ex.Message.Length > 255 ? 255 : ex.Message.Length);
                if (cr != null) EndEditing(cr, false);
                throw;
            }
        }

        public DTO.Context GetContext(int contextId)
        {
            //using (EtchDBContext db = CreateContext())
            using EtchDBContext db = CreateDBContext();
            //EtchDBContext db = _EtchDBContext;
            Entities.Context _context = db.ContextRepository.Find(contextId);
            if (_context == null)
                throw new EtchException(ErrorCode.InvalidContextId);
            DTO.Context context = ConvertContextEntityToDTO(_context);
            FillContextInfomation(context, null);
            return context;

        }


        public List<DTO.Context> GetContextList(IQueryCollection query)
        {
            using EtchDBContext db = CreateDBContext();

            var joinedQueryable = from c in db.ContextRepository
                                  join s in db.StrategyConstantRepository on c.ContextId equals s.ContextId into grouping
                                  from s in grouping.DefaultIfEmpty()
                                  select new
                                  {
                                      c,
                                      c.Fab,
                                      c.ProductId,
                                      c.Stage,
                                      c.Recipe,
                                      c.StepName,
                                      c.StepNumber,
                                      c.Tool,
                                      c.Chamber,
                                      c.ContextGroup,
                                      c.ControlFlag,
                                      ControlLevel = 1 == c.LotLevelControl ? DTO.ControlLevel.LotLevel : DTO.ControlLevel.WaferLevel,
                                      c.ControlType,
                                      c.ContextId,
                                      c.ProcessId,
                                      c.LastModifiedTime,
                                      c.LastModifiedBy,
                                      EstiExpiredDay = s == null ? 0 : s.MaxTimeLastStateEstDays,
                                      IsConstantDefined = s != null,
                                  };

            //var leftJoin = db.ContextRepository.AsNoTracking().LeftJoin(db.StrategyConstantRepository.AsNoTracking(), c => c.ContextId, s => s.ContextId, (c, s) =>
            //new
            //{
            //    c,
            //    c.Fab,
            //    c.ProductId,
            //    c.Stage,
            //    c.Recipe,
            //    c.StepName,
            //    c.StepNumber,
            //    c.Tool,
            //    c.Chamber,
            //    c.ContextGroup,
            //    c.ControlFlag,
            //    ControlLevel = 1 == c.LotLevelControl ? DTO.ControlLevel.LotLevel : DTO.ControlLevel.WaferLevel,
            //    c.ControlType,
            //    c.ContextId,
            //    c.ProcessId,
            //    c.LastModifiedTime,
            //    c.LastModifiedBy,
            //    EstiExpiredDay = s.MaxTimeLastStateEstDays
            //});

            joinedQueryable = joinedQueryable.AsNoTracking().Where(j => j.Fab == TxnContext.Fab).ApplyFilters(query);

            var sortable = joinedQueryable.ApplySorters(query);
            List<Entities.Context> contextEntities = sortable.Select(j => j.c).PageToList(query);

            List<DTO.Context> contexts = new List<DTO.Context>();
            Dictionary<int, DTO.Process> processes = new Dictionary<int, DTO.Process>();
            foreach (Entities.Context contextEntity in contextEntities)
            {
                DTO.Context context = ConvertContextEntityToDTO(contextEntity);
                if (!processes.ContainsKey(context.ProcessId))
                {
                    processes[context.ProcessId] = _processService.GetProcessInfoByID(context.ProcessId);
                }
                FillContextInfomation(context, processes[context.ProcessId]);
                contexts.Add(context);
            }
            return contexts;
        }

        public object[] GetContextValueList(IQueryCollection query, string propertyName)
        {
            using EtchDBContext db = CreateDBContext();

            var joinedQueryable = from c in db.ContextRepository
                                  join s in db.StrategyConstantRepository
                                  on c.ContextId equals s.ContextId
                                  into grouping
                                  from s in grouping.DefaultIfEmpty()
                                  select new
                                  {
                                      c.Fab,
                                      c.ProductId,
                                      c.Stage,
                                      c.Recipe,
                                      c.StepName,
                                      c.StepNumber,
                                      c.Tool,
                                      c.Chamber,
                                      c.ContextGroup,
                                      c.ControlFlag,
                                      ControlLevel = 1 == c.LotLevelControl ? DTO.ControlLevel.LotLevel : DTO.ControlLevel.WaferLevel,
                                      c.ControlType,
                                      c.ContextId,
                                      c.ProcessId,
                                      c.LastModifiedTime,
                                      c.LastModifiedBy,
                                      EstiExpiredDay = s == null ? 0 : s.MaxTimeLastStateEstDays,
                                      IsConstantDefined = s != null,
                                  };
            return joinedQueryable.AsNoTracking().Where(j => j.Fab == TxnContext.Fab).GetValueList(query, propertyName);
        }

        public int GetContextCount(IQueryCollection query)
        {
            using EtchDBContext db = CreateDBContext();

            // left join
            var joinedQueryable = from c in db.ContextRepository
                                  join s in db.StrategyConstantRepository
                                  on c.ContextId equals s.ContextId
                                  into grouping
                                  from s in grouping.DefaultIfEmpty()
                                  select new
                                  {
                                      c.Fab,
                                      c.ProductId,
                                      c.Stage,
                                      c.Recipe,
                                      c.StepName,
                                      c.StepNumber,
                                      c.Tool,
                                      c.Chamber,
                                      c.ContextGroup,
                                      c.ControlFlag,
                                      ControlLevel = 1 == c.LotLevelControl ? DTO.ControlLevel.LotLevel : DTO.ControlLevel.WaferLevel,
                                      c.ControlType,
                                      c.ContextId,
                                      c.ProcessId,
                                      c.LastModifiedTime,
                                      c.LastModifiedBy,
                                      EstiExpiredDay = s == null ? 0 : s.MaxTimeLastStateEstDays,
                                      IsConstantDefined = s != null,
                                  };
            return joinedQueryable.AsNoTracking().Where(j => j.Fab == TxnContext.Fab).ApplyFilters(query).Count();
        }

        public DTO.Context GetContextInfo(int contextId)
        {
            //using (EtchDBContext db = CreateContext())
            using EtchDBContext db = CreateDBContext();
            //EtchDBContext db = _EtchDBContext;
            Entities.Context contextEntity = db.ContextRepository.Find(contextId);
            if (contextEntity == null)
            {
                throw new EtchException(ErrorCode.ResourceNotExisted, $"Context {contextId} doesn't exist.");
            }
            else
            {
                DTO.Context contextDTO = ConvertContextEntityToDTO(contextEntity);
                contextDTO = FillContextInfomation(contextDTO, null);
                return contextDTO;
            }
        }

        public DTO.Context FillContextInfomation(DTO.Context context, DTO.Process process)
        {
            if (context == null) return context;
            context.ContextInput = GetContextInput(context.ContextId);
            context.ContextConstants = GetContextConstants(context.ContextId);
            context.Process = process == null ? _processService.GetProcessInfoByID(context.ProcessId) : process;

            return context;
        }

        public DTO.ContextInput CreateContextInput(ContextInput contextInput)
        {
            using (EtchDBContext db = CreateDBContext())
            {
                Entities.Context _context = db.ContextRepository.Find(contextInput.ContextId);
                if (_context == null)
                    throw new EtchException(ErrorCode.InvalidContextId);
                DTO.Context context = ConvertContextEntityToDTO(_context);

                context.ContextInput = contextInput;
                BaseEntities.ChangeRequest cr = TryEditing(TxnContext.Area, ObjectName.Context.ToString(), "CreateContextInput", TxnContext.UserName, TxnContext.Comment, TxnContext.TxnId, context.ContextKey, "NA");

                using var transaction = db.Database.BeginTransaction();
                try
                {
                    if (!contextInput.Validate(out string errorMessage))
                        throw new EtchException(ErrorCode.ValidateFail, errorMessage);

                    List<DTO.ContextInputPara> inputParas = contextInput.ContextInputParas;
                    if (inputParas == null || inputParas.Count() <= 0)
                        throw new EtchException(ErrorCode.InvalidContextId);
                    //inputdefinition
                    foreach (DTO.ContextInputPara inputPara in inputParas)
                    {
                        if (!context.ContextKey.Equals(inputPara.ContextKey) ||
                            !context.ContextId.Equals(inputPara.ContextId))
                            throw new EtchException(ErrorCode.InvalidContextId);

                        List<Entities.InputDefinition> list = db.InputDefinitionRepository.Where(t => t.ContextId == inputPara.ContextId && t.InputParameterName == inputPara.ParameterName).ToList();
                        if (list.Count() > 0)
                            throw new EtchException(ErrorCode.InputParameterExisted);
                        Entities.InputDefinition id = CopyDTOContextInputPara2EntityInputDefinition(null, inputPara);
                        db.InputDefinitionRepository.Add(id);
                    }

                    #region processsetting
                    Entities.ProcessSetting _psEntity = db.ProcessSettingRepository.Find(context.ContextId);
                    if (_psEntity != null)
                        throw new EtchException(ErrorCode.InputParameterExisted);

                    Entities.ProcessSetting ps = new ProcessSetting();
                    ps.Fab = context.Fab;
                    ps.ProductId = context.ProductId;
                    ps.Stage = context.Stage;
                    ps.Recipe = context.Recipe;
                    ps.StepName = context.StepName;
                    ps.StepNumber = context.StepNumber;
                    ps.Tool = context.Tool;
                    ps.Chamber = context.Chamber;
                    ps.ContextGroup = context.ContextGroup;
                    ps.ContextId = context.ContextId;
                    ps.ChamberCalculationInProgress = 0;
                    ps.FbNegDelta = string.Join(",", context.FBNegDelta);
                    ps.FbPosDelta = string.Join(",", context.FBPostDelta);
                    ps.FfCoefficient = string.Join(",", context.FFCoefficient);
                    ps.FfNegDelta = ps.FbNegDelta;
                    ps.FfPosDelta = ps.FbPosDelta;
                    ps.QsStateEst = string.Join(",", context.QsStatesEst);
                    ps.RsStateEst = string.Join(",", context.RsStatesEst);
                    ps.ControllerQ = string.Join(",", context.ControllerQ);
                    ps.ControllerR = string.Join(",", context.ControllerR);
                    ps.Slot1Compensation = string.Join(",", context.Slot1Compensation);
                    ps.Slot2Compensation = string.Join(",", context.Slot2Compensation);
                    //Matrix
                    //to convert the row (ui) to column (database)
                    Matrix<double> matrix = new Matrix<double>(10, 10, 0);
                    for(int i = 0; i < 10; i++)
                    {
                        switch(i)
                        {
                            case 0:
                                matrix.Cells[i] = context.ModelSlope01;
                                break;

                            case 1:
                                matrix.Cells[i] = context.ModelSlope02;
                                break;

                            case 2:
                                matrix.Cells[i] = context.ModelSlope03;
                                break;

                            case 3:
                                matrix.Cells[i] = context.ModelSlope04;
                                break;

                            case 4:
                                matrix.Cells[i] = context.ModelSlope05;
                                break;

                            case 5:
                                matrix.Cells[i] = context.ModelSlope06;
                                break;

                            case 6:
                                matrix.Cells[i] = context.ModelSlope07;
                                break;

                            case 7:
                                matrix.Cells[i] = context.ModelSlope08;
                                break;

                            case 8:
                                matrix.Cells[i] = context.ModelSlope09;
                                break;

                            case 9:
                                matrix.Cells[i] = context.ModelSlope10;
                                break;

                            default:
                                break;

                        } 
                    }
                    ps.ModelSlope01CSV = string.Join(",", matrix.ColumnCSV(0));
                    ps.ModelSlope02CSV = string.Join(",", matrix.ColumnCSV(1));
                    ps.ModelSlope03CSV = string.Join(",", matrix.ColumnCSV(2));
                    ps.ModelSlope04CSV = string.Join(",", matrix.ColumnCSV(3));
                    ps.ModelSlope05CSV = string.Join(",", matrix.ColumnCSV(4));
                    ps.ModelSlope06CSV = string.Join(",", matrix.ColumnCSV(5));
                    ps.ModelSlope07CSV = string.Join(",", matrix.ColumnCSV(6));
                    ps.ModelSlope08CSV = string.Join(",", matrix.ColumnCSV(7));
                    ps.ModelSlope09CSV = string.Join(",", matrix.ColumnCSV(8));
                    ps.ModelSlope10CSV = string.Join(",", matrix.ColumnCSV(9));

                    /*
                    ps.ModelSlope01CSV = string.Join(",", context.ModelSlope01);
                    ps.ModelSlope02CSV = string.Join(",", context.ModelSlope02);
                    ps.ModelSlope03CSV = string.Join(",", context.ModelSlope03);
                    ps.ModelSlope04CSV = string.Join(",", context.ModelSlope04);
                    ps.ModelSlope05CSV = string.Join(",", context.ModelSlope05);
                    ps.ModelSlope06CSV = string.Join(",", context.ModelSlope06);
                    ps.ModelSlope07CSV = string.Join(",", context.ModelSlope07);
                    ps.ModelSlope08CSV = string.Join(",", context.ModelSlope08);
                    ps.ModelSlope09CSV = string.Join(",", context.ModelSlope09);
                    ps.ModelSlope10CSV = string.Join(",", context.ModelSlope10);
                    */
                    db.ProcessSettingRepository.Add(ps);
                    #endregion processsetting

                    #region contextMisc#linearconstraint
                    Entities.LinearConstraint lc = new LinearConstraint();
                    DTO.ContextMisc contextMisc = context.ContextMisc;
                    if (!IsZero(context.LinearConstraint1Coff) || !IsZero(context.LinearConstraint2Coff))
                    {
                        lc.Fab = context.Fab;
                        lc.ProductId = context.ProductId;
                        lc.Stage = context.Stage;
                        lc.Recipe = context.Recipe;
                        lc.StepName = context.StepName;
                        lc.StepNumber = context.StepNumber;
                        lc.Tool = context.Tool;
                        lc.Chamber = context.Chamber;
                        lc.ContextGroup = context.ContextGroup;
                        lc.ContextId = context.ContextId;
                        lc.LinearConstraint01CSV = string.Join(",", context.LinearConstraint1Coff);
                        lc.LinearConstraint02CSV = string.Join(",", context.LinearConstraint2Coff);
                        lc.MinLinearCSV = contextMisc.Linear1Min + "," + contextMisc.Linear2Min;
                        lc.MaxLinearCSV = contextMisc.Linear1Max + "," + contextMisc.Linear2Max;
                        db.LinearConstraintRepository.Add(lc);
                    }
                    #endregion
                    _context.LastModifiedBy = TxnContext.UserName;
                    _context.LastModifiedTime = cr.CrTimeStamp;
                    db.ContextRepository.Update(_context);

                    db.SaveChanges();
                    transaction.Commit();
                    //

                    EndEditing(cr, true);
                }
                catch (Exception ex)
                {
                    transaction.Rollback();
                    cr.Reason = ex.Message.Substring(0, ex.Message.Length > 255 ? 255 : ex.Message.Length);
                    if (cr != null) EndEditing(cr, false);
                    throw;
                }
            }
            return contextInput;
        }

        private bool IsZero<T>(T[] t)
        {
            bool flag = true;
            if (t == null || t.Count() == 0) return true;
            else
            {
                flag = !t.Any(t => !"0".Equals(t.ToString()));
            }
            return flag;
        }
        public void UpdateContextInput(ContextInput contextInput)
        {
            using EtchDBContext db = CreateDBContext();
            Entities.Context _context = db.ContextRepository.Find(contextInput.ContextId);
            if (_context == null)
                throw new EtchException(ErrorCode.InvalidContextId);
            DTO.Context context = GetContextInfo(contextInput.ContextId);

            BaseEntities.ChangeRequest cr = TryEditing(TxnContext.Area, ObjectName.Context.ToString(), "UpdateContextInput", TxnContext.UserName, TxnContext.Comment, TxnContext.TxnId, context.ContextKey, "NA");

            using var transaction = db.Database.BeginTransaction();
            try
            {
                BaseDTO.CompareResult result = new BaseDTO.CompareResult { IsChange = false, ChangeContent = "" };

                if (!contextInput.Validate(out string errorMessage))
                    throw new EtchException(ErrorCode.ValidateFail, errorMessage);

                BaseDTO.CompareResult cc1 = contextInput.Compare(context.ContextInput);
                DTO.Context newContext = new DTO.Context();
                if (cc1.IsChange)
                {
                    result.Add(cc1);
                    cr.CrDetails = result.ChangeContent;
                    //do update
                    //inputdefinition
                    db.InputDefinitionRepository.RemoveRange(db.InputDefinitionRepository.Where(t => t.ContextId == contextInput.ContextId));
                    //processsetting
                    db.ProcessSettingRepository.RemoveRange(db.ProcessSettingRepository.Where(t => t.ContextId == contextInput.ContextId));

                    //inputdefinition
                    foreach (DTO.ContextInputPara inputPara in contextInput.ContextInputParas)
                    {
                        if (!context.ContextKey.Equals(inputPara.ContextKey) ||
                            !context.ContextId.Equals(inputPara.ContextId))
                            throw new EtchException(ErrorCode.InvalidContextId);
                        Entities.InputDefinition id = CopyDTOContextInputPara2EntityInputDefinition(null, inputPara);
                        db.InputDefinitionRepository.Add(id);
                    }

                    #region processsetting
                    Entities.ProcessSetting ps = new ProcessSetting();
                    newContext.ContextInput = contextInput;
                    ps.Fab = context.Fab;
                    ps.ProductId = context.ProductId;
                    ps.Stage = context.Stage;
                    ps.Recipe = context.Recipe;
                    ps.StepName = context.StepName;
                    ps.StepNumber = context.StepNumber;
                    ps.Tool = context.Tool;
                    ps.Chamber = context.Chamber;
                    ps.ContextGroup = context.ContextGroup;
                    ps.ContextId = context.ContextId;
                    ps.ChamberCalculationInProgress = 0;
                    ps.FbNegDelta = string.Join(",", newContext.FBNegDelta);
                    ps.FbPosDelta = string.Join(",", newContext.FBPostDelta);
                    ps.FfCoefficient = string.Join(",", newContext.FFCoefficient);
                    ps.FfNegDelta = ps.FbNegDelta;
                    ps.FfPosDelta = ps.FbPosDelta;
                    ps.QsStateEst = string.Join(",", newContext.QsStatesEst);
                    ps.RsStateEst = string.Join(",", newContext.RsStatesEst);
                    ps.ControllerQ = newContext.ControllerQ.ToString();
                    ps.ControllerR = newContext.ControllerR.ToString();
                    ps.Slot1Compensation = string.Join(",", newContext.Slot1Compensation);
                    ps.Slot2Compensation = string.Join(",", newContext.Slot2Compensation);
                    //Matrix
                    //to convert the row (ui) to column (database)
                    Matrix<double> matrix = new Matrix<double>(10, 10, 0);
                    for (int i = 0; i < 10; i++)
                    {
                        switch (i)
                        {
                            case 0:
                                matrix.Cells[i] = newContext.ModelSlope01;
                                break;

                            case 1:
                                matrix.Cells[i] = newContext.ModelSlope02;
                                break;

                            case 2:
                                matrix.Cells[i] = newContext.ModelSlope03;
                                break;

                            case 3:
                                matrix.Cells[i] = newContext.ModelSlope04;
                                break;

                            case 4:
                                matrix.Cells[i] = newContext.ModelSlope05;
                                break;

                            case 5:
                                matrix.Cells[i] = newContext.ModelSlope06;
                                break;

                            case 6:
                                matrix.Cells[i] = newContext.ModelSlope07;
                                break;

                            case 7:
                                matrix.Cells[i] = newContext.ModelSlope08;
                                break;

                            case 8:
                                matrix.Cells[i] = newContext.ModelSlope09;
                                break;

                            case 9:
                                matrix.Cells[i] = newContext.ModelSlope10;
                                break;

                            default:
                                break;

                        }
                    }
                    ps.ModelSlope01CSV = string.Join(",", matrix.ColumnCSV(0));
                    ps.ModelSlope02CSV = string.Join(",", matrix.ColumnCSV(1));
                    ps.ModelSlope03CSV = string.Join(",", matrix.ColumnCSV(2));
                    ps.ModelSlope04CSV = string.Join(",", matrix.ColumnCSV(3));
                    ps.ModelSlope05CSV = string.Join(",", matrix.ColumnCSV(4));
                    ps.ModelSlope06CSV = string.Join(",", matrix.ColumnCSV(5));
                    ps.ModelSlope07CSV = string.Join(",", matrix.ColumnCSV(6));
                    ps.ModelSlope08CSV = string.Join(",", matrix.ColumnCSV(7));
                    ps.ModelSlope09CSV = string.Join(",", matrix.ColumnCSV(8));
                    ps.ModelSlope10CSV = string.Join(",", matrix.ColumnCSV(9));

                    /*
                    ps.ModelSlope01CSV = string.Join(",", context.ModelSlope01);
                    ps.ModelSlope02CSV = string.Join(",", context.ModelSlope02);
                    ps.ModelSlope03CSV = string.Join(",", context.ModelSlope03);
                    ps.ModelSlope04CSV = string.Join(",", context.ModelSlope04);
                    ps.ModelSlope05CSV = string.Join(",", context.ModelSlope05);
                    ps.ModelSlope06CSV = string.Join(",", context.ModelSlope06);
                    ps.ModelSlope07CSV = string.Join(",", context.ModelSlope07);
                    ps.ModelSlope08CSV = string.Join(",", context.ModelSlope08);
                    ps.ModelSlope09CSV = string.Join(",", context.ModelSlope09);
                    ps.ModelSlope10CSV = string.Join(",", context.ModelSlope10);
                    */
                    db.ProcessSettingRepository.Add(ps);
                    #endregion processsetting
                }

                BaseDTO.CompareResult cc2 = contextInput.ContextMisc.Compare(context.ContextInput.ContextMisc);
                if (cc2.IsChange || cc1.IsChange)
                {
                    result.Add(cc2);
                    cr.CrDetails = result.ChangeContent;
                    //do update
                    //contextMisc#linearconstraint
                    db.LinearConstraintRepository.RemoveRange(db.LinearConstraintRepository.Where(t => t.ContextId == contextInput.ContextId));
                    #region contextMisc#linearconstraint
                    Entities.LinearConstraint lc = new LinearConstraint();
                    if (!IsZero(newContext.LinearConstraint1Coff) || !IsZero(newContext.LinearConstraint2Coff))
                    { }

                    lc.Fab = context.Fab;
                    lc.ProductId = context.ProductId;
                    lc.Stage = context.Stage;
                    lc.Recipe = context.Recipe;
                    lc.StepName = context.StepName;
                    lc.StepNumber = context.StepNumber;
                    lc.Tool = context.Tool;
                    lc.Chamber = context.Chamber;
                    lc.ContextGroup = context.ContextGroup;
                    lc.ContextId = context.ContextId;
                    lc.LinearConstraint01CSV = string.Join(",", newContext.LinearConstraint1Coff);
                    lc.LinearConstraint02CSV = string.Join(",", newContext.LinearConstraint2Coff);
                    lc.MinLinearCSV = newContext.Linear1Min + "," + newContext.Linear2Min;
                    lc.MaxLinearCSV = newContext.Linear1Max + "," + newContext.Linear2Max;
                    db.LinearConstraintRepository.Add(lc);

                    #endregion
                }

                if (!result.IsChange)
                    throw new EtchException(ErrorCode.NothingIsChanged);


                _context.LastModifiedBy = TxnContext.UserName;
                _context.LastModifiedTime = cr.CrTimeStamp;
                db.ContextRepository.Update(_context);
                db.SaveChanges();
                transaction.Commit();
                //

                cr.Json01 = UtilityHelper.GetJsonByObject(context.ContextInput);
                cr.Json02 = UtilityHelper.GetJsonByObject(contextInput);
                cr.ContextGroupValue1 = _context.ContextId.ToString();
                cr.ContextGroupValue = string.Format("{0}:{1}:{2}:{3}:{4}:{5}:{6}:{7}:{8}", _context.Fab, _context.ProductId, _context.Stage, _context.Recipe, _context.StepName, _context.StepNumber, _context.Tool, _context.Chamber, _context.ContextGroup);
                cr.ContxtGroup = string.Format("{0}:{1}:{2}:{3}:{4}:{5}:{6}:{7}:{8}", "Fab", "ProductId", "Stage", "Recipe", "StepName", "StepNumber", "Tool", "Chamber", "ContextGroup");

                EndEditing(cr, true);
            }
            catch (Exception ex)
            {
                transaction.Rollback();
                cr.Reason = ex.Message.Substring(0, ex.Message.Length > 255 ? 255 : ex.Message.Length);
                if (cr != null) EndEditing(cr, false);
                throw ex;
            }
        }

        public void DeleteContextInput(int contextId)
        {
            using EtchDBContext db = CreateDBContext();
            Entities.Context _context = db.ContextRepository.Find(contextId);
            if (_context == null)
                throw new EtchException(ErrorCode.InvalidContextId);
            DTO.Context context = ConvertContextEntityToDTO(_context);

            BaseEntities.ChangeRequest cr = TryEditing(TxnContext.Area, ObjectName.Context.ToString(), "DeleteContextInput", TxnContext.UserName, TxnContext.Comment, TxnContext.TxnId, context.ContextKey, "NA");

            using var transaction = db.Database.BeginTransaction();
            try
            {
                //TODO business log

                //InputDefinition
                db.InputDefinitionRepository.RemoveRange(db.InputDefinitionRepository.Where(t => t.ContextId == contextId));

                //ProcessSetting
                db.ProcessSettingRepository.RemoveRange(db.ProcessSettingRepository.Where(t => t.ContextId == contextId));

                //contextMisc#linearconstraint
                db.LinearConstraintRepository.RemoveRange(db.LinearConstraintRepository.Where(t => t.ContextId == contextId));

                //StrategyConstant
                db.StrategyConstantRepository.RemoveRange(db.StrategyConstantRepository.Where(t => t.ContextId == contextId));
                db.ContextRepository.Update(_context);
                db.SaveChanges();
                transaction.Commit();

                _context.LastModifiedBy = TxnContext.UserName;
                _context.LastModifiedTime = cr.CrTimeStamp;
                EndEditing(cr, true);
            }
            catch (Exception ex)
            {
                transaction.Rollback();
                cr.Reason = ex.Message.Substring(0, ex.Message.Length > 255 ? 255 : ex.Message.Length);
                if (cr != null) EndEditing(cr, false);
                throw;
            }
        }

        public DTO.ContextInput GetContextInput(int contextId)
        {
            using EtchDBContext db = CreateDBContext();
            //EtchDBContext db = _EtchDBContext;
            Entities.Context _context = db.ContextRepository.Find(contextId);
            if (_context == null)
                throw new EtchException(ErrorCode.InvalidContextId);
            //DTO.Context context = this.GetContext(contextId);
            DTO.Context context = ConvertContextEntityToDTO(_context);

            DTO.ContextInput contextInput = new ContextInput();
            List<Entities.InputDefinition> idsEntity = db.InputDefinitionRepository.Where(t => t.ContextId == contextId).OrderBy(t => t.InputIndex).ToList();
            Entities.ProcessSetting psEntity = db.ProcessSettingRepository.Find(contextId);
            Entities.LinearConstraint lcEntity = db.LinearConstraintRepository.Find(contextId);

            List<DTO.ContextInputPara> contextInputParas = new List<ContextInputPara>();
            ContextMisc contextMisc = new ContextMisc();
            contextInput.ContextKey = context.ContextKey;
            contextInput.ContextId = context.ContextId;
            contextInput.ContextInputParas = contextInputParas;
            contextInput.ContextMisc = contextMisc;

            //ContextInputParas
            Matrix<double> FBNegDelta = psEntity == null ? new Matrix<double>(10, 1, 0) : new Matrix<double>(10, psEntity.FbNegDelta, 0);
            Matrix<double> FBPostDelta = psEntity == null ? new Matrix<double>(10, 1, 0) : new Matrix<double>(10, psEntity.FbPosDelta, 0);
            Matrix<double> Slot1Comp = psEntity == null ? new Matrix<double>(10, 1, 0) : new Matrix<double>(10, psEntity.Slot1Compensation, 0);
            Matrix<double> Slot2Comp = psEntity == null ? new Matrix<double>(10, 1, 0) : new Matrix<double>(10, psEntity.Slot2Compensation, 0);
            Matrix<double> EstiQ = psEntity == null ? new Matrix<double>(10, 1, 0) : new Matrix<double>(10, psEntity.QsStateEst, 0);
            Matrix<double> EstiR = psEntity == null ? new Matrix<double>(10, 1, 0) : new Matrix<double>(10, psEntity.RsStateEst, 0);
            Matrix<double> LinearConstraint1 = lcEntity == null ? new Matrix<double>(10, 1, 0) : new Matrix<double>(10, lcEntity.LinearConstraint01CSV, 0);
            Matrix<double> LinearConstraint2 = lcEntity == null ? new Matrix<double>(10, 1, 0) : new Matrix<double>(10, lcEntity.LinearConstraint02CSV, 0);

            //
            //Matrix
            //to convert the column (database) to row (ui)  
            Matrix<double> matrix = new Matrix<double>(10, 10, 0);
            for (int i = 0; i < 10 && psEntity!=null; i++)
            {
                switch (i)
                {
                    case 0:
                        matrix.Cells[i] = new Matrix<double>(10, psEntity.ModelSlope01CSV, 0).ColumnArray(0);
                        break;

                    case 1:
                        matrix.Cells[i] = new Matrix<double>(10, psEntity.ModelSlope02CSV, 0).ColumnArray(0);
                        break;

                    case 2:
                        matrix.Cells[i] = new Matrix<double>(10, psEntity.ModelSlope03CSV, 0).ColumnArray(0);
                        break;

                    case 3:
                        matrix.Cells[i] = new Matrix<double>(10, psEntity.ModelSlope04CSV, 0).ColumnArray(0);
                        break;

                    case 4:
                        matrix.Cells[i] = new Matrix<double>(10, psEntity.ModelSlope05CSV, 0).ColumnArray(0);
                        break;

                    case 5:
                        matrix.Cells[i] = new Matrix<double>(10, psEntity.ModelSlope06CSV, 0).ColumnArray(0);
                        break;

                    case 6:
                        matrix.Cells[i] = new Matrix<double>(10, psEntity.ModelSlope07CSV, 0).ColumnArray(0);
                        break;

                    case 7:
                        matrix.Cells[i] = new Matrix<double>(10, psEntity.ModelSlope08CSV, 0).ColumnArray(0);
                        break;

                    case 8:
                        matrix.Cells[i] = new Matrix<double>(10, psEntity.ModelSlope09CSV, 0).ColumnArray(0);
                        break;

                    case 9:
                        matrix.Cells[i] = new Matrix<double>(10, psEntity.ModelSlope10CSV, 0).ColumnArray(0);
                        break;

                    default:
                        break;

                }
            }

            foreach (Entities.InputDefinition idEntity in idsEntity)
            {
                DTO.ContextInputPara inputPara = new ContextInputPara();
                inputPara.ContextId = context.ContextId;
                inputPara.ContextKey = context.ContextKey;

                inputPara.Parameter = new BaseDTO.Parameter() { ParameterName = idEntity.InputParameterName };
                inputPara.DefaultRecommandValue = new decimal(idEntity.DefaultRecSetting);
                inputPara.InputIndex = idEntity.InputIndex;
                inputPara.LowerLimit = new decimal(idEntity.InputMin);
                inputPara.UpperLimit = new decimal(idEntity.InputMax);
                inputPara.Deadband = new decimal(idEntity.InputDeadband);
                inputPara.Precision = idEntity.InputPrecision;
                inputPara.Unit = idEntity.Unit;
                inputPara.UsedConversion = idEntity.UsedConversion;
                inputPara.RecVsUsedLimit = idEntity.RecVsUsedLimit;
                inputPara.ContextId = idEntity.ContextId;

                inputPara.FBNegDelta = FBNegDelta[idEntity.InputIndex - 1, 0];
                inputPara.FBPostDelta = FBPostDelta[idEntity.InputIndex - 1, 0];
                inputPara.Slot1Compensation = Slot1Comp[idEntity.InputIndex - 1, 0];
                inputPara.Slot2Compensation = Slot2Comp[idEntity.InputIndex - 1, 0];
                inputPara.LinearConstraint1Coff = LinearConstraint1[idEntity.InputIndex - 1, 0];
                inputPara.LinearConstraint2Coff = LinearConstraint2[idEntity.InputIndex - 1, 0];
                inputPara.QsStatesEst = EstiQ[idEntity.InputIndex - 1, 0];
                inputPara.RsStatesEst = EstiR[idEntity.InputIndex - 1, 0];

                
                string slopeRowCsv =
                    idEntity.InputIndex == 1 ? matrix.ColumnCSV(0) :
                    idEntity.InputIndex == 2 ? matrix.ColumnCSV(1) :
                    idEntity.InputIndex == 3 ? matrix.ColumnCSV(2) :
                    idEntity.InputIndex == 4 ? matrix.ColumnCSV(3) :
                    idEntity.InputIndex == 5 ? matrix.ColumnCSV(4) :
                    idEntity.InputIndex == 6 ? matrix.ColumnCSV(5) :
                    idEntity.InputIndex == 7 ? matrix.ColumnCSV(6) :
                    idEntity.InputIndex == 8 ? matrix.ColumnCSV(7) :
                    idEntity.InputIndex == 9 ? matrix.ColumnCSV(8) :
                    idEntity.InputIndex == 10 ? matrix.ColumnCSV(9) : "";

                /*
                string slopeRowCsv =
                    idEntity.InputIndex == 1 ? psEntity.ModelSlope01CSV :
                    idEntity.InputIndex == 2 ? psEntity.ModelSlope02CSV :
                    idEntity.InputIndex == 3 ? psEntity.ModelSlope03CSV :
                    idEntity.InputIndex == 4 ? psEntity.ModelSlope04CSV :
                    idEntity.InputIndex == 5 ? psEntity.ModelSlope05CSV :
                    idEntity.InputIndex == 6 ? psEntity.ModelSlope06CSV :
                    idEntity.InputIndex == 7 ? psEntity.ModelSlope07CSV :
                    idEntity.InputIndex == 8 ? psEntity.ModelSlope08CSV :
                    idEntity.InputIndex == 9 ? psEntity.ModelSlope09CSV :
                    idEntity.InputIndex == 10 ? psEntity.ModelSlope10CSV : "";
                */
                if (string.IsNullOrEmpty(slopeRowCsv))
                {
                    inputPara.ModelSlope = new Matrix<double>(1, 10, 0);
                }
                else
                {
                    inputPara.ModelSlope = new Matrix<double>(10, slopeRowCsv, 0).Transform();
                }



                contextInputParas.Add(inputPara);
            }


            //ContextMisc
            contextMisc.ContextId = context.ContextId;
            contextMisc.ContextKey = context.ContextKey;

            if (psEntity != null)
            {
                contextMisc.ControllerQ = string.IsNullOrEmpty(psEntity.ControllerQ) ? double.NaN : double.Parse(psEntity.ControllerQ);
                contextMisc.ControllerR = string.IsNullOrEmpty(psEntity.ControllerR) ? double.NaN : double.Parse(psEntity.ControllerR);
            }


            if (lcEntity != null)
            {
                string[] mins = string.IsNullOrEmpty(lcEntity.MinLinearCSV) ? new string[] { } : lcEntity.MinLinearCSV.Split(',');
                contextMisc.Linear1Min = mins.Length > 0 ? string.IsNullOrEmpty(mins[0]) ? -99999999 : double.Parse(mins[0]) : -99999999;
                contextMisc.Linear2Min = mins.Length > 1 ? string.IsNullOrEmpty(mins[01]) ? -99999999 : double.Parse(mins[1]) : -99999999;

                string[] maxs = string.IsNullOrEmpty(lcEntity.MaxLinearCSV) ? new string[] { } : lcEntity.MaxLinearCSV.Split(',');
                contextMisc.Linear1Max = maxs.Length > 0 ? string.IsNullOrEmpty(maxs[0]) ? 99999999 : double.Parse(maxs[0]) : 99999999;
                contextMisc.Linear2Max = maxs.Length > 1 ? string.IsNullOrEmpty(maxs[01]) ? 99999999 : double.Parse(maxs[1]) : 99999999;
            }
            if (psEntity != null && !string.IsNullOrEmpty(psEntity.FfCoefficient))
            {
                contextMisc.FFCoefficient = new Matrix<double>(10, psEntity.FfCoefficient, 0).ColumnArray(0);
            }



            return contextInput;

        }

        public DTO.ContextConstants CreateContextConstants(DTO.ContextConstants contextConstants)
        {
            using EtchDBContext db = CreateDBContext();
            Entities.Context _context = db.ContextRepository.Find(contextConstants.ContextId);
            if (_context == null)
                throw new EtchException(ErrorCode.InvalidContextId);
            //DTO.Context context = this.GetContextInfo(contextConstants.ContextId);
            DTO.Context context = ConvertContextEntityToDTO(_context);
            BaseEntities.ChangeRequest cr = TryEditing(TxnContext.Area, ObjectName.Context.ToString(), "CreateStrategyConstant", TxnContext.UserName, TxnContext.Comment, TxnContext.TxnId, contextConstants.ContextKey, "NA");
            using var transaction = db.Database.BeginTransaction();
            try
            {
                Entities.Process _process = db.ProcessRepository.Find(context.ProcessId);
                if (_process == null)
                {
                    throw new EtchException(ErrorCode.InvalidProcessId);
                }
                StrategyConstant _scEntity = db.StrategyConstantRepository.Find(_context.ContextId);
                if (_scEntity != null)
                {
                    throw new ApiException(GeneralErrorCode.ResourceAlreadyExists);
                }

                if (!contextConstants.Validate(out string errorMessage))
                    throw new EtchException(ErrorCode.ValidateFail, errorMessage);

                StrategyConstant scEntity = new StrategyConstant();
                scEntity.ContextId = _context.ContextId;
                scEntity.Fab = _context.Fab;
                scEntity.ProductId = _context.ProductId;
                scEntity.Stage = _context.Stage;
                scEntity.Recipe = _context.Recipe;
                scEntity.StepName = _context.StepName;
                scEntity.StepNumber = _context.StepNumber;
                scEntity.Tool = _context.Tool;
                scEntity.Chamber = _context.Chamber;
                scEntity.ContextGroup = _context.ContextGroup;
                scEntity.AllowMissingPreMetro = contextConstants.OptAllowMissingPreMetro ? 1 : 0;
                scEntity.LimitLotsWithoutMetro = contextConstants.OptLimitLotsWithoutMetro;
                scEntity.LimitNoConsecutiveMaxAdjust = contextConstants.OptLimitNoConsecutiveMaxAdjust;
                scEntity.LotHoldMissingPreMetro = contextConstants.OptLotHoldMissingPreMet ? 1 : 0;
                scEntity.LotHoldPreDictionOOL = contextConstants.OptLotHoldPredicitonOOL ? 1 : 0;
                scEntity.LotHoldRecommendedOOL = contextConstants.OptLotHoldRecommendedOOL ? 1 : 0;
                scEntity.LotStageWaferUseCalcOffset = contextConstants.OptLotStageWaferUseCalcualteOffset;
                scEntity.LotStageWaferUseCalcPre = contextConstants.OptLotStageWaferUseCalcualtePre ? 1 : 0;
                scEntity.MaxTimeLastStateEstDays = contextConstants.OptMaxTimeLastEstDays;
                scEntity.PreLineAvgExpiredDay = contextConstants.OptPreLineAvgExpiredDay;
                scEntity.PreMetrologyExpiredDay = contextConstants.OptPreMetrologyExpiredDay;
                scEntity.MaxConsecutiveOos = contextConstants.OptLimitMaxConsecutiveOos;
                scEntity.MaxConsecutiveGof = contextConstants.OptLimitMaxConsecutiveGof;
                scEntity.R2RMode = "LL";
                scEntity.UseTarget = contextConstants.OptUseTarget ? 1 : 0;
                scEntity.TotalPostStepNumber = 0;
                scEntity.TotalPreStepNumber = 0;
                scEntity.InputSize = 0;
                scEntity.OutputSize = 0;
                scEntity.HydraFlag = contextConstants.OptHydraFlag ? 1 : 0;
                scEntity.HydraAllowingData = contextConstants.OptHydraAllowMissingData ? 1 : 0;
                scEntity.HydraAllowMissingDataNumber = (int)contextConstants.OptHydraAllowMissingDataNumber;
                scEntity.HydraManualDataEntry = contextConstants.OptHydraManualDataEntry ? 1 : 0;
                scEntity.HydraUseWaferMean = contextConstants.OptHydraUseWaferMean ? 1 : 0;
                scEntity.HydraUseZoneMean = contextConstants.OptHydraUseZoneMean ? 1 : 0;
                db.StrategyConstantRepository.Add(scEntity);

                _context.LastModifiedBy = TxnContext.UserName;
                _context.LastModifiedTime = cr.CrTimeStamp;
                db.ContextRepository.Update(_context);

                db.SaveChanges();
                transaction.Commit();

                //
                cr.Json02 = UtilityHelper.GetJsonByObject(contextConstants);
                cr.ContextGroupValue1 = _context.ContextId.ToString();
                cr.ContextGroupValue = string.Format("{0}:{1}:{2}:{3}:{4}:{5}:{6}:{7}:{8}", _context.Fab, _context.ProductId, _context.Stage, _context.Recipe, _context.StepName, _context.StepNumber, _context.Tool, _context.Chamber, _context.ContextGroup);
                cr.ContxtGroup = string.Format("{0}:{1}:{2}:{3}:{4}:{5}:{6}:{7}:{8}", "Fab", "ProductId", "Stage", "Recipe", "StepName", "StepNumber", "Tool", "Chamber", "ContextGroup");
                EndEditing(cr, true);
            }
            catch (Exception ex)
            {
                transaction.Rollback();
                cr.Reason = ex.Message.Substring(0, ex.Message.Length > 255 ? 255 : ex.Message.Length);
                if (cr != null) EndEditing(cr, false);
                throw;
            }
            return contextConstants;
        }

        public void UpdateContextConstants(DTO.ContextConstants contextConstants)
        {
            using EtchDBContext db = CreateDBContext();
            Entities.Context _context = db.ContextRepository.Find(contextConstants.ContextId);
            if (_context == null)
                throw new EtchException(ErrorCode.InvalidContextId);
            //DTO.Context context = this.GetContextInfo(contextConstants.ContextId);
            DTO.Context context = ConvertContextEntityToDTO(_context);
            BaseEntities.ChangeRequest cr = TryEditing(TxnContext.Area, ObjectName.Context.ToString(), "UpdateContextConstants", TxnContext.UserName, TxnContext.Comment, TxnContext.TxnId, contextConstants.ContextKey, "NA");

            using var transaction = db.Database.BeginTransaction();
            try
            {
                StrategyConstant scEntity = db.StrategyConstantRepository.Find(_context.ContextId);
                if (scEntity == null)
                    throw new EtchException(ErrorCode.InvalidContextId);

                if (!contextConstants.Validate(out string errorMessage))
                    throw new EtchException(ErrorCode.ValidateFail, errorMessage);

                DTO.ContextConstants old = ConvertEntityContextConstantstoDTO(scEntity);
                BaseDTO.CompareResult cc = contextConstants.Compare(old);
                if (!cc.IsChange)
                    throw new EtchException(ErrorCode.NothingIsChanged);

                cr.CrDetails = cc.ChangeContent;
                //
                scEntity.ContextId = _context.ContextId;
                scEntity.Fab = _context.Fab;
                scEntity.ProductId = _context.ProductId;
                scEntity.Stage = _context.Stage;
                scEntity.Recipe = _context.Recipe;
                scEntity.StepName = _context.StepName;
                scEntity.StepNumber = _context.StepNumber;
                scEntity.Tool = _context.Tool;
                scEntity.Chamber = _context.Chamber;
                scEntity.ContextGroup = _context.ContextGroup;
                scEntity.AllowMissingPreMetro = contextConstants.OptAllowMissingPreMetro ? 1 : 0;
                scEntity.LimitLotsWithoutMetro = contextConstants.OptLimitLotsWithoutMetro;
                scEntity.LimitNoConsecutiveMaxAdjust = contextConstants.OptLimitNoConsecutiveMaxAdjust;
                scEntity.LotHoldMissingPreMetro = contextConstants.OptLotHoldMissingPreMet ? 1 : 0;
                scEntity.LotHoldPreDictionOOL = contextConstants.OptLotHoldPredicitonOOL ? 1 : 0;
                scEntity.LotHoldRecommendedOOL = contextConstants.OptLotHoldRecommendedOOL ? 1 : 0;
                scEntity.LotStageWaferUseCalcOffset = contextConstants.OptLotStageWaferUseCalcualteOffset;
                scEntity.LotStageWaferUseCalcPre = contextConstants.OptLotStageWaferUseCalcualtePre ? 1 : 0;
                scEntity.MaxTimeLastStateEstDays = contextConstants.OptMaxTimeLastEstDays;
                scEntity.PreLineAvgExpiredDay = contextConstants.OptPreLineAvgExpiredDay;
                scEntity.PreMetrologyExpiredDay = contextConstants.OptPreMetrologyExpiredDay;
                scEntity.MaxConsecutiveOos = contextConstants.OptLimitMaxConsecutiveOos;
                scEntity.MaxConsecutiveGof = contextConstants.OptLimitMaxConsecutiveGof;
                scEntity.R2RMode = "LL";
                scEntity.UseTarget = contextConstants.OptUseTarget ? 1 : 0;
                scEntity.TotalPostStepNumber = 0;
                scEntity.TotalPreStepNumber = 0;
                scEntity.InputSize = 0;
                scEntity.OutputSize = 0;
                scEntity.HydraFlag = contextConstants.OptHydraFlag ? 1 : 0;
                scEntity.HydraAllowingData = contextConstants.OptHydraAllowMissingData ? 1 : 0;
                scEntity.HydraAllowMissingDataNumber = (int)contextConstants.OptHydraAllowMissingDataNumber;
                scEntity.HydraManualDataEntry = contextConstants.OptHydraManualDataEntry ? 1 : 0;
                scEntity.HydraUseWaferMean = contextConstants.OptHydraUseWaferMean ? 1 : 0;
                scEntity.HydraUseZoneMean = contextConstants.OptHydraUseZoneMean ? 1 : 0;
                db.StrategyConstantRepository.Update(scEntity);

                _context.LastModifiedBy = TxnContext.UserName;
                _context.LastModifiedTime = cr.CrTimeStamp;
                db.ContextRepository.Update(_context);

                db.SaveChanges();
                transaction.Commit();

                //

                cr.Json02 = UtilityHelper.GetJsonByObject(contextConstants);
                cr.ContextGroupValue1 = _context.ContextId.ToString();
                cr.ContextGroupValue = string.Format("{0}:{1}:{2}:{3}:{4}:{5}:{6}:{7}:{8}", _context.Fab, _context.ProductId, _context.Stage, _context.Recipe, _context.StepName, _context.StepNumber, _context.Tool, _context.Chamber, _context.ContextGroup);
                cr.ContxtGroup = string.Format("{0}:{1}:{2}:{3}:{4}:{5}:{6}:{7}:{8}", "Fab", "ProductId", "Stage", "Recipe", "StepName", "StepNumber", "Tool", "Chamber", "ContextGroup");
                EndEditing(cr, true);
            }
            catch (Exception ex)
            {
                transaction.Rollback();
                cr.Reason = ex.Message.Substring(0, ex.Message.Length > 255 ? 255 : ex.Message.Length);
                if (cr != null) EndEditing(cr, false);
                throw;
            }
        }

        public void DeleteContextConstants(int contextId)
        {

        }
        public DTO.ContextConstants GetContextConstants(int contextId)
        {
            //using (EtchDBContext db = CreateContext())
            using EtchDBContext db = CreateDBContext();
            //EtchDBContext db = _EtchDBContext;
            Entities.Context _context = db.ContextRepository.Find(contextId);
            if (_context == null)
                throw new EtchException(ErrorCode.InvalidContextId);
            //DTO.Context context = this.GetContext(contextId);
            DTO.Context context = ConvertContextEntityToDTO(_context);

            DTO.ContextConstants contextConstants = new ContextConstants();
            StrategyConstant scEntity = db.StrategyConstantRepository.Find(_context.ContextId);
            if (scEntity == null) return contextConstants;
            contextConstants.ContextId = scEntity.ContextId;
            contextConstants.ContextKey = context.ContextKey;
            contextConstants.OptAllowMissingPreMetro = scEntity.AllowMissingPreMetro == 1 ? true : false;
            contextConstants.OptLimitLotsWithoutMetro = scEntity.LimitLotsWithoutMetro;
            contextConstants.OptLimitNoConsecutiveMaxAdjust = scEntity.LimitNoConsecutiveMaxAdjust;
            contextConstants.OptLotHoldMissingPreMet = scEntity.LotHoldMissingPreMetro == 1 ? true : false;
            contextConstants.OptLotHoldPredicitonOOL = scEntity.LotHoldPreDictionOOL == 1 ? true : false;
            contextConstants.OptLotHoldRecommendedOOL = scEntity.LotHoldRecommendedOOL == 1 ? true : false;
            contextConstants.OptLotStageWaferUseCalcualteOffset = scEntity.LotStageWaferUseCalcOffset;
            contextConstants.OptLotStageWaferUseCalcualtePre = scEntity.LotStageWaferUseCalcPre == 1 ? true : false;
            contextConstants.OptMaxTimeLastEstDays = scEntity.MaxTimeLastStateEstDays;
            contextConstants.OptPreLineAvgExpiredDay = scEntity.PreLineAvgExpiredDay;
            contextConstants.OptPreMetrologyExpiredDay = scEntity.PreMetrologyExpiredDay;
            contextConstants.OptLimitMaxConsecutiveOos = scEntity.MaxConsecutiveOos;
            contextConstants.OptLimitMaxConsecutiveGof = scEntity.MaxConsecutiveGof;
            //contextConstants.OptR2RMode = "L2L";
            contextConstants.OptUseTarget = scEntity.UseTarget == 1 ? true : false;
            //contextConstants.OptTotalPostStepNumber = 0;
            //contextConstants.OptTotalPreStepNumber = 0;
            //contextConstants.OptInputSize = 0;
            //contextConstants.OptOutputSize = 0;
            contextConstants.OptHydraFlag = scEntity.HydraFlag == 1 ? true : false;
            contextConstants.OptHydraAllowMissingData = scEntity.HydraAllowingData == 1 ? true : false;
            contextConstants.OptHydraAllowMissingDataNumber = scEntity.HydraAllowMissingDataNumber;
            contextConstants.OptHydraManualDataEntry = scEntity.HydraManualDataEntry == 1 ? true : false;
            contextConstants.OptHydraUseWaferMean = scEntity.HydraUseWaferMean == 1 ? true : false;
            contextConstants.OptHydraUseZoneMean = scEntity.HydraUseZoneMean == 1 ? true : false; ;

            return contextConstants;
        }

        private DTO.ContextConstants ConvertEntityContextConstantstoDTO(StrategyConstant scEntity)
        {


            DTO.ContextConstants contextConstants = new ContextConstants();

            contextConstants.ContextId = scEntity.ContextId;
            contextConstants.ContextKey = string.Format("{0}:{1}:{2}:{3}:{4}:{5}:{6}:{7}:{8}", scEntity.Fab, scEntity.ProductId, scEntity.Stage, scEntity.Recipe, scEntity.StepName, scEntity.StepNumber, scEntity.Tool, scEntity.Chamber, scEntity.ContextGroup);

            contextConstants.OptAllowMissingPreMetro = scEntity.AllowMissingPreMetro == 1 ? true : false;
            contextConstants.OptLimitLotsWithoutMetro = scEntity.LimitLotsWithoutMetro;
            contextConstants.OptLimitNoConsecutiveMaxAdjust = scEntity.LimitNoConsecutiveMaxAdjust;
            contextConstants.OptLotHoldMissingPreMet = scEntity.LotHoldMissingPreMetro == 1 ? true : false;
            contextConstants.OptLotHoldPredicitonOOL = scEntity.LotHoldPreDictionOOL == 1 ? true : false;
            contextConstants.OptLotHoldRecommendedOOL = scEntity.LotHoldRecommendedOOL == 1 ? true : false;
            contextConstants.OptLotStageWaferUseCalcualteOffset = scEntity.LotStageWaferUseCalcOffset;
            contextConstants.OptLotStageWaferUseCalcualtePre = scEntity.LotStageWaferUseCalcPre == 1 ? true : false;
            contextConstants.OptMaxTimeLastEstDays = scEntity.MaxTimeLastStateEstDays;
            //contextConstants.OptR2RMode = "L2L";
            contextConstants.OptUseTarget = scEntity.UseTarget == 1 ? true : false;
            //contextConstants.OptTotalPostStepNumber = 0;
            //contextConstants.OptTotalPreStepNumber = 0;
            //contextConstants.OptInputSize = 0;
            //contextConstants.OptOutputSize = 0;
            contextConstants.OptHydraFlag = scEntity.HydraFlag == 1 ? true : false;
            contextConstants.OptHydraAllowMissingData = scEntity.HydraAllowingData == 1 ? true : false;
            contextConstants.OptHydraAllowMissingDataNumber = scEntity.HydraAllowMissingDataNumber;
            contextConstants.OptHydraManualDataEntry = scEntity.HydraManualDataEntry == 1 ? true : false;
            contextConstants.OptHydraUseWaferMean = scEntity.HydraUseWaferMean == 1 ? true : false;
            contextConstants.OptHydraUseZoneMean = scEntity.HydraUseZoneMean == 1 ? true : false; ;

            return contextConstants;
        }

        public DTO.SpecialJob CreateSpecialJob(DTO.SpecialJob specialJob)
        {
            using EtchDBContext db = CreateDBContext();
            Entities.Context contextEntity = db.ContextRepository.Find(specialJob.ContextId);
            if (contextEntity == null)
                throw new EtchException(ErrorCode.InvalidContextId);
            DTO.Context context = ConvertContextEntityToDTO(contextEntity);

            BaseEntities.ChangeRequest cr = TryEditing(TxnContext.Area, ObjectName.SpecialJob.ToString(), "CreateSpecialJob", TxnContext.UserName, TxnContext.Comment, TxnContext.TxnId, specialJob.JobKey, "NA");

            using (var transaction = db.Database.BeginTransaction())
            {
                try
                {
                    //TODO the business here
                    List<Entities.SpecialJob> _specialJobs = db.SpecialJobRepository.Where(t => t.LotId == specialJob.LotId && t.RunCardId == specialJob.RuncardId && t.SplitId == specialJob.SplitId
                    && t.Tool == specialJob.Tool && t.Chamber == specialJob.Chamber
                    && t.ProductId == specialJob.ProductId && t.Stage == specialJob.Stage && t.Recipe == specialJob.Recipe
                    && t.IsValid == 1 && t.JobCompleted == 0).ToList();
                    if (_specialJobs != null && _specialJobs.Count() > 0)
                    {
                        throw new ApiException(GeneralErrorCode.ResourceAlreadyExists);
                    }

                    if (specialJob.SpecialJobParameters == null || specialJob.SpecialJobParameters.Count() <= 0)
                    {
                        throw new EtchException(ErrorCode.ValidateFail, "None Parameters found!");
                    }


                    Entities.SpecialJob sj = new Entities.SpecialJob();
                    sj.Fab = TxnContext.Fab;
                    sj.JobId = cr.CrTimeStamp.ToString("yyyyMMddHH:mm:ss.fff");
                    sj.LotId = specialJob.LotId;
                    sj.RunCardId = specialJob.RuncardId;
                    sj.SplitId = specialJob.SplitId;
                    sj.Fab = TxnContext.Fab;
                    sj.ProductId = specialJob.ProductId;
                    sj.Stage = specialJob.Stage;
                    sj.Recipe = specialJob.Recipe;
                    sj.StepName = "NA";// specialJob.StepName;
                    sj.StepNumber = "NA";//specialJob.StepNumber;
                    sj.Tool = specialJob.Tool;
                    sj.Chamber = specialJob.Chamber;
                    sj.ContextGroup = "NA";// specialJob.ContextGroup;
                    sj.ContextId = specialJob.ContextId;
                    sj.CreateTime = cr.CrTimeStamp;
                    sj.IsValid = 1;
                    sj.JobCompleted = 0;
                    sj.UsedTime = null;
                    sj.UserId = TxnContext.UserName;
                    sj.LastModifiedTime = cr.CrTimeStamp;
                    sj.LastModifiedBy = TxnContext.UserName;

                    db.SpecialJobRepository.Add(sj);

                    int i = 0;
                    foreach (DTO.SpecialJobParameter sjp in specialJob.SpecialJobParameters)
                    {
                        Entities.SpecialJobParameter sjpEntity = new Entities.SpecialJobParameter();
                        sjpEntity.JobId = sj.JobId;
                        sjpEntity.ParameterSeq = ++i;
                        sjpEntity.ParameterName = sjp.ParameterName;
                        sjpEntity.ParameterValue = sjp.InputValue + "";
                        db.SpecialJobParameterRepository.Add(sjpEntity);
                    }

                    db.SaveChanges();
                    transaction.Commit();
                    //
                    specialJob.CreateTime = cr.CrTimeStamp;
                    specialJob.JobId = sj.JobId;
                    specialJob.LastModifiedTime = cr.CrTimeStamp;
                    cr.Json01 = UtilityHelper.GetJsonByObject(specialJob);
                    cr.ContextGroupValue1 = specialJob.JobId.ToString();
                    cr.ContextGroupValue = specialJob.JobKey;
                    cr.ContxtGroup = string.Format("{0}:{1}:{2}:{3}:{4}:{5}:{6}:{7}:{8}", "LotId", "RuncardId", "SplitId", "Fab", "ProductId", "Stage", "Recipe", "Tool", "Chamber");

                    EndEditing(cr, true);
                }
                catch (Exception ex)
                {
                    transaction.Rollback();
                    cr.Reason = ex.Message.Substring(0, ex.Message.Length > 255 ? 255 : ex.Message.Length);
                    if (cr != null) EndEditing(cr, false);
                    throw;
                }
            }

            return specialJob;
        }

        public void DeleteSpecialJob(string jobId)
        {
            using EtchDBContext db = CreateDBContext();
            Entities.SpecialJob specialJob = db.SpecialJobRepository.Find(jobId);
            if (specialJob == null)
                throw new EtchException(ErrorCode.ResourceNotExisted);
            DTO.SpecialJob dtoSpecialJob = ConvertEntitySpecialJob2DTO(specialJob);

            BaseEntities.ChangeRequest cr = TryEditing(TxnContext.Area, ObjectName.SpecialJob.ToString(), "DeleteSpecialJob", TxnContext.UserName, TxnContext.Comment, TxnContext.TxnId, dtoSpecialJob.JobKey, "NA");

            using var transaction = db.Database.BeginTransaction();
            try
            {

                //TODO the business here
                specialJob.IsValid = 0;
                specialJob.LastModifiedTime = cr.CrTimeStamp;
                specialJob.LastModifiedBy = TxnContext.UserName;
                db.SpecialJobRepository.Update(specialJob);
                //SpecialJobParameterRepository.Delete(t => t.JobId == specialJob.JobId);
                db.SaveChanges();
                transaction.Commit();

                //
                cr.Json02 = UtilityHelper.GetJsonByObject(dtoSpecialJob);
                cr.ContextGroupValue1 = specialJob.JobId.ToString();
                cr.ContextGroupValue = dtoSpecialJob.JobKey;
                cr.ContxtGroup = string.Format("{0}:{1}:{2}:{3}:{4}:{5}:{6}:{7}:{8}", "LotId", "RuncardId", "SplitId", "Fab", "ProductId", "Stage", "Recipe", "Tool", "Chamber");

                EndEditing(cr, true);
            }
            catch (Exception ex)
            {
                transaction.Rollback();
                cr.Reason = ex.Message.Substring(0, ex.Message.Length > 255 ? 255 : ex.Message.Length);
                if (cr != null) EndEditing(cr, false);
                throw;
            }
        }

        public void UpdateSpecialJob(DTO.SpecialJob specialJob)
        {
            using EtchDBContext db = CreateDBContext();
            BaseEntities.ChangeRequest cr = TryEditing(TxnContext.Area, ObjectName.SpecialJob.ToString(), "UpdateSpecialJob", TxnContext.UserName, TxnContext.Comment, TxnContext.TxnId, specialJob.JobKey, "NA");

            using var transaction = db.Database.BeginTransaction();
            try
            {
                //TODO the business here
                DTO.SpecialJob oldSpecialJob = GetSpecialJobInfo(specialJob.JobId);
                if (!specialJob.Validate(out string validString))
                    throw new EtchException(ErrorCode.ValidateFail, validString);

                if (!specialJob.IsValid || specialJob.JobCompleted)
                {
                    throw new EtchException(ErrorCode.ValidateFail, "Special Job is not valid or Completed ,Can't update!");
                }

                DTO.Context context = null;
                try
                {
                    context = GetContextInfo(specialJob.ContextId);
                }
                catch
                {
                    throw new EtchException(ErrorCode.ValidateFail, "The Context to which the special job attached is deleted , Can't update!");
                }

                BaseDTO.CompareResult result = specialJob.Compare(oldSpecialJob);
                if (!result.IsChange)
                    throw new EtchException(ErrorCode.NothingIsChanged);

                cr.CrDetails = result.ChangeContent;

                db.SpecialJobParameterRepository.RemoveRange(db.SpecialJobParameterRepository.Where(t => t.JobId == specialJob.JobId));

                int i = 0;
                foreach (DTO.SpecialJobParameter sjp in specialJob.SpecialJobParameters)
                {
                    Entities.SpecialJobParameter sjpEntity = new Entities.SpecialJobParameter();
                    sjpEntity.JobId = specialJob.JobId;
                    sjpEntity.ParameterSeq = ++i;
                    sjpEntity.ParameterName = sjp.ParameterName;
                    sjpEntity.ParameterValue = sjp.InputValue + "";
                    db.SpecialJobParameterRepository.Add(sjpEntity);
                }


                Entities.SpecialJob sj = db.SpecialJobRepository.Where(t => t.JobId == specialJob.JobId).ToList().First();
                sj.LastModifiedTime = cr.CrTimeStamp;
                sj.LastModifiedBy = TxnContext.UserName;
                db.SpecialJobRepository.Update(sj);

                db.SaveChanges();
                transaction.Commit();
                //
                cr.Json01 = UtilityHelper.GetJsonByObject(oldSpecialJob);
                cr.Json02 = UtilityHelper.GetJsonByObject(specialJob);
                cr.ContextGroupValue1 = specialJob.JobId.ToString();
                cr.ContextGroupValue = specialJob.JobKey;
                cr.ContxtGroup = string.Format("{0}:{1}:{2}:{3}:{4}:{5}:{6}:{7}:{8}", "LotId", "RuncardId", "SplitId", "Fab", "ProductId", "Stage", "Recipe", "Tool", "Chamber");

                EndEditing(cr, true);
            }
            catch (Exception ex)
            {
                transaction.Rollback();
                cr.Reason = ex.Message.Substring(0, ex.Message.Length > 255 ? 255 : ex.Message.Length);
                if (cr != null) EndEditing(cr, false);
                throw;
            }
        }

        public DTO.SpecialJob GetSpecialJobInfo(string jobId)
        {

            using EtchDBContext db = CreateDBContext();
            //EtchDBContext db = _EtchDBContext;
            {
                Entities.SpecialJob _specialJob = db.SpecialJobRepository.Find(jobId);
                if (_specialJob == null)
                    throw new EtchException(ErrorCode.ResourceNotExisted);
                IList<InputDefinition> ids = new List<InputDefinition>();
                try
                {
                    ids = db.InputDefinitionRepository.Where(t => t.ContextId == _specialJob.ContextId).ToList();

                }
                catch (Exception)
                {

                }

                DTO.SpecialJob specialJob = ConvertEntitySpecialJob2DTO(_specialJob);
                specialJob.SpecialJobParameters = new List<DTO.SpecialJobParameter>();
                List<Entities.SpecialJobParameter> sjps = db.SpecialJobParameterRepository.Where(t => t.JobId == specialJob.JobId).OrderBy(t => t.ParameterSeq).ToList();
                foreach (Entities.SpecialJobParameter sjpEntity in sjps)
                {
                    DTO.SpecialJobParameter sjp = new DTO.SpecialJobParameter();
                    sjp.JobId = sjpEntity.JobId;
                    sjp.ParameterName = sjpEntity.ParameterName;
                    sjp.InputValue = string.IsNullOrEmpty(sjpEntity.ParameterValue) ? new decimal?() : decimal.Parse(sjpEntity.ParameterValue);
                    List<InputDefinition> hs = ids.Where(t => t.InputParameterName.Equals(sjp.ParameterName)).ToList();
                    if (hs != null && hs.Count > 0)
                    {
                        sjp.Max = new decimal(hs[0].InputMax);
                        sjp.Min = new decimal(hs[0].InputMin);
                        sjp.Unit = hs[0].Unit;
                    }
                    specialJob.SpecialJobParameters.Add(sjp);
                }

                return specialJob;
            }
        }

        public List<DTO.SpecialJob> GetSpecialJobList(IQueryCollection query)
        {
            using EtchDBContext db = CreateDBContext();
            var queryable = db.SpecialJobRepository.AsNoTracking().Where(s => s.Fab == TxnContext.Fab).ApplyFilters(query);

            var sortable = queryable.ApplySorters(query);
            List<Entities.SpecialJob> specialJobEntities = sortable.PageToList(query);

            return specialJobEntities.Select(job => ConvertEntitySpecialJob2DTO(job)).ToList();
        }

        public object[] GetSpecialJobValueList(IQueryCollection query, string propertyName)
        {
            using EtchDBContext db = CreateDBContext();

            var queryable = db.SpecialJobRepository.AsNoTracking().Where(s => s.Fab == TxnContext.Fab).ApplyFilters(query);
            return queryable.GetValueList(query, propertyName);
        }

        public int GetSpecialJobCount(IQueryCollection query)
        {
            using EtchDBContext db = CreateDBContext();

            return db.SpecialJobRepository.AsNoTracking().Where(s => s.Fab == TxnContext.Fab).ApplyFilters(query).Count();
        }

        private DTO.SpecialJob ConvertEntitySpecialJob2DTO(Entities.SpecialJob sj)
        {
            DTO.SpecialJob specialJob = new DTO.SpecialJob
            {
                JobId = sj.JobId,
                Fab = sj.Fab,
                ProductId = sj.ProductId,
                Stage = sj.Stage,
                Recipe = sj.Recipe,
                StepName = sj.StepName,
                StepNumber = sj.StepNumber,
                Tool = sj.Tool,
                Chamber = sj.Chamber,
                ContextGroup = sj.ContextGroup,
                CreateTime = sj.CreateTime,
                UserId = sj.UserId,
                UsedTime = sj.UsedTime,
                ContextId = sj.ContextId,
                IsValid = sj.IsValid == 1 ? true : false,
                JobCompleted = sj.JobCompleted == 1 ? true : false,
                LotId = sj.LotId,
                RuncardId = sj.RunCardId,
                SplitId = sj.SplitId,
                LastModifiedBy = sj.LastModifiedBy,
                LastModifiedTime = sj.LastModifiedTime
            };
            return specialJob;
        }

    }
}
