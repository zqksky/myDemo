﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Contracts;
using System.Linq;
using System.Linq.Dynamic.Core;
using System.Linq.Expressions;
using System.Reflection;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using AMAT.R2R.Server.Base;
using AMAT.R2R.Server.Base.Constants;
using AMAT.R2R.Server.Base.Exceptions;
using AMAT.R2R.Server.Base.Extensions;
using AMAT.R2R.Server.Base.Helpers;
using AMAT.R2R.Server.Base.Repository;
using AMAT.R2R.Server.Base.Service;
using AMAT.R2R.Server.Etch.Entities;
using AMAT.R2R.Server.Etch.Exceptions;
using AMAT.R2R.Server.Etch.Repository;
using AMAT.R2R.Shared.Etch.DTO;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Razor.Language;
using Microsoft.CodeAnalysis.CSharp.Syntax;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Internal;
using Microsoft.EntityFrameworkCore.Storage;
using Namotion.Reflection;
using BaseDTO = AMAT.R2R.Shared.Base.DTO;
using BaseEntities = AMAT.R2R.Server.Base.Entities;
using DTO = AMAT.R2R.Shared.Etch.DTO;
using Entities = AMAT.R2R.Server.Etch.Entities;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;

namespace AMAT.R2R.Server.Etch.Services
{
    public class ProcessService : EtchService, IProcessService
    {
        public ProcessService(IServiceProvider serviceProvider, ILogger<ProcessService> logger) : base(serviceProvider, logger)
        {

        }

        #region Process CRUD

        public DTO.Process CreateProcess(DTO.Process process)
        {
            process.LastModifiedBy = TxnContext.UserName;
            process.LastModifiedTime = DateTime.Now;

            using EtchDBContext db = CreateDBContext();
            BaseEntities.ChangeRequest cr = TryEditing(TxnContext.Area, ObjectName.Process.ToString(), "CreateProcess", TxnContext.UserName, TxnContext.Comment, TxnContext.TxnId, process.ProcessKey, "NA");
            Entities.Process processEntity = null;

            using (var transaction = db.Database.BeginTransaction())
            {
                try
                {
                    IQueryable<Entities.Process> _processes = db.ProcessRepository.Where(t => t.Fab == process.Fab && t.ProductId == process.ProductId && t.Stage == process.Stage && t.Recipe == process.Recipe && t.StepName == process.StepName && t.StepNumber == process.StepNumber);
                    if (_processes != null && _processes.Count() > 0)
                    {
                        EndEditing(cr, false);
                        throw new ApiException(GeneralErrorCode.ResourceAlreadyExists);
                    }

                    process.ProcessId = GetNextId(TxnContext.Area, ObjectName.Process);
                    if (process.ProcessId == 0)
                        throw new EtchException(ErrorCode.ValidateFail, "Fail to generate Id!");

                    processEntity = ConvertDTOProcessToEntity(process);
                    processEntity.LastModifiedBy = TxnContext.UserName;
                    processEntity.LastModifiedTime = cr.CrTimeStamp;
                    processEntity = db.ProcessRepository.Add(processEntity).Entity;

                    db.SaveChanges();
                    transaction.Commit();

                    //
                    cr.ContextGroupValue1 = processEntity.ProcessId.ToString();
                    cr.ContextGroupValue = string.Format("{0}:{1}:{2}:{3}:{4}:{5}", processEntity.Fab, processEntity.ProductId, processEntity.Stage, processEntity.Recipe, processEntity.StepName, processEntity.StepNumber);
                    cr.ContxtGroup = string.Format("{0}:{1}:{2}:{3}:{4}:{5}", "Fab", "ProductId", "Stage", "Recipe", "StepName", "StepNumber");

                    EndEditing(cr, true);
                }
                catch (Exception ex)
                {
                    transaction.Rollback();
                    cr.Reason = ex.Message.Substring(0, ex.Message.Length > 255 ? 255 : ex.Message.Length);
                    EndEditing(cr, false);
                    throw;
                }
            }
            return ConvertProcessEntityToDTO(processEntity);

        }

        public void UpdateProcess(DTO.Process process)
        {
            using EtchDBContext db = CreateDBContext();
            BaseEntities.ChangeRequest cr = TryEditing2(TxnContext.Area, ObjectName.Process.ToString(), "UpdateProcess", TxnContext.UserName, TxnContext.Comment, TxnContext.TxnId, "NA", process.ProcessId.ToString());

            using var transaction = db.Database.BeginTransaction();
            try
            {
                //TODO business log
                Entities.Process oldprocessEntity = db.ProcessRepository.Find(process.ProcessId);
                DTO.Process _oldProcess = ConvertProcessEntityToDTO(oldprocessEntity);
                if (_oldProcess == null)
                    throw new EtchException(ErrorCode.InvalidProcessKey);

                BaseDTO.CompareResult compareResult = process.Compare(_oldProcess);
                cr.CrDetails = compareResult.ChangeContent;
                if (!compareResult.IsChange)
                    throw new EtchException(ErrorCode.NothingIsChanged);

                Entities.Process processEntity = ConvertDTOProcessToEntity(process);
                oldprocessEntity.ProcessEnabled = processEntity.ProcessEnabled;
                oldprocessEntity.OptContextGroupEnabled = processEntity.OptContextGroupEnabled;
                oldprocessEntity.LastModifiedBy = TxnContext.UserName;
                oldprocessEntity.LastModifiedTime = cr.CrTimeStamp;
                db.ProcessRepository.Update(oldprocessEntity);

                db.SaveChanges();
                transaction.Commit();

                //

                cr.ContextGroupValue = string.Format("{0}:{1}:{2}:{3}:{4}:{5}", processEntity.Fab, processEntity.ProductId, processEntity.Stage, processEntity.Recipe, processEntity.StepName, processEntity.StepNumber);
                cr.ContxtGroup = string.Format("{0}:{1}:{2}:{3}:{4}:{5}", "Fab", "ProductId", "Stage", "Recipe", "StepName", "StepNumber");
                //
                cr.CrDetails = compareResult.ChangeContent;
                EndEditing(cr, true);
            }
            catch (Exception ex)
            {
                transaction.Rollback();
                cr.Reason = ex.Message.Substring(0, ex.Message.Length > 255 ? 255 : ex.Message.Length);
                if (cr != null) EndEditing(cr, false);
                throw;
            }
        }


        #region Paging & Filtering
        public int GetProcessCount(IQueryCollection query)
        {
            using EtchDBContext db = CreateDBContext();
            return db.ProcessRepository.AsNoTracking().Where(p => p.Fab == TxnContext.Fab).ApplyFilters(query).Count();
        }

        public object[] GetProcessValueList(IQueryCollection query, string propertyName)
        {
            using EtchDBContext db = CreateDBContext();
            return db.ProcessRepository.AsNoTracking().Where(p => p.Fab == TxnContext.Fab).GetValueList(query, propertyName);
        }

        /// <summary>
        /// Get the Overview list for all the process
        /// </summary>
        /// <returns></returns>
        public List<DTO.Process> GetProcessList(IQueryCollection query)
        {
            Logger.LogTrace($"Starting {nameof(GetProcessList)}", query.ToList().Select(kvp => $"{kvp.Key}={kvp.Value}"));
            using EtchDBContext db = CreateDBContext();

            var processEntityList = db.ProcessRepository.AsNoTracking().Where(p => p.Fab == TxnContext.Fab).ApplyFilters(query).ApplySorters(query).PageToList(query);

            List<DTO.Process> processDtoList = processEntityList.Select(p => ConvertProcessEntityToDTO(p)).ToList();
            return processDtoList;
        }
        #endregion

        private void FillProcessInformation(DTO.Process process)
        {
            using EtchDBContext db = CreateDBContext();
            process.AvailablePreMetrology = GetPreMetrologyList(process.ProcessId);
            process.AvailablePostMetrology = GetPostMetrologyList(process.ProcessId);

            // OutputSettings
            process.OutputSettings = db.PostMetrologySettingRepository.AsNoTracking().Where(t => t.ProcessId == process.ProcessId).OrderBy(t => t.OutputIndex).Select(t => ConvertOutputSettingEntityToDTO(t)).ToList();

            // FeedforwardSettings
            process.FeedforwardSettings = db.PreMetrologySettingRepository.AsNoTracking().Where(t => t.ProcessId == process.ProcessId).OrderBy(t => t.OutputIndex).Select(t => ConvertFeedForwardSettingEntityToDTO(t)).ToList();
        }

        private static OutputSetting ConvertOutputSettingEntityToDTO(PostMetrologySetting t)
        {
            var processKey = $"{t.Fab}:{t.ProductId}:{t.Stage}:{t.Recipe}:{t.StepName}:{t.StepNumber}";
            return new DTO.OutputSetting()
            {
                ProcessKey = processKey,
                OutputIndex = t.OutputIndex,
                Target = t.Target,
                UpperLimit = t.UpperLimits,
                LowerLimit = t.LowerLimit,
                Unit = t.Unit,
                QualityThreshold = t.DataQualityThreshold,
                QualityItemName = t.QualityDataItemName,
                OptUseOOLPostMetro = 1 == t.UseOOLPostMetro,
                OptUseOOLRange = 1 == t.UseOOLRange,
                OptUseOOLStdDev = 1 == t.UseOOLStdDev,
                ZonalFlag = 1 == t.ZonalFlag,
                OptStdDevThreshold = t.StdDevThreshold,
                OptRangeThreshold = t.RangeThreshold,
                OptNoOfSitePerWafer = (int)t.NoOfSitesPerWafer,
                OptMinPercentRemaining = t.MinPercentRemaining,
                OptLowerBetterFilt = 1 == t.LowerIsBetterFilter,
                ZonalDefinition001_Output = t.ZonalDefinition01Output,
                ZonalDefinition002_Output = t.ZonalDefinition02Output,
                ZonalDefinition003_Output = t.ZonalDefinition03Output,
                ZonalDefinition004_Output = t.ZonalDefinition04Output,
                ZonalDefinition005_Output = t.ZonalDefinition05Output,
                ZonalDefinition006_Output = t.ZonalDefinition06Output,
                ZonalDefinition007_Output = t.ZonalDefinition07Output,
                ZonalDefinition008_Output = t.ZonalDefinition08Output,
                ZonalDefinition009_Output = t.ZonalDefinition09Output,
                ZonalDefinition010_Output = t.ZonalDefinition10Output,
                PostMetrologys = new List<PostMetrology>()
                {
                    new PostMetrology()
                    {
                        ProcessKey = processKey,
                        Fab = t.MetroFab,
                        MetroStage = t.MetroStage,
                        MetroRecipe = t.MetroRecipe,
                        MetroStepName = t.MetroStepName,
                        MetroStepNumber = t.MetroStepNumber,
                        ProcessId = t.ProcessId
                    }
                },
                Parameter = new BaseDTO.Parameter() { ParameterName = t.MeasDataItemName },
                ProcessId = t.ProcessId,
                PostMetroId = t.PostMetroId
            };
        }

        private static FeedforwardSetting ConvertFeedForwardSettingEntityToDTO(PreMetrologySetting t)
        {
            var processKey = $"{t.Fab}:{t.ProductId}:{t.Stage}:{t.Recipe}:{t.StepName}:{t.StepNumber}";
            return new DTO.FeedforwardSetting()
            {
                ProcessKey = processKey,
                OutputIndex = t.OutputIndex,
                Target = t.Target,
                UpperLimit = t.UpperLimit,
                LowerLimit = t.LowerLimit,
                Unit = t.Unit,
                QualityThreshold = t.DataQualityThreshold,
                QualityItemName = t.QualityDataItemName,
                OptUseOOLPreMetro = t.UseOOLPreMetro == 1,
                OptUseOOLRange = t.UseOOLRange == 1,
                OptUseOOLStdDev = t.UseOOLStdDev == 1,
                OptStdDevThreshold = t.StdDevThreshold,
                OptRangeThreshold = t.RangeThreshold,
                OptNoOfSitePerWafer = (int)t.NoOfSitesPerWafer,
                OptOffsetPerSlot = t.OffsetPerSlotId,
                OptMinPercentRemaining = t.MinPercentRemaining,
                OptLowerBetterFilt = t.LowerIsBetterFilter == 1,
                OptLambda = t.Lambda,
                PreMetrologys = new List<PreMetrology>()
                {
                    new PreMetrology()
                    {
                        ProcessKey = processKey,
                        Fab = t.MetroFab,
                        MetroStage = t.MetroStage,
                        MetroRecipe = t.MetroRecipe,
                        MetroStepName = t.MetroStepName,
                        MetroStepNumber = t.MetroStepNumber,
                        ProcessId = t.ProcessId
                    }
                },
                Parameter = new BaseDTO.Parameter() { ParameterName = t.MeasDataItemName },
                ProcessId = t.ProcessId,
                PreMetroId = t.PreMetroId
            };
        }

        public DTO.Process GetProcessInfoByID(int processId)
        {
            //using (EtchDBContext db = CreateContext())
            using EtchDBContext db = CreateDBContext();
            //EtchDBContext db = _EtchDBContext;
            var processEntity = db.ProcessRepository.Find(processId);
            if (processEntity == null)
                throw new ApiException(GeneralErrorCode.ResourceNotFound);

            var process = ConvertProcessEntityToDTO(processEntity);
            return process;
        }

        private void ParseFields(string id, out string fab, out string productId, out string stage, out string recipe, out string stepName, out string stepNumber)
        {
            var fields = id?.Split(':');
            if (fields == null || fields.Length != 6)
            {
                throw new EtchException(ErrorCode.InvalidProcessKey, "Invalid Process Key.");
            }

            fab = fields[0];
            productId = fields[1];
            stage = fields[2];
            recipe = fields[3];
            stepName = fields[4];
            stepNumber = fields[5];
        }

        private Entities.Process ConvertDTOProcessToEntity(DTO.Process dtoProcess)
        {
            return dtoProcess == null ? null : new Entities.Process()
            {
                ProcessId = dtoProcess.ProcessId,
                Fab = dtoProcess.Fab,
                ProductId = dtoProcess.ProductId,
                Stage = dtoProcess.Stage,
                Recipe = dtoProcess.Recipe,
                StepName = dtoProcess.StepName,
                StepNumber = dtoProcess.StepNumber,
                ProcessEnabled = dtoProcess.ProcessEnabled ? 1 : 0,
                OptContextGroupEnabled = dtoProcess.OptContextGroupEnabled ? 1 : 0,
                LastModifiedBy = dtoProcess.LastModifiedBy,
                LastModifiedTime = dtoProcess.LastModifiedTime
            };
        }


        private DTO.Process ConvertProcessEntityToDTO(Entities.Process entityProcess)
        {
            var process = entityProcess == null ? null : new DTO.Process()
            {
                Fab = entityProcess.Fab,
                ProductId = entityProcess.ProductId,
                Recipe = entityProcess.Recipe,
                Stage = entityProcess.Stage,
                StepName = entityProcess.StepName,
                StepNumber = entityProcess.StepNumber,
                ProcessEnabled = entityProcess.ProcessEnabled != 0,
                LastModifiedBy = entityProcess.LastModifiedBy,
                LastModifiedTime = entityProcess.LastModifiedTime,
                OptContextGroupEnabled = entityProcess.OptContextGroupEnabled != 0,
                ProcessId = entityProcess.ProcessId
            };

            if (process != null)
            {
                FillProcessInformation(process);
            }

            return process;
        }


        public void DeleteProcess(int processId)
        {
            using EtchDBContext db = CreateDBContext();
            BaseEntities.ChangeRequest cr = TryEditing2(TxnContext.Area, ObjectName.Process.ToString(), "DeleteProcess", TxnContext.UserName, TxnContext.Comment, TxnContext.TxnId, "NA", processId.ToString());

            using var transaction = db.Database.BeginTransaction();
            try
            {
                Entities.Process processEntity = db.ProcessRepository.Find(processId);
                if (processEntity == null)
                    throw new ApiException(GeneralErrorCode.ResourceNotFound);

                List<PreMetrologySetting> pres = db.PreMetrologySettingRepository.Where(t => t.ProcessId == processEntity.ProcessId).ToList();
                if (pres != null && pres.Count() > 0)
                    throw new ApiException(GeneralErrorCode.RequstChangeFail, "Some Feedfoward found , please delete the related settings first!");

                List<PostMetrologySetting> posts = db.PostMetrologySettingRepository.Where(t => t.ProcessId == processEntity.ProcessId).ToList();
                if (posts != null && posts.Count() > 0)
                    throw new ApiException(GeneralErrorCode.RequstChangeFail, "Some Output found , please delete the related settings first!");

                List<Entities.Context> contexts = db.ContextRepository.Where(t => t.ProcessId == processEntity.ProcessId).ToList();
                if (contexts != null && contexts.Count() > 0)
                    throw new ApiException(GeneralErrorCode.RequstChangeFail, "Some Context found , please delete the related Context first!");

                //delete the process
                db.ProcessRepository.Remove(processEntity);
                //delete the processmetrology mapping
                db.ProcessMetrologyRepository.RemoveRange(db.ProcessMetrologyRepository.Where(t => t.ProcessId == processEntity.ProcessId));

                db.SaveChanges();
                transaction.Commit();

                //
                cr.ContextGroupValue = string.Format("{0}:{1}:{2}:{3}:{4}:{5}", processEntity.Fab, processEntity.ProductId, processEntity.Stage, processEntity.Recipe, processEntity.StepName, processEntity.StepNumber);
                cr.ContxtGroup = string.Format("{0}:{1}:{2}:{3}:{4}:{5}", "Fab", "ProductId", "Stage", "Recipe", "StepName", "StepNumber");
                EndEditing(cr, true);
            }
            catch (Exception ex)
            {
                transaction.Rollback();
                cr.Reason = ex.Message.Substring(0, ex.Message.Length > 255 ? 255 : ex.Message.Length);
                //cr.Reason = ex.Message.Substring(0, 255);
                if (cr != null) EndEditing(cr, false);
                throw;
            }
        }

        #endregion

        #region Feedforward Settings

        public DTO.FeedforwardSetting CreateFeedforwardSetting(DTO.FeedforwardSetting feedwardSetting)
        {
            using (EtchDBContext db = CreateDBContext())
            {
                BaseEntities.ChangeRequest cr = TryEditing(TxnContext.Area, ObjectName.Process.ToString(), "CreateFeedforwardSetting", TxnContext.UserName, TxnContext.Comment, TxnContext.TxnId, feedwardSetting.ProcessKey, "NA");
                using var transaction = db.Database.BeginTransaction();
                try
                {
                    Entities.Process _process = db.ProcessRepository.Find(feedwardSetting.ProcessId);
                    if (_process == null)
                    {
                        throw new EtchException(ErrorCode.ValidateFail, "None Process Found!");
                    }

                    if (!feedwardSetting.Validate(out string message))
                        throw new EtchException(ErrorCode.ValidateFail, message);

                    List<FeedforwardSetting> ffs = GetFeedforwardSettingList(feedwardSetting.ProcessId);

                    if (ffs.Count >= 2)
                        throw new EtchException(ErrorCode.FeedforwardSettingShouldLessThanThree);

                    List<FeedforwardSetting> ffs2 = ffs.FindAll(t => t.Parameter.Equals(feedwardSetting.Parameter.ParameterName));
                    if (ffs2.Count() > 0)
                        throw new EtchException(ErrorCode.FeedforwardSettingExisted, "Duplicate Feedforward Parameter found");

                    ffs2 = ffs.FindAll(t => t.ProcessKey.Equals(feedwardSetting.ProcessKey) && t.PreMetrologys.First().MetrologyKey.Equals(feedwardSetting.PreMetrologys.First().MetrologyKey));
                    if (ffs2.Count() > 0)
                        throw new EtchException(ErrorCode.FeedforwardSettingExisted, "A Feedforward already defined on the same Metrology");

                    //to add 
                    ParseFields(feedwardSetting.ProcessKey, out string fab, out string productId, out string stage, out string recipe, out string stepName, out string stepNumber);
                    PreMetrology post = feedwardSetting.PreMetrologys.First();

                    int metrologyId = GetNextId(TxnContext.Area, ObjectName.Metrology);
                    int outputIndex = ffs.Count() > 0 ? ffs.Max(t => t.OutputIndex) + 1 : 1;
                    feedwardSetting.PreMetroId = metrologyId;
                    db.PreMetrologySettingRepository.Add(ConvertFeedForwardSettingDTOtoEntity(feedwardSetting, _process, ffs, fab, productId, stage, recipe, stepName, stepNumber, post, metrologyId));


                    _process.LastModifiedTime = cr.CrTimeStamp;
                    _process.LastModifiedBy = TxnContext.UserName;
                    db.ProcessRepository.Update(_process);

                    db.SaveChanges();
                    transaction.Commit();

                    //
                    cr.CrDetails = feedwardSetting + " Added";
                    cr.Json01 = "";
                    cr.Json02 = UtilityHelper.GetJsonByObject(feedwardSetting);
                    cr.ContextGroupValue1 = metrologyId.ToString();
                    EndEditing(cr, true);
                }
                catch (Exception ex)
                {
                    transaction.Rollback();
                    cr.Reason = ex.Message.Substring(0, ex.Message.Length > 255 ? 255 : ex.Message.Length);
                    EndEditing(cr, false);
                    throw;
                }

            }



            return feedwardSetting;
        }

        private static PreMetrologySetting ConvertFeedForwardSettingDTOtoEntity(FeedforwardSetting feedwardSetting, Entities.Process _process, List<FeedforwardSetting> ffs, string fab, string productId, string stage, string recipe, string stepName, string stepNumber, PreMetrology pre, int metrologyId)
        {
            return new Entities.PreMetrologySetting()
            {
                Fab = fab,
                ProductId = productId,
                Stage = stage,
                Recipe = recipe,
                StepName = stepName,
                StepNumber = stepNumber,
                MetroFab = pre.Fab,
                MetroStage = pre.MetroStage,
                MetroRecipe = pre.MetroRecipe,
                MetroStepName = pre.MetroStepName,
                MetroStepNumber = pre.MetroStepNumber,
                OutputIndex = ffs.Count() + 1,
                MeasDataItemName = feedwardSetting.Parameter.ParameterName,
                Target = feedwardSetting.Target,
                UpperLimit = feedwardSetting.UpperLimit,
                LowerLimit = feedwardSetting.LowerLimit,
                QualityDataItemName = feedwardSetting.QualityItemName,
                DataQualityThreshold = feedwardSetting.QualityThreshold,
                LowerIsBetterFilter = feedwardSetting.OptLowerBetterFilt ? 1 : 0,
                MinPercentRemaining = feedwardSetting.OptMinPercentRemaining,
                NoOfSitesPerWafer = feedwardSetting.OptNoOfSitePerWafer,
                RangeThreshold = feedwardSetting.OptRangeThreshold,
                StdDevThreshold = feedwardSetting.OptStdDevThreshold,
                UseOOLPreMetro = feedwardSetting.OptUseOOLPreMetro ? 1 : 0,
                UseOOLRange = feedwardSetting.OptUseOOLRange ? 1 : 0,
                UseOOLStdDev = feedwardSetting.OptUseOOLStdDev ? 1 : 0,
                OffsetPerSlotId = feedwardSetting.OptOffsetPerSlot,
                Lambda = feedwardSetting.OptLambda,
                Unit = feedwardSetting.Unit,
                ProcessId = _process.ProcessId,
                PreMetroId = metrologyId
            };
        }

        public void UpdateFeedforwardSetting(DTO.FeedforwardSetting feedwardSetting)
        {
            using EtchDBContext db = CreateDBContext();
            BaseEntities.ChangeRequest cr = TryEditing2(TxnContext.Area, ObjectName.Process.ToString(), "UpdateFeedforwardSetting", TxnContext.UserName, TxnContext.Comment, TxnContext.TxnId, "NA", feedwardSetting.ProcessId.ToString());

            using var transaction = db.Database.BeginTransaction();
            try
            {
                Entities.Process _process = db.ProcessRepository.Find(feedwardSetting.ProcessId);
                if (_process == null)
                    throw new EtchException(ErrorCode.ValidateFail, "None Process Found!");

                if (!feedwardSetting.Validate(out string message))
                    throw new EtchException(ErrorCode.ValidateFail, message);

                List<FeedforwardSetting> ffs = GetFeedforwardSettingList(feedwardSetting.ProcessId);

                if (ffs.Count > 2)
                    throw new EtchException(ErrorCode.FeedforwardSettingShouldLessThanThree);

                FeedforwardSetting oldff = ffs.Find(t => t.PreMetroId == feedwardSetting.PreMetroId);
                if (oldff == null)
                {
                    throw new EtchException(ErrorCode.ValidateFail, "Fail to find the original one!");
                }

                if (ffs.Count(t => t.PreMetroId != feedwardSetting.PreMetroId && t.Parameter.ParameterName == feedwardSetting.Parameter.ParameterName) > 0)
                {
                    throw new EtchException(ErrorCode.ValidateFail, "The FeedforwardSetting is existed with the same parameter!");
                }

                if (ffs.Count(t => t.PreMetroId != feedwardSetting.PreMetroId && t.PreMetrologys.First().MetrologyKey.Equals(feedwardSetting.PreMetrologys.First().MetrologyKey)) > 0)
                {
                    throw new EtchException(ErrorCode.ValidateFail, "Some FeedforwardSetting has been defined on the Pre Metrology!");
                }

                //update
                ParseFields(feedwardSetting.ProcessKey, out string fab, out string productId, out string stage, out string recipe, out string stepName, out string stepNumber);
                PreMetrology pre = feedwardSetting.PreMetrologys.First();

                db.PreMetrologySettingRepository.Update(new Entities.PreMetrologySetting()
                {
                    Fab = fab,
                    ProductId = productId,
                    Stage = stage,
                    Recipe = recipe,
                    StepName = stepName,
                    StepNumber = stepNumber,
                    MetroFab = pre.Fab,
                    MetroStage = pre.MetroStage,
                    MetroRecipe = pre.MetroRecipe,
                    MetroStepName = pre.MetroStepName,
                    MetroStepNumber = pre.MetroStepNumber,
                    OutputIndex = feedwardSetting.OutputIndex,
                    MeasDataItemName = feedwardSetting.Parameter.ParameterName,
                    Target = feedwardSetting.Target,
                    UpperLimit = feedwardSetting.UpperLimit,
                    LowerLimit = feedwardSetting.LowerLimit,
                    QualityDataItemName = feedwardSetting.QualityItemName,
                    DataQualityThreshold = feedwardSetting.QualityThreshold,
                    LowerIsBetterFilter = feedwardSetting.OptLowerBetterFilt ? 1 : 0,
                    MinPercentRemaining = feedwardSetting.OptMinPercentRemaining,
                    NoOfSitesPerWafer = feedwardSetting.OptNoOfSitePerWafer,
                    RangeThreshold = feedwardSetting.OptRangeThreshold,
                    StdDevThreshold = feedwardSetting.OptStdDevThreshold,
                    UseOOLPreMetro = feedwardSetting.OptUseOOLPreMetro ? 1 : 0,
                    UseOOLRange = feedwardSetting.OptUseOOLRange ? 1 : 0,
                    UseOOLStdDev = feedwardSetting.OptUseOOLStdDev ? 1 : 0,
                    OffsetPerSlotId = feedwardSetting.OptOffsetPerSlot,
                    Lambda = feedwardSetting.OptLambda,
                    Unit = feedwardSetting.Unit,
                    ProcessId = feedwardSetting.ProcessId,
                    PreMetroId = feedwardSetting.PreMetroId
                });

                _process.LastModifiedTime = cr.CrTimeStamp;
                _process.LastModifiedBy = TxnContext.UserName;
                db.ProcessRepository.Update(_process);

                db.SaveChanges();
                transaction.Commit();

                //

                cr.ContextGroupValue = string.Format("{0}:{1}:{2}:{3}:{4}:{5}", _process.Fab, _process.ProductId, _process.Stage, _process.Recipe, _process.StepName, _process.StepNumber);
                cr.ContxtGroup = string.Format("{0}:{1}:{2}:{3}:{4}:{5}", "Fab", "ProductId", "Stage", "Recipe", "StepName", "StepNumber");
                //cr.CrDetails = compareResult.ChangeContent;
                cr.CrDetails = "Wait compareResult!";
                EndEditing(cr, true);
            }
            catch (Exception ex)
            {
                transaction.Rollback();
                cr.Reason = ex.Message.Substring(0, ex.Message.Length > 255 ? 255 : ex.Message.Length);
                EndEditing(cr, false);
                throw;
            }
        }
        public FeedforwardSetting GetFeedforwardSetting(int processId, int settingId)
        {
            using EtchDBContext db = CreateDBContext();
            try
            {
                Entities.Process process = db.ProcessRepository.Find(processId);
                if (process == null)
                {
                    throw new EtchException(ErrorCode.ValidateFail, "None Process Found!");
                }

                var ffs = db.PreMetrologySettingRepository.FirstOrDefault(t => t.ProcessId == processId && t.PreMetroId == settingId);
                return ffs == null ? null : ConvertFeedForwardSettingEntityToDTO(ffs);
            }
            catch (Exception)
            {
                throw;
            }

        }

        public List<FeedforwardSetting> GetFeedforwardSettingList(int processId)
        {
            using EtchDBContext db = CreateDBContext();
            try
            {
                var feedforwardSettings = db.PreMetrologySettingRepository.Where(t => t.ProcessId == processId).OrderBy(t => t.OutputIndex).Select(t => ConvertFeedForwardSettingEntityToDTO(t)).ToList();

                return feedforwardSettings;
            }
            catch (Exception)
            {
                throw;
            }

        }

        public void DeleteFeedforwardSetting(int processId, int settingId)
        {
            using EtchDBContext db = CreateDBContext();
            BaseEntities.ChangeRequest cr = TryEditing2(TxnContext.Area, ObjectName.Process.ToString(), "DeleteFeedforwardSetting", TxnContext.UserName, TxnContext.Comment, TxnContext.TxnId, "NA", processId.ToString());

            using var transaction = db.Database.BeginTransaction();
            try
            {
                Entities.Process _process = db.ProcessRepository.Find(processId);
                if (_process == null)
                    throw new ApiException(GeneralErrorCode.ResourceNotFound);

                PreMetrologySetting pre = db.PreMetrologySettingRepository.Find(settingId);
                if (pre == null)
                    throw new EtchException(ErrorCode.ValidateFail, "Couldn't found the FF settings");


                db.PreMetrologySettingRepository.Remove(pre);

                _process.LastModifiedTime = cr.CrTimeStamp;
                _process.LastModifiedBy = TxnContext.UserName;
                db.ProcessRepository.Update(_process);

                db.SaveChanges();
                transaction.Commit();

                //

                cr.ContextGroupValue = string.Format("{0}:{1}:{2}:{3}:{4}:{5}", _process.Fab, _process.ProductId, _process.Stage, _process.Recipe, _process.StepName, _process.StepNumber);
                cr.ContxtGroup = string.Format("{0}:{1}:{2}:{3}:{4}:{5}", "Fab", "ProductId", "Stage", "Recipe", "StepName", "StepNumber");
                cr.CrDetails = pre.MeasDataItemName + " Deleted";
                EndEditing(cr, true);
            }
            catch (Exception ex)
            {
                transaction.Rollback();
                cr.Reason = ex.Message.Substring(0, ex.Message.Length > 255 ? 255 : ex.Message.Length);
                EndEditing(cr, false);
                throw;
            }
        }

        #endregion

        #region Output Settings
        public DTO.OutputSetting CreateOutputSetting(DTO.OutputSetting outputSetting)
        {
            using EtchDBContext db = CreateDBContext();
            BaseEntities.ChangeRequest cr = TryEditing(TxnContext.Area, ObjectName.Process.ToString(), "CreateOutputSetting", TxnContext.UserName, TxnContext.Comment, TxnContext.TxnId, outputSetting.ProcessKey, "NA");

            using (var transaction = db.Database.BeginTransaction())
            {
                try
                {
                    if (!outputSetting.Validate(out string message))
                        throw new EtchException(ErrorCode.ValidateFail, message);

                    Entities.Process process = db.ProcessRepository.Find(outputSetting.ProcessId);
                    if (process == null)
                    {
                        throw new EtchException(ErrorCode.ValidateFail, "None Process Found!");
                    }

                    List<OutputSetting> opss = GetOutputSettingList(outputSetting.ProcessId);
                    if (opss.Count() >= 1 && outputSetting.ZonalFlag)
                        throw new EtchException(ErrorCode.NotSupportMultiOutputWithZonalOn);

                    if (opss.Count >= 2)
                        throw new EtchException(ErrorCode.OutputSettingShouldLessThanThree);

                    List<OutputSetting> opss2 = opss.FindAll(t => t.Parameter.Equals(outputSetting.Parameter.ParameterName));
                    if (opss2.Count() > 0)
                        throw new EtchException(ErrorCode.OutputSettingExisted, "Duplicate Output Parameter found");

                    opss2 = opss.FindAll(t => t.ProcessKey.Equals(outputSetting.ProcessKey) && t.PostMetrologys.First().MetrologyKey.Equals(outputSetting.PostMetrologys.First().MetrologyKey));
                    if (opss2.Count() > 0)
                        throw new EtchException(ErrorCode.OutputSettingExisted, "a output already defined on the same Metrology");

                    foreach (OutputSetting ops in opss)
                    {
                        if (ops.ZonalFlag)
                            throw new EtchException(ErrorCode.NotSupportMultiOutputWithZonalOn);
                    }

                    int outputIndex = opss.Count() > 0 ? opss.Max(t => t.OutputIndex) + 1 : 1;
                    //to add 
                    ParseFields(outputSetting.ProcessKey, out string fab, out string productId, out string stage, out string recipe, out string stepName, out string stepNumber);
                    PostMetrology post = outputSetting.PostMetrologys.First();

                    int metrologyId = GetNextId(TxnContext.Area, ObjectName.Metrology);
                    outputSetting.PostMetroId = metrologyId;
                    db.PostMetrologySettingRepository.Add(new Entities.PostMetrologySetting()
                    {
                        Fab = fab,
                        ProductId = productId,
                        Stage = stage,
                        Recipe = recipe,
                        StepName = stepName,
                        StepNumber = stepNumber,
                        MetroFab = post.Fab,
                        MetroStage = post.MetroStage,
                        MetroRecipe = post.MetroRecipe,
                        MetroStepName = post.MetroStepName,
                        MetroStepNumber = post.MetroStepNumber,
                        OutputIndex = outputSetting.OutputIndex == 0 ? outputIndex : outputSetting.OutputIndex,
                        MeasDataItemName = outputSetting.Parameter.ParameterName,
                        Target = outputSetting.Target,
                        UpperLimits = outputSetting.UpperLimit,
                        LowerLimit = outputSetting.LowerLimit,
                        QualityDataItemName = outputSetting.QualityItemName,
                        DataQualityThreshold = outputSetting.QualityThreshold,
                        LowerIsBetterFilter = outputSetting.OptLowerBetterFilt ? 1 : 0,
                        MinPercentRemaining = outputSetting.OptMinPercentRemaining,
                        NoOfSitesPerWafer = outputSetting.OptNoOfSitePerWafer,
                        RangeThreshold = outputSetting.OptRangeThreshold,
                        StdDevThreshold = outputSetting.OptStdDevThreshold,
                        UseOOLPostMetro = outputSetting.OptUseOOLPostMetro ? 1 : 0,
                        UseOOLRange = outputSetting.OptUseOOLRange ? 1 : 0,
                        UseOOLStdDev = outputSetting.OptUseOOLStdDev ? 1 : 0,
                        ZonalFlag = outputSetting.ZonalFlag ? 1 : 0,
                        ZonalDefinition01Output = outputSetting.ZonalDefinition001_Output,
                        ZonalDefinition02Output = outputSetting.ZonalDefinition002_Output,
                        ZonalDefinition03Output = outputSetting.ZonalDefinition003_Output,
                        ZonalDefinition04Output = outputSetting.ZonalDefinition004_Output,
                        ZonalDefinition05Output = outputSetting.ZonalDefinition005_Output,
                        ZonalDefinition06Output = outputSetting.ZonalDefinition006_Output,
                        ZonalDefinition07Output = outputSetting.ZonalDefinition007_Output,
                        ZonalDefinition08Output = outputSetting.ZonalDefinition008_Output,
                        ZonalDefinition09Output = outputSetting.ZonalDefinition009_Output,
                        ZonalDefinition10Output = outputSetting.ZonalDefinition010_Output,
                        Unit = outputSetting.Unit,
                        ProcessId = process.ProcessId,
                        PostMetroId = outputSetting.PostMetroId
                    });

                    process.LastModifiedTime = cr.CrTimeStamp;
                    process.LastModifiedBy = TxnContext.UserName;
                    db.ProcessRepository.Update(process);

                    db.SaveChanges();
                    transaction.Commit();

                    //
                    cr.CrDetails = outputSetting.Parameter.ParameterName + " Added";
                    cr.Json01 = "";
                    cr.Json02 = UtilityHelper.GetJsonByObject(outputSetting);
                    cr.ContextGroupValue1 = metrologyId.ToString();
                    EndEditing(cr, true);
                }
                catch (Exception ex)
                {
                    transaction.Rollback();
                    cr.Reason = ex.Message.Substring(0, ex.Message.Length > 255 ? 255 : ex.Message.Length);
                    EndEditing(cr, false);
                    throw;
                }
            }
            return outputSetting;
        }
        public void UpdateOutputSetting(DTO.OutputSetting outputSetting)
        {
            using EtchDBContext db = CreateDBContext();
            BaseEntities.ChangeRequest cr = TryEditing2(TxnContext.Area, ObjectName.Process.ToString(), "UpdateOutputSetting", TxnContext.UserName, TxnContext.Comment, TxnContext.TxnId, "NA", outputSetting.ProcessId.ToString());

            using var transaction = db.Database.BeginTransaction();
            try
            {
                Entities.Process _process = db.ProcessRepository.Find(outputSetting.ProcessId);
                if (_process == null)
                    throw new EtchException(ErrorCode.ValidateFail, "None Process Found!");

                if (!outputSetting.Validate(out string message))
                    throw new EtchException(ErrorCode.ValidateFail, message);

                List<OutputSetting> opss = GetOutputSettingList(outputSetting.ProcessId);

                if (opss.Count > 2)
                    throw new EtchException(ErrorCode.OutputSettingShouldLessThanThree);

                List<OutputSetting> oldOutputSettings = opss.FindAll(t => t.ProcessId == outputSetting.ProcessId && t.PostMetroId == outputSetting.PostMetroId);
                if (oldOutputSettings == null || oldOutputSettings.Count() != 1)
                    throw new EtchException(ErrorCode.ValidateFail, "Fail to find the original one!");

                //the original one
                OutputSetting oldOutputSetting = oldOutputSettings.First<OutputSetting>();

                //check if paramter existed 
                List<OutputSetting> checkOutputSettings = opss.FindAll(t => t.PostMetroId != outputSetting.PostMetroId && t.Parameter.ParameterName == outputSetting.Parameter.ParameterName);
                if (checkOutputSettings != null && checkOutputSettings.Count() >= 1)
                    throw new EtchException(ErrorCode.ValidateFail, "The output parameter is existed!");
                //output post metrology - one post metrology on output
                checkOutputSettings = opss.FindAll(t => t.PostMetroId != outputSetting.PostMetroId && t.PostMetrologys.First().MetrologyKey.Equals(outputSetting.PostMetrologys.First().MetrologyKey));
                if (checkOutputSettings != null && checkOutputSettings.Count() >= 1)
                    throw new EtchException(ErrorCode.ValidateFail, "Some Output has been defined on the Post Metrology!");

                BaseDTO.CompareResult compareResult = outputSetting.Compare(oldOutputSetting);
                if (!compareResult.IsChange)
                    throw new EtchException(ErrorCode.NothingIsChanged);

                //check ZonalFlag , only one ZonalFlag=true support
                opss.RemoveAll(t => t.PostMetroId == oldOutputSetting.PostMetroId);
                opss.Add(outputSetting);

                if (opss.Count(t => t.ZonalFlag) > 0 && opss.Count() > 1)
                {
                    throw new EtchException(ErrorCode.NotSupportMultiOutputWithZonalOn);
                }

                //to add 
                ParseFields(outputSetting.ProcessKey, out string fab, out string productId, out string stage, out string recipe, out string stepName, out string stepNumber);
                PostMetrology post = outputSetting.PostMetrologys.First();

                db.PostMetrologySettingRepository.Update(new Entities.PostMetrologySetting()
                {
                    Fab = fab,
                    ProductId = productId,
                    Stage = stage,
                    Recipe = recipe,
                    StepName = stepName,
                    StepNumber = stepNumber,
                    MetroFab = post.Fab,
                    MetroStage = post.MetroStage,
                    MetroRecipe = post.MetroRecipe,
                    MetroStepName = post.MetroStepName,
                    MetroStepNumber = post.MetroStepNumber,
                    OutputIndex = outputSetting.OutputIndex,
                    MeasDataItemName = outputSetting.Parameter.ParameterName,
                    Target = outputSetting.Target,
                    UpperLimits = outputSetting.UpperLimit,
                    LowerLimit = outputSetting.LowerLimit,
                    QualityDataItemName = outputSetting.QualityItemName,
                    DataQualityThreshold = outputSetting.QualityThreshold,
                    LowerIsBetterFilter = outputSetting.OptLowerBetterFilt ? 1 : 0,
                    MinPercentRemaining = outputSetting.OptMinPercentRemaining,
                    NoOfSitesPerWafer = outputSetting.OptNoOfSitePerWafer,
                    RangeThreshold = outputSetting.OptRangeThreshold,
                    StdDevThreshold = outputSetting.OptStdDevThreshold,
                    UseOOLPostMetro = outputSetting.OptUseOOLPostMetro ? 1 : 0,
                    UseOOLRange = outputSetting.OptUseOOLRange ? 1 : 0,
                    UseOOLStdDev = outputSetting.OptUseOOLStdDev ? 1 : 0,
                    ZonalFlag = outputSetting.ZonalFlag ? 1 : 0,
                    ZonalDefinition01Output = outputSetting.ZonalDefinition001_Output,
                    ZonalDefinition02Output = outputSetting.ZonalDefinition002_Output,
                    ZonalDefinition03Output = outputSetting.ZonalDefinition003_Output,
                    ZonalDefinition04Output = outputSetting.ZonalDefinition004_Output,
                    ZonalDefinition05Output = outputSetting.ZonalDefinition005_Output,
                    ZonalDefinition06Output = outputSetting.ZonalDefinition006_Output,
                    ZonalDefinition07Output = outputSetting.ZonalDefinition007_Output,
                    ZonalDefinition08Output = outputSetting.ZonalDefinition008_Output,
                    ZonalDefinition09Output = outputSetting.ZonalDefinition009_Output,
                    ZonalDefinition10Output = outputSetting.ZonalDefinition010_Output,
                    Unit = outputSetting.Unit,
                    ProcessId = outputSetting.ProcessId,
                    PostMetroId = outputSetting.PostMetroId
                });

                _process.LastModifiedTime = cr.CrTimeStamp;
                _process.LastModifiedBy = TxnContext.UserName;
                db.ProcessRepository.Update(_process);

                db.SaveChanges();
                transaction.Commit();

                //
                cr.Json01 = UtilityHelper.GetJsonByObject(oldOutputSettings.First<OutputSetting>());
                cr.Json02 = UtilityHelper.GetJsonByObject(outputSetting);
                cr.ContextGroupValue = string.Format("{0}:{1}:{2}:{3}:{4}:{5}", _process.Fab, _process.ProductId, _process.Stage, _process.Recipe, _process.StepName, _process.StepNumber);
                cr.ContxtGroup = string.Format("{0}:{1}:{2}:{3}:{4}:{5}", "Fab", "ProductId", "Stage", "Recipe", "StepName", "StepNumber");
                cr.CrDetails = compareResult.ChangeContent;
                EndEditing(cr, true);
            }
            catch (Exception ex)
            {
                transaction.Rollback();
                cr.Reason = ex.Message.Substring(0, ex.Message.Length > 255 ? 255 : ex.Message.Length);
                EndEditing(cr, false);
                throw;
            }
        }

        public OutputSetting GetOutputSetting(int processId, int settingId)
        {
            //using (EtchDBContext db = CreateContext())
            using EtchDBContext db = CreateDBContext();
            //EtchDBContext db = _EtchDBContext;
            try
            {

                Entities.Process _process = db.ProcessRepository.Find(processId);
                string processKey = string.Format("{0}:{1}:{2}:{3}:{4}:{5}", _process.Fab, _process.ProductId, _process.Stage, _process.Recipe, _process.StepName, _process.StepNumber);
                if (_process == null)
                    throw new EtchException(ErrorCode.ValidateFail, "None Process Found!");

                List<OutputSetting> opss = new List<OutputSetting>();
                List<PostMetrologySetting> posts = db.PostMetrologySettingRepository.Where(t => t.ProcessId == processId && t.PostMetroId == settingId).OrderBy(t => t.OutputIndex).ToList();
                foreach (PostMetrologySetting t in posts)
                {
                    OutputSetting ops = new OutputSetting();
                    ops.ProcessKey = processKey;
                    ops.OutputIndex = t.OutputIndex;
                    ops.Parameter = new BaseDTO.Parameter() { ParameterName = t.MeasDataItemName };
                    ops.QualityItemName = t.QualityDataItemName;
                    ops.QualityThreshold = t.DataQualityThreshold;
                    ops.LowerLimit = t.LowerLimit;
                    ops.UpperLimit = t.UpperLimits;
                    ops.Target = t.Target;
                    ops.Unit = t.Unit;
                    ops.OptLowerBetterFilt = 1 == t.LowerIsBetterFilter ? true : false;
                    ops.OptMinPercentRemaining = t.MinPercentRemaining;
                    ops.OptNoOfSitePerWafer = (int)t.NoOfSitesPerWafer;
                    ops.OptRangeThreshold = t.RangeThreshold;
                    ops.OptStdDevThreshold = t.StdDevThreshold;
                    ops.OptUseOOLPostMetro = 1 == t.UseOOLPostMetro ? true : false;
                    ops.OptUseOOLRange = 1 == t.UseOOLRange ? true : false;
                    ops.OptUseOOLStdDev = 1 == t.UseOOLStdDev ? true : false;
                    ops.ZonalFlag = 1 == t.ZonalFlag ? true : false;
                    ops.ZonalDefinition001_Output = t.ZonalDefinition01Output;
                    ops.ZonalDefinition002_Output = t.ZonalDefinition02Output;
                    ops.ZonalDefinition003_Output = t.ZonalDefinition03Output;
                    ops.ZonalDefinition004_Output = t.ZonalDefinition04Output;
                    ops.ZonalDefinition005_Output = t.ZonalDefinition05Output;
                    ops.ZonalDefinition006_Output = t.ZonalDefinition06Output;
                    ops.ZonalDefinition007_Output = t.ZonalDefinition07Output;
                    ops.ZonalDefinition008_Output = t.ZonalDefinition08Output;
                    ops.ZonalDefinition009_Output = t.ZonalDefinition09Output;
                    ops.ZonalDefinition010_Output = t.ZonalDefinition10Output;
                    ops.PostMetrologys = new List<PostMetrology> { new PostMetrology() { ProcessKey = processKey, Fab = t.MetroFab, MetroRecipe = t.MetroRecipe, MetroStage = t.MetroStage, MetroStepName = t.MetroStepName, MetroStepNumber = t.MetroStepNumber, ProcessId = t.ProcessId } };
                    ops.ProcessId = t.ProcessId;
                    ops.PostMetroId = t.PostMetroId;

                    opss.Add(ops);
                }

                if (posts == null && posts.Count() == 0) return null;
                return opss.First();
            }
            catch (Exception)
            {
                throw;
            }
        }

        public List<OutputSetting> GetOutputSettingList(int processId)
        {
            //using (EtchDBContext db = CreateContext())
            using EtchDBContext db = CreateDBContext();
            //EtchDBContext db = _EtchDBContext;
            try
            {
                Entities.Process _process = db.ProcessRepository.Find(processId);
                string processKey = string.Format("{0}:{1}:{2}:{3}:{4}:{5}", _process.Fab, _process.ProductId, _process.Stage, _process.Recipe, _process.StepName, _process.StepNumber);
                if (_process == null)
                    throw new EtchException(ErrorCode.ValidateFail, "None Process Found!");

                List<OutputSetting> opss = new List<OutputSetting>();
                List<PostMetrologySetting> posts = db.PostMetrologySettingRepository.Where(t => t.ProcessId == processId).OrderBy(t => t.OutputIndex).ToList();
                foreach (PostMetrologySetting t in posts)
                {
                    OutputSetting ops = new OutputSetting();
                    ops.ProcessKey = processKey;
                    ops.OutputIndex = t.OutputIndex;
                    ops.Parameter = new BaseDTO.Parameter() { ParameterName = t.MeasDataItemName };
                    ops.QualityItemName = t.QualityDataItemName;
                    ops.QualityThreshold = t.DataQualityThreshold;
                    ops.LowerLimit = t.LowerLimit;
                    ops.UpperLimit = t.UpperLimits;
                    ops.Target = t.Target;
                    ops.Unit = t.Unit;
                    ops.OptLowerBetterFilt = 1 == t.LowerIsBetterFilter ? true : false;
                    ops.OptMinPercentRemaining = t.MinPercentRemaining;
                    ops.OptNoOfSitePerWafer = (int)t.NoOfSitesPerWafer;
                    ops.OptRangeThreshold = t.RangeThreshold;
                    ops.OptStdDevThreshold = t.StdDevThreshold;
                    ops.OptUseOOLPostMetro = 1 == t.UseOOLPostMetro ? true : false;
                    ops.OptUseOOLRange = 1 == t.UseOOLRange ? true : false;
                    ops.OptUseOOLStdDev = 1 == t.UseOOLStdDev ? true : false;
                    ops.ZonalFlag = 1 == t.ZonalFlag ? true : false;
                    ops.ZonalDefinition001_Output = t.ZonalDefinition01Output;
                    ops.ZonalDefinition002_Output = t.ZonalDefinition02Output;
                    ops.ZonalDefinition003_Output = t.ZonalDefinition03Output;
                    ops.ZonalDefinition004_Output = t.ZonalDefinition04Output;
                    ops.ZonalDefinition005_Output = t.ZonalDefinition05Output;
                    ops.ZonalDefinition006_Output = t.ZonalDefinition06Output;
                    ops.ZonalDefinition007_Output = t.ZonalDefinition07Output;
                    ops.ZonalDefinition008_Output = t.ZonalDefinition08Output;
                    ops.ZonalDefinition009_Output = t.ZonalDefinition09Output;
                    ops.ZonalDefinition010_Output = t.ZonalDefinition10Output;
                    ops.PostMetrologys = new List<PostMetrology> { new PostMetrology() { ProcessKey = processKey, Fab = t.MetroFab, MetroRecipe = t.MetroRecipe, MetroStage = t.MetroStage, MetroStepName = t.MetroStepName, MetroStepNumber = t.MetroStepNumber, ProcessId = t.ProcessId } };
                    ops.ProcessId = t.ProcessId;
                    ops.PostMetroId = t.PostMetroId;

                    opss.Add(ops);
                }

                return opss;
            }
            catch (Exception)
            {
                throw;
            }
        }

        public void DeleteOutputSetting(int processId, int settingId)
        {
            using EtchDBContext db = CreateDBContext();
            BaseEntities.ChangeRequest cr = TryEditing2(TxnContext.Area, ObjectName.Process.ToString(), "DeleteOutputSetting", TxnContext.UserName, TxnContext.Comment, TxnContext.TxnId, "NA", processId.ToString());

            using var transaction = db.Database.BeginTransaction();
            try
            {
                Entities.Process _process = db.ProcessRepository.Find(processId);
                if (_process == null)
                    throw new ApiException(GeneralErrorCode.ResourceNotFound);

                PostMetrologySetting post = db.PostMetrologySettingRepository.Find(settingId);
                if (post == null)
                    throw new EtchException(ErrorCode.ValidateFail, "Couldn't found the Output settings");


                db.PostMetrologySettingRepository.Remove(post);

                _process.LastModifiedTime = cr.CrTimeStamp;
                _process.LastModifiedBy = TxnContext.UserName;
                db.ProcessRepository.Update(_process);

                db.SaveChanges();
                transaction.Commit();
                //
                cr.CrDetails = post.MeasDataItemName + " Deleted";
                cr.ContextGroupValue = string.Format("{0}:{1}:{2}:{3}:{4}:{5}", _process.Fab, _process.ProductId, _process.Stage, _process.Recipe, _process.StepName, _process.StepNumber);
                cr.ContxtGroup = string.Format("{0}:{1}:{2}:{3}:{4}:{5}", "Fab", "ProductId", "Stage", "Recipe", "StepName", "StepNumber");
                EndEditing(cr, true);
            }
            catch (Exception ex)
            {
                transaction.Rollback();
                cr.Reason = ex.Message.Substring(0, ex.Message.Length > 255 ? 255 : ex.Message.Length);
                EndEditing(cr, false);
                throw;
            }
        }
        #endregion

        #region PreMetrology CRD
        public DTO.PreMetrology CreatePreMetrology(DTO.PreMetrology preMetrology)
        {
            using EtchDBContext db = CreateDBContext();
            BaseEntities.ChangeRequest cr = TryEditing(TxnContext.Area, ObjectName.Process.ToString(), "CreatePreMetrology", TxnContext.UserName, TxnContext.Comment, TxnContext.TxnId, preMetrology.ProcessKey, "NA");

            using (var transaction = db.Database.BeginTransaction())
            {
                try
                {
                    if (!preMetrology.Validate(out string errorMessage))
                        throw new EtchException(ErrorCode.ValidateFail);


                    Entities.Process _process = db.ProcessRepository.Find(preMetrology.ProcessId);
                    if (_process == null)
                    {
                        throw new EtchException(ErrorCode.ValidateFail, "None Process Found!");
                    }
                    //TODO : the logic 

                    ParseFields(preMetrology.ProcessKey, out string fab, out string productId, out string stage, out string recipe, out string stepName, out string stepNumber);

                    List<Entities.ProcessMetrology> pm = db.ProcessMetrologyRepository.Where(t => t.Fab == fab && t.ProductId == productId && t.Stage == stage && t.Recipe == recipe && t.StepName == stepName && t.StepNumber == stepNumber &&
                    t.MetroFab == preMetrology.Fab && t.MetroRecipe == preMetrology.MetroRecipe && t.MetroStage == preMetrology.MetroStage && t.MetroStepName == preMetrology.MetroStepName && t.MetroStepNumber == preMetrology.MetroStepNumber).ToList();
                    // .GetByKeys(new string[] { fab, productId, stage, recipe, stepName, stepNumber, preMetrology.Fab, preMetrology.MetroStage, preMetrology.MetroRecipe, preMetrology.MetroStepName, preMetrology.MetroStepNumber });
                    if (pm != null && pm.Count() > 0)
                        throw new ApiException(GeneralErrorCode.UnexpectedError, "Already defined this metrology on the process");


                    db.ProcessMetrologyRepository.Add(new Entities.ProcessMetrology()
                    {
                        Fab = fab,
                        ProductId = productId,
                        Stage = stage,
                        Recipe = recipe,
                        StepName = stepName,
                        StepNumber = stepNumber,
                        MetroFab = preMetrology.Fab,
                        MetroStage = preMetrology.MetroStage,
                        MetroRecipe = preMetrology.MetroRecipe,
                        MetroStepName = preMetrology.MetroStepName,
                        MetroStepNumber = preMetrology.MetroStepNumber,
                        MetroType = "PreMeas",
                        ProcessId = _process.ProcessId
                    });
                    //
                    db.SaveChanges();
                    transaction.Commit();

                    EndEditing(cr, true);
                }
                catch (Exception ex)
                {
                    transaction.Rollback();
                    cr.Reason = ex.Message.Substring(0, ex.Message.Length > 255 ? 255 : ex.Message.Length);
                    EndEditing(cr, false);
                    throw;
                }
            }
            return preMetrology;
        }
        public List<PreMetrology> GetPreMetrologyList(int processId)
        {
            using EtchDBContext db = CreateDBContext();
            var process = db.ProcessRepository.Find(processId);
            if (process == null)
            {
                throw new EtchException(ErrorCode.ValidateFail, "None Process Found!");
            }

            var pres = db.ProcessMetrologyRepository
                .AsNoTracking()
                .Where(t => t.Fab == process.Fab &&
                            t.ProductId == process.ProductId &&
                            t.Stage == process.Stage &&
                            t.Recipe == process.Recipe &&
                            t.StepName == process.StepName &&
                            t.StepNumber == process.StepNumber &&
                            t.ProcessId == process.ProcessId &&
                            t.MetroType == "PreMeas")
                .Select(t => new PreMetrology()
                {
                    ProcessKey = $"{t.Fab}:{t.ProductId}:{t.Stage}:{t.Recipe}:{t.StepName}:{t.StepNumber}",
                    Fab = t.Fab,
                    MetroStage = t.MetroStage,
                    MetroRecipe = t.MetroRecipe,
                    MetroStepName = t.MetroStepName,
                    MetroStepNumber = t.MetroStepNumber,
                    ProcessId = t.ProcessId
                }).ToList();

            return pres;
        }

        public void DeletePreMetrology(int processId, string metrologyKey)
        {
            using EtchDBContext db = CreateDBContext();
            BaseEntities.ChangeRequest cr = TryEditing2(TxnContext.Area, ObjectName.Process.ToString(), "DeletePreMetrology", TxnContext.UserName, TxnContext.Comment, TxnContext.TxnId, "NA", processId.ToString());

            using var transaction = db.Database.BeginTransaction();
            try
            {
                Entities.Process processEntity = db.ProcessRepository.Find(processId);
                if (processEntity == null)
                    throw new ApiException(GeneralErrorCode.ResourceNotFound);

                string[] metro = metrologyKey.Split(":");
                List<Entities.PreMetrologySetting> preMetroSettings= db.PreMetrologySettingRepository.Where(t => t.MetroFab == metro[0] &&
                 t.MetroStage == metro[1] &&
                 t.MetroRecipe == metro[2] &&
                 t.MetroStepName == metro[3] &&
                 t.MetroStepNumber == metro[4] &&
                 t.ProcessId == processEntity.ProcessId).ToList();
                if(preMetroSettings != null && preMetroSettings.Count>0)
                    throw new EtchException(ErrorCode.ValidateFail,"Some PreMetrology is defined on this metrology , pelase delete first!");


                List<ProcessMetrology> processMetrologys = db.ProcessMetrologyRepository.Where(t =>
                 t.Fab == processEntity.Fab &&
                 t.ProductId == processEntity.ProductId &&
                 t.Stage == processEntity.Stage &&
                 t.Recipe == processEntity.Recipe &&
                 t.StepName == processEntity.StepName &&
                 t.StepNumber == processEntity.StepNumber &&
                 t.MetroFab == metro[0] &&
                 t.MetroStage == metro[1] &&
                 t.MetroRecipe == metro[2] &&
                 t.MetroStepName == metro[3] &&
                 t.MetroStepNumber == metro[4] &&
                 t.ProcessId == processEntity.ProcessId &&
                 t.MetroType == "PreMeas").ToList();

                if (processMetrologys == null || processMetrologys.Count() == 0)
                    throw new ApiException(GeneralErrorCode.ResourceNotFound);
                //delete the process
                cr.Json01 = UtilityHelper.GetJsonByObject(processMetrologys.First());
                db.ProcessMetrologyRepository.Remove(processMetrologys.First());

                db.SaveChanges();
                transaction.Commit();

                //

                cr.ContextGroupValue = string.Format("{0}:{1}:{2}:{3}:{4}:{5}", processEntity.Fab, processEntity.ProductId, processEntity.Stage, processEntity.Recipe, processEntity.StepName, processEntity.StepNumber);
                cr.ContxtGroup = string.Format("{0}:{1}:{2}:{3}:{4}:{5}", "Fab", "ProductId", "Stage", "Recipe", "StepName", "StepNumber");
                EndEditing(cr, true);
            }
            catch (Exception ex)
            {
                cr.Reason = ex.Message.Substring(0, ex.Message.Length > 255 ? 255 : ex.Message.Length);
                if (cr != null) EndEditing(cr, false);
                throw;
            }
        }

        #endregion

        #region PostMetrology CRD

        public DTO.PostMetrology CreatePostMetrology(DTO.PostMetrology postMetrology)
        {
            using EtchDBContext db = CreateDBContext();
            BaseEntities.ChangeRequest cr = TryEditing(TxnContext.Area, ObjectName.Process.ToString(), "CreatePostMetrology", TxnContext.UserName, TxnContext.Comment, TxnContext.TxnId, postMetrology.ProcessKey, "NA");

            using (var transaction = db.Database.BeginTransaction())
            {
                try
                {
                    Entities.Process _process = db.ProcessRepository.Find(postMetrology.ProcessId);
                    if (_process == null)
                    {
                        throw new EtchException(ErrorCode.ValidateFail, "None Process Found!");
                    }

                    if (!postMetrology.Validate(out string errorMessage))
                        throw new EtchException(ErrorCode.ValidateFail);

                    ParseFields(postMetrology.ProcessKey, out string fab, out string productId, out string stage, out string recipe, out string stepName, out string stepNumber);

                    List<Entities.ProcessMetrology> pm = db.ProcessMetrologyRepository.Where(t => t.Fab == fab && t.ProductId == productId && t.Stage == stage && t.Recipe == recipe && t.StepName == stepName && t.StepNumber == stepNumber &&
                    t.MetroFab == postMetrology.Fab && t.MetroRecipe == postMetrology.MetroRecipe && t.MetroStage == postMetrology.MetroStage && t.MetroStepName == postMetrology.MetroStepName && t.MetroStepNumber == postMetrology.MetroStepNumber).ToList();
                    //.GetByKeys(new string[] { fab, productId, stage, recipe, stepName, stepNumber, postMetrology.Fab, postMetrology.MetroStage, postMetrology.MetroRecipe, postMetrology.MetroStepName, postMetrology.MetroStepNumber });

                    if (pm != null && pm.Count() > 0)
                        throw new ApiException(GeneralErrorCode.UnexpectedError, "Already defined this metrology on the process");

                    db.ProcessMetrologyRepository.Add(new Entities.ProcessMetrology()
                    {
                        Fab = fab,
                        ProductId = productId,
                        Stage = stage,
                        Recipe = recipe,
                        StepName = stepName,
                        StepNumber = stepNumber,
                        MetroFab = postMetrology.Fab,
                        MetroStage = postMetrology.MetroStage,
                        MetroRecipe = postMetrology.MetroRecipe,
                        MetroStepName = postMetrology.MetroStepName,
                        MetroStepNumber = postMetrology.MetroStepNumber,
                        MetroType = "PostMeas",
                        ProcessId = _process.ProcessId
                    });

                    db.SaveChanges();
                    transaction.Commit();

                    //
                    EndEditing(cr, true);
                }
                catch (Exception ex)
                {
                    transaction.Rollback();
                    cr.Reason = ex.Message.Substring(0, ex.Message.Length > 255 ? 255 : ex.Message.Length);
                    EndEditing(cr, false);
                    throw;
                }
            }
            return postMetrology;
        }

        public List<PostMetrology> GetPostMetrologyList(int processId)
        {
            using EtchDBContext db = CreateDBContext();
            Entities.Process process = db.ProcessRepository.Find(processId);
            if (process == null)
            {
                throw new EtchException(ErrorCode.ValidateFail, "None Process Found!");
            }

            var posts = db.ProcessMetrologyRepository
                .AsNoTracking()
                .Where(t => t.Fab == process.Fab &&
                            t.ProductId == process.ProductId &&
                            t.Stage == process.Stage &&
                            t.Recipe == process.Recipe &&
                            t.StepName == process.StepName &&
                            t.StepNumber == process.StepNumber &&
                            t.ProcessId == process.ProcessId &&
                            t.MetroType == "PostMeas")
                .Select(t => new PostMetrology()
                {
                    ProcessKey = $"{t.Fab}:{t.ProductId}:{t.Stage}:{t.Recipe}:{t.StepName}:{t.StepNumber}",
                    Fab = t.Fab,
                    MetroStage = t.MetroStage,
                    MetroRecipe = t.MetroRecipe,
                    MetroStepName = t.MetroStepName,
                    MetroStepNumber = t.MetroStepNumber,
                    ProcessId = t.ProcessId
                })
                .ToList();

            return posts;
        }

        public void DeletePostMetrology(int processId, string metrologyKey)
        {
            using EtchDBContext db = CreateDBContext();
            BaseEntities.ChangeRequest cr = TryEditing2(TxnContext.Area, ObjectName.Process.ToString(), "DeletePreMetrology", TxnContext.UserName, TxnContext.Comment, TxnContext.TxnId, "NA", processId.ToString());

            using var transaction = db.Database.BeginTransaction();
            try
            {
                Entities.Process processEntity = db.ProcessRepository.Find(processId);
                if (processEntity == null)
                    throw new ApiException(GeneralErrorCode.ResourceNotFound);

                string[] metro = metrologyKey.Split(":");

                List<Entities.PostMetrologySetting> preMetroSettings = db.PostMetrologySettingRepository.Where(t => t.MetroFab == metro[0] &&
                  t.MetroStage == metro[1] &&
                  t.MetroRecipe == metro[2] &&
                  t.MetroStepName == metro[3] &&
                  t.MetroStepNumber == metro[4] &&
                  t.ProcessId == processEntity.ProcessId).ToList();
                if (preMetroSettings != null && preMetroSettings.Count > 0)
                    throw new EtchException(ErrorCode.ValidateFail, "Some OutputSetting is defined on this metrology , pelase delete first!");

                List<ProcessMetrology> processMetrologys = db.ProcessMetrologyRepository.Where(t =>
                 t.Fab == processEntity.Fab &&
                 t.ProductId == processEntity.ProductId &&
                 t.Stage == processEntity.Stage &&
                 t.Recipe == processEntity.Recipe &&
                 t.StepName == processEntity.StepName &&
                 t.StepNumber == processEntity.StepNumber &&
                 t.MetroFab == metro[0] &&
                 t.MetroStage == metro[1] &&
                 t.MetroRecipe == metro[2] &&
                 t.MetroStepName == metro[3] &&
                 t.MetroStepNumber == metro[4] &&
                 t.ProcessId == processEntity.ProcessId &&
                 t.MetroType == "PostMeas").ToList();

                if (processMetrologys == null || processMetrologys.Count() == 0)
                    throw new ApiException(GeneralErrorCode.ResourceNotFound);
                //delete the process
                cr.Json01 = UtilityHelper.GetJsonByObject(processMetrologys.First());
                db.ProcessMetrologyRepository.Remove(processMetrologys.First());

                db.SaveChanges();
                transaction.Commit();

                //

                cr.ContextGroupValue = string.Format("{0}:{1}:{2}:{3}:{4}:{5}", processEntity.Fab, processEntity.ProductId, processEntity.Stage, processEntity.Recipe, processEntity.StepName, processEntity.StepNumber);
                cr.ContxtGroup = string.Format("{0}:{1}:{2}:{3}:{4}:{5}", "Fab", "ProductId", "Stage", "Recipe", "StepName", "StepNumber");
                EndEditing(cr, true);
            }
            catch (Exception ex)
            {
                transaction.Rollback();
                cr.Reason = ex.Message.Substring(0, ex.Message.Length > 255 ? 255 : ex.Message.Length);
                EndEditing(cr, false);
                throw;
            }
        }
        #endregion

        #region Manual Add PreMetrology

        public ManualPreMetrology GetManualPreMetrologyInfo(int processId)
        {
            using EtchDBContext db = CreateDBContext();
            ManualPreMetrology mpm = new ManualPreMetrology();
            mpm.ProcessPreMetrologys = this.GetPreMetrologyList(processId);
            mpm.ManualPreMetrologyItems = new List<ManualPreMetrologyItem>();
            foreach (PreMetrology pm in mpm.ProcessPreMetrologys)
            {
                string metrologyKey = pm.MetrologyKey;
                List<Entities.MetrologyRecord> mrs = db.MetrologyRecordSettingRepository.Where(t => t.Fab == pm.Fab && t.MetroStage == pm.MetroStage && t.MetroRecipe == pm.MetroRecipe && t.MetroStepName == pm.MetroStepName && t.MetroSteNum == pm.MetroStepNumber && t.DataSource == "Manual").ToList();
                List<Entities.MetrologyRecord> measuresPerWafer = mrs.Where(t => !t.MeasDataItemName.ToUpper().StartsWith("GOF") && !t.MeasDataItemName.ToUpper().Equals("NA")).ToList();

                foreach (Entities.MetrologyRecord mr in measuresPerWafer)
                {
                    ManualPreMetrologyItem mpi = new ManualPreMetrologyItem();
                    mpi.MetrologyKey = pm.MetrologyKey;
                    mpi.LotId = mr.LotId;
                    mpi.WaferId = mr.WaferId;
                    mpi.DcollTime = mr.DcollTime;
                    mpi.MeasureItem = mr.MeasDataItemName;
                    mpi.MeasureValue = double.Parse(mr.MeasValues.Split(',')[0]);
                    mpi.Unit = "NA";
                    mpi.uniqueId = mr.ProcessStepNum;

                    //we use the ProcessStepNum as unique number for each manual decoll meansurement
                    List<Entities.MetrologyRecord> mrGofs = mrs.Where(t => t.ProcessStepNum == mr.ProcessStepNum && t.MeasDataItemName != mr.MeasDataItemName).ToList();
                    if (mrGofs != null && mrGofs.Count() > 0)
                    {
                        mpi.QualityItem = mrGofs[0].MeasDataItemName;
                        mpi.QualityValue = double.Parse(mrGofs[0].MeasValues.Split(',')[0]);
                    }

                    mpm.ManualPreMetrologyItems.Add(mpi);
                }
            }
            return mpm;
        }

        //change to list
        public ManualPreMetrologyItem AddManualPreMetrologyItem(ManualPreMetrologyItem manualPreMetrologyItem)
        {
            using (EtchDBContext db = CreateDBContext())
            {
                BaseEntities.ChangeRequest cr = TryEditing(TxnContext.Area, ObjectName.Metrology.ToString(), "AddManalMetrology", TxnContext.UserName, TxnContext.Comment, TxnContext.TxnId, manualPreMetrologyItem.MetrologyKey, "NA");

                using var transaction = db.Database.BeginTransaction();
                try
                {
                    //generate the uniqueId;

                    string txId = cr.CrTimeStamp.ToString("yyyyMMddHH:mm:ss.fff");
                    manualPreMetrologyItem.uniqueId = txId + "." + manualPreMetrologyItem.WaferId + "." + manualPreMetrologyItem.MeasureItem;
                    ParseFields(manualPreMetrologyItem.MetrologyKey, out string metroFab, out string MetroStage, out string metroRecipe, out string metroStepName, out string metroStepNumber);

                    Entities.MetrologyRecord mr = new MetrologyRecord();
                    mr.ProcessStepNum = manualPreMetrologyItem.uniqueId;
                    mr.DataSource = "NA";
                    mr.DcollTime = manualPreMetrologyItem.DcollTime;// cr.CrTimeStamp;
                    mr.TxId = txId;
                    mr.Fab = metroFab;
                    mr.MetroStage = MetroStage;
                    mr.MetroRecipe = metroRecipe;
                    mr.MetroStepName = metroStepName;
                    mr.MetroSteNum = metroStepNumber;
                    mr.MetroToolId = "NA";
                    mr.LotId = manualPreMetrologyItem.LotId;
                    mr.WaferId = manualPreMetrologyItem.WaferId;
                    mr.MeasIndex = "1,2,3,4,5,6,7,8,9,10";
                    mr.MeasOrders = "1,2,3,4,5,6,7,8,9,10";
                    mr.MeasOoss = MakeDouble2Csv("false", 10);
                    mr.MeasType = "PreMeas";
                    mr.DataSource = "Manual";
                    mr.MeasDataItemName = manualPreMetrologyItem.MeasureItem;
                    mr.MeasName = MakeDouble2Csv(manualPreMetrologyItem.MeasureItem, 10);
                    mr.MeasValues = MakeDouble2Csv(manualPreMetrologyItem.MeasureValue + "", 10);
                    db.MetrologyRecordSettingRepository.Add(mr);

                    Entities.MetrologyRecord mr2 = new MetrologyRecord();
                    mr2.ProcessStepNum = manualPreMetrologyItem.uniqueId;
                    mr2.DataSource = "NA";
                    mr2.DcollTime = cr.CrTimeStamp;
                    mr2.TxId = txId;
                    mr2.Fab = metroFab;
                    mr2.MetroStage = MetroStage;
                    mr2.MetroRecipe = metroRecipe;
                    mr2.MetroStepName = metroStepName;
                    mr2.MetroSteNum = metroStepNumber;
                    mr2.MetroToolId = "NA";
                    mr2.LotId = manualPreMetrologyItem.LotId;
                    mr2.WaferId = manualPreMetrologyItem.WaferId;
                    mr2.MeasIndex = "1,2,3,4,5,6,7,8,9,10";
                    mr2.MeasOrders = "1,2,3,4,5,6,7,8,9,10";
                    mr2.MeasOoss = MakeDouble2Csv("false", 10);
                    mr2.MeasType = "PreMeas";
                    mr2.DataSource = "Manual";
                    mr2.MeasDataItemName = manualPreMetrologyItem.QualityItem;
                    mr2.MeasName = MakeDouble2Csv(manualPreMetrologyItem.MeasureItem, 10);
                    mr2.MeasValues = MakeDouble2Csv(manualPreMetrologyItem.QualityValue + "", 10);
                    db.MetrologyRecordSettingRepository.Add(mr2);

                    db.SaveChanges();
                    transaction.Commit();

                    ///
                    cr.ContxtGroup = string.Format("{0}:{1}:{2}:{3}:{4}", "Fab", "MetroStage", "MetroRecipe", "MetroStepName", "MetroStepNumber");
                    EndEditing(cr, true);

                }
                catch (Exception ex)
                {
                    transaction.Rollback();
                    cr.Reason = ex.Message.Substring(0, ex.Message.Length > 255 ? 255 : ex.Message.Length);
                    if (cr != null) EndEditing(cr, false);
                    throw;
                }
            }

            return manualPreMetrologyItem;
        }

        public void DeleteManualPreMetrologyItem(ManualPreMetrologyItem manualPreMetrologyItem)
        {
            using EtchDBContext db = CreateDBContext();
            BaseEntities.ChangeRequest cr = TryEditing(TxnContext.Area, ObjectName.Metrology.ToString(), "AddManalMetrology", TxnContext.UserName, TxnContext.Comment, TxnContext.TxnId, manualPreMetrologyItem.MetrologyKey, "NA");

            using var transaction = db.Database.BeginTransaction();
            try
            {
                List<MetrologyRecord> mrs = db.MetrologyRecordSettingRepository.Where(t => t.DcollTime == manualPreMetrologyItem.DcollTime && t.ProcessStepNum == manualPreMetrologyItem.uniqueId).ToList();
                db.MetrologyRecordSettingRepository.RemoveRange(mrs);
                db.SaveChanges();
                transaction.Commit();

                ///
                cr.ContxtGroup = string.Format("{0}:{1}:{2}:{3}:{4}", "Fab", "MetroStage", "MetroRecipe", "MetroStepName", "MetroStepNumber");
                EndEditing(cr, true);

            }
            catch (Exception ex)
            {
                transaction.Rollback();
                cr.Reason = ex.Message.Substring(0, ex.Message.Length > 255 ? 255 : ex.Message.Length);
                if (cr != null) EndEditing(cr, false);
                throw;
            }
        }
        public void DeleteManualPreMetrologyItem(int processId, string uniqueId)
        {
            using EtchDBContext db = CreateDBContext();
            BaseEntities.ChangeRequest cr = TryEditing(TxnContext.Area, ObjectName.Metrology.ToString(), "AddManalMetrology", TxnContext.UserName, TxnContext.Comment, TxnContext.TxnId, "DeleteManualPreMetrologyItem", "NA");

            using var transaction = db.Database.BeginTransaction();
            try
            {
                List<MetrologyRecord> mrs = db.MetrologyRecordSettingRepository.Where(t => t.ProcessStepNum == uniqueId).ToList();
                db.MetrologyRecordSettingRepository.RemoveRange(mrs);
                db.SaveChanges();
                transaction.Commit();


                ///
                cr.ContxtGroup = string.Format("{0}:{1}:{2}:{3}:{4}", "Fab", "MetroStage", "MetroRecipe", "MetroStepName", "MetroStepNumber");
                EndEditing(cr, true);

            }
            catch (Exception ex)
            {
                transaction.Rollback();
                cr.Reason = ex.Message.Substring(0, ex.Message.Length > 255 ? 255 : ex.Message.Length);
                if (cr != null) EndEditing(cr, false);
                throw;
            }
        }

        private void ParseFields(string id, out string fab, out string stage, out string recipe, out string stepName, out string stepNumber)
        {
            var fields = id?.Split(':');
            if (fields == null || fields.Length != 5)
            {
                throw new EtchException(ErrorCode.InvalidProcessKey, "Invalid Metrology Key.");
            }

            fab = fields[0];
            stage = fields[1];
            recipe = fields[2];
            stepName = fields[3];
            stepNumber = fields[4];
        }

        private string MakeDouble2Csv(string val, int length)
        {
            List<string> vals = new List<string>();
            for (int i = 0; i < length; i++)
            {
                vals.Add(val);
            }
            return string.Join(',', vals);
        }



        #endregion
    }
}
