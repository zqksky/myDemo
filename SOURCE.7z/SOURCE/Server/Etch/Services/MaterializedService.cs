﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Numerics;
using System.Reflection;
using System.Threading;
using System.Threading.Tasks;
using System.Transactions;
using AMAT.R2R.Server.Base;
using AMAT.R2R.Server.Base.Constants;
using AMAT.R2R.Server.Base.Entities;
using AMAT.R2R.Server.Base.Exceptions;
using AMAT.R2R.Server.Base.Repository;
using AMAT.R2R.Server.Base.Service;
using AMAT.R2R.Server.Etch.Entities;
using AMAT.R2R.Server.Etch.Exceptions;
using AMAT.R2R.Server.Etch.Repository;
using AMAT.R2R.Shared.Base.DTO;
using AMAT.R2R.Shared.Etch.DTO;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc.Formatters;
using Microsoft.CodeAnalysis.CSharp.Syntax;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Internal;
using Microsoft.EntityFrameworkCore.Storage;
using Namotion.Reflection;
using BaseDTO = AMAT.R2R.Shared.Base.DTO;
using BaseEntities = AMAT.R2R.Server.Base.Entities;
using DTO = AMAT.R2R.Shared.Etch.DTO;
using Entities = AMAT.R2R.Server.Etch.Entities;
using Microsoft.Extensions.Configuration;
using AMAT.R2R.Server.Base.Helpers;
using Microsoft.Extensions.Logging;

namespace AMAT.R2R.Server.Etch.Services
{
    public interface IMaterializedService
    {
        DTO.MaterializedView GetMaterializedView(int contextId);
        List<MaterializeViewParameter> GetMaterializeViewParameters(int contextId);

        List<RunHist> GetMaterializedViewRunHist(int contextId);

        List<DTO.MaterializedView> GetMaterializedViewList(IQueryCollection query);
        void UpdateMaterializedViewParameter(int contextId, List<MaterializeViewParameter> materializeViewParameters);


        //void ChangeContextControlFlag(int contextId, ControlFlag controlFlag);
        //void ChangeContextControlLevel(int contextId, ControlLevel controlLevel);
        //void ChangeContextControlType(int contextId, ControlType controlType);
        //void ChangeContextControlConstraint(int contextId, ControlFlag controlFlag, ControlLevel controlLevel, ControlType controlType);


        void ChangeContextThreadStatus(int contextId, ThreadStatus threadStatus, string BookedPilotId);

        void ResetControlThreadByContext(int contextId);

        void ResetControlThreadByTool(string tool);


        // 
        DTO.ChamberOffset GetChamberOffset(string tool, string chamberId);
        void UpdateChamberOffsetItem(DTO.ChamberOffsetItem chamberOffsetItem);

        void DeleteChamberOffsetItem(string toolId, string chamberId, string parameterName);
        object[] GetMaterializedViewValueList(IQueryCollection query, string propertyName);
        int GetMaterializedViewCount(IQueryCollection query);
    }


    public class MaterializedService : EtchService, IMaterializedService
    {

        private readonly IProcessService _processService;
        private readonly IContextService _contextService;
        private readonly IGlobalService _globalService;
        public MaterializedService(IGlobalService globalService, IProcessService processService, IContextService contextService, IServiceProvider serviceProvider, ILogger<MaterializedService> logger) : base(serviceProvider, logger)
        {
            this._processService = processService;
            this._contextService = contextService;
            this._globalService = globalService;
        }

        public DTO.MaterializedView GetMaterializedView(int contextId)
        {
            using EtchDBContext db = CreateDBContext();
            DTO.MaterializedView view = null;
            try
            {
                DTO.Context context = this._contextService.GetContext(contextId);
                if (context == null) throw new EtchException(ErrorCode.ResourceNotExisted, "None context found");

                List<AutoStates> assList = db.AutoStatesRepository.Where(t => t.ContextId == contextId).ToList();
                List<PreMetrologyLineAvg> pmlList = db.PreMetrologyLineAvgRepository.Where(t => t.Tool == context.Tool && t.Chamber == context.Chamber && t.ContextGroup == t.ContextGroup && t.Fab == context.Fab && t.ProductId == context.ProductId && t.Stage == context.Stage && t.Recipe == context.Recipe && t.StepName == context.StepName && t.StepNumber == context.StepNumber).ToList();

                AutoStates autoState = assList != null && assList.Count() > 0 ? assList[0] : null;
                PreMetrologyLineAvg preLineAvg = pmlList != null && pmlList.Count() > 0 ? pmlList[0] : null;

                view = new MaterializedView();
                view.ContextId = context.ContextId;
                view.ProcessId = context.ProcessId;
                view.ContextKey = context.ContextKey;
                view.ProcessKey = context.ProcessKey;
                view.Fab = context.Fab;
                view.ProductId = context.ProductId;
                view.Stage = context.Stage;
                view.Recipe = context.Recipe;
                view.StepName = context.StepName;
                view.StepNumber = context.StepNumber;
                view.Tool = context.Tool;
                view.Chamber = context.Chamber;
                view.ContextGroup = context.ContextGroup;
                view.LastModifiedBy = context.LastModifiedBy;
                view.LastModifiedTime = context.LastModifiedTime;
                view.ControlFlag = context.ControlFlag;
                view.ControlLevel = context.ControlLevel;
                view.ControlType = context.ControlType;

                view.MaterializeViewParameters = new List<MaterializeViewParameter>();
                List<Entities.ChamberOffset> chamberOffsets = db.ChamberOffsetRepository.Where(t => t.ToolId == context.Tool && t.ChamberId == context.Chamber).ToList();

                int k = 0;
                string[] OnTargetEstimate = autoState == null || string.IsNullOrEmpty(autoState.DefaultRecSettings) ? new string[] { } :
                    autoState.DefaultRecSettings.Split(',');

                foreach (ContextInputPara cip in context.ContextInputParas)
                {
                    MaterializeViewParameter mvp = new MaterializeViewParameter();

                    mvp.InputParameter = cip.ParameterName;
                    mvp.InputFixedValue = (double)cip.DefaultRecommandValue;
                    mvp.LowerLimit = (double)cip.LowerLimit;
                    mvp.UpperLimt = (double)cip.UpperLimit;
                    mvp.Deadband = (double)cip.Deadband;
                    mvp.Unit = cip.Unit;
                    if (chamberOffsets != null)
                    {
                        int i = chamberOffsets.FindIndex(t => t.ParameterName == mvp.InputParameter);
                        mvp.ChamberOffset = i >= 0 ? (double)chamberOffsets[i].Offset : 0.0;
                    }
                    mvp.OnTargetEstimate = OnTargetEstimate.Length > k ? double.Parse(OnTargetEstimate[k]) : new Nullable<double>();

                    k++;
                    view.MaterializeViewParameters.Add(mvp);
                }

                //estate information
                if (autoState != null)
                {
                    view.States = new List<double?>()
                        {
                            autoState.State01, autoState.State02, autoState.State03, autoState.State04, autoState.State05, autoState.State06, autoState.State07, autoState.State08, autoState.State09, autoState.State10,
                            autoState.State11, autoState.State12, autoState.State13, autoState.State14, autoState.State15, autoState.State16, autoState.State17, autoState.State18, autoState.State19, autoState.State20,
                        };
                    view.LastEstiTime = autoState.LastStateUpdateTime;
                    view.EstiExpiredDay = (int)context.EstiExpiredDay;
                    view.LastResetTime = autoState.LastResetTime;
                    view.ThreadStatus = (ThreadStatus)Enum.Parse(typeof(ThreadStatus), autoState.ThreadStatus);
                    view.BookedPiLotId = autoState.BookPiLot;
                    view.IsValid = autoState.IsValid != 0;
                    view.Remark = autoState.Remark;
                    view.CounterConsecutiveMaxAdjust = autoState.CounterConsecutiveMaxAdjust;
                    view.LotListSinceLastValidMetro = autoState.LotListSinceLastValidMetro;
                    view.LotlistConsecutiveGof = autoState.LotlistConsecutiveGof;
                    view.LotlistConsecutiveOos = autoState.LotlistConsecutiveOos;

                }

                //preLine Avg
                if (preLineAvg != null)
                {
                    view.PreMetroLineFFDisb = (decimal)preLineAvg.FfDisb;
                    view.PreMetroLineAvg = (decimal)preLineAvg.PreMetroLineAvg;
                    view.PreMetroLineLastUpdateTime = preLineAvg.LastUpdateTime;
                }
            }
            catch
            {
                throw;
            }
            return view;
        }


        public List<MaterializeViewParameter> GetMaterializeViewParameters(int contextId)
        {
            try
            {
                DTO.MaterializedView view = GetMaterializedView(contextId);
                if (view == null) throw new EtchException(ErrorCode.ResourceNotExisted, "None context found");
                return view.MaterializeViewParameters;
            }
            catch
            {
                throw;
            }

        }

        public List<RunHist> GetMaterializedViewRunHist(int contextId)
        {
            using EtchDBContext db = CreateDBContext();
            Entities.Context context = db.ContextRepository.Find(contextId);
            if (context == null) throw new EtchException(ErrorCode.ResourceNotExisted, "None context found");
            List<RunHist> runHist = new List<RunHist>();
            List<Entities.HznMaterialized> list = db.HznMaterializedRepository.Where(t => t.ContextId == contextId && t.Tool == context.Tool && t.Chamber == context.Chamber && t.ProductId == context.ProductId && t.Stage == context.Stage)
                       .OrderByDescending(t => t.CalcTimesStamp)
                       .Skip((0) * 10).Take(100).ToList();

            list.ForEach(t =>
            {
                RunHist hist = new RunHist();

                hist.HznKey = t.HznKey;
                hist.CalcTimesStamp = t.CalcTimesStamp;
                hist.UsedTimeStamp = t.UsedTimeStamp;
                hist.PostTimeStamp = t.PostTimeStamp;
                hist.Tool = t.Tool;
                hist.ProductId = t.ProductId;
                hist.Stage = t.Stage;
                hist.Recipe = t.Recipe;
                hist.StepNumber = t.StepNumber;
                hist.StepName = t.StepName;
                hist.Fab = t.Fab;
                hist.ContextGroup = t.ContextGroup;
                hist.Chamber = t.Chamber;
                hist.R2RMode = t.R2RMode;
                hist.ContextId = t.ContextId;
                hist.LotId = t.LotId;
                hist.WaferScribe = t.WaferScribe;
                hist.WaferList = t.WaferList;
                hist.PreMetrology = t.PreMetrology;
                hist.FFDisb = t.FFDisb;
                hist.ChamberOffset = t.ChamberOffset;
                hist.DefaultRecSettings = t.DefaultRecSettings;
                hist.RecipeSettings = t.RecipeSettings;
                hist.FinalRecSettings = t.FinalRecSettings;
                hist.PostMetrology = t.PostMetrology;
                hist.NewRecSettingsFb = t.NewRecSettingsFb;
                hist.States = t.States;
                hist.ModifiedBy = t.ModifiedBy;
                hist.Feedback = t.Feedback;
                hist.Remark = t.Remark;
                hist.SpecifyLot = t.SpecifyLot;
                hist.PilotFlag = t.PilotFlag;
                hist.RunCardId = t.RunCardId;

                runHist.Add(hist);
            });

            return runHist;
        }

        public List<DTO.MaterializedView> GetMaterializedViewList(IQueryCollection query)
        {
            using EtchDBContext db = CreateDBContext();
            var joinedQueryable = from c in db.ContextRepository
                              join s in db.StrategyConstantRepository on c.ContextId equals s.ContextId
                              into grouping1
                              from s in grouping1.DefaultIfEmpty()
                              join a in db.AutoStatesRepository
                              on c.ContextId equals a.ContextId
                              into grouping2
                              from a in grouping2.DefaultIfEmpty()
                              select new
                              {
                                  context = c,
                                  autoState = a,
                                  strategyContant = s,
                                  c.Fab,
                                  c.ProductId,
                                  c.Stage,
                                  c.Recipe,
                                  c.StepName,
                                  c.StepNumber,
                                  c.Tool,
                                  c.Chamber,
                                  c.ContextGroup,
                                  c.ControlFlag,
                                  ControlLevel = 1 == c.LotLevelControl ? DTO.ControlLevel.LotLevel : DTO.ControlLevel.WaferLevel,
                                  c.ControlType,
                                  c.ContextId,
                                  c.ProcessId,
                                  c.LastModifiedTime,
                                  c.LastModifiedBy,
                                  EstiExpiredDay = s == null ? 0 : s.MaxTimeLastStateEstDays,
                                  LastEstiTime = a.LastStateUpdateTime,
                                  LastResetTime = a.LastResetTime,
                                  ThreadStatus = a.ThreadStatus,
                                  BookedPiLotId = a.BookPiLot,
                                  IsValid = a == null ? 0 : a.IsValid,
                                  Remark = a.Remark,
                                  CounterConsecutiveMaxAdjust = s == null ? 0 : a.CounterConsecutiveMaxAdjust,
                                  LotListSinceLastValidMetro = a.LotListSinceLastValidMetro,
                                  LotlistConsecutiveGof = a.LotlistConsecutiveGof,
                                  LotlistConsecutiveOos = a.LotlistConsecutiveOos,
                              };

            var test = joinedQueryable.AsNoTracking().Where(j => j.Fab == TxnContext.Fab).ToList();

            joinedQueryable = joinedQueryable.AsNoTracking().Where(j => j.Fab == TxnContext.Fab).ApplyFilters(query);


            var sortable = joinedQueryable.ApplySorters(query);
            var materializedViewEntities = sortable.PageToList(query);

            var materializedViewDtos = materializedViewEntities.Select(v => CreateMaterializedViewDTO(db, v.context, v.strategyContant, v.autoState)).ToList();

            return materializedViewDtos;
        }

        private DTO.MaterializedView CreateMaterializedViewDTO(EtchDBContext db, Entities.Context contextEntity, StrategyConstant strategyContant, AutoStates autoState)
        {
            var context = _contextService.ConvertContextEntityToDTO(contextEntity);
            _contextService.FillContextInfomation(context, _processService.GetProcessInfoByID(context.ProcessId));

            var view = new MaterializedView
            {
                ContextId = context.ContextId,
                ProcessId = context.ProcessId,
                ContextKey = context.ContextKey,
                ProcessKey = context.ProcessKey,
                Fab = context.Fab,
                ProductId = context.ProductId,
                Stage = context.Stage,
                Recipe = context.Recipe,
                StepName = context.StepName,
                StepNumber = context.StepNumber,
                Tool = context.Tool,
                Chamber = context.Chamber,
                ContextGroup = context.ContextGroup,
                LastModifiedBy = context.LastModifiedBy,
                LastModifiedTime = context.LastModifiedTime,
                ControlFlag = context.ControlFlag,
                ControlLevel = context.ControlLevel,
                ControlType = context.ControlType,
                EstiExpiredDay = strategyContant == null ? 0 : (int)strategyContant.MaxTimeLastStateEstDays,

                MaterializeViewParameters = new List<MaterializeViewParameter>()
            };

            List<Entities.ChamberOffset> chamberOffsets = db.ChamberOffsetRepository.AsNoTracking().Where(t => t.ToolId == context.Tool && t.ChamberId == context.Chamber).ToList();

            List<PreMetrologyLineAvg> pmlList = db.PreMetrologyLineAvgRepository.AsNoTracking().Where(t => t.Tool == context.Tool && t.Chamber == context.Chamber && t.ContextGroup == t.ContextGroup && t.Fab == context.Fab && t.ProductId == context.ProductId && t.Stage == context.Stage && t.Recipe == context.Recipe && t.StepName == context.StepName && t.StepNumber == context.StepNumber).ToList();
            PreMetrologyLineAvg preLineAvg = pmlList != null && pmlList.Count() > 0 ? pmlList[0] : null;

            int k = 0;
            string[] onTargetEstimate = autoState == null || string.IsNullOrEmpty(autoState.DefaultRecSettings) ? new string[] { } :
                autoState.DefaultRecSettings.Split(',');

            foreach (ContextInputPara cip in context.ContextInputParas)
            {
                MaterializeViewParameter mvp = new MaterializeViewParameter
                {
                    InputParameter = cip.ParameterName,
                    InputFixedValue = (double)cip.DefaultRecommandValue,
                    LowerLimit = (double)cip.LowerLimit,
                    UpperLimt = (double)cip.UpperLimit,
                    Deadband = (double)cip.Deadband,
                    Unit = cip.Unit
                };
                if (chamberOffsets != null)
                {
                    int i = chamberOffsets.FindIndex(t => t.ParameterName == mvp.InputParameter);
                    mvp.ChamberOffset = i >= 0 ? (double)chamberOffsets[i].Offset : 0.0;
                }
                mvp.OnTargetEstimate = onTargetEstimate.Length > k ? double.Parse(onTargetEstimate[k]) : new double?();

                k++;
                view.MaterializeViewParameters.Add(mvp);
            }

            //estate information
            if (autoState != null)
            {
                view.States = new List<double?>()
                {
                    autoState.State01, autoState.State02, autoState.State03, autoState.State04, autoState.State05, autoState.State06, autoState.State07, autoState.State08, autoState.State09, autoState.State10,
                    autoState.State11, autoState.State12, autoState.State13, autoState.State14, autoState.State15, autoState.State16, autoState.State17, autoState.State18, autoState.State19, autoState.State20,
                };
                view.LastEstiTime = autoState.LastStateUpdateTime;
                view.EstiExpiredDay = (int)context.EstiExpiredDay;
                view.LastResetTime = autoState.LastResetTime;
                view.ThreadStatus = (ThreadStatus)Enum.Parse(typeof(ThreadStatus), autoState.ThreadStatus);
                view.BookedPiLotId = autoState.BookPiLot;
                view.IsValid = autoState.IsValid != 0;
                view.Remark = autoState.Remark;
                view.CounterConsecutiveMaxAdjust = autoState.CounterConsecutiveMaxAdjust;
                view.LotListSinceLastValidMetro = autoState.LotListSinceLastValidMetro;
                view.LotlistConsecutiveGof = autoState.LotlistConsecutiveGof;
                view.LotlistConsecutiveOos = autoState.LotlistConsecutiveOos;
            }

            //preLine Avg
            if (preLineAvg != null)
            {
                view.PreMetroLineFFDisb = (decimal)preLineAvg.FfDisb;
                view.PreMetroLineAvg = (decimal)preLineAvg.PreMetroLineAvg;
                view.PreMetroLineLastUpdateTime = preLineAvg.LastUpdateTime;
            }

            return view;
        }

        public object[] GetMaterializedViewValueList(IQueryCollection query, string propertyName)
        {
            using EtchDBContext db = CreateDBContext();

            var joinedQuery = from c in db.ContextRepository
                              join s in db.StrategyConstantRepository on c.ContextId equals s.ContextId
                              into grouping1
                              from s in grouping1.DefaultIfEmpty()
                              join a in db.AutoStatesRepository
                              on c.ContextId equals a.ContextId
                              into grouping2
                              from a in grouping2.DefaultIfEmpty()
                              select new
                              {
                                  c.Fab,
                                  c.ProductId,
                                  c.Stage,
                                  c.Recipe,
                                  c.StepName,
                                  c.StepNumber,
                                  c.Tool,
                                  c.Chamber,
                                  c.ContextGroup,
                                  c.ControlFlag,
                                  ControlLevel = 1 == c.LotLevelControl ? DTO.ControlLevel.LotLevel : DTO.ControlLevel.WaferLevel,
                                  c.ControlType,
                                  c.ContextId,
                                  c.ProcessId,
                                  c.LastModifiedTime,
                                  c.LastModifiedBy,
                                  EstiExpiredDay = s == null ? 0 : s.MaxTimeLastStateEstDays,
                                  LastEstiTime = a.LastStateUpdateTime,
                                  LastResetTime = a.LastResetTime,
                                  ThreadStatus = a.ThreadStatus,
                                  BookedPiLotId = a.BookPiLot,
                                  IsValid = a == null ? 0 : a.IsValid,
                                  Remark = a.Remark,
                                  CounterConsecutiveMaxAdjust = s == null ? 0 : a.CounterConsecutiveMaxAdjust,
                                  LotListSinceLastValidMetro = a.LotListSinceLastValidMetro,
                                  LotlistConsecutiveGof = a.LotlistConsecutiveGof,
                                  LotlistConsecutiveOos = a.LotlistConsecutiveOos,
                              };
            return joinedQuery.AsNoTracking().Where(j => j.Fab == TxnContext.Fab).GetValueList(query, propertyName);
        }

        public int GetMaterializedViewCount(IQueryCollection query)
        {
            using EtchDBContext db = CreateDBContext();

            var joinedQuery = from c in db.ContextRepository
                              join s in db.StrategyConstantRepository on c.ContextId equals s.ContextId
                              into grouping1
                              from s in grouping1.DefaultIfEmpty()
                              join a in db.AutoStatesRepository
                              on c.ContextId equals a.ContextId
                              into grouping2
                              from a in grouping2.DefaultIfEmpty()
                              select new
                              {
                                  c.Fab,
                                  c.ProductId,
                                  c.Stage,
                                  c.Recipe,
                                  c.StepName,
                                  c.StepNumber,
                                  c.Tool,
                                  c.Chamber,
                                  c.ContextGroup,
                                  c.ControlFlag,
                                  ControlLevel = 1 == c.LotLevelControl ? DTO.ControlLevel.LotLevel : DTO.ControlLevel.WaferLevel,
                                  c.ControlType,
                                  c.ContextId,
                                  c.ProcessId,
                                  c.LastModifiedTime,
                                  c.LastModifiedBy,
                                  EstiExpiredDay = s == null ? 0 : s.MaxTimeLastStateEstDays,
                                  LastEstiTime = a.LastStateUpdateTime,
                                  LastResetTime = a.LastResetTime,
                                  ThreadStatus = a.ThreadStatus,
                                  BookedPiLotId = a.BookPiLot,
                                  IsValid = a == null ? 0 : a.IsValid,
                                  Remark = a.Remark,
                                  CounterConsecutiveMaxAdjust = s == null ? 0 : a.CounterConsecutiveMaxAdjust,
                                  LotListSinceLastValidMetro = a.LotListSinceLastValidMetro,
                                  LotlistConsecutiveGof = a.LotlistConsecutiveGof,
                                  LotlistConsecutiveOos = a.LotlistConsecutiveOos,
                              };
            return joinedQuery.ApplyFilters(query).Count();
        }

        public void UpdateMaterializedViewParameter(int contextId, List<MaterializeViewParameter> materializeViewParameters)
        {
            using EtchDBContext db = CreateDBContext();
            BaseEntities.ChangeRequest cr = TryEditing(TxnContext.Area, ObjectName.Context.ToString(), "CreateContext", TxnContext.UserName, TxnContext.Comment, TxnContext.TxnId, "", "NA");


            using var transaction = db.Database.BeginTransaction();
            try
            {

            }
            catch
            {

            }


            return;
        }


        public void ChangeContextControlFlag(int contextId, ControlFlag controlFlag)
        {
            using EtchDBContext db = CreateDBContext();
            Entities.Context contextEntity = db.ContextRepository.Find(contextId);
            if (contextEntity == null)
                throw new ApiException(GeneralErrorCode.ResourceNotFound);
            DTO.Context context = _contextService.ConvertContextEntityToDTO(contextEntity);

            BaseEntities.ChangeRequest cr = TryEditing(TxnContext.Area, ObjectName.Context.ToString(), "ChangeFlag", TxnContext.UserName, TxnContext.Comment, TxnContext.TxnId, context.ContextKey, "NA");

            using var transaction = db.Database.BeginTransaction();
            try
            {
                //TODO business log
                contextEntity.ControlFlag = controlFlag.ToString();
                if (controlFlag.Equals(ControlFlag.Active))
                {
                    //check if AutoState existed
                    AutoStates autoStates = db.AutoStatesRepository.Find(contextId);
                    if (autoStates == null)
                        throw new EtchException(ErrorCode.NoneStatesFound, "Can't change to Active because of none states found, Need run Fixed first!");
                }
                db.ContextRepository.Update(contextEntity);

                db.SaveChanges();
                transaction.Commit();

                cr.ContextGroupValue1 = context.ContextId.ToString();
                cr.ContextGroupValue = string.Format("{0}:{1}:{2}:{3}:{4}:{5}:{6}:{7}:{8}", context.Fab, context.ProductId, context.Stage, context.Recipe, context.StepName, context.StepNumber, context.Tool, context.Chamber, context.ContextGroup);
                cr.ContxtGroup = string.Format("{0}:{1}:{2}:{3}:{4}:{5}:{6}:{7}:{8}", "Fab", "ProductId", "Stage", "Recipe", "StepName", "StepNumber", "Tool", "Chamber", "ContextGroup");
                cr.CrDetails = "ControlFlag Change to:" + controlFlag.ToString();
                EndEditing(cr, true);

            }
            catch (Exception ex)
            {
                transaction.Rollback();
                cr.Reason = ex.Message.Substring(0, ex.Message.Length > 255 ? 255 : ex.Message.Length);
                if (cr != null) EndEditing(cr, false);
                throw ex;
            }
        }

        public void ChangeContextControlLevel(int contextId, ControlLevel controlLevel)
        {
            using EtchDBContext db = CreateDBContext();
            Entities.Context contextEntity = db.ContextRepository.Find(contextId);
            if (contextEntity == null)
                throw new ApiException(GeneralErrorCode.ResourceNotFound);
            DTO.Context context = _contextService.ConvertContextEntityToDTO(contextEntity);

            BaseEntities.ChangeRequest cr = TryEditing(TxnContext.Area, ObjectName.Context.ToString(), "ChangeControlLevel", TxnContext.UserName, TxnContext.Comment, TxnContext.TxnId, context.ContextKey, "NA");

            using var transaction = db.Database.BeginTransaction();
            try
            {
                //TODO business log

                contextEntity.LotLevelControl = controlLevel.Equals(ControlLevel.LotLevel) ? 1 : 0;

                db.ContextRepository.Update(contextEntity);

                db.SaveChanges();
                transaction.Commit();

                cr.ContextGroupValue1 = context.ContextId.ToString();
                cr.ContextGroupValue = string.Format("{0}:{1}:{2}:{3}:{4}:{5}:{6}:{7}:{8}", context.Fab, context.ProductId, context.Stage, context.Recipe, context.StepName, context.StepNumber, context.Tool, context.Chamber, context.ContextGroup);
                cr.ContxtGroup = string.Format("{0}:{1}:{2}:{3}:{4}:{5}:{6}:{7}:{8}", "Fab", "ProductId", "Stage", "Recipe", "StepName", "StepNumber", "Tool", "Chamber", "ContextGroup");
                cr.CrDetails = "ControlLevel Change to:" + controlLevel.ToString();
                EndEditing(cr, true);

            }
            catch (Exception ex)
            {
                transaction.Rollback();
                cr.Reason = ex.Message.Substring(0, ex.Message.Length > 255 ? 255 : ex.Message.Length);
                if (cr != null) EndEditing(cr, false);
                throw ex;
            }
        }

        public void ChangeContextControlType(int contextId, ControlType controlType)
        {
            using EtchDBContext db = CreateDBContext();
            Entities.Context contextEntity = db.ContextRepository.Find(contextId);
            if (contextEntity == null)
                throw new ApiException(GeneralErrorCode.ResourceNotFound);
            DTO.Context context = _contextService.ConvertContextEntityToDTO(contextEntity);

            BaseEntities.ChangeRequest cr = TryEditing(TxnContext.Area, ObjectName.Context.ToString(), "ChangeControlType", TxnContext.UserName, TxnContext.Comment, TxnContext.TxnId, context.ContextKey, "NA");

            using var transaction = db.Database.BeginTransaction();
            try
            {
                //TODO business log

                contextEntity.ControlType = controlType.ToString();

                db.ContextRepository.Update(contextEntity);

                db.SaveChanges();
                transaction.Commit();

                cr.ContextGroupValue1 = context.ContextId.ToString();
                cr.ContextGroupValue = string.Format("{0}:{1}:{2}:{3}:{4}:{5}:{6}:{7}:{8}", context.Fab, context.ProductId, context.Stage, context.Recipe, context.StepName, context.StepNumber, context.Tool, context.Chamber, context.ContextGroup);
                cr.ContxtGroup = string.Format("{0}:{1}:{2}:{3}:{4}:{5}:{6}:{7}:{8}", "Fab", "ProductId", "Stage", "Recipe", "StepName", "StepNumber", "Tool", "Chamber", "ContextGroup");
                cr.CrDetails = "ControlType Change to:" + controlType.ToString();
                EndEditing(cr, true);

            }
            catch (Exception ex)
            {
                transaction.Rollback();
                cr.Reason = ex.Message.Substring(0, ex.Message.Length > 255 ? 255 : ex.Message.Length);
                if (cr != null) EndEditing(cr, false);
                throw ex;
            }
        }

        public void ChangeContextControlConstraint(int contextId, ControlFlag controlFlag, ControlLevel controlLevel, ControlType controlType)
        {
            using EtchDBContext db = CreateDBContext();
            Entities.Context contextEntity = db.ContextRepository.Find(contextId);
            if (contextEntity == null)
                throw new ApiException(GeneralErrorCode.ResourceNotFound);
            DTO.Context context = _contextService.ConvertContextEntityToDTO(contextEntity);

            BaseEntities.ChangeRequest cr = TryEditing(TxnContext.Area, ObjectName.Context.ToString(), "ChangeFlag", TxnContext.UserName, TxnContext.Comment, TxnContext.TxnId, context.ContextKey, "NA");

            using var transaction = db.Database.BeginTransaction();
            try
            {
                //TODO business log
                contextEntity.ControlFlag = controlFlag.ToString();
                if (controlFlag.Equals(ControlFlag.Active))
                {
                    //check if AutoState existed
                    AutoStates autoStates = db.AutoStatesRepository.Find(contextId);
                    if (autoStates == null)
                        throw new EtchException(ErrorCode.NoneStatesFound, "Can't change to Active because of none states found, Need run Fixed first!");
                }
                contextEntity.LotLevelControl = controlLevel.Equals(ControlLevel.LotLevel) ? 1 : 0;
                contextEntity.ControlType = controlType.ToString();
                db.ContextRepository.Update(contextEntity);

                db.SaveChanges();
                transaction.Commit();

                cr.ContextGroupValue1 = context.ContextId.ToString();
                cr.ContextGroupValue = string.Format("{0}:{1}:{2}:{3}:{4}:{5}:{6}:{7}:{8}", context.Fab, context.ProductId, context.Stage, context.Recipe, context.StepName, context.StepNumber, context.Tool, context.Chamber, context.ContextGroup);
                cr.ContxtGroup = string.Format("{0}:{1}:{2}:{3}:{4}:{5}:{6}:{7}:{8}", "Fab", "ProductId", "Stage", "Recipe", "StepName", "StepNumber", "Tool", "Chamber", "ContextGroup");
                cr.CrDetails = "ControlType Change to: " + controlFlag.ToString() + "\r\n" +
                                "ControlLevel Change to: " + controlLevel.ToString() + "\r\n" +
                                "ControlType Change to: " + controlType.ToString() + "\r\n";
                EndEditing(cr, true);

            }
            catch (Exception ex)
            {
                transaction.Rollback();
                cr.Reason = ex.Message.Substring(0, ex.Message.Length > 255 ? 255 : ex.Message.Length);
                if (cr != null) EndEditing(cr, false);
                throw ex;
            }
        }

        public void ChangeContextThreadStatus(int contextId, ThreadStatus threadStatus, string BookedPilotId)
        {
            using EtchDBContext db = CreateDBContext();
            Entities.Context contextEntity = db.ContextRepository.Find(contextId);
            if (contextEntity == null)
                throw new ApiException(GeneralErrorCode.ResourceNotFound);
            DTO.Context context = _contextService.ConvertContextEntityToDTO(contextEntity);

            BaseEntities.ChangeRequest cr = TryEditing(TxnContext.Area, ObjectName.Context.ToString(), "ChangeThreadStatus", TxnContext.UserName, TxnContext.Comment, TxnContext.TxnId, context.ContextKey, "NA");

            using var transaction = db.Database.BeginTransaction();
            try
            {
                //TODO business log

                Entities.AutoStates autoStates = db.AutoStatesRepository.Find(contextId);
                if (autoStates == null)
                    throw new ApiException(GeneralErrorCode.ResourceNotFound, "None State found on the Context, please run lot in Fixed Mode first!");

                autoStates.ThreadStatus = threadStatus.ToString();
                autoStates.BookPiLot = BookedPilotId;
                db.AutoStatesRepository.Update(autoStates);

                db.SaveChanges();
                transaction.Commit();

                cr.ContextGroupValue1 = context.ContextId.ToString();
                cr.ContextGroupValue = string.Format("{0}:{1}:{2}:{3}:{4}:{5}:{6}:{7}:{8}", context.Fab, context.ProductId, context.Stage, context.Recipe, context.StepName, context.StepNumber, context.Tool, context.Chamber, context.ContextGroup);
                cr.ContxtGroup = string.Format("{0}:{1}:{2}:{3}:{4}:{5}:{6}:{7}:{8}", "Fab", "ProductId", "Stage", "Recipe", "StepName", "StepNumber", "Tool", "Chamber", "ContextGroup");
                cr.CrDetails = "ThreadStatus Change to:" + threadStatus.ToString() + "\r\n" +
                                            "BookedPilotId:" + BookedPilotId;
                EndEditing(cr, true);

            }
            catch (Exception ex)
            {
                transaction.Rollback();
                cr.Reason = ex.Message.Substring(0, ex.Message.Length > 255 ? 255 : ex.Message.Length);
                if (cr != null) EndEditing(cr, false);
                throw ex;
            }
        }

        public void ResetControlThreadByContext(int contextId)
        {
            using EtchDBContext db = CreateDBContext();
            Entities.Context contextEntity = db.ContextRepository.Find(contextId);
            if (contextEntity == null)
                throw new ApiException(GeneralErrorCode.ResourceNotFound);
            DTO.Context context = _contextService.ConvertContextEntityToDTO(contextEntity);

            BaseEntities.ChangeRequest cr = TryEditing(TxnContext.Area, ObjectName.Context.ToString(), "ResetContext", TxnContext.UserName, TxnContext.Comment, TxnContext.TxnId, context.ContextKey, "NA");

            using var transaction = db.Database.BeginTransaction();
            try
            {
                Entities.AutoStates autoStates = db.AutoStatesRepository.Find(contextId);
                if (autoStates == null)
                    throw new ApiException(GeneralErrorCode.ResourceNotFound, "None State found on the Context, please run lot in Fixed Mode first!");


                //go to reset the thread
                string retMessage = this.ResetThread(TxnContext.UserName, autoStates.ContextId, autoStates.Fab, TxnContext.Area, autoStates.ProductId, autoStates.Stage, autoStates.Recipe,
                    autoStates.StepName, autoStates.StepNumber, autoStates.Tool, autoStates.Chamber, autoStates.ContextGroup,
                    ThreadStatus.PiRun.ToString(), "", TxnContext.Comment);

                if ("Success".Equals(retMessage))
                {

                }
                else
                {
                    throw new EtchException(ErrorCode.ThreadResetFail, retMessage);
                }

                cr.ContextGroupValue1 = context.ContextId.ToString();
                cr.ContextGroupValue = string.Format("{0}:{1}:{2}:{3}:{4}:{5}:{6}:{7}:{8}", context.Fab, context.ProductId, context.Stage, context.Recipe, context.StepName, context.StepNumber, context.Tool, context.Chamber, context.ContextGroup);
                cr.ContxtGroup = string.Format("{0}:{1}:{2}:{3}:{4}:{5}:{6}:{7}:{8}", "Fab", "ProductId", "Stage", "Recipe", "StepName", "StepNumber", "Tool", "Chamber", "ContextGroup");
                cr.CrDetails = "Reset Context";
                EndEditing(cr, true);

            }
            catch (Exception ex)
            {
                transaction.Rollback();
                cr.Reason = ex.Message.Substring(0, ex.Message.Length > 255 ? 255 : ex.Message.Length);
                if (cr != null) EndEditing(cr, false);
                throw ex;
            }


            return;
        }

        public void ResetControlThreadByTool(string tool)
        {

            return;
        }

        public DTO.ChamberOffset GetChamberOffset(string tool, string chamberId)
        {
            using EtchDBContext db = CreateDBContext();
            DTO.ChamberOffset chamberOffset = new DTO.ChamberOffset();
            try
            {
                List<Entities.ChamberOffset> offsets = db.ChamberOffsetRepository.Where(t => t.ToolId == tool && t.ChamberId == chamberId).ToList();
                List<BaseDTO.Parameter> parameters = this._globalService.GetProcessParameterList(tool, chamberId);


                chamberOffset.Chamber = chamberId;
                chamberOffset.Tool = tool;
                foreach (BaseDTO.Parameter parameter in parameters)
                {
                    ChamberOffsetItem coi = new ChamberOffsetItem();
                    coi.ParameterName = parameter.ParameterName;
                    coi.Chamber = chamberId;
                    coi.Tool = tool;
                    coi.ParameterValue = 0;
                    //check from real offsets
                    List<Entities.ChamberOffset> offset2 = offsets.Where(t => t.ParameterName == parameter.ParameterName).ToList(); ;
                    if (offset2 != null && offset2.Count > 0)
                    {
                        coi.ParameterValue = offset2[0].Offset;
                        coi.LastModifiedTime = offset2[0].LastModifyDate;
                        coi.LastModifiedBy = offset2[0].LastModifyBy;
                    }
                    else
                    {
                        coi.ParameterValue = 0;
                    }
                    chamberOffset.ChamberOffsetItems.Add(coi);
                }
                return chamberOffset;
            }
            catch
            {
                throw;
            }
        }
        public void UpdateChamberOffsetItem(DTO.ChamberOffsetItem chamberOffsetItem)
        {
            using EtchDBContext db = CreateDBContext();
            string contextValue = chamberOffsetItem.Tool + ":" + chamberOffsetItem.Chamber;
            BaseEntities.ChangeRequest cr = TryEditing(TxnContext.Area, ObjectName.Context.ToString(), "UpdateChamberOffset", TxnContext.UserName, TxnContext.Comment, TxnContext.TxnId, contextValue, "NA");

            using var transaction = db.Database.BeginTransaction();
            try
            {
                Entities.ChamberOffset offset = db.ChamberOffsetRepository.Find(new string[] { chamberOffsetItem.Tool, chamberOffsetItem.Chamber, chamberOffsetItem.ParameterName });
                if (offset == null)
                {
                    offset = new Entities.ChamberOffset();
                    offset.ChamberId = chamberOffsetItem.Chamber;
                    offset.ToolId = chamberOffsetItem.Tool;
                    offset.ParameterName = chamberOffsetItem.ParameterName;
                    offset.Offset = chamberOffsetItem.ParameterValue;
                    offset.LastModifyBy = TxnContext.UserName;
                    offset.LastModifyDate = cr.CrTimeStamp;
                    db.ChamberOffsetRepository.Add(offset);
                }
                else
                {
                    offset.Offset = chamberOffsetItem.ParameterValue;
                    offset.LastModifyBy = TxnContext.UserName;
                    offset.LastModifyDate = cr.CrTimeStamp;
                    db.ChamberOffsetRepository.Update(offset);
                }


                db.SaveChanges();
                transaction.Commit();

                ///
                cr.ContxtGroup = string.Format("{0}:{1}", "Tool", "Chamber");
                EndEditing(cr, true);

            }
            catch (Exception ex)
            {
                transaction.Rollback();
                cr.Reason = ex.Message.Substring(0, ex.Message.Length > 255 ? 255 : ex.Message.Length);
                if (cr != null) EndEditing(cr, false);
                throw;
            }
        }

        public void DeleteChamberOffsetItem(string toolId, string chamberId, string parameterName)
        {

            using EtchDBContext db = CreateDBContext();
            string contextValue = toolId + ":" + chamberId;
            BaseEntities.ChangeRequest cr = TryEditing(TxnContext.Area, ObjectName.Context.ToString(), "DeleteChamberOffset", TxnContext.UserName, TxnContext.Comment, TxnContext.TxnId, contextValue, "NA");

            using var transaction = db.Database.BeginTransaction();
            try
            {
                List<Entities.ChamberOffset> offsets = db.ChamberOffsetRepository.Where(t => t.ToolId == toolId && t.ChamberId == chamberId && t.ParameterName == parameterName).ToList();
                db.ChamberOffsetRepository.RemoveRange(offsets);
                db.SaveChanges();
                transaction.Commit();

                ///
                cr.ContxtGroup = string.Format("{0}:{1}", "Tool", "Chamber");
                EndEditing(cr, true);

            }
            catch (Exception ex)
            {
                transaction.Rollback();
                cr.Reason = ex.Message.Substring(0, ex.Message.Length > 255 ? 255 : ex.Message.Length);
                if (cr != null) EndEditing(cr, false);
                throw;
            }
        }

        private string ResetThread(string userName, int contextId, string fab, string area, string productId, string stage, string recipe, string stepName, string stepNumber, string tool, string chamber, string contextGroup, string threadStatus, string bookedPilot, string comment)
        {
            string retMessage = "";
            try
            {
                System.Collections.Hashtable resetParameters = new System.Collections.Hashtable();
                resetParameters.Add("ContextId", contextId);
                resetParameters.Add("Area", area);
                resetParameters.Add("Fab", fab);
                resetParameters.Add("UserName", userName);
                resetParameters.Add("ProductId", productId);
                resetParameters.Add("Stage", stage);
                resetParameters.Add("Recipe", recipe);
                resetParameters.Add("StepName", stepName);
                resetParameters.Add("StepNumber", stepNumber);
                resetParameters.Add("Tool", tool);
                resetParameters.Add("Chamber", chamber);
                resetParameters.Add("ContextGroup", contextGroup);
                resetParameters.Add("ClearViolation", true);
                resetParameters.Add("ThreadStatus", threadStatus);
                resetParameters.Add("BookedPilot", string.IsNullOrEmpty(bookedPilot) ? string.Empty : bookedPilot);
                resetParameters.Add("Comment", userName + ":" + comment);
                System.Xml.XmlDocument responseXml = WebServiceHelper.QuerySoapWebService(ConnectionHelper.ResetURL, "RestThread", resetParameters, "", "RestThread_input");

                bool success = false;
                if (WebServiceHelper.TryParseNodeInnerText(responseXml, "Success", out string value))
                {
                    success = "TRUE".Equals(value.ToUpper());
                }

                WebServiceHelper.TryParseNodeInnerText(responseXml, "Message", out string message);
                retMessage = message;

                if (success) return "Success";
                else return retMessage;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }


        }

    }
}
