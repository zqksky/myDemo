﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AMAT.R2R.Server.Base.Repository;
using AMAT.R2R.Server.Base.Service;
using AMAT.R2R.Server.Etch.Repository;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;

namespace AMAT.R2R.Server.Etch.Services
{
    public abstract class EtchService : BaseService
    {
        public EtchService(IServiceProvider serviceProvider, ILogger logger) : base(serviceProvider, logger)
        {
        }


        public EtchDBContext CreateDBContext()
        {
            var builder = new DbContextOptionsBuilder();
            var useOracleSQLCompatibility = Configuration.GetValue<bool>("Oracle:UseOracleSQLCompatibility");

            if (useOracleSQLCompatibility)
            {
                var version = Configuration.GetValue<string>("Oracle:CompatibilityVersion");

                //if (reuseConnection)
                //{
                //    builder = builder.UseOracle(ConnectionHelper.DbConnection, b => b.UseOracleSQLCompatibility(version));
                //}
                //else
                {
                    builder = builder.UseOracle(ConnectionHelper.ConnectionString, b => b.UseOracleSQLCompatibility(version));
                }
            }
            else
            {
                //if (reuseConnection)
                //{
                //    builder = builder.UseOracle(ConnectionHelper.DbConnection);
                //}
                //else
                {
                    builder = builder.UseOracle(ConnectionHelper.ConnectionString);
                }
            }
            
                
            builder = builder.UseLoggerFactory(LoggerFactory).EnableSensitiveDataLogging();
            return new EtchDBContext(builder.Options);

        }

    }
}
