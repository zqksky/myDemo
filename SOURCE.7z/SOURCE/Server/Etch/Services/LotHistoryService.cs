﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using System.Threading.Tasks;
using AMAT.R2R.Server.Base.Constants;
using AMAT.R2R.Server.Base.Exceptions;
using AMAT.R2R.Server.Base.Helpers;
using AMAT.R2R.Server.Base.Repository;
using AMAT.R2R.Server.Base.Service;
using AMAT.R2R.Server.Etch.Entities;
using AMAT.R2R.Server.Etch.Exceptions;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using BaseDTO = AMAT.R2R.Shared.Base.DTO;
using BaseEntities = AMAT.R2R.Server.Base.Entities;
using DTO = AMAT.R2R.Shared.Etch.DTO;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using AMAT.R2R.Shared.Etch.DTO;
using System.Data;
using Microsoft.EntityFrameworkCore.Query;
using AMAT.R2R.Server.Etch.Repository;
using System.Runtime.InteropServices;

namespace AMAT.R2R.Server.Etch.Services
{
    public interface ILotHistoryService
    {
        List<DTO.LotRunHistory> GetLotRunHistoryList(IQueryCollection query);

        object[] GetFilterValueList(IQueryCollection query, string propertyName);

        //Task<object[]> GetSpecialJobValueListAsync(IQueryCollection query, string propertyName);
        //Task<int> GetSpecialJobCountAsync(IQueryCollection query);
    }

    public class LotHistoryService : EtchService, ILotHistoryService
    {
        private ILogger<LotHistoryService> _logger;
        private IGlobalService _globalService;
        public LotHistoryService(IProcessService processService, IGlobalService globalService,IServiceProvider serviceProvider, ILogger<LotHistoryService> logger) : base(serviceProvider, logger)
        {
            _logger = logger;
            _globalService = globalService;
        }

        public List<DTO.LotRunHistory> GetLotRunHistoryList(IQueryCollection query)
        {
            List<BaseDTO.Parameter> parameters = _globalService.GetProcessParameterAll();
            Dictionary<string, string> paraAlias = new Dictionary<string, string>();

            foreach (BaseDTO.Parameter p in parameters)
            {
                paraAlias[p.Tool.ToolId+p.Chamber.ChamberId+p.ParameterName] = string.IsNullOrEmpty(p.AliasName) ? p.ParameterName : p.AliasName;
            }

            List<LotRunHistory> lotHistList = GetLotRunHistoryList(query, true, paraAlias);
            List<LotRunHistory> waferHistList = GetLotRunHistoryList(query, false, paraAlias);

            foreach (var run in waferHistList)
            {
                run.Id = $"{run.TxId}:{run.Tool}:{run.Chamber}:{run.ContextGroup}:{run.ProductId}:{run.Stage}:{run.Recipe}:{run.StepName}:{run.StepNumber}:{run.LotId}:{run.WaferId}";
            }

            foreach (LotRunHistory run in lotHistList)
            {
                run.Id = $"{run.TxId}:{run.Tool}:{run.Chamber}:{run.ContextGroup}:{run.ProductId}:{run.Stage}:{run.Recipe}:{run.StepName}:{run.StepNumber}:{run.LotId}";

                List<LotRunHistory> lotWaferHistList = waferHistList.Where(t => t.LotId == run.LotId && t.Tool == run.Tool && t.Chamber == run.Chamber && t.ContextGroup == run.ContextGroup && t.ProductId == run.ProductId && t.Stage == run.Stage && t.Recipe == run.Recipe && t.StepName == run.StepName && t.StepNumber == run.StepNumber).ToList();
                foreach (var waferHis in lotWaferHistList)
                {
                    waferHis.ParentId = run.Id;
                }

                //if (wafers != null && wafers.Count > 0)
                //{

                //    //run.waferHist = wafers;
                //    //WaferHist.RemoveAll(t => t.LotId == run.LotId && t.Tool == run.Tool && t.Chamber == run.Chamber && t.ContextGroup == run.ContextGroup && t.ProductId == run.ProductId && t.Stage == run.Stage && t.Recipe == run.Recipe && t.StepName == run.StepName && t.StepNumber == run.StepNumber);
                //}
            }

            lotHistList.AddRange(waferHistList);

            return lotHistList;
        }

        private List<DTO.LotRunHistory> GetLotRunHistoryList(IQueryCollection query, bool lotLevel, Dictionary<string, string> paraAlias)
        {
            List<DTO.LotRunHistory> hists = new List<DTO.LotRunHistory>();
            using EtchDBContext db = CreateDBContext();

            var hznQuery = from lothzn in db.HznMaterializedRepository
                           where lotLevel ? (lothzn.WaferScribe == "LotLevel" || lothzn.LotId == lothzn.WaferScribe) : (lothzn.WaferScribe != "LotLevel" && lothzn.LotId != lothzn.WaferScribe)
                           select lothzn;

            hznQuery = hznQuery.Where(j => j.Fab == TxnContext.Fab).ApplyFilters(query);

            var sortable = hznQuery.AsNoTracking().ApplySorters(query);
            var result = sortable.ToList();

             
            foreach (var item in result)
            {
                LotRunHistory lrh = new LotRunHistory();
                lrh.LotId = item.LotId;
                lrh.ProductId = item.ProductId;
                lrh.Tool = item.Tool;
                lrh.Recipe = item.Recipe;
                lrh.Stage = item.Stage;
                lrh.StepName = item.StepName;
                lrh.StepNumber = item.StepNumber;
                lrh.ContextGroup = item.ContextGroup;
                lrh.Chamber = item.Chamber;
                lrh.PilotFlag = "true".Equals(item.PilotFlag)?"Y":"N";
                lrh.ControlFlag = item.R2RMode;
                lrh.MotherLot = "";
                lrh.RunCardId = item.RunCardId;
                lrh.SplitId = item.SplitId;
                lrh.SpecifyLot = "No".Equals(item.SpecifyLot)?"N":item.SpecifyLot;
                lrh.Remark = item.Remark;
                lrh.WaferId = lotLevel ? item.WaferList : item.WaferScribe;
                lrh.WaferQty = lotLevel ? (string.IsNullOrEmpty(item.WaferList) ? 0 : item.WaferList.Split(",").Length) : 1;

                lrh.ControlLevel = "LotLevel".Equals(item.WaferScribe) ? "LotLevel" : "WaferLevel";
                //lrh.ControlType = item.
                lrh.ProcessStamp = item.UsedTimeStamp;
                lrh.PostTimeStamp = item.PostTimeStamp;
                lrh.EstiTimeStamp = item.NewRecSettingsFb != null ? item.PostTimeStamp : null;

                lrh.TxId = item.TxId;
                lrh.ModelingTick = item.ModelingTick;

                //chamberoffser data
                lrh.ChamberOffsets = new List<LotHistoryParameter>();
                if (item.InputParameter != null && item.ChamberOffset != null)
                {
                    string[] params_name = item.InputParameter.Split(",");
                    string[] params_val = item.ChamberOffset.Split(",");
                    for (int i = 0; i < params_name.Count(); i++)
                    {
                        if (params_val.Length > i)
                        {
                            lrh.ChamberOffsets.Add(new LotHistoryParameter() { Name = paraAlias.ContainsKey(lrh.Tool+lrh.Chamber+params_name[i]) ? paraAlias[lrh.Tool + lrh.Chamber + params_name[i]] : params_name[i], Value = params_val[i], IsNumeric = true });
                        }
                    }
                }

                //FinalRecSettings data
                lrh.FinalRecSettings = new List<LotHistoryParameter>();
                if (item.InputParameter != null && item.FinalRecSettings != null)
                {
                    string[] params_name = item.InputParameter.Split(",");
                    string[] params_val = item.FinalRecSettings.Split(",");
                    for (int i = 0; i < params_name.Count(); i++)
                    {
                        if (params_val.Length > i)
                        {
                            lrh.FinalRecSettings.Add(new LotHistoryParameter() { Name = paraAlias.ContainsKey(lrh.Tool + lrh.Chamber + params_name[i])? paraAlias[lrh.Tool + lrh.Chamber + params_name[i]]: params_name[i], Value = params_val[i], IsNumeric = true });
                        }
                    }
                }


                //RecSettings data
                lrh.RecSettings = new List<LotHistoryParameter>();
                if (item.InputParameter != null && item.RecipeSettings != null)
                {
                    string[] params_name = item.InputParameter.Split(",");
                    string[] params_val = item.RecipeSettings.Split(",");
                    for (int i = 0; i < params_name.Count(); i++)
                    {
                        if (params_val.Length > i)
                        {
                            lrh.RecSettings.Add(new LotHistoryParameter() { Name = paraAlias.ContainsKey(lrh.Tool + lrh.Chamber + params_name[i]) ? paraAlias[lrh.Tool + lrh.Chamber + params_name[i]] : params_name[i], Value = params_val[i], IsNumeric = true });
                        }
                    }
                }

                //DefaultRecSettings data
                lrh.DefaultRecSettings = new List<LotHistoryParameter>();
                if (item.InputParameter != null && item.DefaultRecSettings != null)
                {
                    string[] params_name = item.InputParameter.Split(",");
                    string[] params_val = item.DefaultRecSettings.Split(",");
                    for (int i = 0; i < params_name.Count(); i++)
                    {
                        if (params_val.Length > i)
                        {
                            lrh.DefaultRecSettings.Add(new LotHistoryParameter() { Name = paraAlias.ContainsKey(lrh.Tool + lrh.Chamber + params_name[i]) ? paraAlias[lrh.Tool + lrh.Chamber + params_name[i]] : params_name[i], Value = params_val[i], IsNumeric = true });
                        }
                    }
                }

                //process data
                lrh.ProcessVaues = new List<LotHistoryParameter>();
                if (item.InputParameter != null && item.UsedSettings != null)
                {
                    string[] params_name = item.InputParameter.Split(",");
                    string[] params_val = item.UsedSettings.Split(",");
                    for (int i = 0; i < params_name.Count(); i++)
                    {
                        if (params_val.Length > i)
                        {
                            lrh.ProcessVaues.Add(new LotHistoryParameter() { Name = paraAlias.ContainsKey(lrh.Tool + lrh.Chamber + params_name[i]) ? paraAlias[lrh.Tool + lrh.Chamber + params_name[i]] : params_name[i], Value = params_val[i], IsNumeric = true });
                        }
                    }
                }
                //fb data
                lrh.EstimateValues = new List<LotHistoryParameter>();
                if (item.InputParameter != null && item.NewRecSettingsFb != null)
                {
                    string[] params_name = item.InputParameter.Split(",");
                    string[] params_val = item.NewRecSettingsFb.Split(",");
                    for (int i = 0; i < params_name.Count(); i++)
                    {
                        if (params_val.Length > i)
                        {
                            lrh.EstimateValues.Add(new LotHistoryParameter() { Name = paraAlias.ContainsKey(lrh.Tool + lrh.Chamber + params_name[i]) ? paraAlias[lrh.Tool + lrh.Chamber + params_name[i]] : params_name[i], Value = params_val[i], IsNumeric = true });
                        }
                    }
                }

                //pre metrology data
                lrh.PreMetrologyValues = new List<LotHistoryParameter>();
                if (item.PreParameter != null && item.PreMetrology != null)
                {
                    string[] params_name = item.PreParameter.Split(",");
                    string[] params_val = item.PreMetrology.Split(",");
                    for (int i = 0; i < params_name.Count(); i++)
                    {
                        if (params_val.Length > i)
                        {
                            lrh.PreMetrologyValues.Add(new LotHistoryParameter() { Name = params_name[i], Value = params_val[i], IsNumeric = true });
                        }
                    }
                }

                //post metrology data
                lrh.PostMetrologyValues = new List<LotHistoryParameter>();
                if (item.PostParameter != null && item.PostMetrology != null)
                {
                    string[] params_name = item.PostParameter.Split(",");
                    string[] params_val = item.PostMetrology.Split(",");
                    for (int i = 0; i < params_name.Count(); i++)
                    {
                        if (params_val.Length > i)
                        {
                            lrh.PostMetrologyValues.Add(new LotHistoryParameter() { Name = params_name[i], Value = params_val[i], IsNumeric = true });
                        }
                    }
                }

                hists.Add(lrh);
            }
            return hists;
        }
        public object[] GetFilterValueList(IQueryCollection query, string propertyName)
        {
            using EtchDBContext db = CreateDBContext();
            var queryable = db.ContextRepository.AsNoTracking().Where(s => s.Fab == TxnContext.Fab).ApplyFilters(query);
            return queryable.GetValueList(query, propertyName);
        }
    }
}
