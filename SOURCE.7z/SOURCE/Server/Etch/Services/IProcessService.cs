﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Contracts;
using System.Linq;
using System.Threading.Tasks;
using AMAT.R2R.Server.Base;
using AMAT.R2R.Server.Base.Constants;
using AMAT.R2R.Server.Base.Exceptions;
using AMAT.R2R.Server.Base.Repository;
using AMAT.R2R.Server.Base.Service;
using AMAT.R2R.Server.Etch.Entities;
using AMAT.R2R.Server.Etch.Exceptions;
using AMAT.R2R.Server.Etch.Repository;
using AMAT.R2R.Shared.Base.DTO;
using AMAT.R2R.Shared.Etch.DTO;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.CodeAnalysis.CSharp.Syntax;
using Microsoft.EntityFrameworkCore;
using Namotion.Reflection;
using BaseDTO = AMAT.R2R.Shared.Base.DTO;
using BaseEntities = AMAT.R2R.Server.Base.Entities;
using DTO = AMAT.R2R.Shared.Etch.DTO;
using Entities = AMAT.R2R.Server.Etch.Entities;

namespace AMAT.R2R.Server.Etch.Services
{
    public interface IProcessService
    {
        List<DTO.Process> GetProcessList(IQueryCollection query);

        int GetProcessCount(IQueryCollection query);
        object[] GetProcessValueList(IQueryCollection query, string propertyName);

        DTO.Process GetProcessInfoByID(int processId);

        DTO.Process CreateProcess(DTO.Process process);

        void UpdateProcess(DTO.Process process);

        void DeleteProcess(int processId);

        DTO.FeedforwardSetting CreateFeedforwardSetting(DTO.FeedforwardSetting feedwardSetting);
        FeedforwardSetting GetFeedforwardSetting(int processId, int settingId);

        void UpdateFeedforwardSetting(DTO.FeedforwardSetting feedwardSetting);

        List<FeedforwardSetting> GetFeedforwardSettingList(int processId);

        void DeleteFeedforwardSetting(int processId, int settingId);

        DTO.OutputSetting CreateOutputSetting(DTO.OutputSetting outputSetting);
        OutputSetting GetOutputSetting(int processId, int settingId);

        void UpdateOutputSetting(DTO.OutputSetting outputSetting);

        List<OutputSetting> GetOutputSettingList(int processId);

        void DeleteOutputSetting(int processId, int settingId);


        DTO.PreMetrology CreatePreMetrology(DTO.PreMetrology preMetrology);
        List<DTO.PreMetrology> GetPreMetrologyList(int processId);
        void DeletePreMetrology(int processId, string metrologyKey);


        DTO.PostMetrology CreatePostMetrology(DTO.PostMetrology postMetrology);

        List<DTO.PostMetrology> GetPostMetrologyList(int processId);

        void DeletePostMetrology(int processId, string metrologyKey);


        // move to process service
        ManualPreMetrology GetManualPreMetrologyInfo(int processId);
        ManualPreMetrologyItem AddManualPreMetrologyItem(ManualPreMetrologyItem manualPreMetrologyItem);
        void DeleteManualPreMetrologyItem(ManualPreMetrologyItem manualPreMetrologyItem);
        void DeleteManualPreMetrologyItem(int processId, string uniqueId);
    }
}
