﻿using System.Text;
using AMAT.R2R.Server.Base;
using AMAT.R2R.Server.Base.Repository;
using AMAT.R2R.Server.Base.Service;
using AMAT.R2R.Server.Etch.Repository;
using AMAT.R2R.Server.Etch.Services;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Server.Kestrel.Core;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.IdentityModel.Tokens;
using Oracle.ManagedDataAccess.Client;

namespace AMAT.R2R.Server.Etch
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
            //Configuration["Position:Title"];
            //var positionOptions = new PositionOptions();
            //Configuration.GetSection("Position").Bind(positionOptions);    
            ConnectionHelper.ConnectionString = Configuration.GetConnectionString("etch");
            ConnectionHelper.LoginURL = Configuration.GetSection("Login:URL").Value;
            ConnectionHelper.ResetURL = Configuration.GetSection("ResetThread:URL").Value;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            // https://stackoverflow.com/questions/47735133/asp-net-core-synchronous-operations-are-disallowed-call-writeasync-or-set-all

            // If using Kestrel:
            services.Configure<KestrelServerOptions>(options =>
            {
                options.AllowSynchronousIO = true;
            });

            // If using IIS:
            services.Configure<IISServerOptions>(options =>
            {
                options.AllowSynchronousIO = true;
            });

            services.AddControllers().AddNewtonsoftJson(o => o.SerializerSettings.ContractResolver = new Newtonsoft.Json.Serialization.DefaultContractResolver());

            // Register the Swagger services
            services.AddSwaggerDocument();


            services.AddHttpContextAccessor();
            services.AddHttpClient();
            //services.AddScoped<E3suiteDBContext, EtchDBContext>();//dbc
            services.AddScoped<IRepositoryFactory, RepositoryFactory>();//T factory
            services.AddScoped<IAuthenticationService, AuthenticationService>();//ioc
            services.AddScoped<IGlobalService, GlobalService>();//ioc
            services.AddScoped<IProcessService, ProcessService>();//ioc
            services.AddScoped<IContextService, ContextService>();//ioc
            services.AddScoped<IMaterializedService, MaterializedService>();//ioc
            services.AddScoped<ILotHistoryService, LotHistoryService>();//ioc

            services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme).AddJwtBearer(options =>
            {
                options.RequireHttpsMetadata = false;
                options.SaveToken = true;
                options.TokenValidationParameters = new TokenValidationParameters()
                {
                    ValidateIssuer = true,
                    ValidateAudience = true,
                    ValidAudience = Configuration["Jwt:Audience"],
                    ValidIssuer = Configuration["Jwt:Issuer"],
                    IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(Configuration["Jwt:Key"]))
                };
            });
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            if (env.IsProduction() || env.IsStaging() || env.IsEnvironment("Staging_2"))
            {
                app.UseExceptionHandler("/Error");
            }

            app.UseMiddleware(typeof(ErrorHandlingMiddleware));

            app.UseHttpsRedirection();

            app.UseRouting();

            app.UseAuthentication(); // enables 

            app.UseAuthorization();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });

            // Register the Swagger generator and the Swagger UI middlewares
            app.UseOpenApi();
            app.UseSwaggerUi3();

            //
        }
    }
}
