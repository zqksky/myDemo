﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AMAT.R2R.Server.Base.Constants
{
    public enum GeneralErrorCode
    {
        UnexpectedError = -1,

        // generic errors
        ResourceNotFound = 1,
        IdMismatch = 2,
        ResourceAlreadyExists = 3,
        CannotDeleteWhenResourceInUse = 4,

        // DB errors
        DBNotAvailable = 101,

        // Authentication related errors
        UserNameAndPasswordCanNotBeEmpty = 201,
        UserDoesNotExist = 202,
        WrongPassword = 203,
        SessionTimeout = 204,
        FailToLogin = 205,
        //change request fail
        RequstChangeFail = 250,
        GlobalServiceError = 260

    }

    public enum ObjectName
    {
        Process,
        //Global,
        Context,
        SpecialJob,
        Material,
        Metrology,//the pre or post metrology setting ,
        Tool,
        Product,
        ToolStatus,
    }

    public enum CR_Status
    {
        Submitted,
        Approved,
        Fail
    }
}
