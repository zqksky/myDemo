﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AMAT.R2R.Server.Base.Repository;

namespace AMAT.R2R.Server.Base.Service
{
    public interface IBaseService
    {

    }
}
