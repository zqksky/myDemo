﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Contracts;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Xml;
using AMAT.R2R.Server.Base.Constants;
using AMAT.R2R.Server.Base.Exceptions;
using AMAT.R2R.Server.Base.Extensions;
using AMAT.R2R.Server.Base.Repository;
using AMAT.R2R.Server.Base.Service;
using AMAT.R2R.Shared.Base.DTO;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;

namespace AMAT.R2R.Server.Base.Service
{
    public interface IAuthenticationService
    {
        LoginInfo LoginUser(LoginInfo loginInfo);
    }

    public class AuthenticationService : BaseService, IAuthenticationService
    {
        public AuthenticationService(IServiceProvider serviceProvider, ILogger<AuthenticationService> logger) : base(serviceProvider, logger)
        {
        }


        public LoginInfo LoginUser(LoginInfo loginInfo)
        {
            if (loginInfo == null || string.IsNullOrEmpty(loginInfo.UserName) || string.IsNullOrEmpty(loginInfo.Password))
            {
                throw new ApiException(GeneralErrorCode.UserNameAndPasswordCanNotBeEmpty);
            }
            else
            {
                try
                {
                    loginInfo.SessionId = Guid.NewGuid().ToString();
                    loginInfo.LoginTime = DateTime.Now;

                    //// mock to let user login. 
                    //// TODO: remove below if when actual Login is ready.
                    //if(loginInfo.UserName.EqualsIgnoreCase("test"))
                    //{
                    //    return loginInfo;
                    //}


                    LoginResult result = Login(loginInfo, ConnectionHelper.LoginURL);
                    if (!result.Success)
                    {
                        throw new ApiException(GeneralErrorCode.FailToLogin, result.Message);
                    }
                    else
                    {
                        // TODO: write login table with sessionid and other client information.
                        loginInfo.ServerVersion = "NA";
                        loginInfo.AuthorityList = result.AuthorityList;
                        return loginInfo;
                    }
                }
                catch(Exception)
                {
                    throw;
                }
            }
        }
        private LoginResult Login(LoginInfo loginInfo,string url)
        {
            LoginResult loginResult = new LoginResult() { Success = false, Message = "", UserOperations = "" };
            try
            {
                Dictionary<string, string> dicParam = new Dictionary<string, string>();

                string encryptPassword = Convert.ToBase64String(new System.Text.UTF8Encoding().GetBytes(loginInfo.Password));

                System.Collections.Hashtable loginParameters = new System.Collections.Hashtable();
                loginParameters.Add("UserName", loginInfo.UserName);
                loginParameters.Add("DomainName", loginInfo.LoginDomain);
                loginParameters.Add("Password", encryptPassword);
                loginParameters.Add("Fab", loginInfo.LoginFab);
                loginParameters.Add("Area", loginInfo.LoginArea);
                loginParameters.Add("ClientVersion", loginInfo.ClientVersion);
                loginParameters.Add("SessionId", loginInfo.SessionId);
                loginParameters.Add("AppType", "");
                loginParameters.Add("AutoLogin", "true");
                System.Xml.XmlDocument responseXml = WebServiceHelper.QuerySoapWebService(url, "Login", loginParameters, "", "Login_input");

                if (WebServiceHelper.TryParseNodeInnerText(responseXml, "Success", out string value))
                {
                    loginResult.Success = "TRUE".Equals(value.ToUpper());
                }

                WebServiceHelper.TryParseNodeInnerText(responseXml, "Message", out string message);
                loginResult.Message = message;

                WebServiceHelper.TryParseNodeInnerText(responseXml, "UserOperations", out string userOperations);
                loginResult.UserOperations = userOperations;

                WebServiceHelper.TryParseNodeOuterXml(responseXml, "AuthorizedList", out string authorizedListXml);
                loginResult.AuthorityList = new List<string>();
                if (!string.IsNullOrEmpty(authorizedListXml))
                {
                    XmlDocument xml = new XmlDocument();
                    xml.LoadXml(authorizedListXml);
                    if (xml.HasChildNodes)
                    {
                        foreach (XmlNode node in xml.ChildNodes[0].ChildNodes)
                        {
                            loginResult.AuthorityList.Add(node.InnerText);
                        }
                    }
                    
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }

            return loginResult;
        }

        protected class LoginResult
        {
            public bool Success { get; set; }
            public string  Message { get; set; }
            public string UserOperations { get; set; }

            public List<string> AuthorityList { get; set; }
        }
         
    }
}
