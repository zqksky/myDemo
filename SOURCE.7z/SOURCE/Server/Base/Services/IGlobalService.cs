﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Contracts;
using System.Linq;
using System.Threading.Tasks;
using AMAT.R2R.Server.Base;
using AMAT.R2R.Server.Base.Constants;
using AMAT.R2R.Server.Base.Exceptions;
using AMAT.R2R.Server.Base.Repository;
using AMAT.R2R.Server.Base.Service;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.ValueGeneration.Internal;
using BaseDTO = AMAT.R2R.Shared.Base.DTO;
using BaseEntities = AMAT.R2R.Server.Base.Entities;


namespace AMAT.R2R.Server.Base.Service
{
    public interface IGlobalService
    {
        List<BaseDTO.TransactionHistory> GetTransactionHistory(string module, string tableName, string contextValue, string contextValue1);

        List<BaseDTO.Parameter> GetMeasureItemList();

        public List<string> GetLithoToolTypeList();
        List<BaseDTO.Tool> GetToolList();

        List<BaseDTO.Parameter> GetProcessParameterAll();
        List<BaseDTO.Parameter> GetProcessParameterList(string tool, string chamber);

        List<BaseDTO.Product> GetProductList();

        List<BaseDTO.Chamber> GetChamberList(string tool);

        List<string> GetGOFItemsList();

        BaseDTO.Tool GetTool(string toolId);

        BaseDTO.Tool CreateTool(BaseDTO.Tool tool);

        void UpdateTool(BaseDTO.Tool tool);

        void DeleteTool(string toolId);

        BaseDTO.Chamber GetChamber(string toolId, string chamberId);

        BaseDTO.Chamber CreateChamber(BaseDTO.Chamber chamber);

        void UpdateChamber(BaseDTO.Chamber chamber);

        void DeleteChamber(string toolId, string chamberId);

        BaseDTO.Parameter GetParameter(string toolId, string chamberId, string parameterName);

        BaseDTO.Parameter CreateParameter(BaseDTO.Parameter parameter);

        void UpdateParameter(BaseDTO.Parameter parameter);

        void DeleteParameter(string toolId, string chamberId, string parameterName);

        string GetSettingValue(string applicatonName, string settingName, string settingName1);
    }
}
