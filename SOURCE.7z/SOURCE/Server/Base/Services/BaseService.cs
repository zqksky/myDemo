﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using AMAT.R2R.Server.Base.Constants;
using AMAT.R2R.Server.Base.Entities;
using AMAT.R2R.Server.Base.Repository;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Logging.Debug;
using Oracle.ManagedDataAccess.Client;

namespace AMAT.R2R.Server.Base.Service
{
    public abstract class BaseService : IBaseService
    {
        public BaseService(IServiceProvider serviceProvider, ILogger logger)
        {
            ServiceProvider = serviceProvider;
            HttpContextAccessor = serviceProvider.GetService(typeof(IHttpContextAccessor)) as IHttpContextAccessor;
            Configuration = serviceProvider.GetService(typeof(IConfiguration)) as IConfiguration;
            Logger = logger;
        }

        protected IServiceProvider ServiceProvider { get; }
        protected IHttpContextAccessor HttpContextAccessor { get; }
        protected IConfiguration Configuration { get; }

        protected ILogger Logger { get; }

        public static readonly ILoggerFactory LoggerFactory = new LoggerFactory(new ILoggerProvider[] { new NLogLoggerProvider() });


        public ChangeRequest TryEditing(string module, string tableName, string crCategory, string userId, string comment, string txId, string contextValue, string contextValue1)
        {
            var crId = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss:fff") + "." + userId;
            ChangeRequest cr = null;
            using (E3suiteDBContext db = new E3suiteDBContext())
            {
                using (var trans = db.Database.BeginTransaction())
                {
                    try
                    {
                        int t = 0;
                        while (t <= 1 && cr == null)
                        {
                            t++;
                            IList<ChangeRequest> crs = db.Set<ChangeRequest>().FromSqlRaw("SELECT * FROM R2R_UI_CHANGE_REQUEST T WHERE T.CR_TIMESTAMP<SYSTIMESTAMP AND T.CR_TIMESTAMP>SYSTIMESTAMP-10/24/60 AND T.MODULE='" + module + "' AND T.TABLE_NAME='" + tableName + "' AND CONTEXT_GROUP_VALUE='" + contextValue + "' AND CR_STATUS='" + CR_Status.Submitted.ToString() + "'").ToList();
                            if (crs == null || crs.Count() == 0)
                            {
                                var paras = new OracleParameter[] {
                                            new  OracleParameter("CR_ID",crId),
                                            new  OracleParameter("MODULE",module),
                                            new  OracleParameter("TABLE_NAME",tableName),
                                            new OracleParameter("CR_CATEGORY",crCategory),
                                            new  OracleParameter("USER_ID",userId),
                                            new  OracleParameter("CR_COMMENT",comment),
                                            new  OracleParameter("CR_STATUS","Submitted"),
                                            new  OracleParameter("TXID",txId),
                                            new  OracleParameter("CONTEXT_GROUP_VALUE",contextValue),
                                            new  OracleParameter("CONTEXT_GROUP_VALUE_1",contextValue1)
                                            };

                                var i = db.Database.ExecuteSqlRaw($"INSERT INTO R2R_UI_CHANGE_REQUEST(CR_TIMESTAMP,CR_ID,MODULE,TABLE_NAME,CR_CATEGORY,USER_ID,CR_COMMENT,CR_STATUS,TXID,CONTEXT_GROUP_VALUE,CONTEXT_GROUP_VALUE_1) VALUES(SYSTIMESTAMP,:CR_ID,:MODULE,:TABLE_NAME,:CR_CATEGORY,:USER_ID,:CR_COMMENT,:CR_STATUS,:TXID,:CONTEXT_GROUP_VALUE,:CONTEXT_GROUP_VALUE_1)", paras);
                                if (i <= 0) cr = null;
                                else
                                {
                                    cr = db.Set<ChangeRequest>().FromSqlRaw("SELECT * FROM R2R_UI_CHANGE_REQUEST WHERE CR_ID='" + crId + "'").ToList().FirstOrDefault();
                                }
                            }
                            if (cr == null)
                            {
                                Thread.Sleep(50);
                            }
                        }

                        trans.Commit();
                    }
                    catch (Exception ex)
                    {
                        Logger.LogError(ex.ToString());
                        trans.Rollback();
                        //throw;
                    }
                }
            }

            if (cr == null)
                throw new AMAT.R2R.Server.Base.Exceptions.ApiException(GeneralErrorCode.RequstChangeFail, "Maybe others is editing the process , try again later");

            return cr;
        }

        public ChangeRequest TryEditing2(string module, string tableName, string crCategory, string userId, string comment, string txId, string contextValue, string contextValue1)
        {
            var crId = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss:fff") + "." + userId;
            ChangeRequest cr = null;
            using (E3suiteDBContext db = new E3suiteDBContext())
            {
                using (var trans = db.Database.BeginTransaction())
                {
                    try
                    {
                        int t = 0;
                        while (t <= 1 && cr == null)
                        {
                            t++;
                            IList<ChangeRequest> crs = db.Set<ChangeRequest>().FromSqlRaw("SELECT * FROM R2R_UI_CHANGE_REQUEST T WHERE T.CR_TIMESTAMP<SYSTIMESTAMP AND T.CR_TIMESTAMP>SYSTIMESTAMP-10/24/60 AND T.MODULE='" + module + "' AND T.TABLE_NAME='" + tableName + "' AND CONTEXT_GROUP_VALUE_1='" + contextValue1 + "' AND CR_STATUS='" + CR_Status.Submitted.ToString() + "'").ToList();
                            if (crs == null || crs.Count() == 0)
                            {
                                var paras = new OracleParameter[] {
                                        new  OracleParameter("CR_ID",crId),
                                        new  OracleParameter("MODULE",module),
                                        new  OracleParameter("TABLE_NAME",tableName),
                                        new OracleParameter("CR_CATEGORY",crCategory),
                                        new  OracleParameter("USER_ID",userId),
                                        new  OracleParameter("CR_COMMENT",comment),
                                        new  OracleParameter("CR_STATUS","Submitted"),
                                        new  OracleParameter("TXID",txId),
                                        new  OracleParameter("CONTEXT_GROUP_VALUE",contextValue),
                                        new  OracleParameter("CONTEXT_GROUP_VALUE_1",contextValue1)
                                    };
                                var i = db.Database.ExecuteSqlRaw($"INSERT INTO R2R_UI_CHANGE_REQUEST(CR_TIMESTAMP,CR_ID,MODULE,TABLE_NAME,CR_CATEGORY,USER_ID,CR_COMMENT,CR_STATUS,TXID,CONTEXT_GROUP_VALUE,CONTEXT_GROUP_VALUE_1) VALUES(SYSTIMESTAMP,:CR_ID,:MODULE,:TABLE_NAME,:CR_CATEGORY,:USER_ID,:CR_COMMENT,:CR_STATUS,:TXID,:CONTEXT_GROUP_VALUE,:CONTEXT_GROUP_VALUE_1)", paras);
                                if (i <= 0) cr = null;
                                else
                                {
                                    cr = db.Set<ChangeRequest>().FromSqlRaw("SELECT * FROM R2R_UI_CHANGE_REQUEST WHERE CR_ID='" + crId + "'").ToList().FirstOrDefault();
                                }
                            }
                            if (cr == null)
                            {
                                Thread.Sleep(50);
                            }
                        }

                        trans.Commit();

                    }
                    catch (Exception ex)
                    {
                        Logger.LogError(ex.ToString());
                        //this._dbcontext.Database.RollbackTransaction();
                        trans.Rollback();
                        throw new AMAT.R2R.Server.Base.Exceptions.ApiException(GeneralErrorCode.RequstChangeFail, "Maybe others is editing the process , try again later");
                    }
                }
            }
            if (cr == null)
                throw new AMAT.R2R.Server.Base.Exceptions.ApiException(GeneralErrorCode.RequstChangeFail, "Maybe others is editing the process , try again later");

            return cr;
        }

        public ChangeRequest EndEditing(ChangeRequest cr, bool success)
        {
            var ccr = cr;
            using (E3suiteDBContext db = new E3suiteDBContext())
            {
                using (var trans = db.Database.BeginTransaction())
                {
                    try
                    {
                        var paras = new OracleParameter[] {
                        new  OracleParameter("CR_STATUS",success?CR_Status.Approved.ToString():CR_Status.Fail.ToString()),
                        new  OracleParameter("JSON_01",string.IsNullOrEmpty(cr.Json01)?"":cr.Json01),
                        new  OracleParameter("JSON_02",string.IsNullOrEmpty(cr.Json02)?"":cr.Json02),
                        new  OracleParameter("CR_DETAIL",string.IsNullOrEmpty(cr.CrDetails)?"":cr.CrDetails),
                        new  OracleParameter("CONTEXT_GROUP",string.IsNullOrEmpty(cr.ContxtGroup)?"":cr.ContxtGroup),
                        new  OracleParameter("CONTEXT_GROUP_VALUE",string.IsNullOrEmpty(cr.ContextGroupValue)?"":cr.ContextGroupValue),
                        new  OracleParameter("CONTEXT_GROUP_VALUE_1",string.IsNullOrEmpty(cr.ContextGroupValue1)?"":cr.ContextGroupValue1),
                        new  OracleParameter("REASON",string.IsNullOrEmpty(cr.Reason)?"":cr.Reason),
                        new  OracleParameter("CR_ID",cr.CrId),
                    };

                        var i = db.Database.ExecuteSqlRaw($"UPDATE R2R_UI_CHANGE_REQUEST SET CR_STATUS=:CR_STATUS , JSON_01 =:JSON_01, JSON_02 =:JSON_02 , CR_DETAIL =:CR_DETAIL, CONTEXT_GROUP=:CONTEXT_GROUP ,CONTEXT_GROUP_VALUE=:CONTEXT_GROUP_VALUE ,CONTEXT_GROUP_VALUE_1=:CONTEXT_GROUP_VALUE_1,REASON=:REASON WHERE  CR_ID=:CR_ID", paras);
                        if (i <= 0) ccr = null;

                        trans.Commit();
                    }
                    catch (Exception ex)
                    {
                        Logger.LogError(ex.ToString());
                        trans.Rollback();
                    }
                }
            }

            return ccr;
        }

        public int GetNextId(string area, ObjectName objectName)
        {
            using (E3suiteDBContext db = new E3suiteDBContext())
            {
                var nextId = 0;
                try
                {
                    var sql = "";
                    if ("Etch".Equals(area))
                    {
                        switch (objectName)
                        {
                            case ObjectName.Process:
                                sql = "SELECT SEQ_UI_DE_PROCESS_ID.NEXTVAL FROM DUAL";
                                break;

                            case ObjectName.Context:
                                sql = "SELECT SEQ_UI_DE_CONTEXT_ID.NEXTVAL FROM DUAL";
                                break;

                            case ObjectName.Metrology:
                                sql = "SELECT SEQ_UI_DE_METRO_ID.NEXTVAL FROM DUAL";
                                break;

                            default:
                                break;
                        }
                    }

                    if (string.IsNullOrEmpty(sql)) return nextId;

                    var cmd = db.Database.GetDbConnection().CreateCommand();
                    cmd.CommandText = sql;
                    var reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        nextId = reader.GetInt32(0);
                    }
                    reader.Close();
                }
                catch (Exception ex)
                {
                    Logger.LogError(ex.ToString());
                    throw new AMAT.R2R.Server.Base.Exceptions.ApiException(GeneralErrorCode.RequstChangeFail, "Fail to generate the Id");
                }

                return nextId;
            }

        }

        public async Task<int> GetNextIdAsync(string area, ObjectName objectName)
        {
            using (E3suiteDBContext db = new E3suiteDBContext())
            {
                var nextId = 0;
                try
                {
                    var sql = "";
                    if ("Etch".Equals(area))
                    {
                        switch (objectName)
                        {
                            case ObjectName.Process:
                                sql = "SELECT SEQ_UI_DE_PROCESS_ID.NEXTVAL FROM DUAL";
                                break;

                            case ObjectName.Context:
                                sql = "SELECT SEQ_UI_DE_CONTEXT_ID.NEXTVAL FROM DUAL";
                                break;

                            case ObjectName.Metrology:
                                sql = "SELECT SEQ_UI_DE_METRO_ID.NEXTVAL FROM DUAL";
                                break;

                            default:
                                break;
                        }
                    }

                    if (string.IsNullOrEmpty(sql)) return nextId;

                    using (var cmd = db.Database.GetDbConnection().CreateCommand())
                    {
                        cmd.CommandText = sql;
                        using (var reader = await cmd.ExecuteReaderAsync())
                        {
                            while (reader.Read())
                            {
                                nextId = reader.GetInt32(0);
                            }
                            await reader.CloseAsync();
                        }
                    }
                }
                catch (Exception ex)
                {
                    Logger.LogError(ex.ToString());
                    throw new AMAT.R2R.Server.Base.Exceptions.ApiException(GeneralErrorCode.RequstChangeFail, "Fail to generate the Id");
                }

                return nextId;
            }

        }

        protected TxnContext TxnContext
        {
            get
            {
                return new TxnContext(HttpContext);
            }
        }

        protected HttpContext HttpContext
        {
            get
            {
                return HttpContextAccessor.HttpContext;
            }
        }

    }

    public class NLogLogger : ILogger
    {
        NLog.Logger _logger;
        public NLogLogger()
        {
            _logger = NLog.Web.NLogBuilder.ConfigureNLog("nlog.config").GetCurrentClassLogger();
        }

        public IDisposable BeginScope<TState>(TState state)
        {
            return null;
        }

        public bool IsEnabled(LogLevel logLevel)
        {
            return true;
        }

        public void Log<TState>(LogLevel logLevel, EventId eventId, TState state, Exception exception, Func<TState, Exception, string> formatter)
        {
            string message = state?.ToString();
            if (formatter != null)
            {
                message = formatter(state, exception);
            }
            switch (logLevel)
            {
                case LogLevel.Trace:
                    _logger.Trace(message);
                    break;
                case LogLevel.Debug:
                    _logger.Debug(message);
                    break;
                case LogLevel.Information:
                    _logger.Info(message);
                    break;
                case LogLevel.Warning:
                    _logger.Warn(message);
                    break;
                case LogLevel.Error:
                    _logger.Error(message);
                    break;
                case LogLevel.Critical:
                    _logger.Fatal(message);
                    break;
                case LogLevel.None:
                    _logger.Trace(message);
                    break;
                default:
                    break;
            }
        }
    }

    public class NLogLoggerProvider : ILoggerProvider
    {
        public ILogger CreateLogger(string categoryName)
        {
            return new NLogLogger();
        }

        public void Dispose()
        {

        }
    }
}
