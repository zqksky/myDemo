﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AMAT.R2R.Server.Base.Constants;
using AMAT.R2R.Server.Base.Entities;
using AMAT.R2R.Server.Base.Exceptions;
using AMAT.R2R.Server.Base.Repository;
using AMAT.R2R.Server.Base.Service;
using AMAT.R2R.Shared.Base.DTO;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using BaseDTO = AMAT.R2R.Shared.Base.DTO;
using BaseEntities = AMAT.R2R.Server.Base.Entities;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;

namespace AMAT.R2R.Server.Base.Service
{
    public class GlobalService : BaseService, IGlobalService
    {
        public GlobalService(IServiceProvider serviceProvider, ILogger<GlobalService> logger) : base(serviceProvider, logger)
        {

        }

        public List<BaseDTO.TransactionHistory> GetTransactionHistory(string module, string tableName, string contextValue, string contextValue1)
        {
            //using (E3suiteDBContext db = new E3suiteDBContext())
            using (E3suiteDBContext db = new E3suiteDBContext(new DbContextOptionsBuilder().UseOracle(ConnectionHelper.DbConnection).Options))
            {
                List<BaseDTO.TransactionHistory> transactionHistory = new List<BaseDTO.TransactionHistory>();

                try
                {
                    if (string.IsNullOrEmpty(contextValue1))
                    {
                        var count = 0;
                        IQueryable<BaseEntities.ChangeRequest> list = db.ChangeRequestRepo.Where(t => t.Module == module &&
                       t.TableName == tableName &&
                       t.ContextGroupValue == contextValue)
                            .OrderByDescending(t => t.CrTimeStamp)
                            .Skip((0) * 10).Take(10);

                        list.ForEachAsync(t =>
                        {
                            BaseDTO.TransactionHistory hist = new BaseDTO.TransactionHistory();
                            hist.ModifiedTime = t.CrTimeStamp;
                            hist.Category = t.TableName;
                            hist.Action = t.CrCategory;
                            hist.Details = t.CrDetails;
                            hist.Comment = t.CrComment;
                            hist.ModifiedBy = t.UserId;
                            hist.Status = "Fail".Equals(t.CrStatus) ? t.CrStatus : "";
                            hist.Reason = t.Reason;
                            hist.Object = t.ContextGroupValue;
                            hist.SubObject = t.ContextGroupValue1;
                            hist.CrId = t.CrId;
                            hist.TxId = t.TxId;
                            transactionHistory.Add(hist);
                        });
                    }
                    else
                    {
                        var count = 0;
                        IQueryable<BaseEntities.ChangeRequest> list = db.ChangeRequestRepo.Where(t => t.Module == module &&
                       t.TableName == tableName &&
                       t.ContextGroupValue == contextValue &&
                       t.ContextGroupValue1 == contextValue1)
                           .OrderByDescending(t => t.CrTimeStamp)
                           .Skip((0) * 10).Take(10);

                        list.ForEachAsync(t =>
                        {
                            BaseDTO.TransactionHistory hist = new BaseDTO.TransactionHistory();
                            hist.ModifiedTime = t.CrTimeStamp;
                            hist.Category = t.TableName;
                            hist.Action = t.CrCategory;
                            hist.Details = t.CrDetails;
                            hist.Comment = t.CrComment;
                            hist.ModifiedBy = t.UserId;
                            hist.Status = "Fail".Equals(t.CrStatus) ? t.CrStatus : "";
                            hist.Reason = t.Reason;
                            hist.Object = t.ContextGroupValue;
                            hist.SubObject = t.ContextGroupValue1;
                            hist.CrId = t.CrId;
                            hist.TxId = t.TxId;
                            transactionHistory.Add(hist);
                        });
                    }

                    return transactionHistory;
                }
                catch (Exception ex)
                {
                    throw new ApiException(GeneralErrorCode.UnexpectedError, ex.Message);
                }
            }
        }

        public List<BaseDTO.Parameter> GetMeasureItemList()
        {
            //using (xxxE3suiteDBContext db = (E3suiteDBContext)ServiceProvider.GetService(typeof(E3suiteDBContext)))
            //using (E3suiteDBContext db = new E3suiteDBContext())
            using (E3suiteDBContext db = new E3suiteDBContext(new DbContextOptionsBuilder().UseOracle(ConnectionHelper.DbConnection).Options))
            {
                List<BaseDTO.Parameter> parameters = new List<BaseDTO.Parameter>();
                try
                {
                    string applicationnName = "GlobalSettings";
                    string settingName = string.Format("{0}.{1}", TxnContext.Fab, TxnContext.Area);
                    string settingName1 = "MetrologyItems";
                    IQueryable<GlobalSetting> settings = db.GlobalSettingRepository.Where(t => t.ApplicationName == applicationnName && t.SettingName == settingName && t.SettingName1 == settingName1);

                    if (settings != null && settings.Count() > 0)
                    {
                        string[] parameterNames = settings.First().SettingValue.Split(",");
                        foreach (string para in parameterNames)
                        {
                            parameters.Add(new BaseDTO.Parameter { ParameterName = para });
                        }
                    }
                }
                catch (Exception ex)
                {
                    throw new ApiException(GeneralErrorCode.GlobalServiceError, ex.Message);
                }

                return parameters;
            }

        }

        public List<string> GetGOFItemsList()
        {
            //using (xxxE3suiteDBContext db = (E3suiteDBContext)ServiceProvider.GetService(typeof(E3suiteDBContext)))
            //using (E3suiteDBContext db = new E3suiteDBContext())
            using (E3suiteDBContext db = new E3suiteDBContext(new DbContextOptionsBuilder().UseOracle(ConnectionHelper.DbConnection).Options))
            {
                List<string> gofs = new List<string>();
                try
                {
                    string applicationnName = "GlobalSettings";
                    string settingName = string.Format("{0}.{1}", TxnContext.Fab, TxnContext.Area);
                    string settingName1 = "GOFItems";
                    IQueryable<GlobalSetting> settings = db.GlobalSettingRepository.Where(t => t.ApplicationName == applicationnName && t.SettingName == settingName && t.SettingName1 == settingName1);

                    if (settings != null && settings.Count() > 0)
                    {
                        string[] names = settings.First().SettingValue.Split(",");
                        foreach (string name in names)
                        {
                            gofs.Add(name);
                        }
                    }
                }
                catch (Exception ex)
                {
                    throw new ApiException(GeneralErrorCode.GlobalServiceError, ex.Message);
                }

                return gofs;
            }

        }

        public List<BaseDTO.Parameter> GetProcessParameterAll()
        {
            //using (E3suiteDBContext db = new E3suiteDBContext())
            using (E3suiteDBContext db = new E3suiteDBContext(new DbContextOptionsBuilder().UseOracle(ConnectionHelper.DbConnection).Options))
            {
                List<BaseDTO.Parameter> parameters = new List<BaseDTO.Parameter>();
                try
                {
                    List<BaseDTO.Tool> tools = GetToolList();
                    foreach(BaseDTO.Tool tool in tools)
                    {
                        List<BaseEntities.Parameter> list = db.ParameterRepository.Where(t => t.ToolId == tool.ToolId).ToList();
                        list.ForEach(t =>
                        {
                            BaseDTO.Parameter para = new BaseDTO.Parameter();
                            parameters.Add(para);
                            para.Tool = new BaseDTO.Tool() { ToolId = t.ToolId };
                            para.ParameterName = t.ParameterName;
                            para.Precision = t.Precision;
                            para.ParameterType = t.ParameterType;
                            para.AliasName = t.AliasName;
                            para.Chamber = new BaseDTO.Chamber() { ChamberId = t.ProcessUnit };
                        });
                    }
                }
                catch (Exception ex)
                {
                    throw new ApiException(GeneralErrorCode.GlobalServiceError, ex.Message);
                }

                return parameters;
            }


        }

        public List<BaseDTO.Parameter> GetProcessParameterList(string tool, string chamber)
        {
            //using (E3suiteDBContext db = new E3suiteDBContext())
            using (E3suiteDBContext db = new E3suiteDBContext(new DbContextOptionsBuilder().UseOracle(ConnectionHelper.DbConnection).Options))
            {
                List<BaseDTO.Parameter> parameters = new List<BaseDTO.Parameter>();
                try
                {
                    List<BaseEntities.Parameter> list = db.ParameterRepository.Where(t => t.ToolId == tool && t.ProcessUnit == chamber).ToList();
                    list.ForEach(t =>
                    {
                        BaseDTO.Parameter para = new BaseDTO.Parameter();
                        parameters.Add(para);
                        para.Tool = new BaseDTO.Tool() { ToolId = t.ToolId };
                        para.ParameterName = t.ParameterName;
                        para.Precision = t.Precision;
                        para.ParameterType = t.ParameterType;
                        para.AliasName = t.AliasName;
                        para.Chamber = new BaseDTO.Chamber() { ChamberId = t.ProcessUnit };
                    });
                }
                catch (Exception ex)
                {
                    throw new ApiException(GeneralErrorCode.GlobalServiceError, ex.Message);
                }

                return parameters;
            }


        }

        public List<string> GetLithoToolTypeList()
        {
            //using (E3suiteDBContext db = new E3suiteDBContext())
            using (E3suiteDBContext db = new E3suiteDBContext(new DbContextOptionsBuilder().UseOracle(ConnectionHelper.DbConnection).Options))
            {
                List<string> types = new List<string>();
                try
                {
                    string applicationnName = "GlobalSettings";
                    string settingName = string.Format("{0}.{1}", TxnContext.Fab, TxnContext.Area);
                    string settingName1 = "LithoToolType";
                    IQueryable<GlobalSetting> settings = db.GlobalSettingRepository.Where(t => t.ApplicationName == applicationnName && t.SettingName == settingName && t.SettingName1 == settingName1);

                    if (settings != null && settings.Count() > 0)
                    {
                        types = new List<string>(settings.First().SettingValue.Split(",").AsEnumerable());
                    }
                }
                catch (Exception ex)
                {
                    throw new ApiException(GeneralErrorCode.GlobalServiceError, ex.Message);
                }

                return types;
            }

        }

        public List<BaseDTO.Tool> GetToolList()
        {
            //using (E3suiteDBContext db = new E3suiteDBContext())
            using (E3suiteDBContext db = new E3suiteDBContext(new DbContextOptionsBuilder().UseOracle(ConnectionHelper.DbConnection).Options))
            {
                try
                {
                    List<BaseDTO.Tool> tools = new List<BaseDTO.Tool>();
                    List<BaseEntities.Tool> list = db.ToolRepository.Where(t => t.Fab==TxnContext.Fab && t.Area == TxnContext.Area).ToList();
                    list.ForEach(t =>
                    {
                        BaseDTO.Tool tool = new BaseDTO.Tool();
                        tools.Add(tool);
                        tool.Chambers = new List<BaseDTO.Chamber>();
                        tool.ToolModel = t.ToolModel;
                        tool.ToolType = t.ToolType;
                        tool.ToolVendor = t.ToolVendor;
                        tool.ToolProcessType = t.ToolProcessType;
                        tool.ToolId = t.ToolId;
                        List<BaseEntities.ProcessUnit> listch = db.ProcessUnitRepository.Where(s => s.ToolId == t.ToolId).ToList();
                        listch.ForEach(ss =>
                        {
                            BaseDTO.Chamber chamber = new BaseDTO.Chamber();
                            tool.Chambers.Add(chamber);
                            chamber.ChamberId = ss.ProcessUnitId;
                            chamber.ToolId = ss.ToolId;
                            chamber.UnitType = ss.UnitType;
                            chamber.ProcessType = ss.ProcessModel;
                        });
                    });

                    return tools;
                }
                catch (Exception ex)
                {
                    throw new ApiException(GeneralErrorCode.GlobalServiceError, ex.Message);
                }
            }
        }

        
        public List<BaseDTO.Product> GetProductList()
        {
            using (E3suiteDBContext db = new E3suiteDBContext(new DbContextOptionsBuilder().UseOracle(ConnectionHelper.DbConnection).Options))
            {
                List<BaseDTO.Product> products = new List<BaseDTO.Product>();
                try
                {

                    List<BaseEntities.Product> prodEntities = db.ProductRepository.AsNoTracking().ToList();
                    prodEntities.ForEach(ss =>
                    {
                        BaseDTO.Product product = new BaseDTO.Product();
                        products.Add(product);
                        product.ProductId = ss.ProductId;
                        product.ProductType=ss.ProductType;

                    });
                }
                catch (Exception ex)
                {
                    throw new ApiException(GeneralErrorCode.GlobalServiceError, ex.Message);
                }
                return products;
            }

        }

        public List<BaseDTO.Chamber> GetChamberList(string tool)
        {
            //using (E3suiteDBContext db = new E3suiteDBContext())
            using (E3suiteDBContext db = new E3suiteDBContext(new DbContextOptionsBuilder().UseOracle(ConnectionHelper.DbConnection).Options))
            {
                List<BaseDTO.Chamber> chambers = new List<BaseDTO.Chamber>();
                try
                {
                    List<BaseDTO.Tool> tools = new List<BaseDTO.Tool>();
                    List<BaseEntities.Tool> list = db.ToolRepository.Where(t => t.ToolId.Equals(tool)).ToList();
                    if (list == null || list.Count() == 0)
                        throw new ApiException(GeneralErrorCode.UnexpectedError, "Tool not existed");

                    BaseEntities.Tool _tool = list[0];
                    List<BaseEntities.ProcessUnit> listch = db.ProcessUnitRepository.Where(s => s.ToolId == _tool.ToolId).ToList();
                    listch.ForEach(ss =>
                    {
                        BaseDTO.Chamber chamber = new BaseDTO.Chamber();
                        chambers.Add(chamber);
                        chamber.ChamberId = ss.ProcessUnitId;
                        chamber.ToolId = ss.ToolId;
                        chamber.UnitType = ss.UnitType;
                        chamber.ProcessType = ss.ProcessModel;
                    });
                }
                catch (Exception ex)
                {
                    throw new ApiException(GeneralErrorCode.GlobalServiceError, ex.Message);
                }
                return chambers;
            }
        }

        public BaseDTO.Tool GetTool(string toolId)
        {
             
            using (E3suiteDBContext db = new E3suiteDBContext(new DbContextOptionsBuilder().UseOracle(ConnectionHelper.DbConnection).Options))
            {
                BaseDTO.Tool tool = new BaseDTO.Tool();

                try
                {
                    List<Entities.Tool> entities = db.ToolRepository.Where(t => t.ToolId==toolId).ToList();

                    if (entities != null && entities.Count() > 0)
                    {
                        tool.ToolId = entities[0].ToolId;
                        tool.ToolModel = entities[0].ToolModel;
                        tool.ToolProcessType = entities[0].ToolProcessType;
                        tool.ToolType = entities[0].ToolType;
                        tool.ToolVendor = entities[0].ToolVendor;
                        tool.Chambers = new List<Chamber>();
                        List<BaseEntities.ProcessUnit> listch = db.ProcessUnitRepository.Where(s => s.ToolId == toolId).ToList();
                        listch.ForEach(ss =>
                        {
                            BaseDTO.Chamber chamber = new BaseDTO.Chamber();
                            chamber.ChamberId = ss.ProcessUnitId;
                            chamber.ToolId = ss.ToolId;
                            chamber.ProcessType = ss.ProcessModel;
                            chamber.UnitType = ss.UnitType;
                            tool.Chambers.Add(chamber);
                        });
                    }
                }
                catch (Exception ex)
                {
                    throw new ApiException(GeneralErrorCode.ResourceNotFound, ex.Message);
                }

                return tool;
            }
        }

        public BaseDTO.Tool CreateTool(BaseDTO.Tool tool)
        {
            using (E3suiteDBContext db = new E3suiteDBContext())
            {
                BaseEntities.ChangeRequest cr = TryEditing(TxnContext.Area, ObjectName.Tool.ToString(), "CreateTool", TxnContext.UserName, TxnContext.Comment, TxnContext.TxnId, tool.ToolId, "NA");

                using (var transaction = db.Database.BeginTransaction())
                {
                    try
                    {
                        //TODO business log
                        IList<Entities.Tool> entities = db.ToolRepository.Where(t => t.ToolId == tool.ToolId).ToList(); 
                        if (entities != null && entities.Count()>0)
                            throw new ApiException(GeneralErrorCode.ResourceAlreadyExists);

                        Entities.Tool toolEntity= new BaseEntities.Tool();
                        toolEntity.ToolId = tool.ToolId;
                        toolEntity.ToolModel = tool.ToolModel;
                        toolEntity.ToolProcessType = tool.ToolProcessType;
                        toolEntity.ToolType = tool.ToolType;
                        toolEntity.ToolVendor = tool.ToolVendor;
                        toolEntity.Fab = TxnContext.Fab;
                        toolEntity.Area = TxnContext.Area;
                        toolEntity.NameSpace = GetSettingValue("FabNameSpace", TxnContext.Fab, "NA");
                         
                        db.ToolRepository.Add(toolEntity);
                        IList<Entities.ProcessUnit> pus= db.ProcessUnitRepository.Where(t => t.ToolId == tool.ToolId).ToList();
                        if(pus!=null && pus.Count > 0)
                        {
                            db.ProcessUnitRepository.RemoveRange(pus);
                        }
                        
                        if(tool.Chambers!=null && tool.Chambers.Count() > 0)
                        {

                            foreach (BaseDTO.Chamber ch in tool.Chambers)
                            {
                                Entities.ProcessUnit psEntity = new ProcessUnit();
                                psEntity.ToolId = tool.ToolId;
                                psEntity.ProcessUnitId = ch.ChamberId;
                                psEntity.ProcessModel = ch.ProcessType;
                                psEntity.UnitType = ch.UnitType;
                                db.ProcessUnitRepository.Add(psEntity);
                            }
                            
                        }

                        db.SaveChanges();
                        transaction.Commit();
                        //
                        cr.ContextGroupValue1 = "NA";
                        cr.ContextGroupValue = string.Format("{0}", tool.ToolId);
                        cr.ContxtGroup = string.Format("{0}",  "Tool" );
                        EndEditing(cr, true);
                        //
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        cr.Reason = ex.Message.Substring(0, ex.Message.Length > 255 ? 255 : ex.Message.Length);
                        if (cr != null) EndEditing(cr, false);
                        throw;
                    }
                }

                return tool;
            }
            
        }

        public void UpdateTool(BaseDTO.Tool tool)
        {
            using (E3suiteDBContext db = new E3suiteDBContext())
            {
                BaseEntities.ChangeRequest cr = TryEditing(TxnContext.Area, ObjectName.Tool.ToString(), "UpdateTool", TxnContext.UserName, TxnContext.Comment, TxnContext.TxnId, tool.ToolId, "NA");

                using (var transaction = db.Database.BeginTransaction())
                {
                    try
                    {
                        //TODO business log
                        IList<Entities.Tool> entities = db.ToolRepository.Where(t => t.ToolId == tool.ToolId).ToList();
                        if (entities != null && entities.Count() <= 0)
                            throw new ApiException(GeneralErrorCode.ResourceNotFound);

                        Entities.Tool toolEntity = entities[0];
                        toolEntity.ToolId = tool.ToolId;
                        toolEntity.ToolModel = tool.ToolModel;
                        toolEntity.ToolProcessType = tool.ToolProcessType;
                        toolEntity.ToolType = tool.ToolType;
                        toolEntity.ToolVendor = tool.ToolVendor;
                        toolEntity.Fab = TxnContext.Fab;
                        toolEntity.Area = TxnContext.Area;
                        toolEntity.NameSpace =  GetSettingValue("FabNameSpace", TxnContext.Fab, "NA");

                        db.ToolRepository.Update(toolEntity);

                        db.SaveChanges();
                        transaction.Commit();
                        //
                        cr.ContextGroupValue1 = "NA";
                        cr.ContextGroupValue = string.Format("{0}", tool.ToolId);
                        cr.ContxtGroup = string.Format("{0}", "Tool");
                        EndEditing(cr, true);
                        //
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        cr.Reason = ex.Message.Substring(0, ex.Message.Length > 255 ? 255 : ex.Message.Length);
                        if (cr != null) EndEditing(cr, false);
                        throw;
                    }
                }

                return ;
            }
        }

        public void DeleteTool(string toolId)
        {
            using (E3suiteDBContext db = new E3suiteDBContext())
            {
                BaseEntities.ChangeRequest cr = TryEditing(TxnContext.Area, ObjectName.Tool.ToString(), "DeleteTool", TxnContext.UserName, TxnContext.Comment, TxnContext.TxnId, toolId, "NA");

                using (var transaction = db.Database.BeginTransaction())
                {
                    try
                    {
                        //TODO business log
                        IList<Entities.Tool> entities = db.ToolRepository.Where(t => t.ToolId == toolId).ToList();
                        if (entities != null && entities.Count() <= 0)
                            throw new ApiException(GeneralErrorCode.ResourceNotFound);

                        db.ToolRepository.RemoveRange(entities);
                        IList<Entities.ProcessUnit> pus = db.ProcessUnitRepository.Where(t => t.ToolId == toolId).ToList();
                        if (pus != null && pus.Count > 0)
                        {
                            db.ProcessUnitRepository.RemoveRange(pus);
                        }

                        db.SaveChanges();
                        transaction.Commit();
                        //
                        cr.ContextGroupValue1 = "NA";
                        cr.ContextGroupValue = string.Format("{0}", toolId);
                        cr.ContxtGroup = string.Format("{0}", "Tool");
                        EndEditing(cr, true);
                        //
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        cr.Reason = ex.Message.Substring(0, ex.Message.Length > 255 ? 255 : ex.Message.Length);
                        if (cr != null) EndEditing(cr, false);
                        throw;
                    }
                }

                return  ;
            }
        }

        public Chamber GetChamber(string toolId, string chamberId)
        {

            using (E3suiteDBContext db = new E3suiteDBContext(new DbContextOptionsBuilder().UseOracle(ConnectionHelper.DbConnection).Options))
            {
                BaseDTO.Chamber chamber = null;

                try
                {
                    List<Entities.ProcessUnit> psEntities = db.ProcessUnitRepository.Where(t => t.ToolId == toolId && t.ProcessUnitId==chamberId).ToList();

                    if (psEntities != null && psEntities.Count() > 0)
                    {
                        chamber = new BaseDTO.Chamber();
                        chamber.ChamberId = psEntities[0].ProcessUnitId;
                        chamber.ToolId = psEntities[0].ToolId;
                        chamber.ProcessType = psEntities[0].ProcessModel;
                        chamber.UnitType = psEntities[0].UnitType;
                    }
                }
                catch (Exception ex)
                {
                    throw new ApiException(GeneralErrorCode.ResourceNotFound, ex.Message);
                }

                return chamber;
            }
        }

        public Chamber CreateChamber(Chamber chamber)
        {
            using (E3suiteDBContext db = new E3suiteDBContext())
            {
                string chamberKey = string.Format("{0}:{1}",chamber.ToolId,chamber.ChamberId);
                BaseEntities.ChangeRequest cr = TryEditing(TxnContext.Area, ObjectName.Tool.ToString(), "CreateChamber", TxnContext.UserName, TxnContext.Comment, TxnContext.TxnId, chamberKey, chamber.ToolId);

                using (var transaction = db.Database.BeginTransaction())
                {
                    try
                    {
                        //TODO business log
                        IList<Entities.Tool> entities = db.ToolRepository.Where(t => t.ToolId == chamber.ToolId).ToList();
                        if (entities != null && entities.Count() <= 0)
                            throw new ApiException(GeneralErrorCode.ResourceNotFound,"Tool not found!");

                        IList<Entities.ProcessUnit> psEntities = db.ProcessUnitRepository.Where(t => t.ToolId == chamber.ToolId && t.ProcessUnitId==chamber.ChamberId).ToList();
                        if (psEntities != null && psEntities.Count() > 0)
                            throw new ApiException(GeneralErrorCode.ResourceAlreadyExists);


                        Entities.ProcessUnit ps = new ProcessUnit();
                        ps.ProcessUnitId = chamber.ChamberId;
                        ps.ProcessModel = chamber.ProcessType;
                        ps.UnitType = chamber.UnitType;
                        ps.ToolId = chamber.ToolId;

                        db.ProcessUnitRepository.Add(ps);
                        
                        db.SaveChanges();
                        transaction.Commit();
                        //
                        cr.ContextGroupValue1 = chamber.ToolId;
                        cr.ContextGroupValue = string.Format("{0}", chamberKey);
                        cr.ContxtGroup = string.Format("{0}:{1}","Tool","Chamber");
                        EndEditing(cr, true);
                        //
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        cr.Reason = ex.Message.Substring(0, ex.Message.Length > 255 ? 255 : ex.Message.Length);
                        if (cr != null) EndEditing(cr, false);
                        throw;
                    }
                }

                return chamber;
            }
        }

        public void UpdateChamber(Chamber chamber)
        {
            using (E3suiteDBContext db = new E3suiteDBContext())
            {
                string chamberKey = string.Format("{0}:{1}", chamber.ToolId, chamber.ChamberId);
                BaseEntities.ChangeRequest cr = TryEditing(TxnContext.Area, ObjectName.Tool.ToString(), "UpdateChamber", TxnContext.UserName, TxnContext.Comment, TxnContext.TxnId, chamberKey, chamber.ToolId);

                using (var transaction = db.Database.BeginTransaction())
                {
                    try
                    {
                        //TODO business log
                        IList<Entities.ProcessUnit> entities = db.ProcessUnitRepository.Where(t => t.ToolId == chamber.ToolId && t.ProcessUnitId==chamber.ChamberId).ToList();
                        if (entities != null && entities.Count() <= 0)
                            throw new ApiException(GeneralErrorCode.ResourceNotFound );

                        Entities.ProcessUnit psEnitty = entities[0];
                        psEnitty.ProcessUnitId = chamber.ChamberId;
                        psEnitty.ProcessModel = chamber.ProcessType;
                        psEnitty.UnitType = chamber.UnitType;
                        psEnitty.ToolId = chamber.ToolId;

                        db.ProcessUnitRepository.Update(psEnitty);

                        db.SaveChanges();
                        transaction.Commit();
                        //
                        cr.ContextGroupValue1 = chamber.ToolId;
                        cr.ContextGroupValue = string.Format("{0}", chamberKey);
                        cr.ContxtGroup = string.Format("{0}:{1}", "Tool", "Chamber");
                        EndEditing(cr, true);
                        //
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        cr.Reason = ex.Message.Substring(0, ex.Message.Length > 255 ? 255 : ex.Message.Length);
                        if (cr != null) EndEditing(cr, false);
                        throw;
                    }
                }

                return ;
            }
        }

        public void DeleteChamber(string toolId, string chamberId)
        {
            using (E3suiteDBContext db = new E3suiteDBContext())
            {
                string chamberKey = string.Format("{0}:{1}", toolId, chamberId);
                BaseEntities.ChangeRequest cr = TryEditing(TxnContext.Area, ObjectName.Tool.ToString(), "DeleteChamber", TxnContext.UserName, TxnContext.Comment, TxnContext.TxnId, chamberKey, toolId);

                using (var transaction = db.Database.BeginTransaction())
                {
                    try
                    {
                        //TODO business log
                        IList<Entities.ProcessUnit> entities = db.ProcessUnitRepository.Where(t => t.ToolId == toolId && t.ProcessUnitId == chamberId).ToList();
                        if (entities != null && entities.Count() <= 0)
                            throw new ApiException(GeneralErrorCode.ResourceNotFound);

                        Entities.ProcessUnit psEnitty = entities[0]; 

                        db.ProcessUnitRepository.Remove(psEnitty);

                        db.SaveChanges();
                        transaction.Commit();
                        //
                        cr.ContextGroupValue1 = toolId;
                        cr.ContextGroupValue = string.Format("{0}", chamberKey);
                        cr.ContxtGroup = string.Format("{0}:{1}", "Tool", "Chamber");
                        EndEditing(cr, true);
                        //
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        cr.Reason = ex.Message.Substring(0, ex.Message.Length > 255 ? 255 : ex.Message.Length);
                        if (cr != null) EndEditing(cr, false);
                        throw;
                    }
                }

                return;
            }
        }

        public BaseDTO.Parameter GetParameter(string toolId, string chamberId, string parameterName)
        {
            using (E3suiteDBContext db = new E3suiteDBContext(new DbContextOptionsBuilder().UseOracle(ConnectionHelper.DbConnection).Options))
            {
                BaseDTO.Parameter parameter = null;

                try
                {
                    List<Entities.Parameter> paraEntities = db.ParameterRepository.Where(t => t.ToolId == toolId && t.ProcessUnit == chamberId && t.ParameterName==parameterName).ToList();

                    if (paraEntities != null && paraEntities.Count() > 0)
                    {
                        parameter = new BaseDTO.Parameter();
                        parameter.ParameterName = paraEntities[0].ParameterName;
                        parameter.ParameterType = paraEntities[0].ParameterType;
                        parameter.Precision = paraEntities[0].Precision;
                        parameter.AliasName = paraEntities[0].AliasName;
                        parameter.Tool =  new BaseDTO.Tool() { ToolId = toolId };
                        parameter.Chamber = new BaseDTO.Chamber() { ToolId = toolId ,ChamberId= chamberId };
                    }
                }
                catch (Exception ex)
                {
                    throw new ApiException(GeneralErrorCode.ResourceNotFound, ex.Message);
                }

                return parameter;
            }
        }

        public BaseDTO.Parameter CreateParameter(BaseDTO.Parameter parameter)
        {
            using (E3suiteDBContext db = new E3suiteDBContext())
            {
                string parameterKey = string.Format("{0}:{1}:{2}", parameter.Tool.ToolId, parameter.Chamber.ChamberId, parameter.ParameterName);
                BaseEntities.ChangeRequest cr = TryEditing(TxnContext.Area, ObjectName.Tool.ToString(), "CreateParameter", TxnContext.UserName, TxnContext.Comment, TxnContext.TxnId, parameterKey, parameter.Tool.ToolId);

                using (var transaction = db.Database.BeginTransaction())
                {
                    try
                    {
                        //TODO business log
                        List<Entities.Parameter> paraEntities = db.ParameterRepository.Where(t => t.ToolId == parameter.Tool.ToolId && t.ProcessUnit == parameter.Chamber.ChamberId && t.ParameterName == parameter.ParameterName).ToList();
                        if (paraEntities != null && paraEntities.Count() > 0)
                        {
                            throw new ApiException(GeneralErrorCode.ResourceAlreadyExists,"There already has a parameter with the same name");
                        }

                        paraEntities = db.ParameterRepository.Where(t => t.ToolId == parameter.Tool.ToolId && t.ProcessUnit == parameter.Chamber.ChamberId && t.AliasName == parameter.AliasName).ToList();
                        if (paraEntities != null && paraEntities.Count() > 0)
                        {
                            throw new ApiException(GeneralErrorCode.ResourceAlreadyExists,"There already has a parameter with the same alias name");
                        }

                        Entities.Parameter psEntity = new BaseEntities.Parameter();
                        psEntity.ParameterName = parameter.ParameterName;
                        psEntity.ParameterType = parameter.ParameterType;
                        psEntity.Precision = parameter.Precision;
                        psEntity.AliasName = parameter.AliasName;
                        psEntity.ProcessUnit = parameter.Chamber.ChamberId;
                        psEntity.ToolId = parameter.Tool.ToolId;

                        db.ParameterRepository.Add(psEntity);

                        db.SaveChanges();
                        transaction.Commit();
                        //
                        cr.ContextGroupValue1 = parameter.Tool.ToolId;
                        cr.ContextGroupValue = string.Format("{0}", parameterKey);
                        cr.ContxtGroup = string.Format("{0}:{1}:{2}", "Tool", "Chamber","Parameter");
                        EndEditing(cr, true);
                        //
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        cr.Reason = ex.Message.Substring(0, ex.Message.Length > 255 ? 255 : ex.Message.Length);
                        if (cr != null) EndEditing(cr, false);
                        throw;
                    }
                }

                return parameter;
            }
        }

        public void UpdateParameter(BaseDTO.Parameter parameter)
        {
            using (E3suiteDBContext db = new E3suiteDBContext())
            {
                string parameterKey = string.Format("{0}:{1}:{2}", parameter.Tool.ToolId, parameter.Chamber.ChamberId, parameter.ParameterName);
                BaseEntities.ChangeRequest cr = TryEditing(TxnContext.Area, ObjectName.Tool.ToString(), "UpdateParameter", TxnContext.UserName, TxnContext.Comment, TxnContext.TxnId, parameterKey, parameter.Tool.ToolId);

                using (var transaction = db.Database.BeginTransaction())
                {
                    try
                    {
                        //TODO business log
                        List<Entities.Parameter>  paraEntities = db.ParameterRepository.Where(t => t.ToolId == parameter.Tool.ToolId && t.ProcessUnit == parameter.Chamber.ChamberId && t.AliasName == parameter.AliasName).ToList();
                        if (paraEntities != null && paraEntities.Count() > 0)
                        {
                            throw new ApiException(GeneralErrorCode.ResourceAlreadyExists, "There already has a parameter with the same alias name");
                        }

                        paraEntities = db.ParameterRepository.Where(t => t.ToolId == parameter.Tool.ToolId && t.ProcessUnit == parameter.Chamber.ChamberId && t.ParameterName == parameter.ParameterName).ToList();
                        if (paraEntities != null && paraEntities.Count() <= 0)
                        {
                            throw new ApiException(GeneralErrorCode.ResourceNotFound);
                        }

                       

                        Entities.Parameter psEntity = paraEntities[0];
                        psEntity.ParameterName = parameter.ParameterName;
                        psEntity.ParameterType = parameter.ParameterType;
                        psEntity.Precision = parameter.Precision;
                        psEntity.AliasName = parameter.AliasName;
                        psEntity.ProcessUnit = parameter.Chamber.ChamberId;
                        psEntity.ToolId = parameter.Tool.ToolId;

                        db.ParameterRepository.Update(psEntity);

                        db.SaveChanges();
                        transaction.Commit();
                        //
                        cr.ContextGroupValue1 = parameter.Tool.ToolId;
                        cr.ContextGroupValue = string.Format("{0}", parameterKey);
                        cr.ContxtGroup = string.Format("{0}:{1}:{2}", "Tool", "Chamber", "Parameter");
                        EndEditing(cr, true);
                        //
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        cr.Reason = ex.Message.Substring(0, ex.Message.Length > 255 ? 255 : ex.Message.Length);
                        if (cr != null) EndEditing(cr, false);
                        throw;
                    }
                }

                return  ;
            }
        }

        public void DeleteParameter(string toolId, string chamberId, string parameterName)
        {
            using (E3suiteDBContext db = new E3suiteDBContext())
            {
                string parameterKey = string.Format("{0}:{1}:{2}", toolId, chamberId, parameterName);
                BaseEntities.ChangeRequest cr = TryEditing(TxnContext.Area, ObjectName.Tool.ToString(), "DeleteParameter", TxnContext.UserName, TxnContext.Comment, TxnContext.TxnId, parameterKey, toolId);

                using (var transaction = db.Database.BeginTransaction())
                {
                    try
                    {
                        //TODO business log
                        List<Entities.Parameter> paraEntities = db.ParameterRepository.Where(t => t.ToolId == toolId && t.ProcessUnit == chamberId && t.ParameterName == parameterName).ToList();
                        if (paraEntities != null && paraEntities.Count() <= 0)
                        {
                            throw new ApiException(GeneralErrorCode.ResourceNotFound);
                        }


                        db.ParameterRepository.Remove(paraEntities[0]);

                        db.SaveChanges();
                        transaction.Commit();
                        //
                        cr.ContextGroupValue1 = toolId;
                        cr.ContextGroupValue = string.Format("{0}", parameterKey);
                        cr.ContxtGroup = string.Format("{0}:{1}:{2}", "Tool", "Chamber", "Parameter");
                        EndEditing(cr, true);
                        //
                    }
                    catch (Exception ex)
                    {
                        transaction.Rollback();
                        cr.Reason = ex.Message.Substring(0, ex.Message.Length > 255 ? 255 : ex.Message.Length);
                        if (cr != null) EndEditing(cr, false);
                        throw;
                    }
                }

                return;
            }
        }

        public string GetSettingValue(string applicatonName,string settingName,string settingName1)
        {
            using (E3suiteDBContext db = new E3suiteDBContext(new DbContextOptionsBuilder().UseOracle(ConnectionHelper.DbConnection).Options))
            {
                string settingValue = "";

                try
                {
                    List<Entities.GlobalSetting> globalEntities = db.GlobalSettingRepository.Where(t => t.ApplicationName == applicatonName && t.SettingName == settingName && t.SettingName1 == settingName1).ToList();

                    if (globalEntities != null && globalEntities.Count() > 0)
                    {
                        settingValue = globalEntities[0].SettingValue;
                    }
                }
                catch (Exception ex)
                {
                    throw new ApiException(GeneralErrorCode.ResourceNotFound, ex.Message);
                }

                return settingValue;
            }
        }
    }
}
