﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Security.Claims;
using System.Security.Policy;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ApiExplorer;
using Microsoft.EntityFrameworkCore;


namespace AMAT.R2R.Server.Base.Extensions
{
    public abstract class R2RControllerBase : ControllerBase
    {
        public const string UsernameClaimType = "username";
        public const string SessionIdClaimType = "sessionId";

        // Use TxnContext instead.
        //public string UserName
        //{
        //    get
        //    {
        //        return User?.Claims?.FirstOrDefault(c => c.Type == UsernameClaimType)?.Value;
        //    }
        //}

        //public string SessionId
        //{
        //    get
        //    {
        //        return User?.Claims?.FirstOrDefault(c => c.Type == SessionIdClaimType)?.Value;
        //    }
        //}
    }
}

