﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AMAT.R2R.Server.Base.Extensions
{
    public static class StringExtensions
    {
        public static T ToEnum<T>(this string enumString)
        {
            return (T)Enum.Parse(typeof(T), enumString);
        }

        public static List<string> SplitToList(this string str, string separators = ",", StringSplitOptions options = StringSplitOptions.RemoveEmptyEntries, bool trimWhiteSpace = true)
        {
            if (separators is null)
            {
                throw new ArgumentNullException(nameof(separators));
            }

            if (string.IsNullOrEmpty(str))
            {
                return new List<string>();
            }
            else
            {
                var splits = str.Split(separators.ToCharArray(), options).ToList();
                if (options == StringSplitOptions.RemoveEmptyEntries && trimWhiteSpace)
                {
                    splits = splits.Where(s => !string.IsNullOrWhiteSpace(s)).ToList();
                }

                if (trimWhiteSpace)
                {
                    splits = splits.Select(s => s.Trim()).ToList();
                }

                return splits;
            }
        }

        public static bool EqualsIgnoreCase(this string str1, string str2)
        {
            return string.Compare(str1, str2, true) == 0;
        }

    }
}
