﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Security.Claims;
using System.Security.Policy;
using AMAT.R2R.Server.Base.Exceptions;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ApiExplorer;
using Microsoft.EntityFrameworkCore;


namespace AMAT.R2R.Server.Base.Extensions
{
    public static class ExceptionExtensions
    {
        public static bool IsTaskCanceledException(this Exception exp)
        {
            return exp != null && (exp is OperationCanceledException || exp.InnerException.IsTaskCanceledException());
        }

        public static Exception GetInnerestException(this Exception ex)
        {
            return ex == null ? null : ex.InnerException == null ? ex : GetInnerestException(ex.InnerException);
        }
    }
}

