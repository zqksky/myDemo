﻿using System;
using System.Web;
using System.Xml;
using System.Collections;
using System.Net;
using System.Text;
using System.IO;
using System.Xml.Serialization;
using Microsoft.EntityFrameworkCore.ValueGeneration.Internal;

namespace AMAT.R2R.Server.Base
{
    public class WebServiceHelper
    {

        private static Hashtable _xmlNamespaces = new Hashtable(); 


         
        public static XmlDocument QueryPostWebService(String URL, String methodName, Hashtable paras)
        {
            HttpWebRequest request = (HttpWebRequest)HttpWebRequest.Create(URL + "/" + methodName);
            request.Method = "POST";
            request.ContentType = "text/xml; charset=utf-8";
            SetWebRequest(request);
            byte[] data = EncodeParameters(paras);
            WriteRequestData(request, data);

            return ReadXmlResponse(request.GetResponse());
        }

        
        public static XmlDocument QueryGetWebService(String URL, String methodName, Hashtable Pars)
        {
            HttpWebRequest request = (HttpWebRequest)HttpWebRequest.Create(URL + "/" + methodName + "?" + ParsToString(Pars));
            request.Method = "GET";
            request.ContentType = "application/x-www-form-urlencoded";
            SetWebRequest(request);
            return ReadXmlResponse(request.GetResponse());
        }



        
        public static XmlDocument QuerySoapWebService(String URL, String methodName, Hashtable paras,string paraNs, string paraEnclosure)
        {
            if (_xmlNamespaces.ContainsKey(URL))
            {
                return QuerySoapWebService(URL, methodName, paras, _xmlNamespaces[URL].ToString(), paraNs, paraEnclosure);
            }
            else
            {
                return QuerySoapWebService(URL, methodName, paras, GetNamespace(URL), paraNs, paraEnclosure);
            }
        }

        private static XmlDocument QuerySoapWebService(String URL, String methodName, Hashtable Pars, string XmlNs,string paraNs, string paraEnclosure)
        {
            _xmlNamespaces[URL] = XmlNs; 
            HttpWebRequest request = (HttpWebRequest)HttpWebRequest.Create(URL);
            request.Method = "POST";
            request.ContentType = "text/xml; charset=utf-8";
            request.Headers.Add("SOAPAction", "\"" + XmlNs + (XmlNs.EndsWith("/") ? "" : "/") + methodName + "\"");
            SetWebRequest(request);
            byte[] data = EncodeParsToSoap(Pars, XmlNs, methodName, paraNs, paraEnclosure);
            WriteRequestData(request, data);
            XmlDocument doc = new XmlDocument(), doc2 = new XmlDocument();
            doc = ReadXmlResponse(request.GetResponse());

            XmlNamespaceManager mgr = new XmlNamespaceManager(doc.NameTable);
            mgr.AddNamespace("soap", "http://schemas.xmlsoap.org/soap/envelope/");
            String RetXml = doc.SelectSingleNode("//soap:Body/*/*", mgr).InnerXml;
            doc2.LoadXml("<root>" + RetXml + "</root>");
            AddDelaration(doc2);
            return doc2;
        }
        private static string GetNamespace(String URL)
        {
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(URL + "?WSDL");
            SetWebRequest(request);
            WebResponse response = request.GetResponse();
            StreamReader sr = new StreamReader(response.GetResponseStream(), Encoding.UTF8);
            XmlDocument doc = new XmlDocument();
            doc.LoadXml(sr.ReadToEnd());
            sr.Close();
            return doc.SelectSingleNode("//@targetNamespace").Value;
        }
        private static byte[] EncodeParsToSoap(Hashtable paras, String xmlNs, String methodName,string paraNs,string paraEnclosure)
        {
            XmlDocument doc = new XmlDocument();
            doc.LoadXml("<soap:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\"></soap:Envelope>");
            AddDelaration(doc);
            XmlElement soapBody = doc.CreateElement("soap", "Body", "http://schemas.xmlsoap.org/soap/envelope/");
            XmlElement soapMethod = doc.CreateElement(methodName);
            soapMethod.SetAttribute("xmlns", xmlNs);

            XmlElement soapParaEnclosure = doc.CreateElement(paraEnclosure);

            foreach (string k in paras.Keys)
            {
                XmlElement soapPar = doc.CreateElement(k,"");
                soapPar.SetAttribute("xmlns", paraNs);
                soapPar.InnerXml = ObjectToSoapXml(paras[k]);
                soapParaEnclosure.AppendChild(soapPar);
            }
            soapMethod.AppendChild(soapParaEnclosure);
            soapBody.AppendChild(soapMethod);
            doc.DocumentElement.AppendChild(soapBody);
            return Encoding.UTF8.GetBytes(doc.OuterXml);
        }
        private static string ObjectToSoapXml(object o)
        {
            XmlSerializer mySerializer = new XmlSerializer(o.GetType());
            MemoryStream ms = new MemoryStream();
            mySerializer.Serialize(ms, o);
            XmlDocument doc = new XmlDocument();
            doc.LoadXml(Encoding.UTF8.GetString(ms.ToArray()));
            if (doc.DocumentElement != null)
            {
                return doc.DocumentElement.InnerXml;
            }
            else
            {
                return o.ToString();
            }
        }
        private static void SetWebRequest(HttpWebRequest request)
        {
            request.Credentials = CredentialCache.DefaultCredentials;
            request.Timeout = 10000;
        }

        private static void WriteRequestData(HttpWebRequest request, byte[] data)
        {
            request.ContentLength = data.Length;
            Stream writer = request.GetRequestStream();
            writer.Write(data, 0, data.Length);
            writer.Close();
        }

        private static byte[] EncodeParameters(Hashtable Pars)
        {
            return Encoding.UTF8.GetBytes(ParsToString(Pars));
        }

        private static String ParsToString(Hashtable Pars)
        {
            StringBuilder sb = new StringBuilder();
            foreach (string k in Pars.Keys)
            {
                if (sb.Length > 0)
                {
                    sb.Append("&");
                }
                //sb.Append(HttpUtility.UrlEncode(k) + "=" + HttpUtility.UrlEncode(Pars[k].ToString()));
            }
            return sb.ToString();
        }

        private static XmlDocument ReadXmlResponse(WebResponse response)
        {
            StreamReader sr = new StreamReader(response.GetResponseStream(), Encoding.UTF8);
            String retXml = sr.ReadToEnd();
            sr.Close();
            XmlDocument doc = new XmlDocument();
            doc.LoadXml(retXml);
            return doc;
        }

        private static void AddDelaration(XmlDocument doc)
        {
            XmlDeclaration decl = doc.CreateXmlDeclaration("1.0", "utf-8", null);
            doc.InsertBefore(decl, doc.DocumentElement);
        }


        public static bool TryParseNodeInnerText(XmlDocument xml,string nodeString,out string value)
        {
            value = "";
            XmlNode node = xml.SelectSingleNode("//"+ nodeString);
            if (node == null) return false;

            value = node.InnerText;
            return true;
        }

        public static bool TryParseNodeOuterXml(XmlDocument xml, string nodeString, out string value)
        {
            value = "";
            XmlNode node = xml.SelectSingleNode("//" + nodeString);
            if (node == null) return false;

            value = node.OuterXml;
            return true;
        }
    }
}
