﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc.Filters;
using Newtonsoft.Json;

namespace AMAT.R2R.Server.Base
{
    public class EnableBodyRewindAttribute : Attribute, IAuthorizationFilter
    {
        public void OnAuthorization(AuthorizationFilterContext context)
        {
            var bodyStr = "";
            var req = context.HttpContext.Request;

            // Allows using several time the stream in ASP.Net Core
            req.EnableBuffering();

            // Arguments: Stream, Encoding, detect encoding, buffer size 
            // AND, the most important: keep stream opened
            using (StreamReader reader = new StreamReader(req.Body, Encoding.UTF8, true, 1024, true))
            {
                bodyStr = reader.ReadToEnd();
            }

            // Rewind, so the core is not lost when it looks the body for the request
            req.Body.Position = 0;

            var loggableHeaders = new List<string>() { "userName", "sessionId", "txnId", "fab", "area", "comment" };
            Console.WriteLine($"{context.HttpContext.Request.Method}");
            Console.WriteLine($"https://{context.HttpContext.Request.Host.Value}{context.HttpContext.Request.Path}{context.HttpContext.Request.QueryString.Value}");
            Console.WriteLine();
            Console.WriteLine($"Context in Header:\n{string.Join("\n", context.HttpContext.Request.Headers.Where(h => loggableHeaders.Contains(h.Key)).Select(h => $"{h.Key}:{h.Value}"))}");

            Console.WriteLine();
            if (context.HttpContext.Request.Method == "POST" || context.HttpContext.Request.Method == "PUT")
            {
                var requestObj = JsonConvert.DeserializeObject(bodyStr);
                var formattedJson = JsonConvert.SerializeObject(requestObj, Formatting.Indented);
                Console.WriteLine($"Json Body:\n{formattedJson}");
            }
        }
    }
}
