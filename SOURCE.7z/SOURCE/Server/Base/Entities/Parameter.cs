﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Runtime.CompilerServices;
using System.Security.Policy;
using Microsoft.EntityFrameworkCore;


namespace AMAT.R2R.Server.Base.Entities
{
    [Table("R2R_GLOBAL_PARAMETER")]
    public class Parameter
    {

        [Column("PARAMETERNAME")]
        public string ParameterName { get; set; }

        [Column("PARAMETERTYPE")]
        public string ParameterType { get; set; }

        [Column("PRECISION")]
        public int/*,0*/ Precision { get; set; }

        [Column("TOOLID")]
        public string ToolId { get; set; }

        [Column("PROCESSUNIT")]
        public string ProcessUnit { get; set; }

        [Column("ALIASNAME")]
        public string AliasName { get; set; }

    }
}

