﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Runtime.CompilerServices;
using System.Security.Policy;
using Microsoft.EntityFrameworkCore;

namespace AMAT.R2R.Server.Base.Entities
{
    [Table("R2R_GLOBAL_PROCESSUNIT")]
    public class ProcessUnit
    {
        [Column("TOOLID")]
        public string ToolId { get; set; }

        [Column("PROCESSUNIT")]
        public string ProcessUnitId { get; set; }

        [Column("PROCESSMODEL")]
        public string ProcessModel { get; set; }


        [Column("UNITTYPE")]
        public string UnitType { get; set; }
    }
}


