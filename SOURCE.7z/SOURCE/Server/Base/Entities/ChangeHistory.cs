﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Runtime.CompilerServices;
using System.Security.Policy;
using Microsoft.EntityFrameworkCore;

namespace AMAT.R2R.Server.Base.Entities
{
    [Table("R2R_UI_CHANGE_HISTORY")]
    public class ChangeHistory
    {
        [Column("CR_TIMESTAMP")]
        public DateTime CrTimeStamp { get; set; }

        [Column("CR_ID")]
        public string CrId { get; set; }

        [Column("MODULE")]
        public string Module { get; set; }

        [Column("TABLE_NAME")]
        public string TableName { get; set; }

        [Column("USER_ID")]
        public string UserId { get; set; }

        [Column("ACTION")]
        public string Action { get; set; }
    }
}
