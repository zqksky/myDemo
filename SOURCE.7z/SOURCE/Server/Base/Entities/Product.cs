﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Runtime.CompilerServices;
using System.Security.Policy;
using Microsoft.EntityFrameworkCore;

namespace AMAT.R2R.Server.Base.Entities
{
    [Table("R2R_GLOBAL_PRODUCT")]
    public class Product
    {

        [Column("PRODUCTID")]
        public string ProductId { get; set; }

        [Column("PRODUCTTYPE")]
        public string ProductType { get; set; }

        [Column("NAMESPACE")]
        public string NameSpace { get; set; }

        [Column("FAB")]
        public string Fab { get; set; }
    }
}

