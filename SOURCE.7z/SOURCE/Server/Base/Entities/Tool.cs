﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Runtime.CompilerServices;
using System.Security.Policy;
using Microsoft.EntityFrameworkCore;


namespace AMAT.R2R.Server.Base.Entities
{
    [Table("R2R_GLOBAL_TOOL")]
    public class Tool
    {
        [Column("TOOLID")]
        public string ToolId { get; set; }

        [Column("TOOLVENDOR")]
        public string ToolVendor { get; set; }

        [Column("TOOLMODEL")]
        public string ToolModel { get; set; }

        [Column("PROCESSTYPE")]
        public string ToolType { get; set; }

        [Column("PROCESSMODEL")]
        public string ToolProcessType { get; set; }

        [Column("NAMESPACE")]
        public string NameSpace { get; set; }

        [Column("AREA")]
        public string Area { get; set; }

        [Column("FAB")]
        public string Fab { get; set; }
    }
}

