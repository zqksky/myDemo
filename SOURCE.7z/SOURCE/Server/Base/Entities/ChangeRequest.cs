﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Runtime.CompilerServices;
using System.Security.Policy;
using Microsoft.EntityFrameworkCore;

namespace AMAT.R2R.Server.Base.Entities
{
    [Table("R2R_UI_CHANGE_REQUEST")]
    public class ChangeRequest
    {

        [Column("CR_TIMESTAMP")]
        public DateTime CrTimeStamp { get; set; }

        [Column("CR_ID")]
        public string CrId { get; set; }


        [Column("MODULE")]
        public string Module { get; set; }

        [Column("TABLE_NAME")]
        public string TableName { get; set; }

        [Column("USER_ID")]
        public string UserId { get; set; }

        [Column("SUBTABLE_01")]
        public string SubTable01 { get; set; }

        [Column("SUBTABLE_02")]
        public string SubTable02 { get; set; }

        [Column("JSON_01")]
        public string Json01 { get; set; }

        [Column("JSON_02")]
        public string Json02 { get; set; }

        [Column("CR_DETAIL")]
        public string CrDetails { get; set; }

        [Column("CR_CATEGORY")]
        public string CrCategory { get; set; }

        [Column("CR_COMMENT")]
        public string CrComment { get; set; }

        [Column("CR_STATUS")]
        public string CrStatus { get; set; }

        [Column("TRACKTIME")]
        public string TrackTime { get; set; }

        [Column("USER_MODIFY")]
        public string UserModify { get; set; }

        [Column("REASON")]
        public string Reason { get; set; }

        [Column("CONTEXT_GROUP")]
        public string ContxtGroup { get; set; }

        [Column("CONTEXT_GROUP_VALUE")]
        public string ContextGroupValue { get; set; }

        [Column("CONTEXT_GROUP_VALUE_1")]
        public string ContextGroupValue1 { get; set; }

        [Column("TXID")]
        public string TxId { get; set; }

    }
}
