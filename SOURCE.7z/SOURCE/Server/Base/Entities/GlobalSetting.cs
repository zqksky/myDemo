﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Runtime.CompilerServices;
using System.Security.Policy;
using Microsoft.EntityFrameworkCore;

namespace AMAT.R2R.Server.Base.Entities
{
    [Table("R2R_GLOBAL_SETTING2")]
    public class GlobalSetting
    {

        [Column("APPLICATIONNAME")]
        public string ApplicationName { get; set; }

        [Column("SETTINGNAME")]
        public string SettingName { get; set; }

        [Column("DESCRIPTION")]
        public string Description { get; set; }

        [Column("UPDATETIMESTAMP")]
        public DateTime? UpdateTimestamp { get; set; }

        [Column("SETTINGVALUE")]
        public string SettingValue { get; set; }

        [Column("SETTINGNAME1")]
        public string SettingName1 { get; set; }
    }
}
