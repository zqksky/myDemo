﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Dynamic.Core;
using System.Threading.Tasks;
using AMAT.R2R.Server.Base.Extensions;
using AMAT.R2R.Shared.Base.Constants;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Primitives;

namespace AMAT.R2R.Server.Base.Helpers
{
    public static class QueryHelper
    {
        public static IQueryable<T> ApplyFilters<T>(this IQueryable<T> source, IEnumerable<KeyValuePair<string, StringValues>> query)
        {
            if (source is null)
            {
                throw new ArgumentNullException(nameof(source));
            }

            var filters = query.GetFilters();

            if (filters == null || filters.Count() == 0)
            {
                return source;
            }

            foreach (var filter in filters)
            {
                var key = filter.Key;
                var value = filter.Value.ToString();

                var splits = key.SplitToList(QueryWords.OperatorSeperator);
                var propertyName = splits[0];
                var @operator = splits.Count > 1 ? splits[1].ToLower() : null;

                if (string.IsNullOrEmpty(propertyName))
                {
                    continue;
                }

                if (string.IsNullOrEmpty(@operator))
                {
                    // default to use equals as the operator.
                    @operator = QueryOperators.EqualsTo;
                }

                if (string.IsNullOrEmpty(value))
                {
                    // null value only are allowed for Equals, NotEquals, in, notin operators.
                    if (@operator != QueryOperators.EqualsTo && @operator != QueryOperators.NotEqualsTo && @operator != QueryOperators.In && @operator != QueryOperators.NotIn)
                    {
                        // ignore this filter.
                        continue;
                        //throw new InvalidOperationException($"Null value is not allowed for the operator. {key}");
                    }
                }

                if (!ReflectionHelper.TryGetProperty<T>(propertyName, out var property))
                {
                    // ignore not existed property.
                    continue;
                }

                if (@operator == QueryOperators.In || @operator == QueryOperators.NotIn)
                {
                    // if it's value list.
                    List<string> splitedValues = value.SplitToList(QueryWords.ValueSeperator);
                    if (splitedValues.Any(v => !DataConverter.CanConvert(v, property.PropertyType)))
                    {
                        throw new InvalidOperationException($"Invalid value '{value}' provided. Property Name: {property.DeclaringType.Name}.{property.Name}, Property Type: {property.PropertyType.Name}");
                    }

                    // convert true/false to 1/0
                    if (property.PropertyType == typeof(int) && splitedValues.Any(v => !int.TryParse(v, out _)))
                    {
                        splitedValues = splitedValues.Select(v => DataConverter.Convert(v, typeof(int)).ToString()).ToList();
                    }

                    if (@operator == QueryOperators.In)
                    {
                        source = source.Where($"{property.Name} {@operator} @0", splitedValues);
                    }
                    else
                    {
                        splitedValues = splitedValues.Select(v => $"\"{v}\"").ToList();
                        source = source.Where($"not ({property.Name} in ({string.Join(",", splitedValues)}) )");
                    }
                }
                else if (@operator == QueryOperators.Contains)
                {
                    source = source.Where($"{property.Name}.Contains(@0)", value);
                }
                else if (@operator == QueryOperators.StartsWith)
                {
                    source = source.Where($"{property.Name}.StartsWith(@0)", value);
                }
                else if (@operator == QueryOperators.EndsWith)
                {
                    source = source.Where($"{property.Name}.EndsWith(@0)", value);
                }
                else
                {
                    // if the value is not valid, throw error.
                    if (!DataConverter.CanConvert(value, property.PropertyType))
                    {
                        throw new InvalidOperationException($"Invalid value '{value}' provided. Property Name: {property.DeclaringType.Name}.{property.Name}, Property Type: {property.PropertyType.Name}");
                    }

                    // convert true/false to 1/0
                    if (property.PropertyType == typeof(int) && !int.TryParse(value, out _))
                    {
                        value = DataConverter.Convert(value, typeof(int)).ToString();
                    }

                    source = source.Where($"{property.Name} {@operator} @0", value);
                }
            }

            return source;
        }

        public static IQueryable<T> ApplySorters<T>(this IQueryable<T> source, IEnumerable<KeyValuePair<string, StringValues>> query)
        {
            return source.ApplySorters(query.GetSorters());
        }

        public static IQueryable<T> ApplySorters<T>(this IQueryable<T> source, string sorters)
        {
            if (string.IsNullOrEmpty(sorters))
            {
                return source;
            }
            else
            {
                var orderSplits = sorters.SplitToList(QueryWords.ValueSeperator);
                List<string> validatedOrders = new List<string>();
                foreach (var order in orderSplits)
                {
                    var propertyName = order;
                    var direction = QueryWords.OrderAscending;

                    var splits = order.SplitToList(QueryWords.OrderSeperator);
                    if (splits.Count == 2)
                    {
                        propertyName = splits[0];
                        direction = splits[1];
                    }

                    // validate property name.
                    if (!ReflectionHelper.TryGetProperty<T>(propertyName, out var property))
                    {
                        // ignore not existed property.
                        continue;
                    }

                    if (!direction.EqualsIgnoreCase(QueryWords.OrderAscending) && !direction.EqualsIgnoreCase(QueryWords.OrderDescending))
                    {
                        // ignore unknown order direction.
                        continue;
                    }
                    validatedOrders.Add(direction == QueryWords.OrderAscending ? property.Name : $"{property.Name} desc");
                }

                if (validatedOrders.Count == 0)
                {
                    return source;
                }
                else
                {
                    return source.OrderBy(string.Join(",", validatedOrders));
                }
            }
        }

        public static List<T> PageToList<T>(this IQueryable<T> source, IEnumerable<KeyValuePair<string, StringValues>> query)
        {
            return source.PageToList(query.GetSkip(), query.GetTake());
        }
        public static async Task<List<T>> PageToListAsync<T>(this IQueryable<T> source, IEnumerable<KeyValuePair<string, StringValues>> query)
        {
            return await source.PageToListAsync(query.GetSkip(), query.GetTake());
        }

        public static List<T> PageToList<T>(this IQueryable<T> source, int? skip, int? take)
        {
            if (skip.HasValue)
            {
                source = source.Skip(skip.Value);
            }

            if (take.HasValue)
            {
                source = source.Take(take.Value);
            }
            return source.ToList();
        }

        public static async Task<List<T>> PageToListAsync<T>(this IQueryable<T> source, int? skip, int? take)
        {
            if (skip.HasValue)
            {
                source = source.Skip(skip.Value);
            }

            if (take.HasValue)
            {
                source = source.Take(take.Value);
            }
            return await source.ToListAsync();
        }

        public static object[] GetValueList<T>(this IQueryable<T> source, IEnumerable<KeyValuePair<string, StringValues>> query, string propertyName)
        {
            if (ReflectionHelper.TryGetProperty<T>(propertyName, out var property))
            {
                var dynamicList = ApplyFilters(source, query).Select($"p => p.{property.Name}").Distinct().ToDynamicList();
                dynamicList.Sort();
                return dynamicList.ToDynamicArray();
            }
            else
            {
                return new object[] { };
            }
        }

        public static async Task<object[]> GetValueListAsync<T>(this IQueryable<T> source, IEnumerable<KeyValuePair<string, StringValues>> query, string propertyName)
        {
            if (ReflectionHelper.TryGetProperty<T>(propertyName, out var property))
            {
                return await ApplyFilters(source, query).ApplySorters(query.GetSorters()).Select($"p => p.{property.Name}").Distinct().ToDynamicArrayAsync<object>();
            }
            else
            {
                return new object[] { };
            }
        }
    }


    public static class QueryCollectionExtension
    {
        public static IEnumerable<KeyValuePair<string, StringValues>> GetFilters(this IEnumerable<KeyValuePair<string, StringValues>> query)
        {
            return query?.Where(q => q.Key != QueryWords.Sort && q.Key != QueryWords.Skip && q.Key != QueryWords.Take);
        }

        public static string GetSorters(this IEnumerable<KeyValuePair<string, StringValues>> query)
        {
            return query?.SingleOrDefault(kvp => kvp.Key.EqualsIgnoreCase(QueryWords.Sort)).Value;
        }

        public static int? GetSkip(this IEnumerable<KeyValuePair<string, StringValues>> query)
        {
            return DataConverter.ConvertToNullable<int>(query?.SingleOrDefault(kvp => kvp.Key.EqualsIgnoreCase(QueryWords.Skip)).Value);
        }
        public static int? GetTake(this IEnumerable<KeyValuePair<string, StringValues>> query)
        {
            return DataConverter.ConvertToNullable<int>(query?.SingleOrDefault(kvp => kvp.Key.EqualsIgnoreCase(QueryWords.Take)).Value);
        }
    }

    public static class QueryStringExtension
    {
        public static string GetOperator(this string queryKey)
        {
            if (queryKey is null)
            {
                throw new ArgumentNullException(nameof(queryKey));
            }

            var splits = queryKey.SplitToList(QueryWords.OperatorSeperator);
            var propertyName = splits[0];
            var @operator = string.Empty;
            if (splits.Count > 1)
            {
                @operator = splits[1];
            }
            else
            {
                @operator = QueryOperators.EqualsTo;
            }

            return @operator;
        }
    }
}
