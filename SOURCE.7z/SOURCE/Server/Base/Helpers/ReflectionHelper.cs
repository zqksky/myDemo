﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using AMAT.R2R.Server.Base.Extensions;

namespace AMAT.R2R.Server.Base.Helpers
{
    public static class ReflectionHelper
    {
        private static readonly Dictionary<Type, PropertyInfo[]> s_typeProperties = new Dictionary<Type, PropertyInfo[]>();

        static ReflectionHelper()
        {

        }

        public static bool TryGetProperty<T>(string propertyName, out PropertyInfo propertyInfo)
        {
            var type = typeof(T);

            lock (s_typeProperties)
            {
                if (!s_typeProperties.ContainsKey(type))
                {
                    s_typeProperties[type] = type.GetProperties();
                }
                propertyInfo = s_typeProperties[type].FirstOrDefault(prop => prop.Name.EqualsIgnoreCase(propertyName));

                return propertyInfo != null;
            }
        }
    }
}
