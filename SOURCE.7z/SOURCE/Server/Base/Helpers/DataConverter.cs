﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Xml.Schema;
using Newtonsoft.Json;

namespace AMAT.R2R.Server.Base.Helpers
{
    public static class DataConverter
    {
        // for containing Mapping
        private static readonly Dictionary<Type, Delegate> s_mapper = new Dictionary<Type, Delegate>
        {
            { typeof(int?), new Func<object, int?>(TryConvertToInt) },
            { typeof(long?), new Func<object, long?>(TryConvertToLong)},
            { typeof(double?), new Func<object, double?>(TryConvertToDouble)},
            { typeof(decimal?), new Func<object, decimal?>(TryConvertToDecimal) },
            { typeof(bool?), new Func<object, bool?>(TryConvertToBool)},
            { typeof(DateTime?), new Func<object, DateTime?>(TryConvertToDateTime)},
            { typeof(string), new Func<object, string>(TryConvertToString)}
        };

        // currently TryParse function does not allow "T", "F" value for converting target.
        // only String.falseValue, String.trueValue are accepted of target of converting.
        private static readonly List<string> s_lowercasedFalseString = new List<string>
        {
            "false",
            "f",
            "n",
            "no",
            "0"
        };

        private static readonly List<string> s_lowercasedTrueString = new List<string>
        {
            "true",
            "t",
            "y",
            "yes",
            "1"
        };

        // Indexer to get convert method
        /// <summary>
        /// indexer to find ot correspoing converting delegate
        /// </summary>
        /// <param name="type">source type</param>
        /// <returns>Delegated method which provide convert.</returns>
        private static Delegate GetDelegate<T>() where T : struct
        {
            var type = typeof(T?);
            Delegate returnVal;
            if (s_mapper.ContainsKey(type))
            {
                returnVal = s_mapper[type];
            }
            else
            {
                // by default, use stringConverter.
                returnVal = null;
            }
            return returnVal;
        }


        #region Definition for Convert

        /// <summary>
        /// Supports conversion of object.ToString() to Nullable bool, int, long, double, string, DateTime.
        /// </summary>
        /// <typeparam name="T"> bool, int, long, double, string or DateTime</typeparam>
        /// <param name="source">object to be converted.</param>
        /// <returns>Convert result of a Nullable generic type for specified value type.</returns>
        public static T? ConvertToNullable<T>(object source) where T : struct
        {
            var type = typeof(T);
            if (type.IsEnum)
            {
                if (source != null && type.IsEnumDefined(source.ToString()))
                {
                    return Enum.Parse<T>(source.ToString());
                }
                else
                {
                    return null;
                }
            }

            if (GetDelegate<T>() is Func<object, T?> converter)
            {
                return converter.Invoke(source);
            }
            else
            {
                return null;
            }
        }
        public static object Convert(string source, Type toType)
        {
            if (!CanConvert(source, toType))
            {
                throw new InvalidOperationException($"Cannot convert '{source}' to type {toType.FullName}.");
            }

            if(toType == typeof(string))
            {
                return source;
            }
            else if (toType == typeof(int))
            {
                if (int.TryParse(source, out var value))
                {
                    return value;
                }
                else
                {
                    return TryConvertToBool(source).Value ? 1 : 0;
                }
            }
            else if (toType == typeof(double))
            {
                return double.Parse(source);
            }
            else if (toType == typeof(bool))
            {
                return TryConvertToBool(source).Value;
            }
            else if (toType == typeof(decimal))
            {
                return decimal.Parse(source);
            }
            else if (toType == typeof(DateTime))
            {
                return DateTime.Parse(source);
            }
            else if (toType == typeof(long))
            {
                return long.Parse(source);
            }
            else if (toType == typeof(int?))
            {
                if (string.IsNullOrEmpty(source))
                {
                    return null;
                }
                else
                {
                    if (int.TryParse(source, out var value))
                    {
                        return value;
                    }
                    else
                    {
                        return TryConvertToBool(source).Value ? 1 : 0;
                    }
                }
            }
            else if (toType == typeof(bool?))
            {
                return string.IsNullOrEmpty(source) ? null : TryConvertToBool(source);
            }
            else if (toType == typeof(long?))
            {
                return string.IsNullOrEmpty(source) ? null : Convert(source, typeof(long));
            }
            else if (toType == typeof(double?))
            {
                return string.IsNullOrEmpty(source) ? null : Convert(source, typeof(double));
            }
            else if (toType == typeof(decimal?))
            {
                return string.IsNullOrEmpty(source) ? null : Convert(source, typeof(decimal));
            }
            else if (toType == typeof(DateTime?))
            {
                return string.IsNullOrEmpty(source) ? null : Convert(source, typeof(DateTime));
            }
            else
            {
                return source;
            }
        }

        public static bool CanConvert(string source, Type toType)
        {
            if (toType is null)
            {
                throw new ArgumentNullException(nameof(toType));
            }

            if (toType == typeof(string))
            {
                return true;
            }
            else if (toType == typeof(int))
            {
                return string.IsNullOrEmpty(source) ? false : int.TryParse(source, out _) ? true : TryConvertToBool(source).HasValue;
            }
            else if (toType == typeof(bool))
            {
                return string.IsNullOrEmpty(source) ? false : TryConvertToBool(source).HasValue;
            }
            else if (toType == typeof(double))
            {
                return string.IsNullOrEmpty(source) ? false : double.TryParse(source, out _);
            }
            else if (toType == typeof(decimal))
            {
                return string.IsNullOrEmpty(source) ? false : decimal.TryParse(source, out _);
            }
            else if (toType == typeof(DateTime))
            {
                return string.IsNullOrEmpty(source) ? false : DateTime.TryParse(source, out _);
            }
            else if (toType == typeof(long))
            {
                return string.IsNullOrEmpty(source) ? false : long.TryParse(source, out _);
            }
            else if (toType == typeof(int?))
            {
                return string.IsNullOrEmpty(source) ? true : int.TryParse(source, out _) ? true : TryConvertToBool(source).HasValue;
            }
            else if (toType == typeof(bool?))
            {
                return string.IsNullOrEmpty(source) ? true : TryConvertToBool(source).HasValue;
            }
            else if (toType == typeof(long?))
            {
                return string.IsNullOrEmpty(source) ? true : long.TryParse(source, out _);
            }
            else if (toType == typeof(double?))
            {
                return string.IsNullOrEmpty(source) ? true : double.TryParse(source, out _);
            }
            else if (toType == typeof(decimal?))
            {
                return string.IsNullOrEmpty(source) ? true : decimal.TryParse(source, out _);
            }
            else if (toType == typeof(DateTime?))
            {
                return string.IsNullOrEmpty(source) ? true : DateTime.TryParse(source, out _);
            }
            else if(toType.IsEnum)
            {
                return Enum.TryParse(toType, source, out _);
            }
            else
            {
                //JsonConvert.DeserializeObject(source, toType);
                throw new InvalidOperationException($"Not supported DataType. {toType.FullName}");
            }
        }

        #endregion Definition for Convert

        #region Define Convert Methods

        /// <summary>
        /// DefaultConverter
        /// </summary>
        /// <returns>Converted value from source.</returns>
        private static string TryConvertToString(object source)
        {
            return source?.ToString();
        }

        /// <summary>
        /// Converts passed object to <see cref="long?"/>
        /// </summary>
        /// <param name="source">value which will be converted to</param>
        /// <returns>Converted value from source.</returns>
        private static long? TryConvertToLong(object source)
        {
            return source == null ? null : long.TryParse(source.ToString(), out var longValue) ? longValue : (long?)null;
        }

        /// <summary>
        /// Converted passed object to <see cref="int?"/>
        /// </summary>
        /// <param name="source">value which will be converted to</param>
        /// <returns>Converted value from source.</returns>
        private static int? TryConvertToInt(object source)
        {
            return source == null ? null : int.TryParse(source.ToString(), out var intValue) ? intValue : (int?)null;
        }

        /// <summary>
        /// Converted passed object to <see cref="double?"/>
        /// </summary>
        /// <param name="source">value which will be converted to</param>
        /// <returns>Converted value from source.</returns>
        private static double? TryConvertToDouble(object source)
        {
            return source == null ? null : double.TryParse(source.ToString(), out var doubleValue) ? doubleValue : (double?)null;
        }

        /// <summary>
        /// Converted passed object to <see cref="decimal?"/>
        /// </summary>
        /// <param name="source">value which will be converted to</param>
        /// <returns>Converted value from source.</returns>
        private static decimal? TryConvertToDecimal(object source)
        {
            return source == null ? null : decimal.TryParse(source.ToString(), out var intValue) ? intValue : (decimal?)null;
        }

        private static DateTime? TryConvertToDateTime(object source)
        {
            return source == null ? null : DateTime.TryParse(source.ToString(), out var dateTimeValue) ? dateTimeValue : (DateTime?)null;
        }

        /// <summary>
        /// Converted passed object to <see cref="bool?"/>
        /// </summary>
        /// <param name="source">value which will be converted to</param>
        /// <returns>Converted value from source.</returns>
        private static bool? TryConvertToBool(object source)
        {
            bool? result;
            if (source == null)
            {
                result = null;
            }
            else
            {
                if (s_lowercasedFalseString.Contains(source.ToString().ToLower()))
                {
                    result = false;
                }
                else
                {
                    if (s_lowercasedTrueString.Contains(source.ToString().ToLower()))
                    {
                        result = true;
                    }
                    else
                    {
                        result = bool.TryParse(source.ToString(), out var boolValue) ? boolValue : (bool?)null;
                    }
                }
            }

            return result;
        }

        #endregion Define Convert Methods
    }
}
