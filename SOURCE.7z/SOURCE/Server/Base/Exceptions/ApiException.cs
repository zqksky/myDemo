﻿using System;
using System.Runtime.Serialization;
using AMAT.R2R.Server.Base.Constants;
using AMAT.R2R.Server.Base.Exceptions;

namespace AMAT.R2R.Server.Base.Exceptions
{
    public class ApiException : ErrorCodeException
    {
        public ApiException(GeneralErrorCode errorCode) : base((int)errorCode, errorCode.ToString())
        {
        }

        public ApiException(GeneralErrorCode errorCode, string message) : base((int)errorCode, message)
        {
        }
    }
}
