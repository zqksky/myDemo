﻿using System;
using System.Runtime.Serialization;
using AMAT.R2R.Server.Base.Exceptions;

namespace AMAT.R2R.Server.Base.Exceptions
{
    public abstract class ErrorCodeException : Exception
    {
        public ErrorCodeException(int errorCode, string message) : base(message)
        {
            ErrorCode = errorCode;
        }

        public int ErrorCode { get; private set; }
    }
}
