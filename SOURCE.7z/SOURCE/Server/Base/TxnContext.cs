﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net;
using System.Threading;
using System.Threading.Tasks;
using System.Web;
using AMAT.R2R.Server.Base.Constants;
using AMAT.R2R.Server.Base.Exceptions;
using AMAT.R2R.Server.Base.Extensions;
using AMAT.R2R.Shared.Base.Constants;
using Microsoft.AspNetCore.Http;
using Newtonsoft.Json;

namespace AMAT.R2R.Server.Base
{
    public class TxnContext
    {
        internal TxnContext(HttpContext context)
        {
            TxnId = context?.Request?.Headers?.FirstOrDefault(kvp => kvp.Key.EqualsIgnoreCase(HeaderKeys.TxnId)).Value.ToString() ?? string.Empty;
            SessionId = context?.Request?.Headers?.FirstOrDefault(kvp => kvp.Key.EqualsIgnoreCase(HeaderKeys.SessionId)).Value.ToString() ?? string.Empty;
            UserName = context?.Request?.Headers?.FirstOrDefault(kvp => kvp.Key.EqualsIgnoreCase(HeaderKeys.UserName)).Value.ToString() ?? string.Empty;
            Fab = context?.Request?.Headers?.FirstOrDefault(kvp => kvp.Key.EqualsIgnoreCase(HeaderKeys.Fab)).Value.ToString() ?? string.Empty;
            Area = context?.Request?.Headers?.FirstOrDefault(kvp => kvp.Key.EqualsIgnoreCase(HeaderKeys.Area)).Value.ToString() ?? string.Empty;
            Comment = HttpUtility.UrlDecode(context?.Request?.Headers?.FirstOrDefault(kvp => kvp.Key.EqualsIgnoreCase(HeaderKeys.Comment)).Value.ToString() ?? string.Empty);
            ClientMachineName = context?.Request?.Headers?.FirstOrDefault(kvp => kvp.Key.EqualsIgnoreCase(HeaderKeys.ClientMachineName)).Value.ToString() ?? string.Empty;
            ClientIp = context?.Request?.Headers?.FirstOrDefault(kvp => kvp.Key.EqualsIgnoreCase(HeaderKeys.ClientIp)).Value.ToString() ?? string.Empty;
            ClientProcessId = context?.Request?.Headers?.FirstOrDefault(kvp => kvp.Key.EqualsIgnoreCase(HeaderKeys.ClientProcessId)).Value.ToString() ?? string.Empty;
            ClientVersion = context?.Request?.Headers?.FirstOrDefault(kvp => kvp.Key.EqualsIgnoreCase(HeaderKeys.ClientVersion)).Value.ToString() ?? string.Empty;
        }

        internal TxnContext(string txnId,
                           string sessionId,
                           string userName,
                           string fab,
                           string area,
                           string comment,
                           string clientMachineName,
                           string clientIp,
                           string clientProcessId,
                           string clientVersion)
        {
            TxnId = txnId;
            SessionId = sessionId;
            UserName = userName;
            Fab = fab;
            Area = area;
            Comment = comment;
            ClientMachineName = clientMachineName;
            ClientProcessId = clientProcessId;
            ClientIp = clientIp;
            ClientVersion = clientVersion;
        }

        public string TxnId { get; private set; }
        public string SessionId { get; private set; }
        public string UserName { get; private set; }
        public string Fab { get; private set; }
        public string Area { get; private set; }
        public string Comment { get; private set; }

        public string ClientMachineName { get; private set; }
        public string ClientProcessId { get; private set; }
        public string ClientIp { get; private set; }
        public string ClientVersion { get; private set; }
    }

}
