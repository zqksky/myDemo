﻿using System;
using System.Net;
using System.Threading.Tasks;
using AMAT.R2R.Server.Base.Constants;
using AMAT.R2R.Server.Base.Exceptions;
using AMAT.R2R.Server.Base.Extensions;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;

namespace AMAT.R2R.Server.Base
{
    public class ErrorHandlingMiddleware
    {
        private readonly RequestDelegate _next;
        private readonly ILogger _logger;
        public ErrorHandlingMiddleware(RequestDelegate next, ILogger<ErrorHandlingMiddleware> logger)
        {
            _next = next;
            _logger = logger;
        }

        public async Task Invoke(HttpContext context /* other dependencies */)
        {
            try
            {
                Console.WriteLine();
                Console.WriteLine($"===============BEGIN================ {DateTime.Now:yyyy-MM-dd HH:mm:ss fff}");
                await _next(context);
            }
            catch (Exception ex)
            {
                await HandleExceptionAsync(context, ex, _logger);
            }
            finally
            {
                Console.WriteLine($"================END================= {DateTime.Now:yyyy-MM-dd HH:mm:ss fff}");
            }
        }

        private static Task HandleExceptionAsync(HttpContext context, Exception ex, ILogger logger)
        {
            var code = HttpStatusCode.InternalServerError; // 500 if unexpected
            string content;
            if (ex is ErrorCodeException ece)
            {
                switch (ece.ErrorCode)
                {
                    case (int)GeneralErrorCode.DBNotAvailable:
                        code = HttpStatusCode.ServiceUnavailable;
                        break;
                    case (int)GeneralErrorCode.ResourceNotFound:
                        code = HttpStatusCode.NotFound;
                        break;
                    case (int)GeneralErrorCode.UserNameAndPasswordCanNotBeEmpty:
                    case (int)GeneralErrorCode.WrongPassword:
                        code = HttpStatusCode.Unauthorized;
                        break;
                    default:
                        code = HttpStatusCode.BadRequest;
                        break;
                }
                content = JsonConvert.SerializeObject(new { ece.ErrorCode, ece.Message });
            }
            else
            {
                // log unexpected error.
                logger?.LogError(ex, nameof(GeneralErrorCode.UnexpectedError));

                var innerest = ex.GetInnerestException();

                content = JsonConvert.SerializeObject(new { ErrorCode = GeneralErrorCode.UnexpectedError, Message = $"{innerest.GetType().Name}\n{innerest.Message}\n{innerest.StackTrace}" });
            }

            context.Response.ContentType = "application/json";
            context.Response.StatusCode = (int)code;

            return context.Response.WriteAsync(content);
        }
    }
}
