﻿using System.ComponentModel;
using DevExpress.Mvvm.ModuleInjection;

namespace AMAT.R2R.Client.Common.ViewModels
{
    public interface IViewModelLifeCycleAware
    {
        void OnCreated(ViewModelCreatedEventArgs e);
        void OnRemoving(CancelEventArgs ee);
        void OnRemoved(ViewModelRemovedEventArgs e);
    }
}
