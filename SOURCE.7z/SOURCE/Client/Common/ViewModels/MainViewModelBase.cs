﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Deployment.Application;
using System.Diagnostics;
using System.Linq;
using System.Windows.Media;
using AMAT.R2R.Client.Common.Constants;
using AMAT.R2R.Client.Common.Helpers;
using AMAT.R2R.Client.Common.Messages;
using AMAT.R2R.Client.Common.Models;
using AMAT.R2R.Client.Common.Services;
using AMAT.R2R.Client.Common.ViewModels;
using AMAT.R2R.Client.Common.Views;
using DevExpress.Mvvm;
using DevExpress.Mvvm.DataAnnotations;
using DevExpress.Mvvm.ModuleInjection;
using DevExpress.Mvvm.POCO;
using DevExpress.Xpf.Core;

namespace AMAT.R2R.Client.Common.ViewModels
{
    public abstract class MainViewModelBase : SuperViewModel
    {
        public MainViewModelBase()
        {
            SetupEventHandlers();

            RegisterServices();

            SetStatusBarInfo();

            BuildNavigationMenu();

            HasTxnInProgress = false;

            IsMaximized = false;
        }
        protected override void OnViewReadyAsync()
        {
        }

        protected override void OnViewActivated()
        {
            BuildNavigationMenu();

            Messenger.Default.Send(new WaitMessage(WaitMode.HideAll, "MainWindow"));

            try
            {
            }
            catch (Exception ex)
            {
                ErrorHandler.HandleError(ex);
            }
        }


        private readonly List<ApiStartedMessage> _apiStartedMessageList = new List<ApiStartedMessage>();

        protected abstract void RegisterServices();

        protected virtual void SetupEventHandlers()
        {
            ModuleManager.GetEvents(RegionNames.Documents).Navigation += OnDocumentsNavigation;
            ModuleManager.GetEvents(RegionNames.Documents).ViewModelCreated += MainViewModel_ViewModelCreated;
            ModuleManager.GetEvents(RegionNames.Documents).ViewModelRemoving += MainViewModel_ViewModelRemoving;
            ModuleManager.GetEvents(RegionNames.Documents).ViewModelRemoved += MainViewModelBase_ViewModelRemoved;

            Messenger.Default.Register<ApiStartedMessage>(this, OnApiStarted);
            Messenger.Default.Register<ApiCompletedMessage>(this, OnApiCompleted);
            Messenger.Default.Register<LoginMessage>(this, OnUserLogIn);

            PropertyChanged += MainViewModel_PropertyChanged;
        }
        private void MainViewModel_PropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            if (e.PropertyName == nameof(IsMaximized))
            {
                IsRestored = !IsMaximized;
                IsShowNavigationMenu = IsRestored;
                IsRibbonSimplified = IsMaximized;
            }
            else if (e.PropertyName == nameof(IsRestored))
            {
                IsMaximized = !IsRestored;
            }
            else
            { }
            IsHomeSelected = true;
        }

        private void MainViewModel_ViewModelCreated(object sender, ViewModelCreatedEventArgs e)
        {
            if (e.ViewModel is IViewModelLifeCycleAware vm)
            {
                vm.OnCreated(e);
            }
        }

        private void MainViewModelBase_ViewModelRemoved(object sender, ViewModelRemovedEventArgs e)
        {
            if (e.ViewModel is IViewModelLifeCycleAware vm)
            {
                vm.OnRemoved(e);
            }

            if (ModuleManager.GetRegion(RegionNames.Main).SelectedViewModel == this)
            {
                SelectedFunction = null;
            }
        }

        private void MainViewModel_ViewModelRemoving(object sender, ViewModelRemovingEventArgs e)
        {
            if (e.ViewModel is IViewModelLifeCycleAware vm)
            {
                vm.OnRemoving(e);
            }
        }

        private void OnDocumentsNavigation(object sender, NavigationEventArgs e)
        {
            if (e.NewViewModel == null) return;
            var newFunctionName = e.NewViewModel.GetType().Name;

            if (SelectedFunction == null || newFunctionName != $"{SelectedFunction.FunctionType}ViewModel")
            {
                foreach (var group in NavGroups)
                {
                    if (group.SubItems != null)
                    {
                        foreach (var item in group.SubItems)
                        {
                            if (newFunctionName == $"{item.FunctionType}ViewModel")
                            {
                                SelectedFunction = item;
                                break;
                            }
                        }
                    }
                }
            }
        }

        private void OnApiStarted(ApiStartedMessage msg)
        {
            lock (_apiStartedMessageList)
            {
                _apiStartedMessageList.Add(msg);
                HasTxnInProgress = _apiStartedMessageList.Count(m => !m.IsQuery) > 0;
                Status = $"{msg.Method} {msg.ResourceUrl}";
            }
        }

        private void OnApiCompleted(ApiCompletedMessage msg)
        {
            lock (_apiStartedMessageList)
            {
                _apiStartedMessageList.RemoveAll(m => m.TxnId == msg.TxnId);

                if (_apiStartedMessageList.Count > 0)
                {
                    HasTxnInProgress = _apiStartedMessageList.Count(m => !m.IsQuery) > 0;
                    var lastMessage = _apiStartedMessageList.LastOrDefault();
                    Status = $"{lastMessage.Method} {lastMessage.ResourceUrl}";
                }
                else
                {
                    Status = "Ready.";
                }
            }
        }
        private void OnUserLogIn(LoginMessage msg)
        {
            SetStatusBarInfo();
            HasTxnInProgress = false;
        }

        private void SetStatusBarInfo()
        {
            ServerInfo = $"{ClientInfo.ApiAddress}";
            ServerVersion = $"{ClientInfo.ServerVersion}";
            DBInfo = $"{ClientInfo.DBInfo}";
            UserInfo = $"{ClientInfo.UserName}";
            EnvInfo = $"{ClientInfo.LoginEnv}";
            FabInfo = ClientInfo.LoginFab;
            AreaInfo = ClientInfo.LoginArea;
            Status = "Ready.";

            ClientVersionInfo = VersionHelper.ProductVersion;
        }

        protected abstract void BuildNavigationMenu();

        public ImageSource SetIcon(string uri)
        {
            var extension = new SvgImageSourceExtension() { Uri = new Uri(uri, UriKind.RelativeOrAbsolute) };
            return (ImageSource)extension.ProvideValue(null);
        }


        [Command]
        public void NavigateTo(string viewName)
        {
            ModuleManager.RegisterOrInjectOrNavigate(RegionNames.Documents, new Module(viewName, $"{viewName}ViewModel", viewName));
        }

        [Command]
        public void LogOut()
        {
            ModuleManager.Clear(RegionNames.Documents);
            ModuleManager.Navigate(RegionNames.Main, "LoginView");
        }

        public bool CanLogOut()
        {
            return true;
        }

        [Command]
        public void Exit()
        {
            GetService<ICurrentWindowService>()?.Close();
        }

        public bool CanExit()
        {
            return true;
        }

        [Command]
        public void ShowAbout()
        {
            ShowPopup("AboutWindow", new AboutWindowViewModel());
        }


        #region Properties
        public bool IsMaximized
        {
            get { return GetValue<bool>(); }
            set { SetValue(value); }
        }
        public bool IsRestored
        {
            get { return GetValue<bool>(); }
            set { SetValue(value); }
        }


        public bool IsShowNavigationMenu
        {
            get { return GetValue<bool>(); }
            set { SetValue(value); }
        }


        public bool IsRibbonSimplified
        {
            get { return GetValue<bool>(); }
            set { SetValue(value); }
        }
        public bool IsHomeSelected
        {
            get { return GetValue<bool>(); }
            set { SetValue(value); }
        }

        public string Status
        {
            get { return GetValue<string>(); }
            set { SetValue(value); }
        }


        public bool HasTxnInProgress
        {
            get { return GetValue<bool>(); }
            set { SetValue(value); }
        }

        public ReadOnlyCollection<NavigationGroupModel> NavGroups
        {
            get { return GetValue<ReadOnlyCollection<NavigationGroupModel>>(); }
            set { SetValue(value); }
        }

        public NavigationModel SelectedFunction
        {
            get { return GetValue<NavigationModel>(); }
            set { SetValue(value); }
        }

        public string AssemblyVersionInfo
        {
            get { return GetValue<string>(); }
            set { SetValue(value); }
        }
        public string ClientVersionInfo
        {
            get { return GetValue<string>(); }
            set { SetValue(value); }
        }

        public string ServerInfo
        {
            get { return GetValue<string>(); }
            set { SetValue(value); }
        }

        public string ServerVersion
        {
            get { return GetValue<string>(); }
            set { SetValue(value); }
        }

        public string DBInfo
        {
            get { return GetValue<string>(); }
            set { SetValue(value); }
        }

        public string UserInfo
        {
            get { return GetValue<string>(); }
            set { SetValue(value); }
        }
        public string EnvInfo
        {
            get { return GetValue<string>(); }
            set { SetValue(value); }
        }
        public string FabInfo
        {
            get { return GetValue<string>(); }
            set { SetValue(value); }
        }

        public string AreaInfo
        {
            get { return GetValue<string>(); }
            set { SetValue(value); }
        }


        #endregion
    }
}
