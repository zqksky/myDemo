﻿
using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows;
using AMAT.R2R.Client.Common.Enums;
using AMAT.R2R.Client.Common.Helpers;
using AMAT.R2R.Client.Common.Interfaces;
using AMAT.R2R.Client.Common.Messages;
using AMAT.R2R.Client.Common.Services;
using AMAT.R2R.Client.Common.Views;
using AMAT.R2R.Shared.Base.DTO;
using DevExpress.Mvvm;
using DevExpress.Mvvm.DataAnnotations;
using DevExpress.Mvvm.ModuleInjection;

namespace AMAT.R2R.Client.Common.ViewModels
{
    public abstract class SuperViewModel : ViewModelBase, IDocumentModule, INotifyDataErrorInfo, IViewModelLifeCycleAware
    {
        public SuperViewModel()
        {
            AllowClose = true;
            WindowHeight = 720;
            WindowWidth = 1400;
            SizeToContent = SizeToContent.WidthAndHeight;
            Messenger.Default.Register<WaitMessage>(this, OnWaitMessage);
        }

        private bool _isLoaded = false;
        public void Loaded()
        {
            if (!_isLoaded)
            {
                _isLoaded = true;
                OnViewReadyAsync();
            }
            OnViewActivated();
        }

        protected virtual void OnViewActivated()
        {

        }

        protected abstract void OnViewReadyAsync();

        #region IDocumentModule Members

        public string Caption
        {
            get { return GetValue<string>(); }
            set { SetValue(value); }
        }
        public bool IsActive
        {
            get { return GetValue<bool>(); }
            set { SetValue(value); }
        }

        public string Icon
        {
            get { return GetValue<string>(); }
            set { SetValue(value); }
        }

        public double WindowHeight
        {
            get { return GetValue<double>(); }
            set { SetValue(value); }
        }

        public double WindowWidth
        {
            get { return GetValue<double>(); }
            set { SetValue(value); }
        }

        public bool AllowClose
        {
            get { return GetValue<bool>(); }
            set { SetValue(value); }
        }

        #endregion

        public bool IsDirty
        {
            get { return GetValue<bool>(); }
            set { SetValue(value); }
        }

        public FunctionMode Mode
        {
            get { return GetValue<FunctionMode>(); }
            set { SetValue(value); }
        }

        public SizeToContent SizeToContent
        {
            get { return GetValue<SizeToContent>(); }
            set { SetValue(value); }
        }

        public bool IsOK { get; protected set; }

        protected IModuleManager ModuleManager { get { return DevExpress.Mvvm.ModuleInjection.ModuleManager.DefaultManager; } }
        public IMessageBoxService MessageBoxService { get { return GetService<IMessageBoxService>(); } }
        protected IDialogService DialogService { get { return GetService<IDialogService>(); } }
        protected ICurrentDialogService CurrentDialogService { get { return GetService<ICurrentDialogService>(); } }
        protected ISaveFileDialogService SaveFileDialogService { get { return GetService<ISaveFileDialogService>(); } }
        protected IOpenFileDialogService OpenFileDialogService { get { return GetService<IOpenFileDialogService>(); } }
        protected ISplashScreenManagerService WaitIndicatorSplashManager { get { return GetService<ISplashScreenManagerService>("WaitIndicatorSplashScreenService"); } }
        protected IDispatcherHelperService DispatcherHelperService { get { return GetService<IDispatcherHelperService>(); } }
        protected IWindowService WindowService { get { return GetService<IWindowService>(); } }

        protected IErrorHandler ErrorHandler { get { return ServiceContainer.GetService<IErrorHandler>(); } }
        protected ILocalizationService LocalizationService { get { return ServiceContainer.GetService<ILocalizationService>(); } }

        public T ShowPopup<T>(string viewName, T viewModel) where T : ISupportParentViewModel
        {
            if (WindowService == null)
            {
                throw new InvalidOperationException("WindowService is null. Make sure the parent view has WindowService.");
            }
            WindowService?.Show(viewName, viewModel);
            return viewModel;
        }

        #region Confirm
        public bool IsConfirmed(out string comment, string confirmContent = "")
        {
            var vm = ShowPopup("Confirm", new ConfirmViewModel(confirmContent));
            comment = vm.Comment;
            return vm.IsOK;
        }
        #endregion

        #region CurrentWindowService
        [Command]
        public virtual void CloseWindow()
        {
            CurrentWindowService?.Close();
        }

        public ICurrentWindowService CurrentWindowService { get { return GetService<ICurrentWindowService>(); } }
        #endregion

        #region ViewService
        protected IViewService ViewService { get { return GetService<IViewService>(); } }

        protected void SetFocus(string path)
        {
            var viewService = GetService<IViewService>();
            viewService?.SetFocus(path);
        }

        protected void SetFocus(object dataContext, string path)
        {
            ViewService?.SetFocus(dataContext, path);
        }
        #endregion

        #region INotifyDataErrorInfo members

        private readonly Dictionary<string, ICollection<string>>
        _validationErrors = new Dictionary<string, ICollection<string>>();


        public event EventHandler<DataErrorsChangedEventArgs> ErrorsChanged;

        protected virtual void RaiseErrorsChanged(string propertyName)
        {
            ErrorsChanged?.Invoke(this, new DataErrorsChangedEventArgs(propertyName));
        }

        public bool HasErrors
        {
            get { return _validationErrors.Count > 0; }
        }

        public IEnumerable GetErrors(string fieldName)
        {
            if (string.IsNullOrEmpty(fieldName)
                || !_validationErrors.ContainsKey(fieldName))
                return null;

            return _validationErrors[fieldName];
        }

        #endregion INotifyDataErrorInfo members

        #region Validation Methods
        protected void SetError(string propertyName, string error)
        {
            if (string.IsNullOrEmpty(propertyName))
            {
                throw new ArgumentNullException(nameof(propertyName));
            }

            _validationErrors[propertyName] = new List<string>() { error };

            RaiseErrorsChanged(propertyName);
        }

        protected void ClearError(string propertyName = "")
        {
            var properties = _validationErrors.Keys.ToList();
            if (string.IsNullOrEmpty(propertyName))
            {
                _validationErrors.Clear();
                foreach (var p in properties)
                {
                    RaiseErrorsChanged(p);
                }
            }
            else if (_validationErrors.ContainsKey(propertyName))
            {
                _validationErrors.Remove(propertyName);
                RaiseErrorsChanged(propertyName);
            }
            else { }
        }

        protected bool HasErrorWithProperty(string propertyName)
        {
            if (string.IsNullOrEmpty(propertyName))
            {
                return false;
            }
            else
            {
                ValidateProperty(propertyName);
                return _validationErrors.ContainsKey(propertyName);
            }
        }

        protected void ValidateProperty(string propertyName)
        {
            var error = GetError(propertyName);
            if (string.IsNullOrEmpty(error))
            {
                ClearError(propertyName);
            }
            else
            {
                SetError(propertyName, error);
            }
        }

        protected virtual string GetError(string columnName)
        {
            return string.Empty;
        }

        protected void ValidateAndSetErrorFocus(params string[] properties)
        {
            if (properties == null)
            {
                return;
            }
            _validationErrors?.Clear();
            string errorProperty = null;

            foreach (var property in properties)
            {
                if (HasErrorWithProperty(property))
                {
                    errorProperty = property;
                    break;
                }
            }

            SetFocus(errorProperty);
        }
        #endregion


        private void OnWaitMessage(WaitMessage waitMessage)
        {
            // if current view doesn't have WaitIndicatorSplashManager, return directly.
            if (WaitIndicatorSplashManager == null) return;

            if (waitMessage.WaitArea == GetType().Name || waitMessage.Mode == WaitMode.HideAll)
            {
                if (waitMessage.Mode == WaitMode.Show)
                {
                    if (WaitIndicatorSplashManager.ViewModel != null)
                    {
                        WaitIndicatorSplashManager.ViewModel.Status = waitMessage.WaitText;
                    }
                    else
                    {
                        WaitIndicatorSplashManager.ViewModel = new DXSplashScreenViewModel()
                        {
                            Status = waitMessage.WaitText,
                        };
                    }
                    WaitIndicatorSplashManager.Show();
                }
                else
                {
                    WaitIndicatorSplashManager.Close();
                }
            }
        }

        public bool IsLoading
        {
            get { return GetValue<bool>(); }
            set { SetValue(value); }
        }

        public bool IsHistoryLoading
        {
            get { return GetValue<bool>(); }
            set { SetValue(value); }
        }


        public ObservableCollection<TransactionHistory> HistoryList
        {
            get { return GetValue<ObservableCollection<TransactionHistory>>(); }
            set { SetValue(value); }
        }

        public void ShowWait()
        {
            // if current view doesn't have WaitIndicatorSplashManager, return directly.
            if (WaitIndicatorSplashManager == null) return;

            Console.WriteLine("Showing Wait...");
            Messenger.Default.Send(new WaitMessage(WaitMode.Show, GetType().Name));
        }

        public void HideWait()
        {
            // if current view doesn't have WaitIndicatorSplashManager, return directly.
            if (WaitIndicatorSplashManager == null) return;
            Console.WriteLine("Hiding Wait...");
            Messenger.Default.Send(new WaitMessage(WaitMode.Hide, GetType().Name));
            IsLoading = false;
        }


        /// <summary>
        /// This command method is used for CurrentWindowService.ClosingCommand, which will prompt 
        /// </summary>
        /// <param name="e"></param>
        [Command]
        public void Closing(CancelEventArgs e)
        {
            OnRemoving(e);
        }
        public virtual void OnCreated(ViewModelCreatedEventArgs e)
        {
        }

        /// <summary>
        /// This method will be triggered either by the CurrentWindowService.Closingcommand or by the MIF's ViewModelRemoving event for Documents Region.
        /// </summary>
        /// <param name="e"></param>
        public virtual void OnRemoving(CancelEventArgs e)
        {
            // only prompt if IsDirty. 
            if (IsDirty)
            {
                if (MessageBoxService.ShowMessage($"Abandon unsaved changes?",
                                                 "Confirm Close",
                                                 MessageButton.YesNo,
                                                 MessageIcon.Question) == MessageResult.No)
                {
                    e.Cancel = true;
                }
            }

        }

        public virtual void OnRemoved(ViewModelRemovedEventArgs args)
        {
            Messenger.Default.Unregister<WaitMessage>(this, OnWaitMessage);
        }
    }
}
