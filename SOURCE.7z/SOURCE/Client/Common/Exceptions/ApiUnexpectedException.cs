﻿using System;
using System.Runtime.Serialization;

namespace AMAT.R2R.Client.Common.Exceptions
{
    [Serializable]
    internal class ApiUnexpectedException : Exception
    {
        public ApiUnexpectedException()
        {
        }

        public ApiUnexpectedException(string message) : base(message)
        {
        }

        public ApiUnexpectedException(string message, Exception innerException) : base(message, innerException)
        {
        }

        protected ApiUnexpectedException(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}
