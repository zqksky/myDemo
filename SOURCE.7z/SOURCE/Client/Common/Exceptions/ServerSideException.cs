﻿using System;
using System.Runtime.Serialization;

namespace AMAT.R2R.Client.Common.Exceptions
{
    [Serializable]
    internal class ServerSideException : Exception
    {
        public int ErrorCode
        {
            get; private set;
        }

        public ServerSideException(int code, string message) : base(message)
        {
            ErrorCode = code;
        }

        public ServerSideException(int code, string message, Exception innerException) : base(message, innerException)
        {
            ErrorCode = code;
        }

        protected ServerSideException(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}
