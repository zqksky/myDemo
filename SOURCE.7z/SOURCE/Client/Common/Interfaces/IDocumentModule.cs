﻿namespace AMAT.R2R.Client.Common.Interfaces
{
    public interface IDocumentModule
    {
        string Caption { get; }
        bool IsActive { get; set; }
    }
}
