﻿using System;
using System.Runtime.Serialization;
using System.Text;
using System.Web;
using AMAT.R2R.Client.Common.Exceptions;
using AMAT.R2R.Client.Common.Helpers;
using AMAT.R2R.Client.Common.Services;
using AMAT.R2R.Shared.Base.Constants;
using DevExpress.Utils.OAuth.Provider;
using Newtonsoft.Json;
using RestSharp;

namespace AMAT.R2R.Client.Common.Extensions
{
    public static class RequestExtensions
    {
        public static IRestRequest AddR2RHeaders(this IRestRequest request, string token)
        {
            return request?.AddHeader(HeaderKeys.SessionId, ClientInfo.SessionId)
                    .AddHeader(HeaderKeys.Fab, ClientInfo.LoginFab)
                    .AddHeader(HeaderKeys.Area, ClientInfo.LoginArea)
                    .AddHeader(HeaderKeys.UserName, ClientInfo.UserName)
                    .AddHeader(HeaderKeys.SessionId, ClientInfo.SessionId)
                    .AddHeader(HeaderKeys.ClientMachineName, Environment.MachineName)
                    .AddHeader(HeaderKeys.ClientProcessId, System.Diagnostics.Process.GetCurrentProcess().Id.ToString())
                    .AddHeader(HeaderKeys.ClientVersion, VersionHelper.ProductVersion)
                    .AddHeader(HeaderKeys.Authorization, "Bearer " + token);
        }
        public static IRestRequest AddR2RHeaders(this IRestRequest request, string token, string txnId, string comment)
        {
            return request?
                .AddR2RHeaders(token)
                .AddHeader(HeaderKeys.TxnId, txnId)
                .AddHeader(HeaderKeys.Comment, HttpUtility.UrlEncode(comment, Encoding.UTF8));
        }
    }
}
