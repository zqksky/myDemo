﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Web;
using AMAT.R2R.Client.Common.Exceptions;
using AMAT.R2R.Client.Common.Services;
using DevExpress.Utils.OAuth.Provider;
using Newtonsoft.Json;
using RestSharp;

namespace AMAT.R2R.Client.Common.Extensions
{
    public static class StringExtensions
    {
        public static T ToEnum<T>(this string enumString)
        {
            return (T)Enum.Parse(typeof(T), enumString);
        }

        public static List<string> SplitToList(this string str, string separators = ",", StringSplitOptions options = StringSplitOptions.RemoveEmptyEntries, bool trimWhiteSpace = true)
        {
            if (separators is null)
            {
                throw new ArgumentNullException(nameof(separators));
            }

            if (string.IsNullOrEmpty(str))
            {
                return new List<string>();
            }
            else
            {
                var splits = str.Split(separators.ToCharArray(), options).ToList();
                if (options == StringSplitOptions.RemoveEmptyEntries && trimWhiteSpace)
                {
                    splits = splits.Where(s => !string.IsNullOrWhiteSpace(s)).ToList();
                }

                if (trimWhiteSpace)
                {
                    splits = splits.Select(s => s.Trim()).ToList();
                }

                return splits;
            }
        }

        public static bool EqualsIgnoreCase(this string str1, string str2)
        {
            return string.Compare(str1, str2, true) == 0;
        }

        public static string EscapeUrlChar(this string str)
        {
            return str?.Replace("%", "%25").Replace("+", "%2B").Replace(" ", "%20").Replace("/", "%2F").Replace("?", "%3F").Replace("#", "%23").Replace("&", "%26").Replace("=", "%3D");
        }
    }
}
