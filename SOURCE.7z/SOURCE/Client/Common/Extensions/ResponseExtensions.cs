﻿using System;
using System.Runtime.Serialization;
using System.Web;
using AMAT.R2R.Client.Common.Exceptions;
using AMAT.R2R.Client.Common.Helpers;
using AMAT.R2R.Client.Common.Services;
using DevExpress.Utils.OAuth.Provider;
using Newtonsoft.Json;
using RestSharp;

namespace AMAT.R2R.Client.Common.Extensions
{
    public static class ResponseExtensions
    {
        public static Exception ToException(this IRestResponse response)
        {
            return ResponseToException(response);
        }

        public static Exception ResponseToException(IRestResponse response)
        {
            try
            {
                var errorResult = JsonConvert.DeserializeObject<ErrorResult>(response.Content);
                if (errorResult != null)
                {
                    return new ServerSideException(errorResult.ErrorCode, errorResult.Message);
                }
                else
                {
                    if (response.ResponseStatus != ResponseStatus.Completed)
                    {
                        var errorMessage = response.ErrorException == null ? response.ErrorMessage : response.ErrorException.GetInnerestException().Message;

                        return new HttpException((int)response.StatusCode, errorMessage);
                    }
                    else
                    {
                        return new ServerSideException(-1, string.IsNullOrEmpty(response.Content) ? response.StatusDescription : response.Content);
                    }
                }
            }
            catch (Exception)
            {
                return new ServerSideException(-1, response.Content);
            }
        }
    }
}
