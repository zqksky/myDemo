﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using AMAT.R2R.Client.Common.Helpers;
using DevExpress.Xpf.Bars;

namespace AMAT.R2R.Client.Common.Views
{
    /// <summary>
    /// Interaction logic for RecentHistory.xaml
    /// </summary>
    public partial class RecentHistory : UserControl
    {
        public RecentHistory()
        {
            InitializeComponent();
        }
        private void Export_ItemClick(object sender, DevExpress.Xpf.Bars.ItemClickEventArgs e)
        {
            var button = sender as BarButtonItem;
            var format = button.Content.ToString().Substring(10);

            switch (format)
            {
                case "XLSX":
                    DataAwareExportHelper.ExportToXlsx(view);
                    break;

                case "CSV":
                    WYSIWYGExportHelper.DoExport(view, DevExpress.XtraPrinting.ExportFormat.Csv);
                    break;

                default:
                    WYSIWYGExportHelper.DoExport(view, DevExpress.XtraPrinting.ExportFormat.Txt);
                    break;
            }
        }
    }
}
