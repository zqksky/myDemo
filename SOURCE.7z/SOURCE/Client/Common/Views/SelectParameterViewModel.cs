﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using AMAT.R2R.Client.Common.ViewModels;
using AMAT.R2R.Shared.Base.DTO;
using DevExpress.Mvvm;
using DevExpress.Mvvm.DataAnnotations;

namespace AMAT.R2R.Client.Common.Views
{
    public class SelectParameterViewModel : SuperViewModel
    {
        public SelectParameterViewModel()
        {
            SizeToContent = System.Windows.SizeToContent.WidthAndHeight;
            Caption = "Select Parameter";
            IsDirty = false;
        }

        protected override void OnViewReadyAsync()
        {
            //ParameterList = new ObservableCollection<Parameter>(MetroParameterService.GetMetroParameterList());
        }

        public ObservableCollection<Parameter> ParameterList
        {
            get { return GetValue<ObservableCollection<Parameter>>(); }
            set { SetValue(value); }
        }

        public Parameter SelectedParameter
        {
            get { return GetValue<Parameter>(); }
            set { SetValue(value); }
        }


        [Command]
        public void Select()
        {
            IsOK = true;
            CloseWindow();
        }

        public bool CanSelect()
        {
            return SelectedParameter != null;
        }

    }
}
