﻿using System;
using System.ServiceModel.Channels;
using AMAT.R2R.Client.Common.Helpers;
using AMAT.R2R.Client.Common.ViewModels;
using DevExpress.Mvvm;
using DevExpress.Mvvm.DataAnnotations;
using DevExpress.Mvvm.POCO;

namespace AMAT.R2R.Client.Common.Views
{
    public class ConfirmViewModel : SuperViewModel
    {
        public ConfirmViewModel(string confirmContent = "")
        {
            Caption = string.IsNullOrEmpty(confirmContent) ? "Please Confirm" : $"Please Confirm: {confirmContent}";
            Password = string.Empty;
        }
        protected override void OnViewReadyAsync()
        {
        }

        public string Comment
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(Comment));
            }
        }

        public string Password
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(Password));
            }
        }

        protected override string GetError(string fieldName)
        {
            switch (fieldName)
            {
                case nameof(Password):
                    return ClientInfo.CheckLoginPassword(Password) ? null : Properties.Resources.ERR_IncorrectPassword;
                case nameof(Comment):
                    return DataValidator.UTF8StringMaxLength(Comment, 1024);
                default:
                    return null;
            }
        }

        [Command]
        public void OK()
        {
            ValidateAndSetErrorFocus(nameof(Comment), nameof(Password));
            if (!HasErrors)
            {
                IsOK = true;
                CloseWindow();
            }
            else
            {
                if (HasErrorWithProperty(nameof(Password)))
                {
                    MessageBoxService.ShowMessage("Please enter password again!", "Incorrect password!", MessageButton.OK, MessageIcon.Warning);
                }
                return;
            }
        }

        public bool CanOK()
        {
            return !string.IsNullOrEmpty(Comment);
        }

        [Command]
        public void Cancel()
        {
            CloseWindow();
        }

    }
}
