﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using DevExpress.Mvvm;
using DevExpress.Xpf.Core;
using DevExpress.Xpf.Core.Native;
using DevExpress.Xpf.Grid;

namespace AMAT.R2R.Client.Common.Views
{
    /// <summary>
    /// Interaction logic for MessageWindow.xaml
    /// </summary>
    public partial class MessageWindow : ThemedWindow
    {
        public MessageWindow(string messageBoxText, string caption, MessageButton button, MessageIcon icon, MessageResult defaultResult)
        {
            InitializeComponent();
            Title = caption;
            tbMessage.Text = messageBoxText;

            Result = defaultResult;

            btnCopy.Visibility = Visibility.Collapsed;

            var imageSourceUri = @"SvgImages/XAF/State_Validation_Information.svg";
            switch ((int)icon)
            {
                case 0: // MessageIcon.None
                    break;
                case 1: // MessageIcon.Error, MessageIcon.Hand, MessageIcon.Stop
                    HeaderBackground = Brushes.Red;
                    //btnCopy.Visibility = Visibility.Visible;
                    imageSourceUri = "SvgImages/Outlook Inspired/Cancel.svg";
                    break;
                case 2: // MessageIcon.Question
                    HeaderBackground = Brushes.Orange;
                    imageSourceUri = "SvgImages/Icon Builder/Actions_Question.svg";
                    break;
                case 3: // MessageIcon.Warning, MessageIcon.Exclamation
                    HeaderBackground = Brushes.Orange;
                    break;
                case 4: // MessageIcon.Information, MessageIcon.Asterisk
                    HeaderBackground = Application.Current.Resources["OfficeBlue"] as Brush;
                    imageSourceUri = "SvgImages/Outlook Inspired/MarkComplete.svg";
                    break;
                default:
                    break;
            }

            //Icon = WpfSvgRenderer.CreateImageSource(DXImageHelper.GetImageUri(imageSourceUri));
            image.Source = WpfSvgRenderer.CreateImageSource(DXImageHelper.GetImageUri(imageSourceUri));
            switch (button)
            {
                case MessageButton.OK:
                    btnOK.Visibility = Visibility.Visible;
                    btnCancel.Visibility = Visibility.Collapsed;
                    btnYes.Visibility = Visibility.Collapsed;
                    btnNo.Visibility = Visibility.Collapsed;
                    Result = MessageResult.OK;

                    if (defaultResult != MessageResult.OK)
                    {
                        defaultResult = MessageResult.OK;
                    }
                    break;
                case MessageButton.OKCancel:
                    btnOK.Visibility = Visibility.Visible;
                    btnCancel.Visibility = Visibility.Visible;
                    btnYes.Visibility = Visibility.Collapsed;
                    btnNo.Visibility = Visibility.Collapsed;

                    if (defaultResult != MessageResult.OK && defaultResult != MessageResult.Cancel)
                    {
                        defaultResult = MessageResult.OK;
                    }
                    break;
                case MessageButton.YesNoCancel:
                    btnOK.Visibility = Visibility.Collapsed;
                    btnCancel.Visibility = Visibility.Visible;
                    btnYes.Visibility = Visibility.Visible;
                    btnNo.Visibility = Visibility.Visible;

                    if (defaultResult != MessageResult.Yes && defaultResult != MessageResult.No && defaultResult != MessageResult.Cancel)
                    {
                        defaultResult = MessageResult.Yes;
                    }
                    break;
                case MessageButton.YesNo:
                    btnOK.Visibility = Visibility.Collapsed;
                    btnCancel.Visibility = Visibility.Collapsed;
                    btnYes.Visibility = Visibility.Visible;
                    btnNo.Visibility = Visibility.Visible;

                    if (defaultResult != MessageResult.Yes && defaultResult != MessageResult.No)
                    {
                        defaultResult = MessageResult.Yes;
                    }
                    break;
                default:
                    break;
            }

            Result = defaultResult;

            Loaded += MessageWindow_Loaded;
        }

        private void MessageWindow_Loaded(object sender, RoutedEventArgs e)
        {
            switch (Result)
            {
                case MessageResult.None:
                    break;
                case MessageResult.OK:
                    btnOK.Focus();
                    break;
                case MessageResult.Cancel:
                    btnCancel.Focus();
                    break;
                case MessageResult.Yes:
                    btnYes.Focus();
                    break;
                case MessageResult.No:
                    btnNo.Focus();
                    break;
                default:
                    break;
            }
        }

        public MessageResult Result { get; private set; }

        private void BtnCopy_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Clipboard.SetText(tbMessage.Text);
            }
            catch (Exception)
            {
            }
        }

        private void BtnYes_Click(object sender, RoutedEventArgs e)
        {
            Result = MessageResult.Yes;
            Close();
        }

        private void BtnNo_Click(object sender, RoutedEventArgs e)
        {
            Result = MessageResult.No;
            Close();
        }

        private void BtnOK_Click(object sender, RoutedEventArgs e)
        {
            Result = MessageResult.OK;
            Close();
        }

        private void BtnCancel_Click(object sender, RoutedEventArgs e)
        {
            Result = MessageResult.Cancel;
            Close();
        }
    }
}
