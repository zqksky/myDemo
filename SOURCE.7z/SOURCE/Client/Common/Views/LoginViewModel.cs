﻿using System;
using System.CodeDom;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Configuration;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Documents;
using AMAT.R2R.Client.Common.Constants;
using AMAT.R2R.Client.Common.Extensions;
using AMAT.R2R.Client.Common.Helpers;
using AMAT.R2R.Client.Common.Messages;
using AMAT.R2R.Client.Common.Services;
using AMAT.R2R.Shared.Base.DTO;
using AMAT.R2R.Shared.Etch.DTO;
using DevExpress.Mvvm;
using DevExpress.Mvvm.DataAnnotations;
using DevExpress.Mvvm.ModuleInjection;
using DevExpress.Mvvm.POCO;
using DevExpress.Mvvm.UI;
using DevExpress.Xpf.Core;
using RestSharp;
using Module = DevExpress.Mvvm.ModuleInjection.Module;

namespace AMAT.R2R.Client.Common.Views
{
    public class LoginViewModel : BindableBase
    {
        protected IModuleManager ModuleManager { get { return DevExpress.Mvvm.ModuleInjection.ModuleManager.DefaultManager; } }

        protected static LoginViewModel Instance;

        public static LoginViewModel Create()
        {
            if (Instance == null)
            {
                Instance = ViewModelSource.Create(() => new LoginViewModel());
            }
            return Instance;
        }

        protected LoginViewModel()
        {
            BackgroundImagePath = $"pack://application:,,,/Resources/{ConfigMan.GetString(ConfigKeys.AppSettingsSection, ConfigKeys.Background, "background.jpg")}";

            var userId = UserID;
            if (UserID != null && UserID.Contains("\\"))
            {
                var splits = UserID.SplitToList("\\");
                userId = splits.Count > 1 ? splits[1] : null;
            }

            UserID = userId;

            var config = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);
            var envGroup = config.SectionGroups[ConfigKeys.EnvironmentSectionGroup];

            if (envGroup != null)
            {
                EnvList = (from ConfigurationSection section in envGroup.Sections
                           select new EnvironmentConfig(section.SectionInformation.SectionName) into a
                           orderby a.Order
                           select a).ToList();
            }
            else
            {
                EnvList = new List<EnvironmentConfig>();
            }

            SelectedEnv = EnvList?.FirstOrDefault();
            SetDefault();

            PropertyChanged += LoginViewModel_PropertyChanged;

            //ThemeList = new List<ThemePalette>()
            //{
            //    new ThemePalette() {ThemeName = "Office2019Colorful", PaletteName = "Brickwork", PaletteBrush = "#B7472A" },
            //    new ThemePalette() {ThemeName = "Office2019Colorful", PaletteName = "CobaltBlue", PaletteBrush = "#36609F" },
            //    new ThemePalette() {ThemeName = "Office2019Colorful", PaletteName = "DarkLilac", PaletteBrush = "#80397B" },
            //    new ThemePalette() {ThemeName = "Office2019Colorful", PaletteName = "RedWine", PaletteBrush = "#A4373A" },
            //    new ThemePalette() {ThemeName = "Office2019Colorful", PaletteName = "SpruceLeaves", PaletteBrush = "#217346" },
            //    new ThemePalette() {ThemeName = "Office2019Colorful", PaletteName = "Turquoise", PaletteBrush = "#077568" },
            //    new ThemePalette() {ThemeName = "Office2019Colorful", PaletteName = "", PaletteBrush = "#FF0173C7" },
            //};
//#if DEBUG
//            SelectedDomain = "CNXA-DEV-27";
//            UserID = "R2R_USER1";
//            Password = "1qaz@WSX";
//#endif
        }

        private void LoginViewModel_PropertyChanged(object sender, System.ComponentModel.PropertyChangedEventArgs e)
        {
            if (e.PropertyName == nameof(SelectedEnv))
            {
                if (SelectedEnv != null)
                {
                    SetDefault();
                }
            }
            else if (e.PropertyName == nameof(UserID))
            {
                if (UserID.Contains("\\"))
                {
                    var splits = UserID.SplitToList("\\");

                    SelectedDomain = SelectedEnv.DomainList.FirstOrDefault(d => d.EqualsIgnoreCase(splits[0]));
                }
            }
            //else if (e.PropertyName == nameof(SelectedTheme))
            //{
            //    if (SelectedTheme != null)
            //    {
            //        ApplicationThemeHelper.ApplicationThemeName = SelectedTheme.PaletteName + SelectedTheme.ThemeName;
            //    }
            //}
            //else if (e.PropertyName == nameof(SelectedArea))
            //{
            //    switch (SelectedArea)
            //    {
            //        case "Etch":
            //            ApplicationThemeHelper.ApplicationThemeName = "Office2019Colorful";
            //            break;
            //        case "Litho":
            //            ApplicationThemeHelper.ApplicationThemeName = "RedWineOffice2019Colorful";
            //            break;
            //        case "CMP":
            //            ApplicationThemeHelper.ApplicationThemeName = "SpruceLeavesOffice2019Colorful";
            //            break;
            //        default:
            //            break;
            //    }
            //}
        }

        public void SetDefault()
        {
            SelectedFab = SelectedEnv?.FabList?.FirstOrDefault(f => f.FabName == SelectedEnv.DefaultFab);
            SelectedArea = SelectedFab?.AreaList?.FirstOrDefault(a => a == SelectedEnv.DefaultArea);
            SelectedDomain = SelectedEnv?.DomainList?.FirstOrDefault(d => d == SelectedEnv.DefaultDomain);

            UserID = string.Empty;
            Password = string.Empty;
        }


        [Command]
        public async void Login()
        {
            var userId = UserID;
            if (UserID.Contains("\\"))
            {
                var splits = UserID.SplitToList("\\");

                userId = splits.Count > 1 ? splits[1] : null;
            }

            if (string.IsNullOrEmpty(userId))
            {
                throw new ArgumentNullException(nameof(UserID), "Please input User ID.");
            }

            if (string.IsNullOrEmpty(SelectedDomain))
            {
                throw new ArgumentNullException(nameof(SelectedDomain), "Please select domain.");
            }

            LoginInfo loginInfo;

            var apiAddress = SelectedEnv.GetApiAddress(SelectedArea);
            try
            {
                Messenger.Default.Send(new WaitMessage(WaitMode.Show, "MainWindow", "Logging in..."));

                Api.Current = new ApiService(apiAddress);

                loginInfo = await Api.Current.PostNewAsync("token", new LoginInfo
                {
                    ClientVersion = "1.0.0.0",
                    LoginArea = SelectedArea,
                    LoginFab = SelectedFab.FabName,
                    LoginDomain = SelectedDomain,
                    UserName = userId,
                    Password = Password,
                    ProcessId = System.Diagnostics.Process.GetCurrentProcess().Id
                });

                Api.Current.SetToken(loginInfo.Token);

                AuthorityManager.SetupAuthorities(loginInfo.AuthorityList.Distinct());
            }
            finally
            {
            }

            await Task.Delay(10);
            Messenger.Default.Send(new WaitMessage(WaitMode.Show, "MainWindow", "Initializing..."));

            await Task.Delay(10);

            // Post Login.
            // send login message.
            Messenger.Default.Send(new LoginMessage()
            {
                LoginEnv = SelectedEnv.Name,
                LoginTime = loginInfo.LoginTime,
                LoginFab = loginInfo.LoginFab,
                LoginArea = loginInfo.LoginArea,
                LoginDomain = loginInfo.LoginDomain,
                UserName = loginInfo.UserName,
                Password = loginInfo.Password,
                SessionId = loginInfo.SessionId,
                ApiAddress = apiAddress,
                DBInfo = loginInfo.DBInfo,
                ServerVersion = loginInfo.ServerVersion
            });

            // clear password.
            Password = "";

            var assemblies = new[] { typeof(LoginViewModel).Assembly, Assembly.LoadFrom($"AMAT.R2R.Client.{SelectedArea}.dll") };

            ViewModelLocator.Default = new ViewModelLocator(assemblies);
            ViewLocator.Default = new ViewLocator(assemblies);

            ModuleManager.RegisterOrInjectOrNavigate(RegionNames.Main, new Module(SelectedArea, $"MainViewModel", "MainView"));
        }

        public bool CanLogin()
        {
            return SelectedEnv != null && SelectedFab != null && SelectedArea != null && SelectedDomain != null && !string.IsNullOrEmpty(UserID) && !string.IsNullOrEmpty(Password);
            //return !string.IsNullOrEmpty(UserID) && !string.IsNullOrEmpty(Password);
        }


        [Command]
        public void Exit()
        {
            var currentWindow = this.GetRequiredService<ICurrentWindowService>();
            currentWindow?.Close();
        }

        #region  Properties

        public string BackgroundImagePath
        {
            get { return GetValue<string>(); }
            set { SetValue(value); }
        }


        public List<EnvironmentConfig> EnvList
        {
            get { return GetValue<List<EnvironmentConfig>>(); }
            set { SetValue(value); }
        }

        public EnvironmentConfig SelectedEnv
        {
            get { return GetValue<EnvironmentConfig>(); }
            set { SetValue(value); }
        }

        public FabConfig SelectedFab
        {
            get { return GetValue<FabConfig>(); }
            set { SetValue(value); }
        }

        public string SelectedArea
        {
            get { return GetValue<string>(); }
            set { SetValue(value); }
        }

        public string SelectedDomain
        {
            get { return GetValue<string>(); }
            set { SetValue(value); }
        }

        public string UserID
        {
            get { return GetValue<string>(); }
            set { SetValue(value); }
        }

        public string Password
        {
            get { return GetValue<string>(); }
            set { SetValue(value); }
        }


        public List<ThemePalette> ThemeList
        {
            get { return GetValue<List<ThemePalette>>(); }
            set { SetValue(value); }
        }
        public ThemePalette SelectedTheme
        {
            get { return GetValue<ThemePalette>(); }
            set { SetValue(value); }
        }

        #endregion
    }

    public class EnvironmentConfig
    {
        public EnvironmentConfig(string sectionName)
        {
            SectionName = sectionName;
            Order = ConfigMan.GetInt32(sectionName, ConfigKeys.Order);
            Name = ConfigMan.GetString(sectionName, ConfigKeys.Name);

            ServerHost = ConfigMan.GetString(sectionName, ConfigKeys.ServerHost);
            Protocal = ConfigMan.GetBoolean(sectionName, ConfigKeys.UseSSL) ? "https" : "http";

            InitializeAreaPortMap(sectionName);

            FabList = ConfigMan.GetStringList(sectionName, ConfigKeys.FabList).Select(f => new FabConfig(sectionName, f)).ToList();
            DomainList = ConfigMan.GetStringList(SectionName, ConfigKeys.DomainList);
            DefaultFab = ConfigMan.GetString(sectionName, ConfigKeys.DefaultFab);
            DefaultArea = ConfigMan.GetString(sectionName, ConfigKeys.DefaultArea);
            DefaultDomain = ConfigMan.GetString(sectionName, ConfigKeys.DefaultDomain);
        }

        private void InitializeAreaPortMap(string sectionName)
        {
            AreaPortMap = new Dictionary<string, int>();
            var areaPortList = ConfigMan.GetStringList(sectionName, ConfigKeys.AreaPortMap);
            var validAreaList = areaPortList.Where(ap =>
            !string.IsNullOrWhiteSpace(ap) &&
            ap.Count(c => c == ':') == 1 &&
            !string.IsNullOrWhiteSpace(ap.Split(':')[1]) &&
            int.TryParse(ap.Split(':')[1], out var port) &&
            port > 0 &&
            port < 65536
            );

            foreach (var areaPort in areaPortList)
            {
                var key = areaPort.Split(':')[0];
                var value = int.Parse(areaPort.Split(':')[1]);
                AreaPortMap[key] = value;
            }
        }

        public int Order { get; set; }

        public string SectionName { get; set; }

        public string Name { get; set; }

        public Dictionary<string, int> AreaPortMap { get; set; }

        public string ServerHost { get; set; }

        public string Protocal { get; set; }

        public List<FabConfig> FabList { get; set; }

        public List<string> DomainList { get; set; }

        public string DefaultFab { get; set; }

        public string DefaultArea { get; set; }

        public string DefaultDomain { get; set; }

        public string GetApiAddress(string selectedArea)
        {
            if (selectedArea is null)
            {
                throw new ArgumentNullException(nameof(selectedArea));
            }

            if (!AreaPortMap.TryGetValue(selectedArea, out var portNumber))
            {
                portNumber = 80;
            }

            return $"{Protocal}://{ServerHost}:{portNumber}/api/";
        }
    }

    public class FabConfig
    {
        public FabConfig(string sectionName, string fabName)
        {
            FabName = fabName;
            AreaList = ConfigMan.GetStringList(sectionName, $"{fabName}.{ConfigKeys.AreaList}");
        }

        public string FabName { get; set; }

        public List<string> AreaList { get; set; }
    }


    public class ThemePalette
    {
        public string PaletteBrush { get; set; }

        public string ThemeName { get; set; }

        public string PaletteName { get; set; }
    }

}
