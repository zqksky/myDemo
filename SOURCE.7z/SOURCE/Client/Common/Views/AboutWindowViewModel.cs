﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Deployment.Application;
using System.Diagnostics;
using AMAT.R2R.Client.Common.Helpers;
using AMAT.R2R.Client.Common.ViewModels;
using AMAT.R2R.Shared.Base.DTO;
using DevExpress.Mvvm;
using DevExpress.Mvvm.DataAnnotations;

namespace AMAT.R2R.Client.Common.Views
{
    public class AboutWindowViewModel : SuperViewModel
    {
        public AboutWindowViewModel()
        {
            SizeToContent = System.Windows.SizeToContent.Manual;
            Caption = "About";
            ProductName = "Applied R2R Client";

            WindowWidth = 400;
            WindowHeight = 300;

            if (ApplicationDeployment.IsNetworkDeployed)
            {
                DeploymentVersion = ApplicationDeployment.CurrentDeployment?.CurrentVersion.ToString();
            }

            AssemblyVersion = VersionHelper.ProductVersion;
            ServerVersion = ClientInfo.ServerVersion;

        }
        protected override void OnViewReadyAsync()
        {

        }

        public string ProductName
        {
            get { return GetValue<string>(); }
            set { SetValue(value); }
        }


        public string DeploymentVersion
        {
            get { return GetValue<string>(); }
            set { SetValue(value); }
        }

        public string AssemblyVersion
        {
            get { return GetValue<string>(); }
            set { SetValue(value); }
        }
        public string ServerVersion
        {
            get { return GetValue<string>(); }
            set { SetValue(value); }
        }

    }
}
