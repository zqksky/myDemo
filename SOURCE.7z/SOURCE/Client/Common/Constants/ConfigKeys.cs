﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AMAT.R2R.Client.Common.Constants
{
    public class ConfigKeys
    {
        public const string AppSettingsSection = "appSettings";

        public const string UseMockService = "UseMockService";



        public const string Background = "Background";
        public const string Icon = "Icon";
        public const string EnvironmentSectionGroup = "environment";
        public const string ServerHost = "ServerHost";
        public const string UseSSL = "UseSSL";
        public const string AreaPortMap = "AreaPortMap";
        public const string Fab = "Fab";
        public const string Order = "Order";
        public const string Name = "Name";
        public const string FabList = "FabList";
        public const string AreaPortList = "AreaPortList";
        public const string AreaList = "AreaList";
        public const string DefaultFab = "DefaultFab";
        public const string DefaultArea = "DefaultArea";
        public const string DomainList = "DomainList";
        public const string DefaultDomain = "DefaultDomain";
    }
}
