﻿namespace AMAT.R2R.Client.Common.Constants
{
    public class RegexConst
    {
        public const string NormalId40 = @"[a-zA-Z0-9#\-_]{1,40}";
        public const string ToolIdRegex = @"[A-Z0-9#\-_]{1,40}";
        public const string NormalId255 = @"[a-zA-Z0-9#\-_]{1,255}";
        public const string NormalIdWithDot255 = @"[a-zA-Z0-9#\-_\.]{1,255}";
        public const string ZoneDefinitionRegex = @"(([1-9]{1}[0-9]*)|(([1-9]{1}[0-9]*)(,|-|(,?([1-9]{1}[0-9]*))|(-?([1-9]{1}[0-9]*)){1})*))"; // ??
        public const string DomainUserRegex = @"[a-zA-Z0-9\-_]{0,61}\\?[a-zA-Z0-9\-_]*";
    }
}
