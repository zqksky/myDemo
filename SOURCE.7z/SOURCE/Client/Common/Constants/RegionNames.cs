﻿namespace AMAT.R2R.Client.Common.Constants
{
    public class RegionNames
    {
        public const string Main = "Main";
        public const string Documents = "Documents";
        public const string Navigation = "Navigation";
        public const string Details = "Details";
    }
}
