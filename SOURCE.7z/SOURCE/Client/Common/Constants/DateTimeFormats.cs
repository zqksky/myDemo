﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AMAT.R2R.Client.Common.Constants
{
    public class DateTimeFormats
    {
        public const string OracleTimeStampFormat = "yyyy-MM-dd HH:mm:ss.ff";
        public const string OracleTimeStampFormatF6 = "yyyy-MM-dd HH:mm:ss.ffffff";
        public const string ClrDateTimeFormat = "yyyy/MM/dd HH:mm:ss";
        public const string ClrTimeStampFormat = "yyyy/MM/dd HH:mm:ss.fff";
        public const string DefaultTimeStampFormat = "yyyyMMdd HHmmssfff";
        public const string DefaultDateTimeFormat = "yyyyMMdd HHmmss";
        public const string NonSpaceDateTimeFormat = "yyyyMMddHHmmss";
    }
}
