﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Threading;
using AMAT.R2R.Client.Common.Helpers;
using DevExpress.Mvvm.UI.Interactivity;
using DevExpress.Xpf.Data;
using DevExpress.Xpf.Grid;

namespace AMAT.R2R.Client.Common.Behaviors
{
    public class GridControlBestFitBehavior : Behavior<GridControl>
    {
        protected override void OnAttached()
        {
            if (AssociatedObject.ItemsSource != null)
            {
                var pagedAsyncSource = AssociatedObject.ItemsSource as PagedAsyncSource;
                if (pagedAsyncSource != null)
                {
                    pagedAsyncSource.PropertyChanged += PagedAsyncSource_PropertyChanged;
                }
            }
            AssociatedObject.ItemsSourceChanged += Grid_ItemsSourceChanged;
            base.OnAttached();
        }

        protected override void OnDetaching()
        {
            var pagedAsyncSource = AssociatedObject.ItemsSource as PagedAsyncSource;
            if (pagedAsyncSource != null)
            {
                pagedAsyncSource.PropertyChanged -= PagedAsyncSource_PropertyChanged;
            }

            AssociatedObject.ItemsSourceChanged -= Grid_ItemsSourceChanged;
            base.OnDetaching();
        }

        //When a new source is assigned
        private void Grid_ItemsSourceChanged(object sender, ItemsSourceChangedEventArgs e)
        {
            if (e.NewItemsSource != null)
            {
                var pagedAsyncSource = e.NewItemsSource as PagedAsyncSource;
                if (pagedAsyncSource != null)
                {
                    pagedAsyncSource.PropertyChanged += PagedAsyncSource_PropertyChanged;
                }
            }

            if (e.OldItemsSource != null)
            {
                var pagedAsyncSource = e.OldItemsSource as PagedAsyncSource;
                if (pagedAsyncSource != null)
                {
                    pagedAsyncSource.PropertyChanged -= PagedAsyncSource_PropertyChanged;
                }
            }
        }

        private void PagedAsyncSource_PropertyChanged(object sender, System.ComponentModel.PropertyChangedEventArgs e)
        {
            if (e.PropertyName == nameof(PagedAsyncSource.AreRowsFetching))
            {
                var pagedAsyncSource = sender as PagedAsyncSource;
                if (!pagedAsyncSource.AreRowsFetching && pagedAsyncSource.Count > 0)
                {
                    Dispatcher.BeginInvoke(new Action(() =>
                    {
                        ((TableView)AssociatedObject.View).BestFitColumns();
                    }),
                    DispatcherPriority.Render);
                }
            }
        }
    }
}
