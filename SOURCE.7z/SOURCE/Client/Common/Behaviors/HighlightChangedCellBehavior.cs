﻿
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Media;
using DevExpress.Data;
using DevExpress.Mvvm.UI.Interactivity;
using DevExpress.Xpf.Grid;
using DevExpress.Xpf.Grid.ConditionalFormatting;

namespace AMAT.R2R.Client.Common.Behaviors
{
    public class ChangedCellsHighlightBehavior : Behavior<GridControl>
    {
        private readonly string _unboundColumnPrefix = "IsEdited_";
        private readonly Dictionary<CellInfo, bool> _modifiedCells = new Dictionary<CellInfo, bool>();
        public static readonly DependencyProperty HighlightBrushProperty = DependencyProperty.Register("HighlightBrush", typeof(Brush), typeof(ChangedCellsHighlightBehavior));
        public static readonly DependencyProperty RowFilterExpressionProperty = DependencyProperty.Register("RowFilterExpression", typeof(string), typeof(ChangedCellsHighlightBehavior));
        public Brush HighlightBrush
        {
            get { return (Brush)GetValue(HighlightBrushProperty); }
            set { SetValue(HighlightBrushProperty, value); }
        }

        public string RowFilterExpression
        {
            get { return (string)GetValue(RowFilterExpressionProperty); }
            set { SetValue(RowFilterExpressionProperty, value); }
        }

        protected TableView View
        {
            get
            {
                return (TableView)AssociatedObject.View;
            }
        }
        protected override void OnAttached()
        {
            AssociatedObject.CustomUnboundColumnData += OnGridCustomUnboundColumnData;
            AssociatedObject.Loaded += OnGridLoaded;
        }
        protected override void OnDetaching()
        {
            AssociatedObject.CustomUnboundColumnData -= OnGridCustomUnboundColumnData;
            View.CellValueChanged -= OnViewCellValueChanged;
        }
        void OnGridLoaded(object sender, System.Windows.RoutedEventArgs e)
        {
            AssociatedObject.Loaded -= OnGridLoaded;
            View.CellValueChanged += OnViewCellValueChanged;
            InitializeFormattings(CreateUnboundColumns());
        }
        void OnViewCellValueChanged(object sender, CellValueChangedEventArgs e)
        {
            if (!e.Column.FieldName.StartsWith(_unboundColumnPrefix))
            {
                AssociatedObject.SetCellValue(e.RowHandle, _unboundColumnPrefix + e.Column.FieldName, true);
            }
        }
        void OnGridCustomUnboundColumnData(object sender, GridColumnDataEventArgs e)
        {
            if (e.Column.FieldName.StartsWith(_unboundColumnPrefix))
            {
                if (e.IsGetData)
                {
                    _ = _modifiedCells.TryGetValue(new CellInfo(AssociatedObject.GetRowByListIndex(e.ListSourceRowIndex), e.Column.FieldName), out var res);
                    e.Value = res;
                }
                else
                {
                    CellInfo modifiedCell = new CellInfo(AssociatedObject.GetRowByListIndex(e.ListSourceRowIndex), e.Column.FieldName);
                    _modifiedCells[modifiedCell] = true;
                }
            }
        }
        List<GridColumn> CreateUnboundColumns()
        {
            List<GridColumn> unboundColumns = new List<GridColumn>();
            foreach (GridColumn column in AssociatedObject.Columns)
            {
                GridColumn stateKeeperUnboundColumn = new GridColumn
                {
                    FieldName = _unboundColumnPrefix + column.FieldName,
                    UnboundType = UnboundColumnType.Boolean,
                    Visible = false,
                    ShowInColumnChooser = false,
                    Tag = column.FieldName
                };
                unboundColumns.Add(stateKeeperUnboundColumn);
            }
            return unboundColumns;
        }
        void InitializeFormattings(List<GridColumn> unboundColumns)
        {
            foreach (GridColumn unboundColumn in unboundColumns)
            {
                AssociatedObject.Columns.Add(unboundColumn);
                if(string.IsNullOrEmpty(RowFilterExpression))
                {
                    View.FormatConditions.Add(new FormatCondition() { FieldName = (string)unboundColumn.Tag, Expression = string.Format("[{0}] = true", unboundColumn.FieldName), Format = new DevExpress.Xpf.Core.ConditionalFormatting.Format() { Background = HighlightBrush } });
                }
                else
                {
                    View.FormatConditions.Add(new FormatCondition() { FieldName = (string)unboundColumn.Tag, Expression = string.Format("[{0}] = true AND {1}", unboundColumn.FieldName, RowFilterExpression), Format = new DevExpress.Xpf.Core.ConditionalFormatting.Format() { Background = HighlightBrush } });
                }
            }
        }
    }

    public class CellInfo
    {
        public object Row { get; set; }
        public string FieldName { get; set; }
        public CellInfo(object row, string fieldName)
        {
            Row = row;
            FieldName = fieldName;
        }
        public override bool Equals(object obj)
        {
            return obj is CellInfo other && other.FieldName == FieldName && ReferenceEquals(Row, other.Row);
        }
        public override int GetHashCode()
        {
            return Row.GetHashCode() ^ FieldName.GetHashCode();
        }
    }
}
