﻿
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace AMAT.R2R.Client.Common.Messages
{
    public class LogoutMessage
    {
        public string UserID { get; set; }
        public string Domain { get; set; }
    }
}
