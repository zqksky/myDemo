﻿
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using AMAT.R2R.Client.Common.Views;
using AMAT.R2R.Shared.Base.DTO;
using AMAT.R2R.Shared.Etch.DTO;

namespace AMAT.R2R.Client.Common.Messages
{
    public class LoginMessage : LoginInfo
    {
        public string LoginEnv { get; set; }
        public string ApiAddress { get; set; }
    }
}
