﻿
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using AMAT.R2R.Client.Common.Views;
using AMAT.R2R.Shared.Base.DTO;
using AMAT.R2R.Shared.Etch.DTO;

namespace AMAT.R2R.Client.Common.Messages
{
    public class ApiCompletedMessage
    {
        public ApiCompletedMessage(string txnId)
        {
            TxnId = txnId;
        }
        public string TxnId { get; }
    }
}
