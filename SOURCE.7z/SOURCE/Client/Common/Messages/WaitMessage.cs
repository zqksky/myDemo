﻿
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using AMAT.R2R.Client.Common.Views;
using AMAT.R2R.Shared.Base.DTO;
using AMAT.R2R.Shared.Etch.DTO;

namespace AMAT.R2R.Client.Common.Messages
{
    public class WaitMessage
    {
        public WaitMessage(WaitMode mode, string waitArea, string waitText = "Please wait...")
        {
            Mode = mode;
            WaitArea = waitArea;
            WaitText = waitText;
        }

        public string WaitArea { get; private set; }

        public string WaitText { get; private set; }

        public WaitMode Mode { get; private set; }
    }

    public enum WaitMode
    {
        Show,
        Hide,
        HideAll
    }
}
