﻿
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using AMAT.R2R.Client.Common.Views;
using AMAT.R2R.Shared.Base.DTO;
using AMAT.R2R.Shared.Etch.DTO;

namespace AMAT.R2R.Client.Common.Messages
{
    public class ApiStartedMessage
    {
        public ApiStartedMessage(string method, string resourceUrl, string txnId, bool isQuery)
        {
            Method = method;
            ResourceUrl = resourceUrl;
            TxnId = txnId;
            IsQuery = isQuery;
        }
        public bool IsQuery { get; }
        public string TxnId { get; }
        public string Method { get; }
        public string ResourceUrl { get; }
    }
}
