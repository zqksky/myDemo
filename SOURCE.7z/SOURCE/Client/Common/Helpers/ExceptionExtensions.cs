﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AMAT.R2R.Client.Common.Helpers
{
    public static class ExceptionExtensions
    {
        public static bool IsTaskCanceledException(this Exception exp)
        {
            return exp != null && (exp is OperationCanceledException || exp.InnerException.IsTaskCanceledException());

        }

        public static Exception GetInnerestException(this Exception ex)
        {
            return ex == null ? null : ex.InnerException == null ? ex : GetInnerestException(ex.InnerException);
        }
    }
}
