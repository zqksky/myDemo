﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace AMAT.R2R.Client.Common.Helpers
{
    public class DataValidator
    {
        public const string MaskID = @"^[a-zA-Z0-9_\-\.]*$";
        public const string MaskUserID = @"^[a-zA-Z0-9_]*$";
        public const string MaskEmail = @"^([\w\.\-]+)@([\w\-]+)((\.(\w){2,3})+)$";
        public const string MaskTel = @"^\+?[0-9]{7,}$";
        public const string MaskUri = @"^(http|https|ftp)\://[a-zA-Z0-9\-\.]+(:[a-zA-Z0-9]*)?/?([a-zA-Z0-9\-\._\?\,\'/\\\+&$%\$#\=~])*$";


        public static string ValidateInOrder(params Func<string>[] validators)
        {
            var result = string.Empty;
            foreach (var validator in validators)
            {
                if (validator != null)
                {
                    result = validator();
                    if (!string.IsNullOrWhiteSpace(result))
                    {
                        return result;
                    }
                    else
                    {
                        continue;
                    }
                }
            }
            return null;
        }

        public static string UTF8StringMaxLength(string value, int maxLengthUTF8 = 255)
        {
            var length = value == null ? 0 : Encoding.UTF8.GetByteCount(value);
            if (length > maxLengthUTF8)
            {
                return string.Format(Properties.Resources.ERR_ValueTooLong, maxLengthUTF8);
            }
            else
            {
                return null;
            }
        }

        public static string NotNull(object value)
        {
            if (value == null || (value is string) && string.IsNullOrWhiteSpace(value as string))
            {
                return Properties.Resources.ERR_ValueCannotBeEmpty;
            }
            else
            {
                return null;
            }
        }

        public static string InRange(decimal? value, decimal? min, decimal? max)
        {
            if (!value.HasValue)
            {
                return null;
            }
            else if (!min.HasValue)
            {
                return SmallerThanOrEqualTo(value, max);
            }
            else if (!max.HasValue)
            {
                return LargerThanOrEqualTo(value, min);
            }
            else
            {
                return value >= min && value <= max ? null : $"Value must >= {min} and <= {max}";
            }
        }

        public static string InRangeLeftOpen(decimal? value, decimal? min, decimal? max)
        {
            if (!value.HasValue)
            {
                return null;
            }
            else if (!min.HasValue)
            {
                return SmallerThanOrEqualTo(value, max);
            }
            else if (!max.HasValue)
            {
                return LargerThan(value, min);
            }
            else
            {
                return value > min && value <= max ? null : $"Value must > {min} and <= {max}";
            }
        }

        public static string InRangeRightOpen(decimal? value, decimal? min, decimal? max)
        {
            if (!value.HasValue)
            {
                return null;
            }
            else if (!min.HasValue)
            {
                return SmallerThan(value, max);
            }
            else if (!max.HasValue)
            {
                return LargerThanOrEqualTo(value, min);
            }
            else
            {
                return value >= min && value < max ? null : $"Value must >= {min} and < {max}";
            }
        }

        public static string InRangeOpen(decimal? value, decimal? min, decimal? max)
        {
            if (!value.HasValue)
            {
                return null;
            }
            else if (!min.HasValue)
            {
                return SmallerThan(value, max);
            }
            else if (!max.HasValue)
            {
                return LargerThan(value, min);
            }
            else
            {
                return value > min && value < max ? null : $"Value must > {min} and < {max}";
            }
        }

        public static string NotZero(decimal? target)
        {
            return !target.HasValue || target.Value != 0 ? null : "Value cannot be 0";
        }

        public static string NotZero(decimal?[] targets)
        {
            string result = null;
            Boolean notZero = false;
            foreach (decimal ? target in targets)
            {
                if (target.HasValue && target.Value != 0)
                {
                    notZero = true;
                    break;
                }
            }
            result = notZero?null:"All Value can't be 0";
            return result;
        }

        public static string LargerThan(decimal? value, decimal? min)
        {
            if (!value.HasValue || !min.HasValue)
            {
                return null;
            }
            else
            {
                return value > min ? null : $"Value must > {min}";
            }
        }
        public static string LargerThanOrEqualTo(decimal? value, decimal? min)
        {
            if (!value.HasValue || !min.HasValue)
            {
                return null;
            }
            else
            {
                return value >= min ? null : $"Value must >= {min}";
            }
        }

        public static string SmallerThan(decimal? value, decimal? max)
        {
            if (!value.HasValue || !max.HasValue)
            {
                return null;
            }
            else
            {
                return value < max ? null : $"Value must < {max}";
            }
        }
        public static string SmallerThanOrEqualTo(decimal? value, decimal? max)
        {
            if (!value.HasValue || !max.HasValue)
            {
                return null;
            }
            else
            {
                return value <= max ? null : $"Value must <= {max}";
            }
        }

        //onlu validate empty or not and value length.Need not regex.
        public static string ValidString(string value, int maxLengthUTF8 = 40, bool validateNotNull = true)
        {
            if (validateNotNull && string.IsNullOrEmpty(value))
            {
                return Properties.Resources.ERR_ValueCannotBeEmpty;
            }

            if (string.IsNullOrEmpty(value))
            {
                return null;
            }

            var lengthValidateResult = UTF8StringMaxLength(value, maxLengthUTF8);
            if (lengthValidateResult != null)
            {
                return lengthValidateResult;
            }
            else
            {
                return null;
            }
        }

        public static string NotStartEndWithSpace(string value, int maxLengthUTF8 = 40, bool validateNotNull = true)
        {
            if (value != value?.Trim())
            {
                return Properties.Resources.ERR_ValueCannotStartOrEndWithSpace;
            }

            if (validateNotNull && string.IsNullOrEmpty(value))
            {
                return Properties.Resources.ERR_ValueCannotBeEmpty;
            }

            if (string.IsNullOrEmpty(value))
            {
                return null;
            }

            var lengthValidateResult = UTF8StringMaxLength(value, maxLengthUTF8);
            if (lengthValidateResult != null)
            {
                return lengthValidateResult;
            }
            else
            {
                return null;
            }
        }

        public static string ValidEmail(string value, int maxLengthUTF8 = 40, bool validateNotNull = true)
        {
            if (validateNotNull && string.IsNullOrEmpty(value))
            {
                return Properties.Resources.ERR_ValueCannotBeEmpty;
            }

            if (string.IsNullOrEmpty(value))
            {
                return null;
            }

            var lengthValidateResult = UTF8StringMaxLength(value, maxLengthUTF8);
            if (lengthValidateResult != null)
            {
                return lengthValidateResult;
            }
            else
            {
                return !new Regex(MaskEmail).Match(value).Success ? Properties.Resources.ERR_InvalidEmail : null;
            }

        }

        public static string ValidPhoneNumber(string value, int maxLengthUTF8 = 20, bool validateNotNull = false)
        {
            if (validateNotNull && string.IsNullOrEmpty(value))
            {
                return Properties.Resources.ERR_ValueCannotBeEmpty;
            }

            if (string.IsNullOrEmpty(value))
            {
                return null;
            }

            var lengthValidateResult = UTF8StringMaxLength(value, maxLengthUTF8);
            if (lengthValidateResult != null)
            {
                return lengthValidateResult;
            }
            else
            {
                return !new Regex(MaskTel).Match(value).Success ? Properties.Resources.ERR_InvalidPhoneNumber : null;
            }

        }

        public static string ValidatePassword(string value, int maxLengthUTF8 = 40, bool validateNotNull = true)
        {
            if (validateNotNull && string.IsNullOrEmpty(value))
            {
                return Properties.Resources.ERR_ValueCannotBeEmpty;
            }

            if (string.IsNullOrEmpty(value))
            {
                return null;
            }

            var lengthValidateResult = UTF8StringMaxLength(value, maxLengthUTF8);
            if (lengthValidateResult != null)
            {
                return lengthValidateResult;
            }
            else
            {
                return null;
            }
        }

        public static string ValidateUri(string value, bool validateNotNull = true)
        {
            if (validateNotNull && string.IsNullOrEmpty(value))
            {
                return Properties.Resources.ERR_ValueCannotBeEmpty;
            }

            if (string.IsNullOrEmpty(value))
            {
                return null;
            }
            return !new Regex(MaskUri).Match(value).Success ? Properties.Resources.ERR_InvalidUri : null;
        }

        public static string ValidateUserID(string value, int maxLengthUTF8 = 40, bool validateNotNull = true)
        {
            if (validateNotNull && string.IsNullOrEmpty(value))
            {
                return Properties.Resources.ERR_ValueCannotBeEmpty;
            }

            if (string.IsNullOrEmpty(value))
            {
                return null;
            }

            var lengthValidateResult = UTF8StringMaxLength(value, maxLengthUTF8);
            if (lengthValidateResult != null)
            {
                return lengthValidateResult;
            }
            else
            {
                return !new Regex(MaskUserID).Match(value).Success ? string.Format(Properties.Resources.ERR_InvalidUserID) : null;
            }

        }
    }
}
