﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Media;

namespace AMAT.R2R.Client.Common.Helpers
{

    public static class VisualTreeUtility
    {
        ///
        /// Finds a Child of a given item in the visual tree.
        ///
        /// A direct parent of the queried item.
        /// The type of the queried item.
        /// x:Name or Name of child.
        /// The first parent item that matches the submitted type parameter.
        /// If not matching item can be found,
        /// a null parent is being returned.
        public static T FindChild<T>(DependencyObject parent, string childName)
            where T : DependencyObject
        {
            // confirm parent and childName are valid
            if (parent == null) return null;
            T foundChild = null;
            int childrenCount = VisualTreeHelper.GetChildrenCount(parent);

            for (int i = 0; i < childrenCount; i++)
            {
                var child = VisualTreeHelper.GetChild(parent, i);

                // if hte child is not the requested child type child
                T childType = child as T;
                if (childType == null)
                {
                    // recursively drill down the tree
                    foundChild = FindChild<T>(child, childName);

                    // if the child is Found, break so we don't overwrite the found child
                    if (foundChild != null) break;
                }
                else if (!string.IsNullOrEmpty(childName))
                {
                    var frameworkElement = child as FrameworkElement;

                    // if the child's name is set for search
                    if (frameworkElement != null && string.Compare(frameworkElement.Name, childName, true) == 0)
                    {
                        // if the child's name is of the request name
                        foundChild = (T)child;
                        break;
                    }
                    else
                    {
                        // recursively drill down the tree
                        foundChild = FindChild<T>(child, childName);
                        // if the child is Found, break so we don't overwrite the found child
                        if (foundChild != null) break;
                    }
                }
                else
                {
                    // child element found.
                    foundChild = (T)child;
                    break;
                }
            }
            return foundChild;
        }

        public static T GetVisualChild<T>(Visual parent) where T : Visual
        {
            T childContent = default(T);
            int numVisuals = VisualTreeHelper.GetChildrenCount(parent);
            for (int i = 0; i < numVisuals; i++)
            {
                Visual v = (Visual)VisualTreeHelper.GetChild(parent, i);
                childContent = v as T;
                if (childContent == null)
                {
                    childContent = GetVisualChild<T>(v);
                }
                if (childContent != null)
                {
                    break;
                }
            }

            return childContent;
        }

        public static void ForEachChild<T>(DependencyObject parent, Action<T> action) where T : FrameworkElement
        {
            if (parent == null) return;

            int childrenCount = VisualTreeHelper.GetChildrenCount(parent);

            for (int i = 0; i < childrenCount; i++)
            {
                var child = VisualTreeHelper.GetChild(parent, i);
                if (child is T)
                {
                    action(child as T);
                }

                ForEachChild(child, action);
            }
        }


        public static T GetParentOfType<T>(DependencyObject element) where T : DependencyObject
        {
            Type type = typeof(T);
            if (element == null) return null;
            DependencyObject parent = VisualTreeHelper.GetParent(element);
            if (parent == null && ((FrameworkElement)element).Parent is DependencyObject) parent = ((FrameworkElement)element).Parent;
            if (parent == null) return null;
            else if (parent.GetType() == type || parent.GetType().IsSubclassOf(type)) return parent as T;
            return GetParentOfType<T>(parent);
        }


        public static T GetControlByMousePosition<T>(Visual parent, Point point) where T : DependencyObject
        {
            HitTestResult hitTestResult = VisualTreeHelper.HitTest(parent, point);
            if (hitTestResult == null)
                return null;
            T control = GetParentOfType<T>(hitTestResult.VisualHit);
            return control;
        }
    }
}
