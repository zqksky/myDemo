﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AMAT.R2R.Client.Common.Extensions;

namespace AMAT.R2R.Client.Common.Helpers
{
    public class AuthorityManager
    {
        private static AuthorityManager _authorityManager;

        private List<string> _authorityList = new List<string>();

        private static AuthorityManager Instance
        {
            get
            {
                if(_authorityManager == null)
                {
                    _authorityManager = new AuthorityManager();
                }
                return _authorityManager;
            }
        }

        private AuthorityManager()
        {

        }

        internal static void SetupAuthorities(IEnumerable<string> authorities)
        {
            if (authorities is null)
            {
                throw new ArgumentNullException(nameof(authorities));
            }

            Instance._authorityList = authorities.ToList();
        }


        public static bool HasAuthority(string authority)
        {
            return Instance._authorityList.Any(a => a.EqualsIgnoreCase(authority));
        }
    }
}
