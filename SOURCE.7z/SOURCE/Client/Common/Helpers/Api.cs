﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AMAT.R2R.Client.Common.Services;

namespace AMAT.R2R.Client.Common.Helpers
{
    public class Api
    {
        private Api()
        {

        }

        public static IApiService Current
        {
            get; internal set;
        }
    }
}
