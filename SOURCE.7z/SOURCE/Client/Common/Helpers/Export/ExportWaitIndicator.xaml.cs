﻿using System.Windows.Controls;

namespace AMAT.R2R.Client.Common.Helpers
{
    /// <summary>
    /// Interaction logic for ExportWaitIndicator
    /// </summary>
    public partial class ExportWaitIndicator : UserControl
    {
        public ExportWaitIndicator()
        {
            InitializeComponent();
        }
    }
}
