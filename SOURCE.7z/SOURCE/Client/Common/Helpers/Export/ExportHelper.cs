﻿using DevExpress.Export;
using DevExpress.Mvvm;
using DevExpress.Mvvm.Native;
using DevExpress.Xpf.Core;
using DevExpress.Xpf.Grid;
//using DevExpress.Xpf.PdfViewer;
using DevExpress.Xpf.Printing;
using DevExpress.Xpf.Ribbon;
using DevExpress.Xpf.RichEdit;
//using DevExpress.Xpf.Spreadsheet;
using DevExpress.XtraPrinting;
using DevExpress.XtraPrinting.Localization;
using DevExpress.XtraPrinting.Native;
using DevExpress.XtraPrinting.Native.ExportOptionsControllers;
using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using IDialogService = DevExpress.Mvvm.IDialogService;
using System.Windows.Threading;

namespace AMAT.R2R.Client.Common.Helpers
{
    public static class DataAwareExportHelper
    {
        public static void ExportToXlsx(DataViewBase view)
        {
            Export(new Action<Stream, XlsxExportOptionsEx>(view.ExportToXlsx));
        }
        public static void ExportToXls(DataViewBase view)
        {
            Export(new Action<Stream, XlsExportOptionsEx>(view.ExportToXls));
        }
        public static void ExportToCsv(DataViewBase view)
        {
            Export(new Action<Stream, CsvExportOptionsEx>(view.ExportToCsv));
        }
        static void Export<T>(Action<Stream, T> exportToStreamMethod) where T : ExportOptionsBase, new()
        {
            Dispatcher.CurrentDispatcher.BeginInvoke(new Action<Action<Stream, T>>(ExportCore), DispatcherPriority.ContextIdle, exportToStreamMethod);
        }
        static void ExportCore<T>(Action<Stream, T> exportToStreamMethod) where T : ExportOptionsBase, new()
        {
            using (MemoryStream stream = new MemoryStream())
            {
                ExportHelper.ExportCore(exportToStreamMethod, stream, SubscribeProgressEvents, UnsubscribeProgressEvents);
            }
        }
        static void UnsubscribeProgressEvents<T>(T options) where T : ExportOptionsBase
        {
            ((IDataAwareExportOptions)options).ExportProgress -= ExportHelper.ExportProgress;
        }
        static void SubscribeProgressEvents<T>(T options) where T : ExportOptionsBase
        {
            ((IDataAwareExportOptions)options).ExportProgress += ExportHelper.ExportProgress;
        }
    }
    public static class WYSIWYGExportHelper
    {
        public static void DoExport(DataViewBase view, ExportFormat format)
        {
            switch (format)
            {
                case ExportFormat.Xls:
                    Export(view, link => new Action<Stream, XlsExportOptions>(link.ExportToXls));
                    break;
                case ExportFormat.Xlsx:
                    Export(view, link => new Action<Stream, XlsxExportOptions>(link.ExportToXlsx));
                    break;
                case ExportFormat.Pdf:
                    Export(view, link => new Action<Stream, PdfExportOptions>(link.ExportToPdf));
                    break;
                case ExportFormat.Htm:
                    Export(view, link => new Action<Stream, HtmlExportOptions>(link.ExportToHtml));
                    break;
                case ExportFormat.Mht:
                    Export(view, link => new Action<Stream, MhtExportOptions>(link.ExportToMht));
                    break;
                case ExportFormat.Rtf:
                    Export(view, link => new Action<Stream, RtfExportOptions>(link.ExportToRtf));
                    break;
                case ExportFormat.Txt:
                    Export(view, link => new Action<Stream, TextExportOptions>(link.ExportToText));
                    break;
                case ExportFormat.Image:
                    Export(view, link => new Action<Stream, ImageExportOptions>(link.ExportToImage));
                    break;
                case ExportFormat.Xps:
                    Export(view, link => new Action<Stream, XpsExportOptions>(link.ExportToXps));
                    break;
                case ExportFormat.Docx:
                    Export(view, link => new Action<Stream, DocxExportOptions>(link.ExportToDocx));
                    break;
                case ExportFormat.Csv:
                    Export(view, link => new Action<Stream, CsvExportOptions>(link.ExportToCsv));
                    break;
            }
        }
        static void OnAfterBuildPages(object sender, EventArgs e)
        {
            DXSplashScreen.Close();
        }
        static void UnsubscribeProgressEvents(PrintableControlLink link, EventHandler onExportProgress)
        {
            link.PrintingSystem.ProgressReflector.PositionChanged -= onExportProgress;
            link.PrintingSystem.AfterBuildPages -= OnAfterBuildPages;
        }
        static void SubscribeProgressEvents(PrintableControlLink link, EventHandler onExportProgress)
        {
            link.PrintingSystem.ProgressReflector.PositionChanged += onExportProgress;
            link.PrintingSystem.AfterBuildPages += OnAfterBuildPages;
        }
        static void Export<T>(DataViewBase view, Func<PrintableControlLink, Action<Stream, T>> getExportToStreamMethod) where T : ExportOptionsBase, new()
        {
            var link = new PrintableControlLink(view);
            EventHandler onExportProgress = (o, e) => ExportHelper.ExportProgress(new ProgressChangedEventArgs(link.PrintingSystem.ProgressReflector.Position, null));
            using (MemoryStream stream = new MemoryStream())
            {
                ExportHelper.ExportCore(getExportToStreamMethod(link), stream,
                options => SubscribeProgressEvents(link, onExportProgress),
                options => UnsubscribeProgressEvents(link, onExportProgress));
            }
        }
    }
    static class ExportHelper
    {
        const string SaveFile = "Save";
        const string SaveAndOpenFile = "Save and Open with Default App";
        const string OpenExportedFile = "Open Exported File";

        public static void ExportCore<T>(Action<Stream, T> exportToStream, Stream stream, Action<T> subscribeProgress, Action<T> unsubscribeProgress)
            where T : ExportOptionsBase, new()
        {
            if (stream == null)
                return;
            try
            {
                DXSplashScreen.Show<ExportWaitIndicator>();
                var options = new T();
                subscribeProgress(options);
                try
                {
                    exportToStream(stream, options);
                }
                finally
                {
                    unsubscribeProgress(options);
                    if (DXSplashScreen.IsActive)
                        DXSplashScreen.Close();
                }

                stream.Seek(0, SeekOrigin.Begin);

                SaveFileDialog sfd = new SaveFileDialog
                {
                    Title = "Save File",
                    OverwritePrompt = true,
                    AddExtension = true,
                    RestoreDirectory = true,
                    Filter = $"{options.GetFormat()} file ({options.GetFileExtension()})|*{options.GetFileExtension()}"
                };

                var result = sfd.ShowDialog();
                if (result.HasValue && result.Value)
                {
                    SaveStreamToFile(stream, options, sfd.FileName);

                    if (ShouldOpenFile(sfd.FileName))
                    {
                        ProcessLaunchHelper.StartProcess(sfd.FileName, false);
                    }
                }

                return;
            }
            catch (Exception e)
            {
                DXMessageBox.Show(e.Message, "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        static bool ShouldOpenFile(string fileName)
        {
            List<UICommand> dialogCommands = new List<UICommand>();
            bool result = false;
            dialogCommands.Add(new UICommand(0, OpenExportedFile, DelegateCommandFactory.Create(() => result = true), true, false));
            dialogCommands.Add(new UICommand(1, "Close", DelegateCommandFactory.Create(() => result = false), false, true));
            DXDialogWindow d = new DXDialogWindow()
            {
                ResizeMode = ResizeMode.NoResize,
                SizeToContent = SizeToContent.WidthAndHeight,
                WindowStyle = WindowStyle.SingleBorderWindow,
                ShowInTaskbar = false,
                WindowStartupLocation = WindowStartupLocation.CenterOwner,
                Owner = Application.Current.MainWindow,
                Title = OpenExportedFile
            };
            d.CommandsSource = dialogCommands;
            d.Content = new TextBox() { IsReadOnly = true, BorderThickness = new Thickness(0, 0, 0, 0), Text = $"File saved to {fileName}.", Margin = new Thickness(24, 15, 24, 16), HorizontalAlignment = HorizontalAlignment.Center };
            d.ShowDialogWindow();
            return result;
        }


        static void SaveStreamToFile<T>(Stream stream, T options, string fileName) where T : ExportOptionsBase
        {
            SaveToFile(stream, options, fileName);
        }


        static void ViewerWindow_Loaded1(object sender, RoutedEventArgs e)
        {
            FrameworkElement element = (FrameworkElement)sender;
            element.Loaded -= ViewerWindow_Loaded1;
            if (DXSplashScreen.IsActive)
                DXSplashScreen.Close();
        }

        static string SaveToFile<T>(Stream stream, T options, string fileName) where T : ExportOptionsBase
        {
            //string changedFileName = Path.ChangeExtension(fileName, options.GetFileExtension());
            using (FileStream fileStream = new FileStream(fileName, FileMode.Create))
            {
                stream.CopyTo(fileStream);
            }
            return fileName;
        }

        public static void ExportProgress(ProgressChangedEventArgs ea)
        {
            if (!DXSplashScreen.IsActive)
                return;
            DXSplashScreen.Progress(ea.ProgressPercentage);
        }
    }


}
