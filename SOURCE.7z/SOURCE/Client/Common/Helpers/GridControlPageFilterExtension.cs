﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AMAT.R2R.Client.Common.Services;
using DevExpress.Data.Filtering;
using DevExpress.Xpf.Data;
using DevExpress.Mvvm;
using DevExpress.Mvvm.DataAnnotations;
using DevExpress.Mvvm.Native;

namespace AMAT.R2R.Client.Common.Helpers
{
    public static class GridControlPageFilterExtension
    {
        public static List<QuerySorter> MakeSorters(this FetchPageAsyncEventArgs e) => e?.SortOrder?.Select(sd => new QuerySorter(sd.PropertyName, sd.Direction))?.ToList();

        public static List<QueryFilter> MakeFilters(this CriteriaOperator filter)
        {
            return filter.Match(
                binary: (propertyName, value, type) =>
                {
                    var parameters = new List<QueryFilter>();
                    switch (type)
                    {
                        case BinaryOperatorType.Equal:
                            parameters.Add(new QueryFilter(propertyName, value));
                            break;
                        case BinaryOperatorType.NotEqual:
                            parameters.Add(new QueryFilter(propertyName, value, QueryOperator.NotEquals));
                            break;
                        case BinaryOperatorType.Greater:
                            parameters.Add(new QueryFilter(propertyName, value, QueryOperator.GreaterThan));
                            break;
                        case BinaryOperatorType.Less:
                            parameters.Add(new QueryFilter(propertyName, value, QueryOperator.LessThan));
                            break;
                        case BinaryOperatorType.LessOrEqual:
                            parameters.Add(new QueryFilter(propertyName, value, QueryOperator.LessThanOrEqualsTo));
                            break;
                        case BinaryOperatorType.GreaterOrEqual:
                            parameters.Add(new QueryFilter(propertyName, value, QueryOperator.GreaterThanOrEqualsTo));
                            break;
                        default:
                            throw new InvalidOperationException();
                    }
                    return parameters;
                },
                @in: (propertyName, values) =>
                {
                    var parameters = new List<QueryFilter>
                    {
                        new QueryFilter(propertyName, values, QueryOperator.In)
                    };
                    return parameters;
                },
                and: filters =>
                {
                    return filters.SelectMany(f => f).ToList();
                },
                or: filters =>
                {
                    throw new InvalidOperationException();
                },
                function: (string propertyName, object[] values, FunctionOperatorType operatorType) =>
                {
                    if (operatorType == FunctionOperatorType.Contains)
                    {
                        return new List<QueryFilter>
                        {
                            new QueryFilter(propertyName, values[0], QueryOperator.Contains)
                        };
                    }
                    else if (operatorType == FunctionOperatorType.StartsWith)
                    {
                        return new List<QueryFilter>
                        {
                            new QueryFilter(propertyName, values[0], QueryOperator.StartsWith)
                        };
                    }
                    else if (operatorType == FunctionOperatorType.EndsWith)
                    {
                        return new List<QueryFilter>
                        {
                            new QueryFilter(propertyName, values[0], QueryOperator.EndsWith)
                        };
                    }
                    else { }
                    throw new InvalidOperationException();
                },
                not: operand =>
                {
                    var filters = new List<QueryFilter>();
                    foreach (var f in operand)
                    {
                        if (f.Operator == QueryOperator.In)
                        {
                            filters.Add(new QueryFilter(f.PropertyName, f.Value, QueryOperator.NotIn));
                        }
                        else
                        {
                            throw new InvalidOperationException();
                        }
                    }
                    return filters;
                },
                @null: default
            );
        }
    }
}
