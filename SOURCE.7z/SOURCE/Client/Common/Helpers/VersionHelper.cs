﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AMAT.R2R.Client.Common.Helpers
{
    public static class VersionHelper
    {
        private static string s_version;

        public static string ProductVersion
        {
            get
            {
                if (string.IsNullOrEmpty(s_version))
                {
                    s_version = FileVersionInfo.GetVersionInfo(System.Reflection.Assembly.GetEntryAssembly().Location).FileVersion;
                }
                return s_version;
            }
        }
    }
}
