﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.ServiceModel.Channels;
using System.Text;
using System.Threading.Tasks;
using AMAT.R2R.Client.Common.Messages;
using AMAT.R2R.Client.Common.Views;
using AMAT.R2R.Shared.Base.DTO;
using AMAT.R2R.Shared.Etch.DTO;
using DevExpress.Internal.WinApi.Windows.UI.Notifications;
using DevExpress.Mvvm;

namespace AMAT.R2R.Client.Common.Helpers
{
    public class ClientInfo
    {
        static ClientInfo()
        {
            LoginMessage = new LoginMessage();
        }

        private static ClientInfo s_user;
        private static ClientInfo Instance
        {
            get
            {
                if (s_user == null)
                {
                    s_user = new ClientInfo();
                }
                return s_user;
            }
        }

        private ClientInfo()
        {
            Messenger.Default.Register<LoginMessage>(this, OnUserLogin);
        }

        public static void Initialize()
        {
            _ = Instance;
        }

        public static bool CheckLoginPassword(string password)
        {
            return password != null && password == LoginMessage.Password;
        }

        private void OnUserLogin(LoginMessage msg)
        {
            LoginMessage = msg;
        }

        private static LoginMessage LoginMessage { get; set; }

        public static string LoginEnv { get { return LoginMessage.LoginEnv; } }

        public static string SessionId { get { return LoginMessage.SessionId; } }

        public static string UserName { get { return LoginMessage.FullUserName; } }

        public static string LoginDomain { get { return LoginMessage.LoginDomain; } }

        public static string LoginFab { get { return LoginMessage.LoginFab; } }

        public static string LoginArea { get { return LoginMessage.LoginArea; } }

        public static string ClientVersion { get { return LoginMessage.ClientVersion; } }

        public static DateTime LoginTime { get { return LoginMessage.LoginTime; } }

        public static int ProcessId { get { return LoginMessage.ProcessId; } }

        public static string ApiAddress { get { return LoginMessage.ApiAddress; } }
        public static string ServerVersion { get { return LoginMessage.ServerVersion; } }
        public static string DBInfo { get { return LoginMessage.DBInfo; } }
    }
}
