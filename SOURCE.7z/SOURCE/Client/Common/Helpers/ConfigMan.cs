﻿
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Configuration;
using System.Linq;
using System.Windows.Media.Converters;
using AMAT.R2R.Client.Common.Extensions;

namespace AMAT.R2R.Client.Common.Helpers
{
    /// <summary>
    /// Provides easy reading of NameValueCollection settings from application configuration file.
    /// </summary>
    public class ConfigMan
    {
        private static readonly Dictionary<string, object> s_configCache = new Dictionary<string, object>();

        private static string ReadStringFromConfigFile(string section, string key)
        {
            if (ConfigurationManager.GetSection(section) is NameValueCollection settings)
            {
                return settings[key];
            }
            else
            {
                return null;
            }
        }

        /// <summary>
        /// Get a NameValueCollection setting from application configuration file
        /// </summary>
        /// <param name="section">section name</param>
        /// <param name="key">setting key</param>
        /// <param name="defaultValue">The default value if section or key does not exist. If not provided, empty string is used.</param>
        /// <returns></returns>
        public static string GetString(string section, string key, string defaultValue = "")
        {
            lock (s_configCache)
            {
                var uniqueKey = $"{section}/{key}";
                if (s_configCache.ContainsKey(uniqueKey))
                {
                    return s_configCache[uniqueKey] as string;
                }
                else
                {
                    string configuredValue = ReadStringFromConfigFile(section, key);
                    if (configuredValue != null)
                    {
                        s_configCache[uniqueKey] = configuredValue;
                        Logger.Info($"Explicit Config: {uniqueKey} = {configuredValue}");
                        return configuredValue;
                    }
                    else
                    {
                        s_configCache[uniqueKey] = defaultValue;
                        Logger.Info($"Default Config: {uniqueKey} = {defaultValue}");
                        return defaultValue;
                    }
                }
            }
        }

        public static List<string> GetStringList(string section, string key, string seperators = ",", bool removeEmptyEntries = true)
        {
            lock (s_configCache)
            {
                var uniqueKey = $"{section}/{key}";
                if (s_configCache.ContainsKey(uniqueKey))
                {
                    return s_configCache[uniqueKey] as List<string>;
                }
                else
                {
                    string configuredValue = ReadStringFromConfigFile(section, key);
                    if (configuredValue != null)
                    {
                        Logger.Info($"Explicit Config: {uniqueKey} = {configuredValue}");
                        var stringList = configuredValue.SplitToList(seperators, removeEmptyEntries ? StringSplitOptions.RemoveEmptyEntries : StringSplitOptions.None, true).ToList();
                        s_configCache[uniqueKey] = stringList;
                        return stringList;
                    }
                    else
                    {
                        s_configCache[uniqueKey] = new List<string>();
                        Logger.Info($"Default Config: {uniqueKey} = EmptyArray");
                        return new List<string>();
                    }
                }
            }
        }

        /// <summary>
        /// Get a NameValueCollection setting from application configuration file, and convert it to a boolean
        /// </summary>
        /// <param name="section">section name</param>
        /// <param name="key">setting key</param>
        /// <param name="defaultValue">The default value if section or key does not exist, or the setting's value is not a valid boolean.
        /// If not provided, false is used. </param>
        /// <returns></returns>
        public static bool GetBoolean(string section, string key, bool defaultValue = false)
        {
            lock (s_configCache)
            {
                var uniqueKey = $"{section}/{key}";
                if (s_configCache.ContainsKey(uniqueKey))
                {
                    return (bool)s_configCache[uniqueKey];
                }
                else
                {
                    var nullable = NullableDataConverter.Convert<bool>(ReadStringFromConfigFile(section, key));
                    if (nullable.HasValue)
                    {
                        s_configCache[uniqueKey] = nullable.Value;
                        Logger.Info($"Explicit Config: {uniqueKey} = {nullable.Value}");
                        return nullable.Value;
                    }
                    else
                    {
                        s_configCache[uniqueKey] = defaultValue;
                        Logger.Info($"Default Config: {uniqueKey} = {defaultValue}");
                        return defaultValue;
                    }
                }
            }
        }

        /// <summary>
        /// Get a NameValueCollection setting from application configuration file, and convert it to a integer
        /// </summary>
        /// <param name="section">section name</param>
        /// <param name="key">setting key</param>
        /// <param name="defaultValue">The default value if section or key does not exist, or the setting's value is not a valid integer.
        /// If not provided, 0 is used. </param>
        /// <returns></returns>
        public static int GetInt32(string section, string key, int defaultValue = 0)
        {
            lock (s_configCache)
            {
                var uniqueKey = $"{section}/{key}";
                if (s_configCache.ContainsKey(uniqueKey))
                {
                    return (int)s_configCache[uniqueKey];
                }
                else
                {
                    if (int.TryParse(ReadStringFromConfigFile(section, key), out var configuredValue))
                    {
                        s_configCache[uniqueKey] = configuredValue;
                        Logger.Info($"Explicit Config: {uniqueKey} = {configuredValue}");
                        return configuredValue;
                    }
                    else
                    {
                        s_configCache[uniqueKey] = defaultValue;
                        Logger.Info($"Default Config: {uniqueKey} = {defaultValue}");
                        return defaultValue;
                    }
                }
            }
        }

        /// <summary>
        /// Get a NameValueCollection setting from application configuration file, and convert it to an unsigned integer.
        /// </summary>
        /// <param name="section">section name</param>
        /// <param name="key">setting key</param>
        /// <param name="defaultValue">The default value if section or key does not exist, or the setting's value is not a valid unsigned integer.
        /// If not provided, 0 is used. </param>
        /// <returns></returns>
        public static uint GetUInt32(string section, string key, uint defaultValue = 0)
        {
            lock (s_configCache)
            {
                var uniqueKey = $"{section}/{key}";
                if (s_configCache.ContainsKey(uniqueKey))
                {
                    return (uint)s_configCache[uniqueKey];
                }
                else
                {
                    if (uint.TryParse(ReadStringFromConfigFile(section, key), out var configuredValue))
                    {
                        s_configCache[uniqueKey] = configuredValue;
                        Logger.Info($"Explicit Config: {uniqueKey} = {configuredValue}");
                        return configuredValue;
                    }
                    else
                    {
                        s_configCache[uniqueKey] = defaultValue;
                        Logger.Info($"Default Config: {uniqueKey} = {defaultValue}");
                        return defaultValue;
                    }
                }
            }
        }

        /// <summary>
        /// Get a NameValueCollection setting from application configuration file, and convert it to an unsigned short.
        /// </summary>
        /// <param name="section">section name</param>
        /// <param name="key">setting key</param>
        /// <param name="defaultValue">The default value if section or key does not exist, or the setting's value is not a valid unsigned short.
        /// If not provided, 0 is used. </param>
        /// <returns></returns>
        public static ushort GetUInt16(string section, string key, ushort defaultValue = 0)
        {
            lock (s_configCache)
            {
                var uniqueKey = $"{section}/{key}";
                if (s_configCache.ContainsKey(uniqueKey))
                {
                    return (ushort)s_configCache[uniqueKey];
                }
                else
                {
                    if (ushort.TryParse(ReadStringFromConfigFile(section, key), out var configuredValue))
                    {
                        s_configCache[uniqueKey] = configuredValue;
                        Logger.Info($"Explicit Config: {uniqueKey} = {configuredValue}");
                        return configuredValue;
                    }
                    else
                    {
                        s_configCache[uniqueKey] = defaultValue;
                        Logger.Info($"Default Config: {uniqueKey} = {defaultValue}");
                        return defaultValue;
                    }
                }
            }
        }

        /// <summary>
        /// Get a NameValueCollection setting from application configuration file, and convert it to a double number.
        /// </summary>
        /// <param name="section">section name</param>
        /// <param name="key">setting key</param>
        /// <param name="defaultValue">The default value if section or key does not exist, or the setting's value is not a valid double number.
        /// If not provided, 0.0 is used. </param>
        /// <returns></returns>
        public static double GetDouble(string section, string key, double defaultValue = 0.0)
        {
            lock (s_configCache)
            {
                var uniqueKey = $"{section}/{key}";
                if (s_configCache.ContainsKey(uniqueKey))
                {
                    return (double)s_configCache[uniqueKey];
                }
                else
                {
                    if (double.TryParse(ReadStringFromConfigFile(section, key), out var configuredValue))
                    {
                        s_configCache[uniqueKey] = configuredValue;
                        Logger.Info($"Explicit Config: {uniqueKey} = {configuredValue}");
                        return configuredValue;
                    }
                    else
                    {
                        s_configCache[uniqueKey] = defaultValue;
                        Logger.Info($"Default Config: {uniqueKey} = {defaultValue}");
                        return defaultValue;
                    }
                }
            }
        }

    }
}
