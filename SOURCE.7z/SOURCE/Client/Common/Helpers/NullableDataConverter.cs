﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using AMAT.R2R.Client.Common.Constants;

namespace AMAT.R2R.Client.Common.Helpers
{
    public static class NullableDataConverter
    {
        // for containing Mapping
        private static readonly Dictionary<Type, Delegate> s_mapper = new Dictionary<Type, Delegate>
        {
            { typeof(int?), new Func<object, int?>(TryConvertToInt) },
            { typeof(long?), new Func<object, long?>(TryConvertToLong)},
            { typeof(double?), new Func<object, double?>(TryConvertToDouble)},
            { typeof(decimal?), new Func<object, decimal?>(TryConvertToDecimal)},
            { typeof(bool?), new Func<object, bool?>(TryConvertToBool)},
            { typeof(DateTime?), new Func<object, DateTime?>(TryConvertToDateTime)},
            { typeof(string), new Func<object, string>(TryConvertToString)},
        };

        // currently TryParse function does not allow "T", "F" value for converting target.
        // only String.falseValue, String.trueValue are accepted of target of converting.
        private static readonly List<string> s_lowercasedFalseString = new List<string>
        {
            "false",
            "f",
            "n",
            "no",
            "0"
        };

        private static readonly List<string> s_lowercasedTrueString = new List<string>
        {
            "true",
            "t",
            "y",
            "yes",
            "1"
        };

        private static readonly string[] s_dateFormats = new string[]
        {
            DateTimeFormats.DefaultDateTimeFormat,
            DateTimeFormats.DefaultTimeStampFormat,
            DateTimeFormats.ClrTimeStampFormat,
            DateTimeFormats.ClrDateTimeFormat,
            DateTimeFormats.NonSpaceDateTimeFormat,
        };

        // Indexer to get convert method
        /// <summary>
        /// indexer to find ot correspoing converting delegate
        /// </summary>
        /// <param name="type">source type</param>
        /// <returns>Delegated method which provide convert.</returns>
        private static Delegate GetDelegate<T>() where T : struct
        {
            var type = typeof(T?);
            Delegate returnVal;
            if (s_mapper.ContainsKey(type))
            {
                returnVal = s_mapper[type];
            }
            else
            {
                // by default, use stringConverter.
                returnVal = s_mapper[typeof(string)];
            }
            return returnVal;
        }

        #region Definition for Convert

        /// <summary>
        /// Supports conversion of object.ToString() to Nullable bool, int, long, double, string, DateTime.
        /// </summary>
        /// <typeparam name="T"> bool, int, long, double, string or DateTime</typeparam>
        /// <param name="source">object to be converted.</param>
        /// <returns>Convert result of a Nullable generic type for specified value type.</returns>
        public static T? Convert<T>(object source) where T : struct
        {
            var type = typeof(T);
            if (type.IsEnum)
            {
                if (source != null && type.IsEnumDefined(source.ToString()))
                {
                    return (T)source;
                }
                else
                {
                    return null;
                }
            }

            if (GetDelegate<T>() is Func<object, T?> converter)
            {
                return converter.Invoke(source);
            }
            else
            {
                return null;
            }
        }

        #endregion Definition for Convert

        #region Define Convert Methods

        /// <summary>
        /// DefaultConverter
        /// </summary>
        /// <returns>Converted value from source.</returns>
        private static string TryConvertToString(object source)
        {
            return source?.ToString();
        }

        /// <summary>
        /// Converts passed object to <see cref="long?"/>
        /// </summary>
        /// <param name="source">value which will be converted to</param>
        /// <returns>Converted value from source.</returns>
        private static long? TryConvertToLong(object source)
        {
            return source == null ? null : long.TryParse(source.ToString(), out var longValue) ? longValue : (long?)null;
        }

        /// <summary>
        /// Converted passed object to <see cref="int?"/>
        /// </summary>
        /// <param name="source">value which will be converted to</param>
        /// <returns>Converted value from source.</returns>
        private static int? TryConvertToInt(object source)
        {
            return source == null ? null : int.TryParse(source.ToString(), out var intValue) ? intValue : (int?)null;
        }

        /// <summary>
        /// Converted passed object to <see cref="double?"/>
        /// </summary>
        /// <param name="source">value which will be converted to</param>
        /// <returns>Converted value from source.</returns>
        private static double? TryConvertToDouble(object source)
        {
            return source == null ? null : double.TryParse(source.ToString(), out var doubleValue) ? doubleValue : (double?)null;
        }

        /// <summary>
        /// Converted passed object to <see cref="decimal?"/>
        /// </summary>
        /// <param name="source">value which will be converted to</param>
        /// <returns>Converted value from source.</returns>
        private static decimal? TryConvertToDecimal(object source)
        {
            return source == null ? null : decimal.TryParse(source.ToString(), out var decimalValue) ? decimalValue : (decimal?)null;
        }

        /// <summary>
        /// Converted passed object to <see cref="bool?"/>
        /// </summary>
        /// <param name="source">value which will be converted to</param>
        /// <returns>Converted value from source.</returns>
        private static bool? TryConvertToBool(object source)
        {
            bool? result;
            if (source == null)
            {
                result = null;
            }
            else
            {
                if (s_lowercasedFalseString.Contains(source.ToString().ToLower()))
                {
                    result = false;
                }
                else
                {
                    if (s_lowercasedTrueString.Contains(source.ToString().ToLower()))
                    {
                        result = true;
                    }
                    else
                    {
                        result = bool.TryParse(source.ToString(), out var boolValue) ? boolValue : (bool?)null;
                    }
                }
            }

            return result;
        }

        /// <summary>
        /// Converted passed object to <see cref="DateTime?"/>
        /// </summary>
        /// <param name="source">value which will be converted to</param>
        /// <returns>Converted value from source.</returns>
        private static DateTime? TryConvertToDateTime(object source)
        {
            if (source == null) return null;

            if (source is DateTime || source is DateTime?)
            {
                return (DateTime?)source;
            }

            DateTime? result = null;
            // by deafult set current time

            if (DateTime.TryParseExact(source.ToString(),
                                       s_dateFormats,
                                       CultureInfo.InvariantCulture,
                                       DateTimeStyles.AssumeLocal,
                                       out var dateTimeValue))
            {
                result = dateTimeValue;
            }

            return result;
        }

        #endregion Define Convert Methods
    }
}
