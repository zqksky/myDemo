﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NLog;

namespace AMAT.R2R.Client.Common.Helpers
{
    public class Logger
    {
        private static readonly NLog.Logger s_infoLogger;
        private static readonly NLog.Logger s_traceLogger;
        private static readonly NLog.Logger s_errorLogger;


        static Logger()
        {
            s_traceLogger = LogManager.GetLogger("trace");
            s_infoLogger = LogManager.GetLogger("info");
            s_errorLogger = LogManager.GetLogger("error");

            s_infoLogger.Trace($"Product Version: {VersionHelper.ProductVersion}");
        }

        //
        // Summary:
        //     Writes the diagnostic message at the Trace level.
        //
        // Parameters:
        //   message:
        //     Log message.
        public static void Trace([Localizable(false)] string message = "")
        {
            s_traceLogger.Trace(message);
        }

        //
        // Summary:
        //     Writes the diagnostic message at the Trace level using the specified parameters.
        //
        // Parameters:
        //   message:
        //     A string containing format items.
        //
        //   args:
        //     Arguments to format.
        [MessageTemplateFormatMethod("message")]
        public static void Trace([Localizable(false)] string message, params object[] args)
        {
            s_traceLogger.Trace(message, args);
        }

        //
        // Summary:
        //     Writes the diagnostic message and exception at the Trace level.
        //
        // Parameters:
        //   message:
        //     A string to be written.
        //
        //   exception:
        //     An exception to be logged.
        public static void Trace(Exception exception, [Localizable(false)] string message = "")
        {
            s_traceLogger.Trace(exception, message);
        }

        //
        // Summary:
        //     Writes the diagnostic message and exception at the Trace level.
        //
        // Parameters:
        //   message:
        //     A string to be written.
        //
        //   exception:
        //     An exception to be logged.
        //
        //   args:
        //     Arguments to format.
        [MessageTemplateFormatMethod("message")]
        public static void Trace(Exception exception, [Localizable(false)] string message, params object[] args)
        {
            s_traceLogger.Trace(exception, message, args);
        }

        //
        // Summary:
        //     Writes the diagnostic message at the Debug level.
        //
        // Parameters:
        //   message:
        //     Log message.
        public static void Debug([Localizable(false)] string message)
        {
            s_traceLogger.Debug(message);
        }

        //
        // Summary:
        //     Writes the diagnostic message at the Debug level using the specified parameters.
        //
        // Parameters:
        //   message:
        //     A string containing format items.
        //
        //   args:
        //     Arguments to format.
        [MessageTemplateFormatMethod("message")]
        public static void Debug([Localizable(false)] string message, params object[] args)
        {
            s_traceLogger.Debug(message, args);
        }

        //
        // Summary:
        //     Writes the diagnostic message and exception at the Debug level.
        //
        // Parameters:
        //   message:
        //     A string to be written.
        //
        //   exception:
        //     An exception to be logged.
        public static void Debug(Exception exception, [Localizable(false)] string message = "")
        {
            s_traceLogger.Debug(exception, message);
        }

        //
        // Summary:
        //     Writes the diagnostic message and exception at the Debug level.
        //
        // Parameters:
        //   message:
        //     A string to be written.
        //
        //   exception:
        //     An exception to be logged.
        //
        //   args:
        //     Arguments to format.
        [MessageTemplateFormatMethod("message")]
        public static void Debug(Exception exception, [Localizable(false)] string message, params object[] args)
        {
            s_traceLogger.Debug(exception, message, args);
        }

        //
        // Summary:
        //     Writes the diagnostic message at the Info level.
        //
        // Parameters:
        //   message:
        //     Log message.
        public static void Info([Localizable(false)] string message)
        {
            s_infoLogger.Info(message);
        }

        //
        // Summary:
        //     Writes the diagnostic message at the Info level using the specified parameters.
        //
        // Parameters:
        //   message:
        //     A string containing format items.
        //
        //   args:
        //     Arguments to format.
        [MessageTemplateFormatMethod("message")]
        public static void Info([Localizable(false)] string message, params object[] args)
        {
            s_infoLogger.Info(message, args);
        }

        //
        // Summary:
        //     Writes the diagnostic message and exception at the Info level.
        //
        // Parameters:
        //   message:
        //     A string to be written.
        //
        //   exception:
        //     An exception to be logged.
        public static void Info(Exception exception, [Localizable(false)] string message = "")
        {
            s_infoLogger.Info(exception, message);
        }

        //
        // Summary:
        //     Writes the diagnostic message and exception at the Info level.
        //
        // Parameters:
        //   message:
        //     A string to be written.
        //
        //   exception:
        //     An exception to be logged.
        //
        //   args:
        //     Arguments to format.
        [MessageTemplateFormatMethod("message")]
        public static void Info(Exception exception, [Localizable(false)] string message, params object[] args)
        {
            s_infoLogger.Info(exception, message, args);
        }

        //
        // Summary:
        //     Writes the diagnostic message at the Warn level.
        //
        // Parameters:
        //   message:
        //     Log message.
        public static void Warn([Localizable(false)] string message)
        {
            s_infoLogger.Warn(message);
        }

        //
        // Summary:
        //     Writes the diagnostic message at the Warn level using the specified parameters.
        //
        // Parameters:
        //   message:
        //     A string containing format items.
        //
        //   args:
        //     Arguments to format.
        [MessageTemplateFormatMethod("message")]
        public static void Warn([Localizable(false)] string message, params object[] args)
        {
            s_infoLogger.Warn(message, args);
        }

        //
        // Summary:
        //     Writes the diagnostic message and exception at the Warn level.
        //
        // Parameters:
        //   message:
        //     A string to be written.
        //
        //   exception:
        //     An exception to be logged.
        public static void Warn(Exception exception, [Localizable(false)] string message = "")
        {
            s_infoLogger.Warn(exception, message);
        }

        //
        // Summary:
        //     Writes the diagnostic message and exception at the Warn level.
        //
        // Parameters:
        //   message:
        //     A string to be written.
        //
        //   exception:
        //     An exception to be logged.
        //
        //   args:
        //     Arguments to format.
        [MessageTemplateFormatMethod("message")]
        public static void Warn(Exception exception, [Localizable(false)] string message, params object[] args)
        {
            s_infoLogger.Warn(exception, message, args);
        }

        //
        // Summary:
        //     Writes the diagnostic message at the Error level.
        //
        // Parameters:
        //   message:
        //     Log message.
        public static void Error([Localizable(false)] string message)
        {
            s_errorLogger.Error(message);
        }

        //
        // Summary:
        //     Writes the diagnostic message at the Error level using the specified parameters.
        //
        // Parameters:
        //   message:
        //     A string containing format items.
        //
        //   args:
        //     Arguments to format.
        [MessageTemplateFormatMethod("message")]
        public static void Error([Localizable(false)] string message, params object[] args)
        {
            s_errorLogger.Error(message, args);
        }

        //
        // Summary:
        //     Writes the diagnostic message and exception at the Error level.
        //
        // Parameters:
        //   message:
        //     A string to be written.
        //
        //   exception:
        //     An exception to be logged.
        public static void Error(Exception exception, [Localizable(false)] string message = "")
        {
            s_errorLogger.Error(exception, message);
        }

        //
        // Summary:
        //     Writes the diagnostic message and exception at the Error level.
        //
        // Parameters:
        //   message:
        //     A string to be written.
        //
        //   exception:
        //     An exception to be logged.
        //
        //   args:
        //     Arguments to format.
        [MessageTemplateFormatMethod("message")]
        public static void Error(Exception exception, [Localizable(false)] string message, params object[] args)
        {
            s_errorLogger.Error(exception, message, args);
        }

        //
        // Summary:
        //     Writes the diagnostic message at the Fatal level.
        //
        // Parameters:
        //   message:
        //     Log message.
        public static void Fatal([Localizable(false)] string message)
        {
            s_errorLogger.Fatal(message);
        }

        //
        // Summary:
        //     Writes the diagnostic message at the Fatal level using the specified parameters.
        //
        // Parameters:
        //   message:
        //     A string containing format items.
        //
        //   args:
        //     Arguments to format.
        [MessageTemplateFormatMethod("message")]
        public static void Fatal([Localizable(false)] string message, params object[] args)
        {
            s_errorLogger.Fatal(message, args);
        }


        //
        // Summary:
        //     Writes the diagnostic message and exception at the Fatal level.
        //
        // Parameters:
        //   message:
        //     A string to be written.
        //
        //   exception:
        //     An exception to be logged.
        public static void Fatal(Exception exception, [Localizable(false)] string message = "")
        {
            s_errorLogger.Fatal(exception, message);
        }

        //
        // Summary:
        //     Writes the diagnostic message and exception at the Fatal level.
        //
        // Parameters:
        //   message:
        //     A string to be written.
        //
        //   exception:
        //     An exception to be logged.
        //
        //   args:
        //     Arguments to format.
        [MessageTemplateFormatMethod("message")]
        public static void Fatal(Exception exception, [Localizable(false)] string message, params object[] args)
        {
            s_errorLogger.Fatal(exception, message, args);
        }

        ///// <summary>
        ///// Log the start of a performance log.  This method should be called in the beginning of a method, and the corresponding <see cref="PerformanceStop(string)"/> 
        ///// with the same <paramref name="name"/> must be called in the same method by the same thread. 
        ///// In practice, put <see cref="PerformanceStart(string)"/> in the beginning of a try block, and put <see cref="PerformanceStop(string)"/> in the beginning of the finally block.
        ///// </summary>
        //public static void PerformanceStart(string name)
        //{
        //    if (name != null && !string.IsNullOrEmpty(name.ToString()))
        //    {
        //        PerformanceHelper.StartPerformance(name.ToString());
        //    }
        //}



        ///// <summary>
        ///// Log the end of a performance log. This method should be called in the beginning of a method, and the corresponding <see cref="PerformanceStart(string)"/> 
        ///// with the same <paramref name="name"/> must be called in the same method by the same thread. 
        ///// In practice, put <see cref="PerformanceStart(string)"/> in the beginning of a try block, and put <see cref="PerformanceStop(string)"/> in the beginning of the finally block.
        ///// </summary>
        //public static void PerformanceStop(string name)
        //{
        //    if (name != null && !string.IsNullOrEmpty(name))
        //    {
        //        PerformanceHelper.StopPerformance(name);
        //    }
        //}


        ///// <summary>
        ///// Log the start of a performance log. This method should be called in the beginning of a method, and the corresponding <see cref="PerformanceStop"/> must be called
        ///// in the same method by the same thread. 
        ///// In practice, put <see cref="PerformanceStart"/> in the beginning of a try block, and put <see cref="PerformanceStop"/> in the beginning of the finally block.
        ///// </summary>
        //public static void PerformanceStart()
        //{
        //    var stopWatch = new Stopwatch();
        //    stopWatch.Start();

        //    var stackFrame = new StackFrame(1, true);
        //    var filePath = stackFrame.GetFileName();
        //    var methodName = stackFrame.GetMethod().Name;

        //    stopWatch.Stop();

        //    PerformanceHelper.StartPerformance(filePath, methodName, stopWatch.ElapsedTicks);
        //}


        ///// <summary>
        ///// Log the end of a performance log. This method should be called in the beginning of a method, and the corresponding <see cref="PerformanceStart"/> must be called
        ///// in the same method by the same thread. 
        ///// In practice, put <see cref="PerformanceStart"/> in the beginning of a try block, and put <see cref="PerformanceStop"/> in the beginning of the finally block.
        ///// </summary>
        //public static void PerformanceStop()
        //{
        //    var stopWatch = new Stopwatch();
        //    stopWatch.Start();

        //    var stackFrame = new StackFrame(1, true);
        //    var filePath = stackFrame.GetFileName();
        //    var methodName = stackFrame.GetMethod().Name;

        //    stopWatch.Stop();

        //    PerformanceHelper.StopPerformance(filePath, methodName, stopWatch.ElapsedTicks);
        //}


        /// <summary>
        /// Log the start of a performance log.  
        /// This method should be called in the beginning of a method, and the corresponding <see cref="PerformanceStart(string, Guid)"/> 
        /// with the same <paramref name="name"/> and <paramref name="guid"/> must be called in the same method by the same thread. 
        /// In practice, put <see cref="PerformanceStart(string, Guid)"/> in the beginning of a try block, and put <see cref="PerformanceStop(string, Guid)"/> in the beginning of the finally block.
        /// </summary>
        public static void PerformanceStart(string name, Guid guid)
        {
            if (!string.IsNullOrEmpty(name))
            {
                PerformanceHelper.StartPerformance(name, guid);
            }
        }

        /// <summary>
        /// Log the end of a performance log.  
        /// This method should be called in the beginning of a method, and the corresponding <see cref="PerformanceStop(string, Guid)"/> 
        /// with the same <paramref name="name"/> and <paramref name="guid"/> must be called in the same method by the same thread. 
        /// In practice, put <see cref="PerformanceStart(string, Guid)"/> in the beginning of a try block, and put <see cref="PerformanceStop(string, Guid)"/> in the beginning of the finally block.
        /// </summary>
        public static void PerformanceStop(string name, Guid guid)
        {
            if (!string.IsNullOrEmpty(name))
            {
                PerformanceHelper.StopPerformance(name, guid);
            }
        }
    }

    internal class PerformanceHelper
    {
        private static readonly NLog.Logger s_performanceHelperLog;

        internal static long FrequencyMilliseconds;

        static PerformanceHelper()
        {
            s_performanceHelperLog = LogManager.GetLogger("performance");
            s_performanceHelperLog.Trace($"Product Version: {VersionHelper.ProductVersion}");
            FrequencyMilliseconds = (long)Math.Round(Stopwatch.Frequency / 1000d);
            s_performanceCounterByGuid = new Dictionary<string, PerformanceCounter>();
        }

        private static readonly Dictionary<string, PerformanceCounter> s_performanceCounterByGuid;
        private const string SpacePlaceHodlerForElapsedTime = "          ";
        internal static void StartPerformance(string name, Guid guid)
        {
            var strGuid = guid.ToString();
            var key = $"{name}_{strGuid}";

            lock (s_performanceCounterByGuid)
            {
                s_performanceCounterByGuid.Add(key, new PerformanceCounter(name));
                s_performanceHelperLog.Info($"{SpacePlaceHodlerForElapsedTime} [S] {name}\t{strGuid}");
            }
        }


        internal static void StopPerformance(string name, Guid guid)
        {
            var strGuid = guid.ToString();
            var key = $"{name}_{strGuid}";

            lock (s_performanceCounterByGuid)
            {
                if (s_performanceCounterByGuid.ContainsKey(key) && s_performanceCounterByGuid[key].IsRunning)
                {
                    s_performanceHelperLog.Info($"{GetElapsedStr(s_performanceCounterByGuid[key].Stop())} [C] {name}\t{strGuid}");
                    s_performanceCounterByGuid.Remove(key);
                }
                else
                {
                    s_performanceHelperLog.Warn($"{SpacePlaceHodlerForElapsedTime}     Customized Timer [{key}] stops before starting.");
                }
            }
        }

        private static string GetElapsedStr(double elapsedMilliseconds)
        {
            var elapsedStr = ((int)elapsedMilliseconds).ToString();
            var newSpacePlaseHodler = SpacePlaceHodlerForElapsedTime.Substring(0, SpacePlaceHodlerForElapsedTime.Length - Math.Min(SpacePlaceHodlerForElapsedTime.Length, elapsedStr.Length));
            return $"{newSpacePlaseHodler}{elapsedStr}";
        }
    }

    internal class PerformanceCounter
    {
        private Stopwatch TotalStopwatch { get; set; }

        internal string Name { get; private set; }

        internal string ShortName { get; private set; }

        internal string FilePath { get; private set; }

        internal string MethodName { get; private set; }

        internal int ThreadID { get; private set; }

        internal double LastElapsedMiliSeconds
        {
            get
            {
                return TotalStopwatch.Elapsed.TotalMilliseconds;
            }
        }

        internal long ExtraElapsedTicks { get; set; }

        internal bool IsRunning
        {
            get
            {
                if (TotalStopwatch != null)
                {
                    return TotalStopwatch.IsRunning;
                }

                return false;
            }
        }

        private PerformanceCounter()
        {
            TotalStopwatch = new Stopwatch();
            TotalStopwatch.Start();
        }

        internal PerformanceCounter(string name)
            : this()
        {
            ShortName = name;
        }

        private const string SourceCodeRootDir = "\\R2RUI\\";
        internal PerformanceCounter(string filePath, string methodName)
            : this()
        {
            FilePath = filePath;
            MethodName = methodName;

            if (FilePath != null && FilePath.Contains(SourceCodeRootDir))
            {
                var relativeFilePath = FilePath.Substring(FilePath.IndexOf(SourceCodeRootDir) + SourceCodeRootDir.Length);
                ShortName = string.Format("{0} : {1}", relativeFilePath, MethodName);
            }
            else
            {
                ShortName = string.Format("{0} : {1}", FilePath, MethodName);
            }
        }

        internal void ReStart()
        {
            TotalStopwatch.Restart();
        }

        /// <summary>
        /// Stop timer and return total miliseconds
        /// </summary>
        /// <returns></returns>
        internal double Stop()
        {
            TotalStopwatch.Stop();
            return LastElapsedMiliSeconds;
        }
    }
}
