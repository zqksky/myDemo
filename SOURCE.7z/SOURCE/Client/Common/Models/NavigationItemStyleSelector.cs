﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using DevExpress.Xpf.Accordion;

namespace AMAT.R2R.Client.Common.Models
{
    public class NavigationItemStyleSelector : StyleSelector
    {
        public Style GroupStyle { get; set; }
        public Style FunctionStyle { get; set; }

        public override Style SelectStyle(object item, DependencyObject container)
        {
            if (item is NavigationGroupModel)
            {
                return GroupStyle;
            }
            else if (item is NavigationModel)
            {
                return FunctionStyle;
            }
            else
            {
                return base.SelectStyle(item, container);
            }
        }
    }
}
