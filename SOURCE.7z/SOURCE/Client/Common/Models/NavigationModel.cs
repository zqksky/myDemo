﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Media;

namespace AMAT.R2R.Client.Common.Models
{
    public class NavigationGroupModel
    {
        public string Header { get; set; }
        public ReadOnlyCollection<NavigationModel> SubItems { get; set; }

    }
    public class NavigationModel
    {
        public NavigationModel()
        {
            IsVisible = true;
        }

        public string Header { get; set; }
        public string FunctionType { get; set; }
        public virtual bool IsSelected { get; set; }
        public virtual ImageSource Icon { get; set; }
        public virtual bool IsVisible { get; set; }
    }
}
