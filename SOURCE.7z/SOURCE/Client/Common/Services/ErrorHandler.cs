﻿using System;
using System.Linq;
using AMAT.R2R.Client.Common.Exceptions;
using AMAT.R2R.Client.Common.Helpers;
using AMAT.R2R.Client.Common.Messages;
using DevExpress.Mvvm;

namespace AMAT.R2R.Client.Common.Services
{
    public class ErrorHandler : IErrorHandler
    {
        IMessageBoxService MessageBoxService { get { return ServiceContainer.Default.GetService<IMessageBoxService>(); } }
        ILocalizationService LocalizationService { get { return ServiceContainer.Default.GetService<ILocalizationService>(); } }
        IDispatcherHelperService DispatcherHelperService { get { return ServiceContainer.Default.GetService<IDispatcherHelperService>(); } }

        public ErrorHandler()
        {

        }

        public void HandleError(Exception ex)
        {
            if (ex == null) return;

            Messenger.Default.Send(new WaitMessage(WaitMode.HideAll, ""));


            if (ex is ServerSideException sse)
            {
                if (sse.ErrorCode <= 0)
                {
                    Logger.Warn(ex);
                }
            }
            else
            {
                // none-api exception.
                // log the error details.
                Logger.Error(ex);
            }

            DispatcherHelperService.CheckBeginInvokeOnUI(() =>
            {
                MessageBoxService.ShowMessage(LocalizationService.LocalizeException(ex),
                      LocalizationService.Localize("Error"),
                      MessageButton.OK,
                      MessageIcon.Error);
            });
        }
    }
}
