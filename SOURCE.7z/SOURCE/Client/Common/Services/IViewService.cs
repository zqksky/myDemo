﻿namespace AMAT.R2R.Client.Common.Services
{
    public interface IViewService
    {
        void SetFocus(object dataContext, string path);
        void SetFocus(string path);
    }
}
