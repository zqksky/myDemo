﻿using System;
using System.Linq;
using AMAT.R2R.Client.Common.Exceptions;
using AMAT.R2R.Client.Common.Helpers;
using AMAT.R2R.Client.Common.Messages;
using AMAT.R2R.Client.Common.Views;
using DevExpress.Mvvm;
using DevExpress.Xpf.Core;

namespace AMAT.R2R.Client.Common.Services
{
    public class MessageBoxService : IMessageBoxService
    {
        public MessageResult Show(string messageBoxText, string caption, MessageButton button, MessageIcon icon, MessageResult defaultResult)
        {
            var window = new MessageWindow(messageBoxText, caption, button, icon, defaultResult);

            if (System.Windows.Application.Current.MainWindow != null)
            {
                window.Owner = System.Windows.Application.Current.MainWindow;
            }

            window.ShowDialog();

            return window.Result;
        }
    }
}
