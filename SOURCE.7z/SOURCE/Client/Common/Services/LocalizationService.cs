﻿using System;
using System.Linq;
using AMAT.R2R.Client.Common.Exceptions;
using AMAT.R2R.Client.Common.Helpers;
using DevExpress.Mvvm;

namespace AMAT.R2R.Client.Common.Services
{
    public class LocalizationService : ILocalizationService
    {
        public string Localize(string resourceKey)
        {
            // TODO: get real localized error by code.
            return resourceKey;
        }

        public string LocalizeDialog(int dialogCode, string defaultMessage = "")
        {
            throw new NotImplementedException();
        }

        public string LocalizeError(int errorCode, string defaultMessage = "")
        {
            bool foundResourceByCode = false;

            if (foundResourceByCode)
            {
                // TODO: get real localized error by code.
                return errorCode.ToString();
            }
            else
            {
                //if (string.IsNullOrEmpty(defaultMessage))
                //{
                //    return $"ErrorCode: {errorCode} Localized Resource not found for this code.";
                //}
                //else
                {
                    return $"{Localize("ErrorCode")}: {errorCode}, {Localize("ErrorMessage")}: {defaultMessage}";
                }
            }
        }

        public string LocalizeException(Exception ex)
        {
            string message;
            if (ex is ServerSideException sse)
            {
                if (sse.ErrorCode > 0)
                {
                    message = LocalizeError(sse.ErrorCode, sse.Message);
                    // expected error. no need to log. only notify user.
                }
                else
                {
#if DEBUG
                    // show detailed information of the exception at DEBUG mode.
                    message = $"{ LocalizeError(sse.ErrorCode)} : {sse.Message}";
#else
                    // only show message section of the sse.Message at Release mode.
                    message = $"{ LocalizeError(sse.ErrorCode)} : {sse?.Message?.Split('\n')?.FirstOrDefault()}";
#endif
                }
            }
            else
            {
                //by zqk note ex==null
                // no code, not localizable, show the message.
                message = ex.GetInnerestException().Message;
            }

            return message;
        }
    }
}
