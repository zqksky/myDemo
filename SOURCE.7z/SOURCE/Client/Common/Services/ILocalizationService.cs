﻿using System;

namespace AMAT.R2R.Client.Common.Services
{
    public interface ILocalizationService
    {
        string Localize(string resourceKey);
        string LocalizeError(int errorCode, string defaultMessage = "");
        string LocalizeDialog(int dialogCode, string defaultMessage = "");
        string LocalizeException(Exception ex);
    }
}
