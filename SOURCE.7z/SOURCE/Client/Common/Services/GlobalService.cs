﻿using System;
using System.Collections.Generic;
using System.Reflection;
using System.Threading.Tasks;
using AMAT.R2R.Client.Common.Extensions;
using AMAT.R2R.Client.Common.Helpers;
using AMAT.R2R.Client.Common.Messages;
using AMAT.R2R.Client.Common.Services;
using AMAT.R2R.Shared.Base.DTO;
using AMAT.R2R.Shared.Etch.DTO;
using DevExpress.Mvvm;

namespace AMAT.R2R.Client.Common.Services
{
    public class GlobalService : IGlobalService
    {
        const string HistoryEndpoint = "history";
        const string ToolEndpoint = "tool";
        const string ChamberEndpoint = "chamber";
        const string ParameterEndpoint = "parameter";
        const string ContextGroupEndpoint = "contextGroup";
        const string MetroParameterEndpoint = "metroParameter";
        const string GOFItemEndpoint = "gofitem";

        public IEnumerable<TransactionHistory> GetHistory(string module, string tableName, string contextValue, string contextValue1)
        {
            var guid = Guid.NewGuid();
            var method = nameof(GetHistory);
            Logger.PerformanceStart(method, guid);
            try
            {
                return Api.Current.GetList<TransactionHistory>(HistoryEndpoint,
                        new QueryFilter("module", module),
                        new QueryFilter("tableName", tableName),
                        new QueryFilter("contextValue", contextValue),
                        new QueryFilter("contextValue1", contextValue1)
                        );
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }
        }

        public async Task<List<TransactionHistory>> GetHistoryAsync(string module, string tableName, string contextValue, string contextValue1)
        {
            var guid = Guid.NewGuid();
            var method = nameof(GetHistoryAsync);
            Logger.PerformanceStart(method, guid);
            try
            {
                return await Api.Current.GetListAsync<TransactionHistory>(HistoryEndpoint,
                        new QueryFilter("module", module),
                        new QueryFilter("tableName", tableName),
                        new QueryFilter("contextValue", contextValue),
                        new QueryFilter("contextValue1", contextValue1)
                        );
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }
        }

        public async Task<List<Tool>> GetToolListAsync()
        {
            var guid = Guid.NewGuid();
            var method = nameof(GetToolListAsync);
            Logger.PerformanceStart(method, guid);
            try
            {
                return await Api.Current.GetListAsync<Tool>(ToolEndpoint);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }
        }

        public async Task<List<Chamber>> GetChamberListAsync(string toolId)
        {
            var guid = Guid.NewGuid();
            var method = nameof(GetChamberListAsync);
            Logger.PerformanceStart(method, guid);
            try
            {
                return await Api.Current.GetListAsync<Chamber>($"{ToolEndpoint}/{toolId.EscapeUrlChar()}/{ChamberEndpoint}");
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }
        }

        public async Task<List<Parameter>> GetProcessParameterListAsync(string toolId, string chamberId)
        {
            var guid = Guid.NewGuid();
            var method = nameof(GetProcessParameterListAsync);
            Logger.PerformanceStart(method, guid);
            try
            {
                return await Api.Current.GetListAsync<Parameter>($"{ToolEndpoint}/{toolId.EscapeUrlChar()}/{ChamberEndpoint}/{chamberId.EscapeUrlChar()}/{ParameterEndpoint}");
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }
        }


        public async Task<List<string>> GetContextGroupListAsync()
        {
            var guid = Guid.NewGuid();
            var method = nameof(GetContextGroupListAsync);
            Logger.PerformanceStart(method, guid);
            try
            {
                return await Api.Current.GetListAsync<string>($"{ContextGroupEndpoint}");
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }
        }


        public List<Parameter> GetMetroParameterList()
        {
            var guid = Guid.NewGuid();
            var method = nameof(GetMetroParameterList);
            Logger.PerformanceStart(method, guid);
            try
            {
                return Api.Current.GetList<Parameter>($"{MetroParameterEndpoint}");
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }
        }
        public async Task<List<Parameter>> GetMetroParameterListAsync()
        {
            var guid = Guid.NewGuid();
            var method = nameof(GetMetroParameterList);
            Logger.PerformanceStart(method, guid);
            try
            {
                return await Api.Current.GetListAsync<Parameter>($"{MetroParameterEndpoint}");
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }
        }

        public List<string> GetGOFItemList()
        {
            var guid = Guid.NewGuid();
            var method = nameof(GetGOFItemList);
            Logger.PerformanceStart(method, guid);
            try
            {
                return Api.Current.GetList<string>($"{GOFItemEndpoint}");
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }
        }

        public async Task<Tool> GetToolAsync(string toolId)
        {
            var guid = Guid.NewGuid();
            var method = nameof(GetToolAsync);
            Logger.PerformanceStart(method, guid); 
            try
            {
                return await Api.Current.GetSingleAsync<Tool>($"{ToolEndpoint}/{toolId.EscapeUrlChar()}");
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }
        }

        public async Task<Tool> CreateToolAsync(Tool newTool, string comment)
        {
            var guid = Guid.NewGuid();
            var method = nameof(CreateToolAsync);
            Logger.PerformanceStart(method, guid); 
            try
            {
                return await Api.Current.PostNewAsync($"{ToolEndpoint}", newTool, comment);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }
        }

        public async Task UpdateToolAsync(string toolId, Tool newTool, string comment)
        {
            var guid = Guid.NewGuid();
            var method = nameof(UpdateToolAsync);
            Logger.PerformanceStart(method, guid);
            try
            {
                await Api.Current.PutUpdateAsync($"{ToolEndpoint}/{toolId.EscapeUrlChar()}", newTool, comment);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }
        }

        public async Task DeleteToolAsync(string toolId, string comment)
        {
            var guid = Guid.NewGuid();
            var method = nameof(DeleteToolAsync);
            Logger.PerformanceStart(method, guid);
            try
            {
                await Api.Current.DeleteAsync($"{ToolEndpoint}/{toolId.EscapeUrlChar()}", comment);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }
        }

        public async Task<Chamber> GetChamberAsync(string toolId, string chamberId)
        {
            var guid = Guid.NewGuid();
            var method = nameof(GetChamberAsync);
            Logger.PerformanceStart(method, guid);
            try
            {
                return await Api.Current.GetSingleAsync<Chamber>($"{ToolEndpoint}/{toolId.EscapeUrlChar()}/{ChamberEndpoint}/{chamberId.EscapeUrlChar()}");
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }
        }

        public async Task<Chamber> CreateChamberAsync(string toolId, Chamber newChamber, string comment)
        {
            var guid = Guid.NewGuid();
            var method = nameof(CreateChamberAsync);
            Logger.PerformanceStart(method, guid);
            try
            {
                return await Api.Current.PostNewAsync($"{ToolEndpoint}/{toolId.EscapeUrlChar()}/{ChamberEndpoint}", newChamber, comment);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }
        }

        public async Task UpdateChamberAsync(string toolId, string chamberId, Chamber newChamber, string comment)
        {
            var guid = Guid.NewGuid();
            var method = nameof(UpdateChamberAsync);
            Logger.PerformanceStart(method, guid);
            try
            {
                await Api.Current.PutUpdateAsync($"{ToolEndpoint}/{toolId.EscapeUrlChar()}/{ChamberEndpoint}/{chamberId.EscapeUrlChar()}", newChamber, comment);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }
        }

        public async Task DeleteChamberAsync(string toolId, string chamberId, string comment)
        {
            var guid = Guid.NewGuid();
            var method = nameof(DeleteChamberAsync);
            Logger.PerformanceStart(method, guid);
            try
            {
                await Api.Current.DeleteAsync($"{ToolEndpoint}/{toolId.EscapeUrlChar()}/{ChamberEndpoint}/{chamberId.EscapeUrlChar()}", comment);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }
        }

        public async Task<Parameter> GetParameterAsync(string toolId, string chamberId, string parameterName)
        {
            var guid = Guid.NewGuid();
            var method = nameof(GetParameterAsync);
            Logger.PerformanceStart(method, guid);
            try
            {
                return await Api.Current.GetSingleAsync<Parameter>($"{ToolEndpoint}/{toolId.EscapeUrlChar()}/{ChamberEndpoint}/{chamberId.EscapeUrlChar()}/{ParameterEndpoint}/{parameterName.EscapeUrlChar()}");
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }
        }

        public async Task<Parameter> CreateParameterAsync(string toolId, string chamberId, Parameter newParameter, string comment)
        {
            var guid = Guid.NewGuid();
            var method = nameof(CreateParameterAsync);
            Logger.PerformanceStart(method, guid);
            try
            {
                return await Api.Current.PostNewAsync($"{ToolEndpoint}/{toolId.EscapeUrlChar()}/{ChamberEndpoint}/{chamberId.EscapeUrlChar()}/{ParameterEndpoint}", newParameter, comment);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }
        }

        public async Task UpdateParameterAsync(string toolId, string chamberId, string parameterName, Parameter newParameter, string comment)
        {
            var guid = Guid.NewGuid();
            var method = nameof(UpdateParameterAsync);
            Logger.PerformanceStart(method, guid);
            try
            {
                await Api.Current.PutUpdateAsync($"{ToolEndpoint}/{toolId.EscapeUrlChar()}/{ChamberEndpoint}/{chamberId.EscapeUrlChar()}/{ParameterEndpoint}/{parameterName.EscapeUrlChar()}", newParameter, comment);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }
        }

        public async Task DeleteParameterAsync(string toolId, string chamberId, string parameterName, string comment)
        {
            var guid = Guid.NewGuid();
            var method = nameof(DeleteParameterAsync);
            Logger.PerformanceStart(method, guid);
            try
            {
                await Api.Current.DeleteAsync($"{ToolEndpoint}/{toolId.EscapeUrlChar()}/{ChamberEndpoint}/{chamberId.EscapeUrlChar()}/{ParameterEndpoint}/{parameterName.EscapeUrlChar()}", comment);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }
        }
    }
}
