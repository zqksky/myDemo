﻿using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Threading.Tasks;

namespace AMAT.R2R.Client.Common.Services
{
    public interface IApiService
    {
        T PostNew<T>(string resourceUrl, T obj, string comment = "") where T : new();
        void PutUpdate<T>(string resourceUrl, T obj, string comment = "") where T : new();
        List<T> GetList<T>(string resourceUrl, params QueryFilter[] filters);
        void Delete(string resourceUrl, string comment = "");
        T GetSingle<T>(string resourceUrl);
        void SetToken(string token);

        Task<List<T>> GetListAsync<T>(string resourceUrl, params QueryFilter[] filters);
        Task<List<T>> GetListAsync<T>(string resourceUrl, IList<QueryFilter> filters);
        Task<List<T>> GetListAsync<T>(string resourceUrl, IList<QueryFilter> filters, IList<QuerySorter> sorters);
        Task<List<T>> GetListAsync<T>(string resourceUrl, IList<QueryFilter> filters, IList<QuerySorter> sorters, int? skip, int? take);
        Task<int> GetTotalCountAsync(string resourceUrl, IList<QueryFilter> filters = null);
        Task<object[]> GetValueListAsync(string resourceUrl, string propertyName, IList<QueryFilter> filters = null, IList<QuerySorter> sorters = null);

        Task<T> GetSingleAsync<T>(string resourceUrl);
        Task<T> PostNewAsync<T>(string resourceUrl, T resource, string comment = "") where T : new();
        Task PutUpdateAsync<T>(string resourceUrl, T obj, string comment = "");
        Task DeleteAsync(string resourceUrl, string comment = "");
        Task PutUpdateAsync(string resourceUrl, string comment = "");
        Task DeleteEntityAsync<T>(string resourceUrl, T obj, string comment = "");
        bool IsExecutingApi { get; }
    }

    public class QueryFilter
    {
        public QueryFilter(string propertyName, object value, QueryOperator @operator = QueryOperator.Equals)
        {
            PropertyName = propertyName;

            var type = value?.GetType();
            if(type != null && type.IsArray)
            {
                Value = ((IEnumerable)value)?.Cast<string>().ToArray();
            }
            else
            {
                Value = value?.ToString();
            }
            Operator = @operator;
        }

        public string PropertyName { get; private set; }
        public object Value { get; private set; }
        public QueryOperator Operator { get; private set; }
    }

    public enum QueryOperator
    {
        Equals,
        NotEquals,
        GreaterThan,
        LessThan,
        GreaterThanOrEqualsTo,
        LessThanOrEqualsTo,
        In,
        NotIn,
        Contains,
        StartsWith,
        EndsWith
    }

    public class QuerySorter
    {
        public QuerySorter(string name, ListSortDirection direction)
        {
            PropertyName = name;
            Direction = direction;
        }

        public string PropertyName { get; private set; }
        public ListSortDirection Direction { get; private set; }
    }


    public class ErrorResult
    {
        public int ErrorCode { get; set; }

        public string Message { get; set; }
    }
}
