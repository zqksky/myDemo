﻿
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using AMAT.R2R.Client.Common.Extensions;
using AMAT.R2R.Client.Common.Messages;
using AMAT.R2R.Shared.Base.Constants;
using DevExpress.Mvvm;
using RestSharp;
using RestSharp.Serializers.NewtonsoftJson;

namespace AMAT.R2R.Client.Common.Services
{

    public class ApiService : IApiService
    {
        readonly IRestClient _client;
        readonly List<string> _inProgressTxnList = new List<string>();


        public ApiService(string baseUrl)
        {
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12 | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls;
            _client = new RestClient(baseUrl);

            // default serializer has bugs deserialiing boolean types sometimes. 
            // So DO use NewtonSoft Json Serializer.
            _client.UseNewtonsoftJson();
        }

        public List<T> GetList<T>(string resourceUrl, params QueryFilter[] filters)
        {
            var txnId = Guid.NewGuid().ToString();
            try
            {
                StartTxn(Method.GET, _client.BaseUrl + resourceUrl, txnId);
                var request = new RestRequest(resourceUrl, Method.GET)
                    .AddR2RHeaders(_token);

                if (filters != null)
                {
                    foreach (var param in filters)
                    {
                        request.AddParameter(param.PropertyName, param.Value);
                    }
                }

                var response = _client.Execute<List<T>>(request);

                if (response.IsSuccessful)
                {
                    return response.Data;
                }
                else
                {
                    throw response.ToException();
                }
            }
            finally
            {
                CompleteTxn(txnId);
            }
        }

        public async Task<List<T>> GetListAsync<T>(string resourceUrl, params QueryFilter[] filters)
        {
            return await GetListAsync<T>(resourceUrl, filters.ToList());
        }

        public async Task<List<T>> GetListAsync<T>(string resourceUrl, IList<QueryFilter> filters)
        {
            return await GetListAsync<T>(resourceUrl, filters, null, null, null);
        }

        public async Task<List<T>> GetListAsync<T>(string resourceUrl, IList<QueryFilter> filters, IList<QuerySorter> sorters)
        {
            return await GetListAsync<T>(resourceUrl, filters, sorters, null, null);
        }

        public async Task<List<T>> GetListAsync<T>(string resourceUrl, IList<QueryFilter> filters, IList<QuerySorter> sorters, int? skip, int? take)
        {
            var txnId = Guid.NewGuid().ToString();
            try
            {
                StartTxn(Method.GET, _client.BaseUrl + resourceUrl, txnId);
                var request = new RestRequest(resourceUrl, Method.GET).AddR2RHeaders(_token)
                    .AddFilters(filters)
                    .AddSorters(sorters)
                    .AddPaging(skip, take);

                var response = await _client.ExecuteAsync<List<T>>(request).ConfigureAwait(false);

                if (response.IsSuccessful)
                {
                    return response.Data;
                }
                else
                {
                    throw response.ToException();
                }
            }
            finally
            {
                CompleteTxn(txnId);
            }
        }


        public async Task<int> GetTotalCountAsync(string resourceUrl, IList<QueryFilter> filters = null)
        {
            var txnId = Guid.NewGuid().ToString();
            resourceUrl = $"{resourceUrl}/{QueryWords.ItemsCountEndpoint.EscapeUrlChar()}";
            try
            {
                StartTxn(Method.GET, _client.BaseUrl + resourceUrl, txnId);
                var request = new RestRequest(resourceUrl, Method.GET)
                    .AddR2RHeaders(_token)
                    .AddFilters(filters);

                var response = await _client.ExecuteAsync<int>(request).ConfigureAwait(false);

                if (response.IsSuccessful)
                {
                    return response.Data;
                }
                else
                {
                    throw response.ToException();
                }
            }
            finally
            {
                CompleteTxn(txnId);
            }
        }

        public async Task<object[]> GetValueListAsync(string resourceUrl, string propertyName, IList<QueryFilter> filters = null, IList<QuerySorter> sorters = null)
        {
            var txnId = Guid.NewGuid().ToString();
            resourceUrl = $"{resourceUrl}/{QueryWords.ValueListEndpoint.EscapeUrlChar()}/{propertyName.EscapeUrlChar()}";
            try
            {
                StartTxn(Method.GET, _client.BaseUrl + resourceUrl, txnId);

                var request = new RestRequest(resourceUrl, Method.GET)
                    .AddR2RHeaders(_token)
                    .AddFilters(filters)
                    .AddSorters(sorters);

                var response = await _client.ExecuteAsync<object[]>(request).ConfigureAwait(false);

                if (response.IsSuccessful)
                {
                    return response.Data;
                }
                else
                {
                    throw response.ToException();
                }
            }
            finally
            {
                CompleteTxn(txnId);
            }
        }

        public T GetSingle<T>(string resourceUrl)
        {
            var txnId = Guid.NewGuid().ToString();
            try
            {
                StartTxn(Method.GET, _client.BaseUrl + resourceUrl, txnId);
                var id = resourceUrl.SplitToList("/").LastOrDefault();
                var request = new RestRequest(resourceUrl, Method.GET)
                    .AddR2RHeaders(_token)
                    .AddParameter("id", id, ParameterType.UrlSegment);

                var response = _client.Execute<T>(request);

                if (response.IsSuccessful)
                {
                    return response.Data;
                }
                else
                {
                    throw response.ToException();
                }
            }
            finally
            {
                CompleteTxn(txnId);
            }
        }
        public async Task<T> GetSingleAsync<T>(string resourceUrl)
        {
            var txnId = Guid.NewGuid().ToString();
            StartTxn(Method.GET, _client.BaseUrl + resourceUrl, txnId);
            try
            {
                var id = resourceUrl.SplitToList("/").LastOrDefault();
                var request = new RestRequest($"{resourceUrl}", Method.GET)
                    .AddR2RHeaders(_token)
                    .AddParameter("id", id, ParameterType.UrlSegment);

                var response = await _client.ExecuteAsync<T>(request).ConfigureAwait(false);

                if (response.IsSuccessful)
                {
                    return response.Data;
                }
                else
                {
                    throw response.ToException();
                }
            }
            finally
            {
                CompleteTxn(txnId);
            }
        }

        public T PostNew<T>(string resourceUrl, T resource, string comment = "") where T : new()
        {
            var txnId = Guid.NewGuid().ToString();
            try
            {
                StartTxn(Method.POST, _client.BaseUrl + resourceUrl, txnId);
                var request = new RestRequest(resourceUrl, Method.POST)
                    .AddR2RHeaders(_token, txnId, comment)
                    .AddJsonBody(resource);

                var response = _client.Execute<T>(request);

                if (response.IsSuccessful)
                {
                    return response.Data;
                }
                else
                {
                    throw response.ToException();
                }
            }
            finally
            {
                CompleteTxn(txnId);
            }
        }

        public async Task<T> PostNewAsync<T>(string resourceUrl, T resource, string comment = "") where T : new()
        {
            var txnId = Guid.NewGuid().ToString();
            try
            {
                StartTxn(Method.POST, _client.BaseUrl + resourceUrl, txnId);
                var request = new RestRequest(resourceUrl, Method.POST)
                    .AddR2RHeaders(_token, txnId, comment)
                    .AddJsonBody(resource);

                var response = await _client.ExecuteAsync<T>(request).ConfigureAwait(false);

                if (response.IsSuccessful)
                {
                    return response.Data;
                }
                else
                {
                    throw response.ToException();
                }
            }
            finally
            {
                CompleteTxn(txnId);
            }
        }

        public void PutUpdate<T>(string resourceUrl, T obj, string comment = "") where T : new()
        {
            var txnId = Guid.NewGuid().ToString();
            try
            {
                StartTxn(Method.PUT, _client.BaseUrl + resourceUrl, txnId);
                var id = resourceUrl.SplitToList("/").LastOrDefault();
                var request = new RestRequest(resourceUrl, Method.PUT)
                    .AddR2RHeaders(_token, txnId, comment)
                    .AddParameter("id", id, ParameterType.UrlSegment)
                    .AddJsonBody(obj);

                var response = _client.Execute(request);

                if (!response.IsSuccessful)
                {
                    throw response.ToException();
                }
            }
            finally
            {
                CompleteTxn(txnId);
            }
        }

        public async Task PutUpdateAsync<T>(string resourceUrl, T obj, string comment = "")
        {
            var txnId = Guid.NewGuid().ToString();
            try
            {
                StartTxn(Method.PUT, _client.BaseUrl + resourceUrl, txnId);
                var id = resourceUrl.SplitToList("/").LastOrDefault();
                var request = new RestRequest(resourceUrl, Method.PUT)
                    .AddR2RHeaders(_token, txnId, comment)
                    .AddParameter("id", id, ParameterType.UrlSegment)
                    .AddJsonBody(obj);

                var response = await _client.ExecuteAsync(request).ConfigureAwait(false);

                if (!response.IsSuccessful)
                {
                    throw response.ToException();
                }
            }
            finally
            {
                CompleteTxn(txnId);
            }
        }

        public async Task PutUpdateAsync(string resourceUrl, string comment = "")
        {
            var txnId = Guid.NewGuid().ToString();
            try
            {
                StartTxn(Method.PUT, _client.BaseUrl + resourceUrl, txnId);
                var id = resourceUrl.SplitToList("/").LastOrDefault();
                var request = new RestRequest(resourceUrl, Method.PUT)
                    .AddR2RHeaders(_token, txnId, comment)
                    .AddParameter("id", id, ParameterType.UrlSegment);

                var response = await _client.ExecuteAsync(request).ConfigureAwait(false);

                if (!response.IsSuccessful)
                {
                    throw response.ToException();
                }
            }
            finally
            {
                CompleteTxn(txnId);
            }
        }

        public void Delete(string resourceUrl, string comment = "")
        {
            var txnId = Guid.NewGuid().ToString();
            try
            {
                StartTxn(Method.DELETE, _client.BaseUrl + resourceUrl, txnId);
                var id = resourceUrl.SplitToList("/").LastOrDefault();

                var request = new RestRequest(resourceUrl, Method.DELETE)
                    .AddR2RHeaders(_token, txnId, comment)
                    .AddParameter("id", id, ParameterType.UrlSegment);

                var response = _client.Execute(request);

                if (!response.IsSuccessful)
                {
                    throw response.ToException();
                }
            }
            finally
            {
                CompleteTxn(txnId);
            }
        }

        public async Task DeleteAsync(string resourceUrl, string comment = "")
        {
            var txnId = Guid.NewGuid().ToString();
            try
            {
                StartTxn(Method.DELETE, _client.BaseUrl + resourceUrl, txnId);
                var id = resourceUrl.SplitToList("/").LastOrDefault();

                var request = new RestRequest(resourceUrl, Method.DELETE)
                    .AddR2RHeaders(_token, txnId, comment)
                    .AddParameter("id", id, ParameterType.UrlSegment);

                var response = await _client.ExecuteAsync(request).ConfigureAwait(false);

                if (!response.IsSuccessful)
                {
                    throw response.ToException();
                }
            }
            finally
            {
                CompleteTxn(txnId);
            }
        }

        public async Task DeleteEntityAsync<T>(string resourceUrl, T obj, string comment = "")
        {
            var txnId = Guid.NewGuid().ToString();
            try
            {
                StartTxn(Method.DELETE, _client.BaseUrl + resourceUrl, txnId);
                var request = new RestRequest(resourceUrl, Method.DELETE)
                    .AddR2RHeaders(_token, txnId, comment)
                    .AddJsonBody(obj);

                var response = await _client.ExecuteAsync(request).ConfigureAwait(false);

                if (!response.IsSuccessful)
                {
                    throw response.ToException();
                }
            }
            finally
            {
                CompleteTxn(txnId);
            }
        }

        private string _token = string.Empty;

        public void SetToken(string token)
        {
            _token = token;
        }

        private void StartTxn(Method method, string resourceUrl, string txnId)
        {
            lock (_inProgressTxnList)
            {
                if (!_inProgressTxnList.Contains(txnId))
                {
                    _inProgressTxnList.Add(txnId);
                }
            }

            var methodText = "";
            var isQuery = false;
            switch (method)
            {
                case Method.GET:
                    methodText = "Getting ";
                    isQuery = true;
                    break;
                case Method.POST:
                    methodText = "Creating ";
                    break;
                case Method.PUT:
                    methodText = "Updating ";
                    break;
                case Method.DELETE:
                    methodText = "Deleting ";
                    break;
                case Method.HEAD:
                    break;
                case Method.OPTIONS:
                    break;
                case Method.PATCH:
                    break;
                case Method.MERGE:
                    break;
                case Method.COPY:
                    break;
                default:
                    break;
            }

            Messenger.Default?.Send(new ApiStartedMessage(methodText, resourceUrl, txnId, isQuery));
        }

        private void CompleteTxn(string txnId)
        {
            lock (_inProgressTxnList)
            {
                if (_inProgressTxnList.Contains(txnId))
                {
                    _inProgressTxnList.Remove(txnId);
                }
            }
            Messenger.Default?.Send(new ApiCompletedMessage(txnId));
        }

        public bool IsExecutingApi { get => _inProgressTxnList.Count > 0; }
    }


    public static class RestRequestExtension
    {
        public static IRestRequest AddPaging(this IRestRequest request, int? skip, int? take)
        {
            if (request is null)
            {
                throw new ArgumentNullException(nameof(request));
            }

            if (skip.HasValue && take.HasValue)
            {
                request.AddParameter(QueryWords.Skip, skip);
                request.AddParameter(QueryWords.Take, take);
            }
            return request;
        }

        public static IRestRequest AddSorters(this IRestRequest request, IList<QuerySorter> sorters)
        {
            if (request is null)
            {
                throw new ArgumentNullException(nameof(request));
            }

            if (sorters != null)
            {
                request.AddParameter(QueryWords.Sort, string.Join(QueryWords.ValueSeperator, sorters.Select(s => $"{s.PropertyName}{QueryWords.OrderSeperator}{ConvertDirection(s.Direction)}")).EscapeUrlChar());
            }
            return request;
        }

        private static string ConvertDirection(ListSortDirection direction) => direction == ListSortDirection.Ascending ? QueryWords.OrderAscending : QueryWords.OrderDescending;

        public static IRestRequest AddFilters(this IRestRequest request, IList<QueryFilter> filters)
        {
            if (request is null)
            {
                throw new ArgumentNullException(nameof(request));
            }

            if (filters != null)
            {
                foreach (var filter in filters)
                {
                    switch (filter.Operator)
                    {
                        case QueryOperator.NotEquals:
                            request.AddParameter($"{filter.PropertyName}{QueryWords.OperatorSeperator}{QueryOperators.NotEqualsTo}", filter.Value);
                            break;
                        case QueryOperator.GreaterThan:
                            request.AddParameter($"{filter.PropertyName}{QueryWords.OperatorSeperator}{QueryOperators.GreaterThan}", filter.Value);
                            break;
                        case QueryOperator.LessThan:
                            request.AddParameter($"{filter.PropertyName}{QueryWords.OperatorSeperator}{QueryOperators.LessThan}", filter.Value);
                            break;
                        case QueryOperator.GreaterThanOrEqualsTo:
                            request.AddParameter($"{filter.PropertyName}{QueryWords.OperatorSeperator}{QueryOperators.GreaterThanOrEqualsTo}", filter.Value);
                            break;
                        case QueryOperator.LessThanOrEqualsTo:
                            request.AddParameter($"{filter.PropertyName}{QueryWords.OperatorSeperator}{QueryOperators.LessThanOrEqualsTo}", filter.Value);
                            break;
                        case QueryOperator.In:
                            request.AddParameter($"{filter.PropertyName}{QueryWords.OperatorSeperator}{QueryOperators.In}", string.Join(QueryWords.ValueSeperator, (string[])filter.Value));
                            break;
                        case QueryOperator.NotIn:
                            request.AddParameter($"{filter.PropertyName}{QueryWords.OperatorSeperator}{QueryOperators.NotIn}", string.Join(QueryWords.ValueSeperator, (string[])filter.Value));
                            break;
                        case QueryOperator.Contains:
                            request.AddParameter($"{filter.PropertyName}{QueryWords.OperatorSeperator}{QueryOperators.Contains}", filter.Value);
                            break;
                        case QueryOperator.StartsWith:
                            request.AddParameter($"{filter.PropertyName}{QueryWords.OperatorSeperator}{QueryOperators.StartsWith}", filter.Value);
                            break;
                        case QueryOperator.EndsWith:
                            request.AddParameter($"{filter.PropertyName}{QueryWords.OperatorSeperator}{QueryOperators.EndsWith}", filter.Value);
                            break;
                        default:
                            request.AddParameter(filter.PropertyName, filter.Value);
                            break;
                    }
                }
            }
            else { }
            return request;
        }

    }

}
