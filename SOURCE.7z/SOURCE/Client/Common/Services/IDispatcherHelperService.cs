﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DevExpress.Mvvm;

namespace AMAT.R2R.Client.Common.Services
{
    public interface IDispatcherHelperService : IDispatcherService
    {
        void CheckBeginInvokeOnUI(Action action);
        void RunAsync(Action action);
    }
}
