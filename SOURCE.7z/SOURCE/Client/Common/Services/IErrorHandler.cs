﻿using System;

namespace AMAT.R2R.Client.Common.Services
{
    public interface IErrorHandler
    {
        void HandleError(Exception ex);
    }
}
