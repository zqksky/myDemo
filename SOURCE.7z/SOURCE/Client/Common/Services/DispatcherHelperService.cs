﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AMAT.R2R.Client.Common.Helpers;
using DevExpress.Mvvm.UI;

namespace AMAT.R2R.Client.Common.Services
{
    public class DispatcherHelperService : DispatcherService, IDispatcherHelperService
    {
        public void CheckBeginInvokeOnUI(Action action)
        {
            DispatcherHelper.CheckBeginInvokeOnUI(action);
        }

        public void RunAsync(Action action)
        {
            DispatcherHelper.RunAsync(action);
        }
    }
}
