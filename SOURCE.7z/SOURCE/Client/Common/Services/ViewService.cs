﻿
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using AMAT.R2R.Client.Common.Helpers;
using AMAT.R2R.Client.Common.Interfaces;
using AMAT.R2R.Client.Common.ViewModels;
using DevExpress.Mvvm.UI;
using DevExpress.Xpf.Editors;

namespace AMAT.R2R.Client.Common.Services
{
    public class ViewService : ServiceBase, IViewService
    {
        //public static readonly DependencyProperty MessageProperty =
        //    DependencyProperty.Register("Message", typeof(string), typeof(CustomMessageBoxService), new PropertyMetadata("Hello"));
        //public string Message
        //{
        //    get { return (string)GetValue(MessageProperty); }
        //    set { SetValue(MessageProperty, value); }
        //}

        protected override void OnAttached()
        {
            base.OnAttached();
        }

        protected override void OnDetaching()
        {
            base.OnDetaching();
        }

        public void SetFocus(string bindingName)
        {
            GetErrorControl(AssociatedObject, bindingName)?.Focus();
        }

        private Control GetErrorControl(DependencyObject parentElement, string errorProperty)
        {
            Control errorControl = null;
            var childrenCount = VisualTreeHelper.GetChildrenCount(parentElement);
            for (var i = 0; i < childrenCount; i++)
            {
                var child = VisualTreeHelper.GetChild(parentElement, i);

                if (child is Control controlChild)
                {
                    var bindingProperty = GetBindingPath(controlChild);
                    if (bindingProperty == errorProperty)
                    {
                        errorControl = controlChild;
                        break;
                    }
                }

                errorControl = GetErrorControl(child, errorProperty);
                if (errorControl != null)
                {
                    if (errorControl is DevExpress.Xpf.Grid.GridControl gridControl)
                    {
                        if (gridControl.ItemsSource is System.Collections.IList itemsList && itemsList.Count > 0)
                        {
                            foreach (var item in itemsList)
                            {
                                var index = itemsList.IndexOf(item);
                                if (item is IDataErrorInfo errorInfo && !string.IsNullOrEmpty(errorInfo.Error))
                                {
                                    var rowHandle = gridControl.GetRowHandleByListIndex(index);
                                    if (gridControl.View.GetRowElementByRowHandle(rowHandle) is Control row)
                                    {
                                        gridControl.View.FocusedRowHandle = rowHandle;
                                        break;
                                    }
                                }
                            }
                        }
                    }
                    break;
                }
                else { }
            }
            return errorControl;
        }

        private string GetBindingPath(Control control)
        {
            if (control is TextBox)
            {
                var bindingExpression = control.GetBindingExpression(TextBox.TextProperty);
                if (bindingExpression?.ParentBinding != null)
                {
                    return bindingExpression.ParentBinding.Path.Path;
                }
            }
            else if (control is System.Windows.Controls.Primitives.Selector)
            {
                if (control is ComboBox combo)
                {
                    var bindingExpressionText = combo.GetBindingExpression(ComboBox.TextProperty);
                    if (bindingExpressionText?.ParentBinding != null)
                    {
                        return bindingExpressionText.ParentBinding.Path.Path;
                    }
                }

                var bindingExpression = control.GetBindingExpression(System.Windows.Controls.Primitives.Selector.SelectedItemProperty);
                if (bindingExpression?.ParentBinding != null)
                {
                    return bindingExpression.ParentBinding.Path.Path;
                }
            }
            // DX Controls
            else if (control is BaseEdit)
            {
                var bindingExpressionEditValue = control.GetBindingExpression(BaseEdit.EditValueProperty);
                if (bindingExpressionEditValue?.ParentBinding != null)
                {
                    return bindingExpressionEditValue.ParentBinding.Path.Path;
                }
                else if (control is TextEditBase)
                {
                    var bindingExpressionText = control.GetBindingExpression(TextEditBase.TextProperty);
                    if (bindingExpressionText?.ParentBinding != null)
                    {
                        return bindingExpressionText.ParentBinding.Path.Path;
                    }
                    else if (control is LookUpEditBase)
                    {
                        var bindingExpressionSelectedItem = control.GetBindingExpression(LookUpEditBase.SelectedItemProperty);
                        if (bindingExpressionSelectedItem?.ParentBinding != null)
                        {
                            return bindingExpressionSelectedItem.ParentBinding.Path.Path;
                        }
                    }
                    else if (control is PasswordBoxEdit)
                    {
                        var bindingExpression = control.GetBindingExpression(PasswordBoxEdit.PasswordProperty);
                        if (bindingExpression?.ParentBinding != null)
                        {
                            return bindingExpression.ParentBinding.Path.Path;
                        }
                    }
                }
                else if (control is CheckEdit)
                {
                    bindingExpressionEditValue = control.GetBindingExpression(CheckEdit.IsCheckedProperty);
                    if (bindingExpressionEditValue?.ParentBinding != null)
                    {
                        return bindingExpressionEditValue.ParentBinding.Path.Path;
                    }
                }
            }
            else if (control is DevExpress.Xpf.Grid.GridControl)
            {
                var bindingExpression = control.GetBindingExpression(DevExpress.Xpf.Grid.GridControl.SelectedItemProperty);
                if (bindingExpression?.ParentBinding != null)
                {
                    return bindingExpression.ParentBinding.Path.Path;
                }
                else
                {
                    bindingExpression = control.GetBindingExpression(DevExpress.Xpf.Grid.GridControl.ItemsSourceProperty);
                    if (bindingExpression?.ParentBinding != null)
                    {
                        return bindingExpression.ParentBinding.Path.Path;
                    }
                }
            }
            return string.Empty;
        }

        public void SetFocus(object dataContext, string path)
        {
            DispatcherHelper.RunAsync(() =>
            {
                var control = GetControlByBindingInfo(AssociatedObject, dataContext, path);
                if (control != null)
                {
                    control.Focus();
                }
            });
        }

        private Control GetControlByBindingInfo(DependencyObject parentElement, object dataContext, string path)
        {
            Control control = null;
            if (parentElement == null)
            {
                return control;
            }
            var childrenCount = VisualTreeHelper.GetChildrenCount(parentElement);
            for (var i = 0; i < childrenCount; i++)
            {
                var child = VisualTreeHelper.GetChild(parentElement, i);

                if (child is Control controlChild)
                {
                    if (controlChild.DataContext == dataContext)
                    {
                        var bindingPath = GetBindingPath(controlChild);
                        if (bindingPath == path)
                        {
                            control = controlChild;
                            break;
                        }
                    }
                }

                control = GetControlByBindingInfo(child, dataContext, path);
                if (control != null)
                {
                    break;
                }
                else { }
            }
            return control;
        }
    }
}
