﻿
using System.Collections.Generic;
using System.Threading.Tasks;
using AMAT.R2R.Shared.Base.DTO;
using AMAT.R2R.Shared.Etch.DTO;

namespace AMAT.R2R.Client.Common.Services
{
    public interface IGlobalService
    {
        IEnumerable<TransactionHistory> GetHistory(string module, string tableName, string contextValue, string contextValue1);
        Task<List<TransactionHistory>> GetHistoryAsync(string module, string tableName, string contextValue, string contextValue1);
        Task<List<Tool>> GetToolListAsync();
        Task<List<Chamber>> GetChamberListAsync(string toolId);
        Task<List<string>> GetContextGroupListAsync();
        Task<List<Parameter>> GetProcessParameterListAsync(string toolId, string chamberId);
        List<Parameter> GetMetroParameterList();
        List<string> GetGOFItemList();

        Task<Tool> GetToolAsync(string toolId);
        Task<Tool> CreateToolAsync(Tool newTool, string comment);
        Task UpdateToolAsync(string toolId, Tool newTool, string comment);
        Task DeleteToolAsync(string toolId, string comment);


        Task<Chamber> GetChamberAsync(string toolId, string chamberId);
        Task<Chamber> CreateChamberAsync(string toolId, Chamber newChamber, string comment);
        Task UpdateChamberAsync(string toolId, string chamberId, Chamber newChamber, string comment);
        Task DeleteChamberAsync(string toolId, string chamberId, string comment);


        Task<Parameter> GetParameterAsync(string toolId, string chamberId, string parameterName);
        Task<Parameter> CreateParameterAsync(string toolId, string chamberId, Parameter newParameter, string comment);
        Task UpdateParameterAsync(string toolId, string chamberId, string parameterName, Parameter newParameter, string comment);
        Task DeleteParameterAsync(string toolId, string chamberId, string parameterName, string comment);
        Task<List<Parameter>> GetMetroParameterListAsync();
    }
}
