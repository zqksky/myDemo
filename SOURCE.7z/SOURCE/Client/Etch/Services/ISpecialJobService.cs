﻿
using System.Collections.Generic;
using System.Threading.Tasks;
using AMAT.R2R.Client.Common.Services;
using AMAT.R2R.Client.Etch.Modules.ProcessSettings;
using AMAT.R2R.Client.Etch.Modules.SpecialJobSettings;
using AMAT.R2R.Shared.Base.DTO;
using AMAT.R2R.Shared.Etch.DTO;

namespace AMAT.R2R.Client.Etch.Services
{
    public interface ISpecialJobService
    {
        Task DeleteSpecialJobAsync(string specialJobId, string comment);

        Task<SpecialJob> CreateSpecialJobAsync(SpecialJob newSpecialJob, string comment);

        Task<SpecialJobModel> GetSpecialJobAsync(string specialJobId);

        Task<List<SpecialJobModel>> GetSpecialJobListAsync(params QueryFilter[] parameters);

        Task UpdateSpecialJobAsync(string specialJobId, SpecialJob newSpecialJob, string comment);
        Task<int> GetSpecialJobCount(List<QueryFilter> filters);
        Task<object[]> GetSpecialJobValueListAsync(string propertyName, List<QueryFilter> filters);
        Task<List<SpecialJobModel>> GetSpecialJobListAsync(IList<QueryFilter> filters, IList<QuerySorter> sorters, int? skip, int? take);
    }
}
