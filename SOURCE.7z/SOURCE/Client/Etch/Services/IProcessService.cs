﻿
using System.Collections.Generic;
using System.Threading.Tasks;
using AMAT.R2R.Client.Common.Services;
using AMAT.R2R.Client.Etch.Modules.ProcessSettings;
using AMAT.R2R.Shared.Base.DTO;
using AMAT.R2R.Shared.Etch.DTO;
using DevExpress.Xpf.Data;

namespace AMAT.R2R.Client.Etch.Services
{
    public interface IProcessService
    {
        #region Process
        // Filter
        Task<List<ProcessModel>> GetProcessListAsync(IList<QueryFilter> filters, IList<QuerySorter> sorters, int? skip, int? take);
        Task<int> GetProcessCount(List<QueryFilter> lists);
        Task<object[]> GetProcessValueListAsync(string propertyName, List<QueryFilter> filters);

        // CURD
        Task<ProcessModel> GetProcessAsync(int processId);
        Task<Process> CreateProcessAsync(Process process, string comment);
        Task ModifyProcessAsync(int processId, Process process, string comment);
        Task DeleteProcessAsync(int processId, string comment);
        #endregion

        #region FeedForward Settings
        Task<List<FeedforwardSetting>> GetFeedforwardSettingListAsync(int processId);
        Task<FeedforwardSetting> CreateFeedforwardSettingAsync(int processId, FeedforwardSetting feedforwardSetting, string comment);
        Task<FeedforwardSetting> GetFeedforwardSettingAsync(int processId, int settingId);
        Task ModifyFeedforwardSettingAsync(int processId, int settingId, FeedforwardSetting feedforwardSetting, string comment);
        void DeleteFeedforwardSetting(int processId, int settingId, string comment);
        #endregion

        #region OutputSettings
        Task<List<OutputSetting>> GetOutputSettingListAsync(int processId);
        Task<OutputSetting> GetOutputSettingAsync(int processId, int settingId);
        Task<OutputSetting> CreateOutputSettingAsync(int processId, OutputSetting newOutputSetting, string comment);
        Task ModifyOutputSettingAsync(int processId, int postMetroId, OutputSetting newOutputSetting, string comment);
        void DeleteOutputSetting(int processId, int settingId, string comment); 
        #endregion

        List<PreMetrology> GetPreMetrologyList(int processId);
        PreMetrology CreatePreMetrology(int processId, PreMetrology preMetrology, string comment);

        List<PostMetrology> GetPostMetrologyList(int processId);
        PostMetrology CreatePostMetrology(int processId, PostMetrology postMetrology, string comment);


        Task<ManualPreMetrology> GetManualPreMetrologyInfoAsync(int processId);
        Task<ManualPreMetrologyItem> AddManualPreMetrologyItemAsync(ManualPreMetrologyItem manualPreMetrologyItem, int processId, string comment);
        Task DeleteManualPreMetrologyItemAsync(int processId, string uniqueId, string comment);
        Task DeletePostMetrologyAsync(int processId, string metrologyKey, string comment);
        Task DeletePreMetrologyAsync(int processId, string metrologyKey, string comment);
    }
}
