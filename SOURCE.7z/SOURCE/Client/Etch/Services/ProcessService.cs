﻿using System;
using System.Collections.Generic;
using System.Reflection;
using System.Threading.Tasks;
using AMAT.R2R.Client.Common.Extensions;
using AMAT.R2R.Client.Common.Helpers;
using AMAT.R2R.Client.Common.Messages;
using AMAT.R2R.Client.Common.Services;
using AMAT.R2R.Client.Etch.Modules.ProcessSettings;
using AMAT.R2R.Shared.Base.DTO;
using AMAT.R2R.Shared.Etch.DTO;
using DevExpress.Mvvm;
using DevExpress.Xpf.Data;

namespace AMAT.R2R.Client.Etch.Services
{
    public class ProcessService : IProcessService
    {
        const string ProcessEndpoint = "process";
        const string FeedforwardEndpoint = "FeedforwardSetting";
        const string OutputSettingEndpoint = "OutputSetting";
        const string PreMetrologyEndpoint = "PreMetrology";
        const string PostMetrologyEndpoint = "PostMetrology";
        const string ManualPreMetrologyItemEndpoint = "ManualPreMetrologyItem";

        #region Process Methods
        public async Task<List<ProcessModel>> GetProcessListAsync(IList<QueryFilter> filters, IList<QuerySorter> sorters, int? skip, int? take)
        {
            var guid = Guid.NewGuid();
            var method = nameof(GetProcessListAsync);
            Logger.PerformanceStart(method, guid);
            try
            {
                return await Api.Current.GetListAsync<ProcessModel>(ProcessEndpoint, filters, sorters, skip, take);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }
        }
        public async Task<int> GetProcessCount(List<QueryFilter> filters)
        {
            var guid = Guid.NewGuid();
            var method = nameof(GetProcessCount);
            Logger.PerformanceStart(method, guid);
            try
            {
                return await Api.Current.GetTotalCountAsync(ProcessEndpoint, filters);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }
        }
        public async Task<object[]> GetProcessValueListAsync(string propertyName, List<QueryFilter> filters)
        {
            var guid = Guid.NewGuid();
            var method = nameof(GetProcessValueListAsync);
            Logger.PerformanceStart(method, guid);
            try
            {
                return await Api.Current.GetValueListAsync(ProcessEndpoint, propertyName, filters);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }
        }

        public async Task<ProcessModel> GetProcessAsync(int processId)
        {
            var guid = Guid.NewGuid();
            var method = nameof(GetProcessAsync);
            Logger.PerformanceStart(method, guid);
            try
            {
                return await Api.Current.GetSingleAsync<ProcessModel>($"{ProcessEndpoint}/{processId}");
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }
        }

        public async Task<Process> CreateProcessAsync(Process process, string comment)
        {
            var guid = Guid.NewGuid();
            var method = nameof(CreateProcessAsync);
            Logger.PerformanceStart(method, guid);
            try
            {
                return await Api.Current.PostNewAsync(ProcessEndpoint, process, comment);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }
        }

        public async Task DeleteProcessAsync(int processId, string comment)
        {
            var guid = Guid.NewGuid();
            var method = nameof(DeleteProcessAsync);
            Logger.PerformanceStart(method, guid);
            try
            {
                await Api.Current.DeleteAsync($"{ProcessEndpoint}/{processId}", comment);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }
        }

        public async Task ModifyProcessAsync(int processId, Process process, string comment)
        {
            var guid = Guid.NewGuid();
            var method = nameof(ModifyProcessAsync);
            Logger.PerformanceStart(method, guid);
            try
            {
                await Api.Current.PutUpdateAsync($"{ProcessEndpoint}/{processId}", process, comment);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }
        }
        #endregion

        #region FeedforwardSetting Methods
        public async Task<List<FeedforwardSetting>> GetFeedforwardSettingListAsync(int processId)
        {
            var guid = Guid.NewGuid();
            var method = nameof(GetFeedforwardSettingListAsync);
            Logger.PerformanceStart(method, guid);
            try
            {
                return await Api.Current.GetListAsync<FeedforwardSetting>($"{ProcessEndpoint}/{processId}/{FeedforwardEndpoint}");
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }
        }

        public Task<FeedforwardSetting> GetFeedforwardSettingAsync(int processId, int settingId)
        {
            var guid = Guid.NewGuid();
            var method = nameof(GetFeedforwardSettingAsync);
            Logger.PerformanceStart(method, guid);
            try
            {
                return Api.Current.GetSingleAsync<FeedforwardSetting>($"{ProcessEndpoint}/{processId}/{FeedforwardEndpoint}/{settingId}");
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }
        }

        public async Task<FeedforwardSetting> CreateFeedforwardSettingAsync(int processId, FeedforwardSetting feedforwardSetting, string comment)
        {
            var guid = Guid.NewGuid();
            var method = nameof(CreateFeedforwardSettingAsync);
            Logger.PerformanceStart(method, guid);
            try
            {
                return await Api.Current.PostNewAsync($"{ProcessEndpoint}/{processId}/{FeedforwardEndpoint}", feedforwardSetting, comment);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }
        }

        public void DeleteFeedforwardSetting(int processId, int settingId, string comment)
        {
            var guid = Guid.NewGuid();
            var method = nameof(DeleteFeedforwardSetting);
            Logger.PerformanceStart(method, guid);
            try
            {
                Api.Current.Delete($"{ProcessEndpoint}/{processId}/{FeedforwardEndpoint}/{settingId}", comment);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }
        }

        public async Task ModifyFeedforwardSettingAsync(int processId, int settingId, FeedforwardSetting feedforwardSetting, string comment)
        {
            var guid = Guid.NewGuid();
            var method = nameof(ModifyFeedforwardSettingAsync);
            Logger.PerformanceStart(method, guid);
            try
            {
                await Api.Current.PutUpdateAsync($"{ProcessEndpoint}/{processId}/{FeedforwardEndpoint}/{settingId}", feedforwardSetting, comment);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }
        }
        #endregion

        public async Task<List<OutputSetting>> GetOutputSettingListAsync(int processId)
        {
            var guid = Guid.NewGuid();
            var method = nameof(GetOutputSettingListAsync);
            Logger.PerformanceStart(method, guid);
            try
            {
                return await Api.Current.GetListAsync<OutputSetting>($"{ProcessEndpoint}/{processId}/{OutputSettingEndpoint}");
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }
        }

        public Task<OutputSetting> GetOutputSettingAsync(int processId, int settingId)
        {
            var guid = Guid.NewGuid();
            var method = nameof(GetOutputSettingAsync);
            Logger.PerformanceStart(method, guid);
            try
            {
                return Api.Current.GetSingleAsync<OutputSetting>($"{ProcessEndpoint}/{processId}/{OutputSettingEndpoint}/{settingId}");
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }
        }

        public void DeleteOutputSetting(int processId, int settingId, string comment)
        {
            var guid = Guid.NewGuid();
            var method = nameof(DeleteOutputSetting);
            Logger.PerformanceStart(method, guid);
            try
            {
                Api.Current.Delete($"{ProcessEndpoint}/{processId}/{OutputSettingEndpoint}/{settingId}", comment);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }
        }

        public async Task ModifyOutputSettingAsync(int processId, int settingId, OutputSetting outputSetting, string comment)
        {
            var guid = Guid.NewGuid();
            var method = nameof(ModifyOutputSettingAsync);
            Logger.PerformanceStart(method, guid);
            try
            {
                await Api.Current.PutUpdateAsync($"{ProcessEndpoint}/{processId}/{OutputSettingEndpoint}/{settingId}", outputSetting, comment);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }
        }

        public async Task<OutputSetting> CreateOutputSettingAsync(int processId, OutputSetting outputSetting, string comment)
        {
            var guid = Guid.NewGuid();
            var method = nameof(CreateOutputSettingAsync);
            Logger.PerformanceStart(method, guid);
            try
            {
                return await Api.Current.PostNewAsync($"{ProcessEndpoint}/{processId}/{OutputSettingEndpoint}", outputSetting, comment);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }
        }

        public List<PreMetrology> GetPreMetrologyList(int processId)
        {
            var guid = Guid.NewGuid();
            var method = nameof(GetPreMetrologyList);
            Logger.PerformanceStart(method, guid);
            try
            {
                return Api.Current.GetList<PreMetrology>($"{ProcessEndpoint}/{processId}/{PreMetrologyEndpoint}");
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }
        }

        public PreMetrology CreatePreMetrology(int processId, PreMetrology preMetrology, string comment)
        {
            var guid = Guid.NewGuid();
            var method = nameof(CreatePreMetrology);
            Logger.PerformanceStart(method, guid);
            try
            {
                return Api.Current.PostNew($"{ProcessEndpoint}/{processId}/{PreMetrologyEndpoint}", preMetrology, comment);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }
        }

        public List<PostMetrology> GetPostMetrologyList(int processId)
        {
            var guid = Guid.NewGuid();
            var method = nameof(GetPostMetrologyList);
            Logger.PerformanceStart(method, guid);
            try
            {
                return Api.Current.GetList<PostMetrology>($"{ProcessEndpoint}/{processId}/{PostMetrologyEndpoint}");
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }
        }

        public PostMetrology CreatePostMetrology(int processId, PostMetrology postMetrology, string comment)
        {
            var guid = Guid.NewGuid();
            var method = nameof(CreatePostMetrology);
            Logger.PerformanceStart(method, guid);
            try
            {
                return Api.Current.PostNew($"{ProcessEndpoint}/{processId}/{PostMetrologyEndpoint}", postMetrology, comment);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }
        }

        public async Task<ManualPreMetrology> GetManualPreMetrologyInfoAsync(int processId)
        {
            var guid = Guid.NewGuid();
            var method = nameof(GetManualPreMetrologyInfoAsync);
            Logger.PerformanceStart(method, guid);
            try
            {
                return await Api.Current.GetSingleAsync<ManualPreMetrology>($"{ProcessEndpoint}/{processId}/{ManualPreMetrologyItemEndpoint}");
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }
        }

        public async Task<ManualPreMetrologyItem> AddManualPreMetrologyItemAsync(ManualPreMetrologyItem manualPreMetrologyItem, int processId, string comment)
        {
            var guid = Guid.NewGuid();
            var method = nameof(AddManualPreMetrologyItemAsync);
            Logger.PerformanceStart(method, guid);
            try
            {
                return await Api.Current.PostNewAsync($"{ProcessEndpoint}/{processId}/{ManualPreMetrologyItemEndpoint}", manualPreMetrologyItem, comment);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }
        }

        public async Task DeleteManualPreMetrologyItemAsync(int processId, string uniqueId, string comment)
        {
            var guid = Guid.NewGuid();
            var method = nameof(DeleteManualPreMetrologyItemAsync);
            Logger.PerformanceStart(method, guid);
            try
            {
                await Api.Current.DeleteAsync($"{ProcessEndpoint}/{processId}/{ManualPreMetrologyItemEndpoint}/{uniqueId.EscapeUrlChar()}", comment);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }
        }

        public async Task DeletePostMetrologyAsync(int processId, string metrologyKey, string comment)
        {
            var guid = Guid.NewGuid();
            var method = nameof(DeletePostMetrologyAsync);
            Logger.PerformanceStart(method, guid);
            try
            {
                await Api.Current.DeleteAsync($"{ProcessEndpoint}/{processId}/{PostMetrologyEndpoint}/{metrologyKey}", comment);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }
        }

        public async Task DeletePreMetrologyAsync(int processId, string metrologyKey, string comment)
        {
            var guid = Guid.NewGuid();
            var method = nameof(DeletePostMetrologyAsync);
            Logger.PerformanceStart(method, guid);
            try
            {
                await Api.Current.DeleteAsync($"{ProcessEndpoint}/{processId}/{PreMetrologyEndpoint}/{metrologyKey}", comment);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }
        }
    }
}
