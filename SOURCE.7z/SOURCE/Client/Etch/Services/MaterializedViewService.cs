﻿using System;
using System.Collections.Generic;
using System.Reflection;
using System.Threading.Tasks;
using AMAT.R2R.Client.Common.Extensions;
using AMAT.R2R.Client.Common.Helpers;
using AMAT.R2R.Client.Common.Messages;
using AMAT.R2R.Client.Common.Services;
using AMAT.R2R.Client.Etch.Modules.MaterializedViewSettings;
using AMAT.R2R.Client.Etch.Modules.ProcessSettings;
using AMAT.R2R.Shared.Base.DTO;
using AMAT.R2R.Shared.Etch.DTO;
using DevExpress.Mvvm;

namespace AMAT.R2R.Client.Etch.Services
{
    public class MaterializedViewService : IMaterializedViewService
    {
        const string MaterializedViewEndpoint = "Materialized";
        const string InputEndpoint = "input";
        const string RunHisEndpoint = "run";
        const string ChangeStatusEndpoint = "change";
        const string ResetStatusEndpoint = "reset";
        const string ToolEndpoint = "tool";
        const string ChamberEndpoint = "chamber";
        const string ChamberOffsetEndpoint = "offset";


        public async Task<MaterializedViewModel> GetMaterializedViewAsync(int contextId)
        {
            var guid = Guid.NewGuid();
            var method = nameof(GetMaterializedViewAsync);
            Logger.PerformanceStart(method, guid); 
            try
            {
                return await Api.Current.GetSingleAsync<MaterializedViewModel>($"{MaterializedViewEndpoint}/{contextId}");
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }
        }


        public async Task<List<MaterializedViewModel>> GetMaterializedViewListAsync(IList<QueryFilter> filters, IList<QuerySorter> sorters, int? skip, int? take)
        {
            var guid = Guid.NewGuid();
            var method = nameof(GetMaterializedViewListAsync);
            Logger.PerformanceStart(method, guid);
            try
            {
                return await Api.Current.GetListAsync<MaterializedViewModel>(MaterializedViewEndpoint, filters, sorters, skip, take);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }
        }

        public async Task<int> GetMaterializedViewCount(List<QueryFilter> filters)
        {
            var guid = Guid.NewGuid();
            var method = nameof(GetMaterializedViewCount);
            Logger.PerformanceStart(method, guid);
            try
            {
                return await Api.Current.GetTotalCountAsync(MaterializedViewEndpoint, filters);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }
        }
        public async Task<object[]> GetMaterializedViewValueListAsync(string propertyName, List<QueryFilter> filters)
        {
            var guid = Guid.NewGuid();
            var method = nameof(GetMaterializedViewValueListAsync);
            Logger.PerformanceStart(method, guid);
            try
            {
                return await Api.Current.GetValueListAsync(MaterializedViewEndpoint, propertyName, filters);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }
        }

        public async Task<List<MaterializeViewParameterExtend>> GetMaterializedViewInputListAsync(int contextId)
        {
            var guid = Guid.NewGuid();
            var method = nameof(GetMaterializedViewInputListAsync);
            Logger.PerformanceStart(method, guid); 
            try
            {
                return await Api.Current.GetListAsync<MaterializeViewParameterExtend>($"{MaterializedViewEndpoint}/{contextId}/{InputEndpoint}");
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }
        }

        public async Task<List<RunHist>> GetMaterializedViewRunHisListAsync(int contextId)
        {
            var guid = Guid.NewGuid();
            var method = nameof(GetMaterializedViewRunHisListAsync);
            Logger.PerformanceStart(method, guid); 
            try
            {
                return await Api.Current.GetListAsync<RunHist>($"{MaterializedViewEndpoint}/{contextId}/{RunHisEndpoint}");
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }
        }

        public async Task ChangeStatus(MaterializedView materializedView, int contextId, string comment)
        {
            var guid = Guid.NewGuid();
            var method = nameof(ChangeStatus);
            Logger.PerformanceStart(method, guid); 
            try
            {
                await Api.Current.PutUpdateAsync($"{MaterializedViewEndpoint}/{contextId}/{ChangeStatusEndpoint}", materializedView, comment);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }
        }

        public async Task ResetStatus(MaterializedView materializedView, int contextId, string comment)
        {
            var guid = Guid.NewGuid();
            var method = nameof(ResetStatus);
            Logger.PerformanceStart(method, guid); 
            try
            {
                await Api.Current.PutUpdateAsync($"{MaterializedViewEndpoint}/{contextId}/{ResetStatusEndpoint}", materializedView, comment);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }
        }

        public async Task<List<ChamberOffsetItem>> GetChamberOffsetList(string toolId, string chamberId)
        {
            var guid = Guid.NewGuid();
            var method = nameof(GetChamberOffsetList);
            Logger.PerformanceStart(method, guid); 
            try
            {
                return await Api.Current.GetListAsync<ChamberOffsetItem>($"{ToolEndpoint}/{toolId.EscapeUrlChar()}/{ChamberEndpoint}/{chamberId.EscapeUrlChar()}/{ChamberOffsetEndpoint}");
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }
        }

        public async Task UpdateChamberOffset(ChamberOffsetItem chamberOffset, string toolId, string chamberId, string parameterName, string comment)
        {
            var guid = Guid.NewGuid();
            var method = nameof(UpdateChamberOffset);
            Logger.PerformanceStart(method, guid); 
            try
            {
                await Api.Current.PutUpdateAsync($"{ToolEndpoint}/{toolId.EscapeUrlChar()}/{ChamberEndpoint}/{chamberId.EscapeUrlChar()}/{ChamberOffsetEndpoint}/{parameterName.EscapeUrlChar()}", chamberOffset, comment);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }
        }

        public async Task DeleteChamberOffset(string toolId, string chamberId, string parameterName, string comment)
        {
            var guid = Guid.NewGuid();
            var method = nameof(DeleteChamberOffset);
            Logger.PerformanceStart(method, guid); 
            try
            {
                await Api.Current.DeleteAsync($"{ToolEndpoint}/{toolId.EscapeUrlChar()}/{ChamberEndpoint}/{chamberId.EscapeUrlChar()}/{ChamberOffsetEndpoint}/{parameterName.EscapeUrlChar()}", comment);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }
        }
    }
}
