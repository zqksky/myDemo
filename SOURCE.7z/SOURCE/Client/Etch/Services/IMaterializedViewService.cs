﻿
using System.Collections.Generic;
using System.Threading.Tasks;
using AMAT.R2R.Client.Common.Services;
using AMAT.R2R.Client.Etch.Modules.MaterializedViewSettings;
using AMAT.R2R.Client.Etch.Modules.ProcessSettings;
using AMAT.R2R.Shared.Base.DTO;
using AMAT.R2R.Shared.Etch.DTO;

namespace AMAT.R2R.Client.Etch.Services
{
    public interface IMaterializedViewService
    {
        Task<MaterializedViewModel> GetMaterializedViewAsync(int contextId);
        Task<List<MaterializeViewParameterExtend>> GetMaterializedViewInputListAsync(int contextId);
        Task<List<RunHist>> GetMaterializedViewRunHisListAsync(int contextId);
        Task ChangeStatus(MaterializedView materializedView, int contextId, string comment);
        Task ResetStatus(MaterializedView materializedView, int contextId, string comment);

        Task<List<ChamberOffsetItem>> GetChamberOffsetList(string toolId, string chamber);
        Task UpdateChamberOffset(ChamberOffsetItem chamberOffset, string toolId, string chamber, string parameterName, string comment);
        Task DeleteChamberOffset(string toolId, string chamber, string parameterName, string comment);
        Task<int> GetMaterializedViewCount(List<QueryFilter> filters);
        Task<object[]> GetMaterializedViewValueListAsync(string propertyName, List<QueryFilter> filters);
        Task<List<MaterializedViewModel>> GetMaterializedViewListAsync(IList<QueryFilter> filters, IList<QuerySorter> sorters, int? skip, int? take);
    }
}
