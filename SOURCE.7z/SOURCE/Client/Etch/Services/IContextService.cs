﻿
using System.Collections.Generic;
using System.Threading.Tasks;
using AMAT.R2R.Client.Common.Services;
using AMAT.R2R.Client.Etch.Modules.ContextSettings;
using AMAT.R2R.Client.Etch.Modules.ProcessSettings;
using AMAT.R2R.Shared.Base.DTO;
using AMAT.R2R.Shared.Etch.DTO;

namespace AMAT.R2R.Client.Etch.Services
{
    public interface IContextService
    {
        Task DeleteContextAsync(int contextId, string comment);

        Task<Context> CreateContextAsync(Context newContext, string comment);

        Task<ContextModel> GetContextAsync(int contextId);

        Task<List<ContextModel>> GetContextListAsync(params QueryFilter[] parameters);
        Task UpdateContextAsync(int contextId, Context newContext, string comment);

        Task<ContextInput> CreateContextInputAsync(ContextInput contextInput, int contextId, string comment);

        Task UpdateContextInputAsync(ContextInput contextInput, int contextId, string comment);

        Task<ContextConstants> CreateContextConstantsAsync(ContextConstants contextConstants, int contextId, string comment);

        Task UpdateContextConstantsAsync(ContextConstants contextConstants, int contextId, string comment);
        Task<List<ContextModel>> GetContextListAsync(IList<QueryFilter> filters, IList<QuerySorter> sorters, int? skip, int? take);
        Task<int> GetContextCount(List<QueryFilter> filters);
        Task<object[]> GetContextValueListAsync(string propertyName, List<QueryFilter> filters);
    }
}
