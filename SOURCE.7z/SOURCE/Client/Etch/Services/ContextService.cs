﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;
using AMAT.R2R.Client.Common.Helpers;
using AMAT.R2R.Client.Common.Messages;
using AMAT.R2R.Client.Common.Services;
using AMAT.R2R.Client.Etch.Modules.ContextSettings;
using AMAT.R2R.Client.Etch.Modules.ProcessSettings;
using AMAT.R2R.Shared.Base.DTO;
using AMAT.R2R.Shared.Etch.DTO;
using DevExpress.Mvvm;

namespace AMAT.R2R.Client.Etch.Services
{
    public class ContextService : IContextService
    {
        const string ContextEndpoint = "context";
        const string ContextInputEndpoint = "input";
        const string ContextConstantsEndpoint = "constants";


        public async Task<Context> CreateContextAsync(Context newContext, string comment)
        {
            var guid = Guid.NewGuid();
            var method = nameof(CreateContextAsync);
            Logger.PerformanceStart(method, guid); 
            try
            {
                return await Api.Current.PostNewAsync($"{ContextEndpoint}", newContext, comment);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }
        }

        public async Task DeleteContextAsync(int contextId, string comment)
        {
            var guid = Guid.NewGuid();
            var method = nameof(DeleteContextAsync);
            Logger.PerformanceStart(method, guid); 
            try
            {
                await Api.Current.DeleteAsync($"{ContextEndpoint}/{contextId}", comment);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }
        }

        public async Task<ContextModel> GetContextAsync(int contextId)
        {
            var guid = Guid.NewGuid();
            var method = nameof(GetContextAsync);
            Logger.PerformanceStart(method, guid); 
            try
            {
                return await Api.Current.GetSingleAsync<ContextModel>($"{ContextEndpoint}/{contextId}");
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }
        }

        public async Task<ContextInput> GetContextInputAsync(int contextId)
        {
            var guid = Guid.NewGuid();
            var method = nameof(GetContextInputAsync);
            Logger.PerformanceStart(method, guid); 
            try
            {
                return await Api.Current.GetSingleAsync<ContextInput>($"{ContextEndpoint}/{contextId}/{ContextInputEndpoint}");
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }
        }

        public async Task<List<ContextModel>> GetContextListAsync(params QueryFilter[] parameters)
        {
            return await GetContextListAsync(parameters.ToList(), null, null, null);
        }

        public async Task<List<ContextModel>> GetContextListAsync(IList<QueryFilter> filters, IList<QuerySorter> sorters, int? skip, int? take)
        {
            var guid = Guid.NewGuid();
            var method = nameof(GetContextListAsync);
            Logger.PerformanceStart(method, guid);
            try
            {
                return await Api.Current.GetListAsync<ContextModel>(ContextEndpoint, filters, sorters, skip, take);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }
        }
        public async Task<int> GetContextCount(List<QueryFilter> filters)
        {
            var guid = Guid.NewGuid();
            var method = nameof(GetContextCount);
            Logger.PerformanceStart(method, guid);
            try
            {
                return await Api.Current.GetTotalCountAsync(ContextEndpoint, filters);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }
        }
        public async Task<object[]> GetContextValueListAsync(string propertyName, List<QueryFilter> filters)
        {
            var guid = Guid.NewGuid();
            var method = nameof(GetContextValueListAsync);
            Logger.PerformanceStart(method, guid);
            try
            {
                return await Api.Current.GetValueListAsync(ContextEndpoint, propertyName, filters);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }
        }


        public async Task UpdateContextAsync(int contextId, Context newContext, string comment)
        {
            var guid = Guid.NewGuid();
            var method = nameof(UpdateContextAsync);
            Logger.PerformanceStart(method, guid); 
            try
            {
                await Api.Current.PutUpdateAsync($"{ContextEndpoint}/{contextId}", newContext, comment);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }
        }

        public async Task<ContextInput> CreateContextInputAsync(ContextInput contextInput, int contextId, string comment)
        {
            var guid = Guid.NewGuid();
            var method = nameof(CreateContextInputAsync);
            Logger.PerformanceStart(method, guid); 
            try
            {
                return await Api.Current.PostNewAsync($"{ContextEndpoint}/{contextId}/{ContextInputEndpoint}", contextInput, comment);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }
        }
        public async Task UpdateContextInputAsync(ContextInput contextInput, int contextId, string comment)
        {
            var guid = Guid.NewGuid();
            var method = nameof(UpdateContextInputAsync);
            Logger.PerformanceStart(method, guid); 
            try
            {
                await Api.Current.PutUpdateAsync($"{ContextEndpoint}/{contextId}/{ContextInputEndpoint}", contextInput, comment);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }
        }

        public async Task<ContextConstants> CreateContextConstantsAsync(ContextConstants contextConstants, int contextId, string comment)
        {
            var guid = Guid.NewGuid();
            var method = nameof(CreateContextConstantsAsync);
            Logger.PerformanceStart(method, guid); 
            try
            {
                return await Api.Current.PostNewAsync($"{ContextEndpoint}/{contextId}/{ContextConstantsEndpoint}", contextConstants, comment);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }
        }

        public async Task UpdateContextConstantsAsync(ContextConstants contextConstants, int contextId, string comment)
        {
            var guid = Guid.NewGuid();
            var method = nameof(UpdateContextConstantsAsync);
            Logger.PerformanceStart(method, guid); 
            try
            {
                await Api.Current.PutUpdateAsync($"{ContextEndpoint}/{contextId}/{ContextConstantsEndpoint}", contextConstants, comment);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }
        }

    }
}
