﻿
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using AMAT.R2R.Client.Common.Enums;
using AMAT.R2R.Client.Common.Views;
using AMAT.R2R.Shared.Base.DTO;
using AMAT.R2R.Shared.Etch.DTO;

namespace AMAT.R2R.Client.Etch.Messages
{
    public class ContextChangedMessage
    {
        public ObjectChangeType ChangeType { get; set; }

        public int ContextId { get; set; }
    }
}
