﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Deployment.Application;
using System.Diagnostics;
using System.Linq;
using System.Windows.Media;
using AMAT.R2R.Client.Common.Constants;
using AMAT.R2R.Client.Common.Helpers;
using AMAT.R2R.Client.Common.Messages;
using AMAT.R2R.Client.Common.Models;
using AMAT.R2R.Client.Common.Services;
using AMAT.R2R.Client.Common.ViewModels;
using AMAT.R2R.Client.Etch.Modules;
using AMAT.R2R.Client.Etch.Modules.ContextSettings;
using AMAT.R2R.Client.Etch.Modules.MaterializedViewSettings;
using AMAT.R2R.Client.Etch.Modules.ProcessSettings;
using AMAT.R2R.Client.Etch.Modules.SpecialJobSettings;
using AMAT.R2R.Client.Etch.Modules.ToolChamberSettings;
using AMAT.R2R.Client.Etch.Services;
using DevExpress.Mvvm;
using DevExpress.Mvvm.DataAnnotations;
using DevExpress.Mvvm.ModuleInjection;
using DevExpress.Mvvm.POCO;
using DevExpress.Xpf.Core;

namespace AMAT.R2R.Client.Etch
{
    public class MainViewModel : MainViewModelBase
    {
        public MainViewModel()
        {
            IsShowNavigationMenu = true;
        }

        protected override void RegisterServices()
        {
            DevExpress.Mvvm.ServiceContainer.Default.RegisterService(new ProcessService());
            DevExpress.Mvvm.ServiceContainer.Default.RegisterService(new ContextService());
            DevExpress.Mvvm.ServiceContainer.Default.RegisterService(new SpecialJobService());
            DevExpress.Mvvm.ServiceContainer.Default.RegisterService(new MaterializedViewService());
            DevExpress.Mvvm.ServiceContainer.Default.RegisterService(new LotRunHistoryService());
        }
        protected override void BuildNavigationMenu()
        {
            NavGroups = new ReadOnlyCollection<NavigationGroupModel>(new NavigationGroupModel[]
                {
                    new NavigationGroupModel()
                    {
                        Header = "Configuration",
                        SubItems = new ReadOnlyCollection<NavigationModel>(new NavigationModel[]
                        {
                            new NavigationModel()
                            {
                                Header = "Process",
                                FunctionType = "ProcessList",
                                Icon = SetIcon("pack://application:,,,/DevExpress.Images.v20.1;component/SvgImages/Business Objects/BO_KPI_Definition.svg"),
                                IsVisible = AuthorityManager.HasAuthority(ProcessListViewModel.Auth_Process)
                            },
                            new NavigationModel()
                            {
                                Header = "Context",
                                FunctionType = "ContextList",
                                Icon = SetIcon("pack://application:,,,/DevExpress.Images.v20.1;component/SvgImages/Business Objects/BO_KPI_Scorecard.svg"),
                                IsVisible = AuthorityManager.HasAuthority(ContextListViewModel.Auth_Context)
                            },
                        })
                    },
                    new NavigationGroupModel()
                    {
                        Header = "Operation",
                        SubItems = new ReadOnlyCollection<NavigationModel>(new NavigationModel[]
                        {
                            new NavigationModel()
                            {
                                Header = "Special Job",
                                FunctionType = "SpecialJobList",
                                Icon = SetIcon("pack://application:,,,/DevExpress.Images.v20.1;component/SvgImages/Snap/SnapHeader.svg"),
                                IsVisible = AuthorityManager.HasAuthority(SpecialJobListViewModel.Auth_SpecialJob)
                            },
                            new NavigationModel()
                            {
                                Header = "Materialized View",
                                FunctionType = "MaterializedViewList",
                                Icon = SetIcon("pack://application:,,,/DevExpress.Images.v20.1;component/SvgImages/XAF/ModelEditor_Business_Object_Model.svg"),
                                IsVisible = AuthorityManager.HasAuthority(MaterializedViewListViewModel.Auth_MaterialView)
                            },
                        })
                    },
                    new NavigationGroupModel()
                    {
                        Header = "History",
                        SubItems = new ReadOnlyCollection<NavigationModel>(new NavigationModel[]
                        {
                            new NavigationModel()
                            {
                                Header = "Lot Run History",
                                FunctionType = "LotRunHistoryList",
                                Icon = SetIcon("pack://application:,,,/DevExpress.Images.v20.1;component/SvgImages/Business Objects/BO_Audit_ChangeHistory.svg"),
                                IsVisible = true,
                                //IsVisible = true,
                            },
                        })
                    },
                    new NavigationGroupModel()
                    {
                        Header = "Global",
                        SubItems = new ReadOnlyCollection<NavigationModel>(new NavigationModel[]
                        {
                            new NavigationModel()
                            {
                                Header = "Tool And Chamber",
                                FunctionType = "ToolChamberList",
                                Icon = SetIcon("pack://application:,,,/DevExpress.Images.v20.1;component/SvgImages/Business Objects/BO_Category.svg"),
                                IsVisible = AuthorityManager.HasAuthority(ToolChamberListViewModel.Auth_Global)
                            },
                        })
                    },
                    //new NavigationGroupModel()
                    //{
                    //    Header = "History",
                    //    SubItems = new ReadOnlyCollection<NavigationModel>(new NavigationModel[]
                    //    {
                    //        new NavigationModel()
                    //        {
                    //            Header = "Lot History - Tool View",
                    //            FunctionType = "ToolViewHistory",
                    //            Icon = SetIcon("pack://application:,,,/DevExpress.Images.v20.1;component/SvgImages/Business Objects/BO_Audit_ChangeHistory.svg"),
                    //            IsVisible = AuthorityManager.HasAuthority(ToolViewHistoryViewModel.Auth_ToolViewHistory)
                    //        },
                    //    })
                    //},
                }
            );
        }

    }
}
