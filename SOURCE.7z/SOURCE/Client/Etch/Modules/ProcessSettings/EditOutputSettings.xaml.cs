﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace AMAT.R2R.Client.Etch.Modules.ProcessSettings
{
    /// <summary>
    /// Interaction logic for EditOutputSettings.xaml
    /// </summary>
    public partial class EditOutputSettings : UserControl
    {
        public EditOutputSettings()
        {
            InitializeComponent();
            //Loaded += EditOutputSettings_Loaded;
        }

        //private void EditOutputSettings_Loaded(object sender, RoutedEventArgs e)
        //{
        //    Window.GetWindow(this).Closing += EditOutputSettings_Closing;
        //}

        //private void EditOutputSettings_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        //{
        //    (DataContext as EditOutputSettingsViewModel)?.OnClosing(e);
        //}
    }
}
