﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using AMAT.R2R.Client.Common.Enums;
using AMAT.R2R.Client.Common.Helpers;
using AMAT.R2R.Shared.Base.DTO;
using AMAT.R2R.Shared.Etch.DTO;
using DevExpress.Mvvm;
using DevExpress.Mvvm.DataAnnotations;
using DevExpress.Mvvm.Native;
using DevExpress.Mvvm.UI.Native;

namespace AMAT.R2R.Client.Etch.Modules.ProcessSettings
{
    public class OutputSettingsViewModel : EtchViewModelBase
    {

        public OutputSettingsViewModel(Process process, OutputSetting outputSetting, FunctionMode mode)
        {
            Initialize(process, outputSetting, mode);
        }

        protected override void OnViewReadyAsync()
        {

        }

        internal void Initialize(Process process, OutputSetting outputSetting, FunctionMode mode)
        {
            OwnerProcess = process ?? throw new ArgumentNullException(nameof(process));
            Mode = mode;
            OriginalSettings = outputSetting;
            AvailableMetrologyList = new ObservableCollection<PostMetrologyModel>(OwnerProcess.AvailablePostMetrology.Select(m => new PostMetrologyModel(m)));
            ZoneDefinitionList = new ObservableCollection<ZoneDefinition>()
            {
                new ZoneDefinition() { Zone = "Zone_1" },
                new ZoneDefinition() { Zone = "Zone_2" },
                new ZoneDefinition() { Zone = "Zone_3" },
                new ZoneDefinition() { Zone = "Zone_4" },
                new ZoneDefinition() { Zone = "Zone_5" },
                new ZoneDefinition() { Zone = "Zone_6" },
                new ZoneDefinition() { Zone = "Zone_7" },
                new ZoneDefinition() { Zone = "Zone_8" },
                new ZoneDefinition() { Zone = "Zone_9" },
                new ZoneDefinition() { Zone = "Zone_10" },
            };
            foreach (var zd in ZoneDefinitionList)
            {
                zd.PropertyChanged += OnZoneDefinitionChanged;
            }

            Reload();
        }

        internal void Reload()
        {
            if (Mode == FunctionMode.Modify)
            {
                SelectedParameter = OriginalSettings?.Parameter;

                Target = OriginalSettings.Target;
                LowerLimit = OriginalSettings.LowerLimit;
                UpperLimit = OriginalSettings.UpperLimit;
                Unit = OriginalSettings.Unit;
                QualityItemName = OriginalSettings.QualityItemName;
                QualityThreshold = OriginalSettings.QualityThreshold;
                OptUseOOLPostMetro = OriginalSettings.OptUseOOLPostMetro;
                OptUseOOLRange = OriginalSettings.OptUseOOLRange;
                OptRangeThreshold = OriginalSettings.OptRangeThreshold;
                OptUseOOLStdDev = OriginalSettings.OptUseOOLStdDev;
                OptStdDevThreshold = OriginalSettings.OptStdDevThreshold;
                OptNoOfSitePerWafer = OriginalSettings.OptNoOfSitePerWafer;
                OptMinPercentRemaining = OriginalSettings.OptMinPercentRemaining;
                OptLowerBetterFilt = OriginalSettings.OptLowerBetterFilt;

                ZonalFlag = OriginalSettings.ZonalFlag;

                ZoneDefinitionList[0].Definition = OriginalSettings.ZonalDefinition001_Output;
                ZoneDefinitionList[1].Definition = OriginalSettings.ZonalDefinition002_Output;
                ZoneDefinitionList[2].Definition = OriginalSettings.ZonalDefinition003_Output;
                ZoneDefinitionList[3].Definition = OriginalSettings.ZonalDefinition004_Output;
                ZoneDefinitionList[4].Definition = OriginalSettings.ZonalDefinition005_Output;
                ZoneDefinitionList[5].Definition = OriginalSettings.ZonalDefinition006_Output;
                ZoneDefinitionList[6].Definition = OriginalSettings.ZonalDefinition007_Output;
                ZoneDefinitionList[7].Definition = OriginalSettings.ZonalDefinition008_Output;
                ZoneDefinitionList[8].Definition = OriginalSettings.ZonalDefinition009_Output;
                ZoneDefinitionList[9].Definition = OriginalSettings.ZonalDefinition010_Output;


                SelectedMetrology = AvailableMetrologyList.FirstOrDefault(m => m.MetrologyKey == OriginalSettings.PostMetrologys?.FirstOrDefault()?.MetrologyKey);

                if (SelectedMetrology != null)
                {
                    AvailableMetrologyList.ForEach(m => m.IsChecked = m == SelectedMetrology);
                }
                else
                {
                    AvailableMetrologyList.ForEach(m => m.IsChecked = false);
                }
                IsDirty = false;
            }
            else
            {
                SelectedParameter = null;

                OptUseOOLRange = true;
                OptUseOOLStdDev = true;
                ZonalFlag = false;
                OptUseOOLPostMetro = false;
                OptLowerBetterFilt = false;

                Target = null;
                LowerLimit = null;
                UpperLimit = null;
                Unit = null;
                QualityItemName = null;
                QualityThreshold = null;
                OptRangeThreshold = null;
                OptStdDevThreshold = null;
                OptNoOfSitePerWafer = null;
                OptMinPercentRemaining = null;


                ZoneDefinitionList.ForEach(d => d.Definition = null);

                SelectedMetrology = null;

                AvailableMetrologyList.ForEach(m => m.IsChecked = false);

                IsDirty = true;
            }
        }

        private void OnZoneDefinitionChanged(object sender, PropertyChangedEventArgs e)
        {
            if (e.PropertyName == nameof(ZoneDefinition.Definition))
            {
                ClearError($"{nameof(ZoneDefinitionList)}.{(sender as ZoneDefinition).Zone}");
                IsDirty = true;
            }
        }

        internal void Validate()
        {
            ValidateAndSetErrorFocus(
                nameof(SelectedParameter),
                nameof(Target),
                nameof(LowerLimit),
                nameof(UpperLimit),
                nameof(Unit),
                nameof(QualityItemName),
                nameof(QualityThreshold),
                nameof(OptUseOOLPostMetro),
                nameof(OptUseOOLRange),
                nameof(OptRangeThreshold),
                nameof(OptUseOOLStdDev),
                nameof(OptStdDevThreshold),
                nameof(OptNoOfSitePerWafer),
                nameof(OptMinPercentRemaining),
                nameof(OptLowerBetterFilt),
                nameof(ZonalFlag),
                nameof(SelectedMetrology));

            if (!HasErrors && ZonalFlag.Value)
            {
                foreach (var def in ZoneDefinitionList)
                {
                    if (def[nameof(ZoneDefinition.Definition)] != null)
                    {
                        SetError($"{nameof(ZoneDefinitionList)}.{def.Zone}", def[nameof(ZoneDefinition.Definition)]);
                        SetFocus(nameof(ZoneDefinitionList));
                        return;
                    }
                }
            }
        }

        protected override string GetError(string columnName)
        {
            switch (columnName)
            {
                case nameof(SelectedMetrology):
                    return DataValidator.NotNull(SelectedMetrology);
                case nameof(SelectedParameter):
                    return DataValidator.NotNull(SelectedParameter);
                case nameof(Target):
                    return DataValidator.ValidateInOrder(
                        () => DataValidator.NotNull(Target),
                        () => DataValidator.InRange(Target, LowerLimit, UpperLimit));
                case nameof(LowerLimit):
                    return DataValidator.ValidateInOrder(
                        () => DataValidator.NotNull(LowerLimit),
                        () => DataValidator.SmallerThanOrEqualTo(LowerLimit, UpperLimit));
                case nameof(UpperLimit):
                    return DataValidator.ValidateInOrder(
                        () => DataValidator.NotNull(UpperLimit),
                        () => DataValidator.LargerThanOrEqualTo(UpperLimit, LowerLimit));
                case nameof(Unit):
                    return DataValidator.ValidString(Unit);
                case nameof(QualityItemName):
                    return DataValidator.ValidString(QualityItemName);
                case nameof(QualityThreshold):
                    return DataValidator.ValidateInOrder(
                        () => DataValidator.NotNull(QualityThreshold),
                        () => QualityItemName == "NA" ? DataValidator.InRange(QualityThreshold, 0, 1) : DataValidator.InRangeLeftOpen(QualityThreshold, 0, 1));
                case nameof(OptRangeThreshold):
                    return DataValidator.ValidateInOrder(
                        () => DataValidator.NotNull(OptRangeThreshold),
                        () => DataValidator.LargerThanOrEqualTo(OptRangeThreshold, 0));

                case nameof(OptStdDevThreshold):
                    return DataValidator.ValidateInOrder(
                        () => DataValidator.NotNull(OptStdDevThreshold),
                        () => DataValidator.LargerThanOrEqualTo(OptStdDevThreshold, 0));

                case nameof(OptNoOfSitePerWafer):
                    return DataValidator.ValidateInOrder(
                        () => DataValidator.NotNull(OptNoOfSitePerWafer),
                        () => DataValidator.InRange(OptNoOfSitePerWafer, 1, null));
                case nameof(OptMinPercentRemaining):
                    return DataValidator.ValidateInOrder(
                        () => DataValidator.NotNull(OptMinPercentRemaining),
                        () => DataValidator.InRangeLeftOpen(OptMinPercentRemaining, 0, 1));
                case nameof(OptUseOOLPostMetro):
                    return DataValidator.NotNull(OptUseOOLPostMetro);
                case nameof(OptUseOOLRange):
                    return DataValidator.NotNull(OptUseOOLRange);
                case nameof(OptUseOOLStdDev):
                    return DataValidator.NotNull(OptUseOOLStdDev);
                case nameof(OptLowerBetterFilt):
                    return DataValidator.NotNull(OptLowerBetterFilt);
                case nameof(ZonalFlag):
                    return DataValidator.NotNull(ZonalFlag);
                default:
                    return null;
            }
        }


        #region Properties
        public Process OwnerProcess
        {
            get { return GetValue<Process>(); }
            set { SetValue(value); }
        }

        public OutputSetting OriginalSettings
        {
            get { return GetValue<OutputSetting>(); }
            set { SetValue(value); }
        }


        public Parameter SelectedParameter
        {
            get { return GetValue<Parameter>(); }
            set
            {
                SetValue(value);
                RaisePropertyChanged(nameof(ParameterName));
            }
        }

        public string ParameterName
        {
            get
            {
                return SelectedParameter == null ? "NEW" : SelectedParameter.ParameterName;
            }
        }

        public decimal? Target
        {
            get { return GetValue<decimal?>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(Target));
            }
        }

        public decimal? LowerLimit
        {
            get { return GetValue<decimal?>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(LowerLimit));
            }
        }

        public decimal? UpperLimit
        {
            get { return GetValue<decimal?>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(UpperLimit));
            }
        }

        public string Unit
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(Unit));
            }
        }

        public string QualityItemName
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(QualityItemName));
            }
        }

        public decimal? QualityThreshold
        {
            get { return GetValue<decimal?>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(QualityThreshold));
            }
        }

        public bool? OptUseOOLPostMetro
        {
            get { return GetValue<bool?>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(OptUseOOLPostMetro));
            }
        }

        public bool? OptUseOOLRange
        {
            get { return GetValue<bool?>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(OptUseOOLRange));
                ClearError(nameof(OptRangeThreshold));
            }
        }

        public decimal? OptRangeThreshold
        {
            get { return GetValue<decimal?>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(OptRangeThreshold));
            }
        }

        public bool? OptUseOOLStdDev
        {
            get { return GetValue<bool?>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(OptUseOOLStdDev));
                ClearError(nameof(OptStdDevThreshold));
            }
        }

        public decimal? OptStdDevThreshold
        {
            get { return GetValue<decimal?>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(OptStdDevThreshold));
            }
        }

        public decimal? OptNoOfSitePerWafer
        {
            get { return GetValue<decimal?>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(OptNoOfSitePerWafer));
            }
        }

        public decimal? OptMinPercentRemaining
        {
            get { return GetValue<decimal?>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(OptMinPercentRemaining));
            }
        }

        public bool? OptLowerBetterFilt
        {
            get { return GetValue<bool?>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(OptLowerBetterFilt));
            }
        }

        public bool? ZonalFlag
        {
            get { return GetValue<bool?>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(ZonalFlag));
            }
        }

        public ObservableCollection<ZoneDefinition> ZoneDefinitionList
        {
            get { return GetValue<ObservableCollection<ZoneDefinition>>(); }
            set { SetValue(value); }
        }

        public ObservableCollection<PostMetrologyModel> AvailableMetrologyList
        {
            get { return GetValue<ObservableCollection<PostMetrologyModel>>(); }
            set { SetValue(value); }
        }

        public PostMetrologyModel SelectedMetrology
        {
            get { return GetValue<PostMetrologyModel>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(SelectedMetrology));

                if (Mode != FunctionMode.View)
                {
                    if (value != null)
                    {
                        AvailableMetrologyList.ForEach(m => m.IsChecked = m == value);
                    }
                    else
                    {
                        AvailableMetrologyList.ForEach(m => m.IsChecked = false);
                    }
                }
            }
        }

        #endregion

    }

    public class ZoneDefinition : BindableBase, IDataErrorInfo
    {
        public string Zone
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
            }
        }
        public string Definition
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
            }
        }

        public string Error
        {
            get
            {
                return string.IsNullOrEmpty(this[nameof(Definition)]) ? null : $"{nameof(Definition)} error";
            }
        }


        public string this[string propertyName]
        {
            get
            {
                switch (propertyName)
                {
                    case nameof(Definition):
                        if (!string.IsNullOrWhiteSpace(Definition))
                        {
                            return DataValidator.UTF8StringMaxLength(Definition, 1024);
                        }
                        else
                        {
                            return null;
                        }

                    default:
                        return null;
                }
            }
        }
    }


    public class PostMetrologyModel : PostMetrology, INotifyPropertyChanged
    {
        public PostMetrologyModel(PostMetrology postMetrology)
        {
            ProcessKey = postMetrology.ProcessKey;
            MetroRecipe = postMetrology.MetroRecipe;
            Fab = postMetrology.Fab;
            MetroStage = postMetrology.MetroStage;
            MetroStepName = postMetrology.MetroStepName;
            MetroStepNumber = postMetrology.MetroStepNumber;
        }

        private bool _isChecked;
        public bool IsChecked
        {
            get
            {
                return _isChecked;
            }
            set
            {
                _isChecked = value;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(IsChecked)));
            }
        }


        public event PropertyChangedEventHandler PropertyChanged;
    }
}
