﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Threading.Tasks;
using System.Web.Configuration;
using AMAT.R2R.Client.Common.Enums;
using AMAT.R2R.Client.Common.Helpers;
using AMAT.R2R.Client.Common.Services;
using AMAT.R2R.Client.Etch.Messages;
using AMAT.R2R.Client.Etch.Modules.ContextSettings;
using AMAT.R2R.Client.Etch.Services;
using AMAT.R2R.Shared.Base.Constants;
using AMAT.R2R.Shared.Base.DTO;
using AMAT.R2R.Shared.Etch.DTO;
using DevExpress.Data.Filtering;
using DevExpress.Mvvm;
using DevExpress.Mvvm.DataAnnotations;
using DevExpress.Mvvm.Native;
using DevExpress.Xpf.Data;

namespace AMAT.R2R.Client.Etch.Modules.ProcessSettings
{
    public class ProcessListViewModel : EtchViewModelBase
    {
        public const string Auth_Process = "Process";
        public const string Auth_Process_Add = "Process:Add";
        public const string Auth_Process_Copy = "Process:Copy";
        public const string Auth_Process_Edit = "Process:Edit";
        public const string Auth_Process_Delete = "Process:Delete";
        public const string Auth_Process_OutputSettings = "Process:OutputSettings";
        public const string Auth_Process_FeedForwardSettings = "Process:FeedForwardSettings";
        public const string Auth_Process_CreateContext = "Context:Create";


        public ProcessListViewModel()
        {
            Caption = "Process Settings";
            Icon = "SvgImages/Business Objects/BO_KPI_Definition.svg";
            PropertyChanged += OnPropertyChanged;
            Messenger.Default.Register<ProcessChangedMessage>(this, OnProcessChanged);

            InitializePagedSource();
        }

        #region Filtering & Paging

        private void InitializePagedSource()
        {
            #region Paged Source
            var pagedSource = new PagedAsyncSource()
            {
                ElementType = typeof(ProcessModel),
                KeyProperty = nameof(Process.ProcessId),
                PageSize = 100,
                PageNavigationMode = PageNavigationMode.ArbitraryWithTotalPageCount
            };

#if DEBUG
            pagedSource.PageSize = 10;
#endif

            pagedSource.FetchPage += (o, e) =>
            {
                e.Result = FetchPageRowsAsync(e);
            };

            pagedSource.GetTotalSummaries += (o, e) =>
            {
                e.Result = GetSummariesAsync(e);
            };

            pagedSource.GetUniqueValues += (o, e) =>
            {
                e.Result = GetValueListAsync(e);
            };

            pagedSource.PropertyChanged += (o, e) =>
            {
                if (e.PropertyName == nameof(PagedAsyncSource.AreRowsFetching))
                {
                    IsLoading = PagedSource.AreRowsFetching;

                    // restore selection.
                    if (!IsLoading)
                    {
                        if (_lastSelectedItem != null)
                        {
                            foreach (var item in PagedSource)
                            {
                                var process = item as ProcessModel;
                                if (process.ProcessId == _lastSelectedItem.ProcessId)
                                {
                                    SelectedProcess = process;
                                    break;
                                }
                            }
                        }
                    }
                }
            };

            PagedSource = pagedSource;
            #endregion
        }

        ProcessModel _lastSelectedItem = null;

        private async Task<FetchRowsResult> FetchPageRowsAsync(FetchPageAsyncEventArgs e)
        {
            try
            {
                if (SelectedProcess != null)
                {
                    _lastSelectedItem = SelectedProcess;
                }

                var items = await ProcessService.GetProcessListAsync(e.Filter.MakeFilters(), e.MakeSorters(), e.Skip, e.Take);
                return new FetchRowsResult(items.ToArray(), hasMoreRows: items.Count == e.Take);
            }
            catch (Exception ex)
            {
                Logger.Error(ex);
                throw;
            }
        }

        private async Task<object[]> GetSummariesAsync(GetSummariesAsyncEventArgs e)
        {
            try
            {
                var summary = await ProcessService.GetProcessCount(e.Filter.MakeFilters());
                return e.Summaries.Select(x =>
                {
                    return x.SummaryType == SummaryType.Count ? (object)summary : throw new InvalidOperationException();
                }).ToArray();
            }
            catch (Exception ex)
            {
                Logger.Error(ex);
                throw;
            }
        }

        private async Task<object[]> GetValueListAsync(GetUniqueValuesAsyncEventArgs e)
        {
            try
            {
                if (e.PropertyName == nameof(Process.ProcessEnabled) || e.PropertyName == nameof(Process.OptContextGroupEnabled))
                {
                    var values = new object[] { true, false };
                    return await Task.Factory.StartNew(() => values);
                }
                else
                {
                    return await ProcessService.GetProcessValueListAsync(e.PropertyName, e.Filter.MakeFilters());
                }
            }
            catch (Exception ex)
            {
                Logger.Error(ex);
                throw;
            }
        }

        #endregion


        #region Events
        protected override void OnViewReadyAsync()
        {
            //Refresh();
        }

        public override void OnRemoving(CancelEventArgs e)
        {
            base.OnRemoving(e);

            PagedSource?.Dispose();
            Messenger.Default.Unregister<ProcessChangedMessage>(this, OnProcessChanged);
        }

        private async void OnPropertyChanged(object sender, System.ComponentModel.PropertyChangedEventArgs e)
        {
            if (e.PropertyName == nameof(SelectedProcess))
            {
                if (SelectedProcess != null)
                {
                    await GetProcessDetailsAsync();
                }
                else
                {
                    ClearProcessDetails();
                }
            }
        }

        private void OnProcessChanged(ProcessChangedMessage msg)
        {
            Refresh();
        }

        private async Task RefreshSingleProcess(ProcessModel process)
        {
            var lastModifiedTime = process.LastModifiedTime;
            ProcessModel newProcess = await ProcessService.GetProcessAsync(process.ProcessId);

            process.AvailablePostMetrology = newProcess.AvailablePostMetrology;
            process.AvailablePreMetrology = newProcess.AvailablePreMetrology;
            process.FeedforwardSettings = newProcess.FeedforwardSettings;
            process.OutputSettings = newProcess.OutputSettings;
            process.OptContextGroupEnabled = newProcess.OptContextGroupEnabled;
            process.ProcessEnabled = newProcess.ProcessEnabled;
            process.LastModifiedBy = newProcess.LastModifiedBy;
            process.LastModifiedTime = newProcess.LastModifiedTime;
            process.NotifyPrePostSettingsChanges();

            if (SelectedProcess != null && process.ProcessId == SelectedProcess.ProcessId && lastModifiedTime != newProcess.LastModifiedTime)
            {
                await GetProcessDetailsAsync();
            }
        }
        #endregion

        #region Commands
        [Command]
        public void Refresh()
        {
            PagedSource.UpdateSummaries();
            PagedSource.RefreshRows();
        }

        public bool CanRefresh()
        {
            return !IsLoading;
        }

        private async Task GetProcessDetailsAsync()
        {
            if (SelectedProcess != null)
            {
                OutputSettingVMList = new ObservableCollection<ViewOutputSettingsViewModel>
                    (SelectedProcess.OutputSettings.Select(s => new ViewOutputSettingsViewModel(SelectedProcess, s)));

                FeedforwardSettingVMList = new ObservableCollection<ViewFeedforwardSettingsViewModel>
                (SelectedProcess.FeedforwardSettings.Select(s => new ViewFeedforwardSettingsViewModel(SelectedProcess, s)));

                try
                {
                    IsHistoryLoading = true;
                    HistoryList = new ObservableCollection<TransactionHistory>(await GlobalService.GetHistoryAsync(ClientInfo.LoginArea, "Process", SelectedProcess.ProcessKey, null));
                }
                finally
                {
                    IsHistoryLoading = false;
                }
            }
            else
            {
                OutputSettingVMList?.Clear();
                FeedforwardSettingVMList?.Clear();
                HistoryList?.Clear();
            }
        }

        [Command]
        public void Add()
        {
            ShowPopup("EditProcess", new EditProcessViewModel(null, FunctionMode.Add));
        }

        public bool CanAdd()
        {
            return AuthorityManager.HasAuthority(Auth_Process_Add);
        }

        [Command]
        public async void Copy()
        {
            await UpdateBeforeAction();
            ShowPopup("EditProcess", new EditProcessViewModel(SelectedProcess, FunctionMode.Add));
        }

        public bool CanCopy()
        {
            return SelectedProcess != null && !IsLoading && SelectedProcessList != null && SelectedProcessList.Count == 1 && AuthorityManager.HasAuthority(Auth_Process_Copy);
        }

        [Command]
        public async void Edit()
        {
            await UpdateBeforeAction();
            ShowPopup("EditProcess", new EditProcessViewModel(SelectedProcess, FunctionMode.Modify));
        }

        public bool CanEdit()
        {
            return SelectedProcess != null && !IsLoading && SelectedProcessList != null && SelectedProcessList.Count == 1 &&
                AuthorityManager.HasAuthority(Auth_Process_Edit);
        }


        [Command]
        public async void Delete()
        {
            await UpdateBeforeAction();
            if (IsConfirmed(out var comment, $"Delete Process"))
            {
                var toDeleteProcess = SelectedProcess;
                await ProcessService.DeleteProcessAsync(SelectedProcess.ProcessId, comment);
                Messenger.Default.Send(new ProcessChangedMessage() { ChangeType = ObjectChangeType.Deleted, ProcessId = toDeleteProcess.ProcessId });
                MessageBoxService.ShowMessage($"Process {toDeleteProcess.ProcessKey} is deleted.", "Success", MessageButton.OK, MessageIcon.Information);
            }
        }

        public bool CanDelete()
        {
            return SelectedProcess != null && !IsLoading && SelectedProcessList != null && SelectedProcessList.Count == 1 &&
                AuthorityManager.HasAuthority(Auth_Process_Delete);
        }

        private void ClearProcessDetails()
        {
            OutputSettingVMList = new ObservableCollection<ViewOutputSettingsViewModel>();
            FeedforwardSettingVMList = new ObservableCollection<ViewFeedforwardSettingsViewModel>();
            HistoryList = new ObservableCollection<TransactionHistory>();
        }

        [Command]
        public async void AddContext()
        {
            await UpdateBeforeAction();
            ShowPopup("EditContext", new EditContextViewModel(SelectedProcess, new Context(), FunctionMode.Add));
        }

        public bool CanAddContext()
        {
            return SelectedProcess != null && !IsLoading && SelectedProcessList != null && SelectedProcessList.Count == 1 &&
                AuthorityManager.HasAuthority(Auth_Process_CreateContext);
        }

        [Command]
        public async void EditOutputSettings()
        {
            await UpdateBeforeAction();
            ShowPopup("EditOutputSettings", new EditOutputSettingsViewModel(SelectedProcess));
        }

        public bool CanEditOutputSettings()
        {
            return SelectedProcess != null && !IsLoading && SelectedProcessList != null && SelectedProcessList.Count == 1 &&
                AuthorityManager.HasAuthority(Auth_Process_OutputSettings);
        }

        [Command]
        public async void EditFeedforwardSettings()
        {
            await UpdateBeforeAction();
            ShowPopup("EditFeedforwardSettings", new EditFeedforwardSettingsViewModel(SelectedProcess));
        }

        public bool CanEditFeedforwardSettings()
        {
            return SelectedProcess != null && !IsLoading && SelectedProcessList != null && SelectedProcessList.Count == 1 &&
                AuthorityManager.HasAuthority(Auth_Process_FeedForwardSettings);
        }

        protected async Task UpdateBeforeAction()
        {
            ShowWait();
            await RefreshSingleProcess(SelectedProcess);
            HideWait();
        }
        #endregion

        #region Properties

        public PagedAsyncSource PagedSource
        {
            get { return GetValue<PagedAsyncSource>(); }
            set { SetValue(value); }
        }

        public ProcessModel SelectedProcess
        {
            get { return GetValue<ProcessModel>(); }
            set { SetValue(value); }
        }
        public ObservableCollection<ProcessModel> SelectedProcessList { get; } = new ObservableCollection<ProcessModel>();

        public ObservableCollection<ViewOutputSettingsViewModel> OutputSettingVMList
        {
            get { return GetValue<ObservableCollection<ViewOutputSettingsViewModel>>(); }
            set { SetValue(value); }
        }

        public ObservableCollection<ViewFeedforwardSettingsViewModel> FeedforwardSettingVMList
        {
            get { return GetValue<ObservableCollection<ViewFeedforwardSettingsViewModel>>(); }
            set { SetValue(value); }
        }

        #endregion
    }
}
