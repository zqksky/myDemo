﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AMAT.R2R.Shared.Etch.DTO;

namespace AMAT.R2R.Client.Etch.Modules.ProcessSettings
{
    public class ProcessModel : Process, INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;

        public void NotifyPrePostSettingsChanges()
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(PreMetrologyParameter)));
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(PreMetrologyTarget)));
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(PreMetrologyLowerLimit)));
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(PreMetrologyUpperLimit)));
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(OutputParameter)));
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(OutputTarget)));
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(OutputLowerLimit)));
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(OutputUpperLimit)));
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(LastModifiedBy)));
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(LastModifiedTime)));
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(ProcessEnabled)));
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(OptContextGroupEnabled)));
        }

        public string PreMetrologyParameter
        {
            get
            {
                return FeedforwardSettings == null ? string.Empty : string.Join(",", FeedforwardSettings.Select(s => s.Parameter?.ParameterName));
            }
        }

        public string PreMetrologyTarget
        {
            get
            {
                return FeedforwardSettings == null ? string.Empty : string.Join(",", FeedforwardSettings.Select(s => s.Target));
            }
        }

        public string PreMetrologyLowerLimit
        {
            get
            {
                return FeedforwardSettings == null ? string.Empty : string.Join(",", FeedforwardSettings.Select(s => s.LowerLimit));
            }
        }

        public string PreMetrologyUpperLimit
        {
            get
            {
                return FeedforwardSettings == null ? string.Empty : string.Join(",", FeedforwardSettings.Select(s => s.UpperLimit));
            }
        }

        public string OutputParameter
        {
            get
            {
                return OutputSettings == null ? string.Empty : string.Join(",", OutputSettings.Select(o => o.Parameter?.ParameterName));
            }
        }

        public string OutputTarget
        {
            get
            {
                return OutputSettings == null ? string.Empty : string.Join(",", OutputSettings.Select(o => o.Target));
            }
        }

        public string OutputLowerLimit
        {
            get
            {
                return OutputSettings == null ? string.Empty : string.Join(",", OutputSettings.Select(o => o.LowerLimit));
            }
        }

        public string OutputUpperLimit
        {
            get
            {
                return OutputSettings == null ? string.Empty : string.Join(",", OutputSettings.Select(o => o.UpperLimit));
            }
        }
    }
}
