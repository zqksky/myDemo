﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using AMAT.R2R.Client.Common.Enums;
using AMAT.R2R.Shared.Base.DTO;
using AMAT.R2R.Shared.Etch.DTO;
using DevExpress.Mvvm;
using DevExpress.Mvvm.DataAnnotations;
using DevExpress.Mvvm.Native;

namespace AMAT.R2R.Client.Etch.Modules.ProcessSettings
{
    public class ViewFeedforwardSettingsViewModel : BindableBase
    {
        public Process OwnerProcess { get; private set; }

        public FeedforwardSetting Settings { get; private set; }

        public ViewFeedforwardSettingsViewModel(Process process, FeedforwardSetting feedforwardSetting)
        {
            OwnerProcess = process ?? throw new ArgumentNullException(nameof(process));
            Settings = feedforwardSetting ?? throw new ArgumentNullException(nameof(feedforwardSetting));
            Initialize();
        }


        internal void Initialize()
        {
            AvailableMetrologyList = new ObservableCollection<PreMetrologyModel>(OwnerProcess.AvailablePreMetrology.Select(m => new PreMetrologyModel(m)));
            SelectedMetrology = AvailableMetrologyList.FirstOrDefault(m => m.MetrologyKey == Settings.PreMetrologys?.FirstOrDefault()?.MetrologyKey);

            if (SelectedMetrology != null)
            {
                AvailableMetrologyList.ForEach(m => m.IsChecked = m == SelectedMetrology);
            }
            else
            {
                AvailableMetrologyList.ForEach(m => m.IsChecked = false);
            }
        }


        #region Properties


        public ObservableCollection<PreMetrologyModel> AvailableMetrologyList
        {
            get { return GetValue<ObservableCollection<PreMetrologyModel>>(); }
            set { SetValue(value); }
        }

        public PreMetrologyModel SelectedMetrology
        {
            get { return GetValue<PreMetrologyModel>(); }
            set { SetValue(value); }
        }

        #endregion

    }
}
