﻿using System;
using AMAT.R2R.Client.Common.Enums;
using AMAT.R2R.Client.Common.Helpers;
using AMAT.R2R.Client.Common.ViewModels;
using AMAT.R2R.Client.Common.Views;
using AMAT.R2R.Client.Etch.Messages;
using AMAT.R2R.Shared.Etch.DTO;
using DevExpress.Mvvm;
using DevExpress.Mvvm.DataAnnotations;
using DevExpress.Mvvm.POCO;

namespace AMAT.R2R.Client.Etch.Modules.ProcessSettings
{
    public class EditProcessViewModel : EtchViewModelBase
    {
        private const string NA = "NA";
        public EditProcessViewModel(Process process, FunctionMode mode)
        {
            OriginalProcess = process;
            Mode = mode;

            // TODO: read from config for Primary Keys.
            IsFabPrimaryKey = true;
            IsProductIdPrimaryKey = true;
            IsStagePrimaryKey = true;
            IsRecipePrimaryKey = true;
            IsStepNumberPrimaryKey = false;
            IsStepNamePrimaryKey = false;

            IsFabRequired = IsFabPrimaryKey;
            IsProductIdRequired = IsProductIdPrimaryKey;
            IsStageRequired = IsStagePrimaryKey;
            IsRecipeRequired = IsRecipePrimaryKey;
            IsStepNameRequired = false;
            IsStepNumberRequired = false;

            if (process != null)
            {
                Fab = process.Fab;
                ProductId = process.ProductId;
                Stage = process.Stage;
                Recipe = process.Recipe;
                StepName = process.StepName;
                IsStepNameRequired = StepName != NA;
                StepNumber = process.StepNumber;
                IsStepNumberRequired = StepNumber != NA;
                IsProcessEnabled = process.ProcessEnabled;
                IsContextGroupEnabled = process.OptContextGroupEnabled;
            }
            else
            {
                Fab = ClientInfo.LoginFab;
                StepName = NA;
                StepNumber = NA;
                IsProcessEnabled = true;
                IsContextGroupEnabled = false;
            }

            Caption = Mode == FunctionMode.Modify ? "Edit Process" : "New Process";
            IsDirty = false;
        }

        protected override void OnViewReadyAsync()
        {
            if (Mode == FunctionMode.Add)
            {
                SetFocus(nameof(ProductId));
            }
        }

        public void SetStepNameNA() => StepName = NA;
        public void SetStepNumberNA() => StepNumber = NA;

        [Command]
        public async void Save()
        {
            ValidateAndSetErrorFocus(nameof(Fab), nameof(ProductId), nameof(Stage), nameof(Recipe), nameof(StepName), nameof(StepNumber));

            if (HasErrors)
            {
                return;
            }

            // 
            if (IsConfirmed(out string comment))
            {
                var newProcess = new Process
                {
                    Fab = Fab,
                    Recipe = Recipe,
                    ProductId = ProductId,
                    StepName = StepName,
                    StepNumber = StepNumber,
                    Stage = Stage,
                    ProcessEnabled = IsProcessEnabled,
                    OptContextGroupEnabled = IsContextGroupEnabled,
                    LastModifiedBy = OriginalProcess?.LastModifiedBy,
                    LastModifiedTime = OriginalProcess != null ? OriginalProcess.LastModifiedTime : DateTime.MinValue
                };

                if (Mode == FunctionMode.Modify)
                {
                    ShowWait();
                    newProcess.ProcessId = OriginalProcess.ProcessId;
                    await ProcessService.ModifyProcessAsync(newProcess.ProcessId, newProcess, comment);
                    IsDirty = false;
                    HideWait();
                    Messenger.Default.Send(new ProcessChangedMessage() { ChangeType = ObjectChangeType.Updated, ProcessId = OriginalProcess.ProcessId });
                    MessageBoxService.ShowMessage($"Process {newProcess.ProcessKey} is updated!", "Success", MessageButton.OK, MessageIcon.Information);
                }
                else
                {
                    ShowWait();
                    var createdProcess = await ProcessService.CreateProcessAsync(newProcess, comment);
                    IsDirty = false;
                    HideWait();
                    Messenger.Default.Send(new ProcessChangedMessage() { ChangeType = ObjectChangeType.Created, ProcessId = createdProcess.ProcessId });
                    MessageBoxService.ShowMessage($"Process {createdProcess.ProcessKey} is created!", "Success", MessageButton.OK, MessageIcon.Information);
                }

                IsOK = true;
                CloseWindow();
            }
        }

        public bool CanSave()
        {
            switch (Mode)
            {
                case FunctionMode.Add:
                    return true;
                case FunctionMode.Modify:
                    return IsDirty;
                default:
                    return true;
            }
        }

        protected override string GetError(string columnName)
        {
            switch (columnName)
            {
                case nameof(Fab):
                    return DataValidator.ValidString(Fab);
                case nameof(ProductId):
                    return DataValidator.ValidString(ProductId);
                case nameof(Stage):
                    return DataValidator.ValidString(Stage, 255);
                case nameof(Recipe):
                    return DataValidator.ValidString(Recipe, 255);
                case nameof(StepNumber):
                    return DataValidator.ValidString(StepNumber, 255);
                case nameof(StepName):
                    if (StepNumber != NA && StepName == NA)
                    {
                        return "Step Name cannot be NA when StepNumber is not NA";
                    }
                    return DataValidator.ValidString(StepName, 255);
                default:
                    return null;
            }
        }


        #region Properties
        public Process OriginalProcess { get; private set; }

        public Process SubmittedProcess { get; set; }


        public string Fab
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(Fab));
            }
        }

        public string ProductId
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(ProductId));
            }
        }

        public string Recipe
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(Recipe));
            }
        }
        public string StepName
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(StepName));
            }
        }
        public string StepNumber
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(StepNumber));
                ClearError(nameof(StepName));
            }
        }
        public string Stage
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(Stage));
            }
        }

        public bool IsProcessEnabled { get { return GetValue<bool>(); } set { SetValue(value); IsDirty = true; } }
        public bool IsContextGroupEnabled { get { return GetValue<bool>(); } set { SetValue(value); IsDirty = true; } }
        public bool IsFabPrimaryKey { get { return GetValue<bool>(); } set { SetValue(value); } }
        public bool IsFabRequired
        {
            get
            {
                return GetValue<bool>();
            }
            set
            {
                SetValue(value);
                SetFocus(nameof(Fab));
            }
        }
        public bool IsProductIdPrimaryKey { get { return GetValue<bool>(); } set { SetValue(value); } }
        public bool IsProductIdRequired
        {
            get
            {
                return GetValue<bool>();
            }
            set
            {
                SetValue(value);
                if (value)
                {
                    SetFocus(nameof(ProductId));
                }
            }
        }
        public bool IsStagePrimaryKey { get { return GetValue<bool>(); } set { SetValue(value); } }
        public bool IsStageRequired
        {
            get
            {
                return GetValue<bool>();
            }
            set
            {
                SetValue(value);
                if (value)
                {
                    SetFocus(nameof(Stage));
                }
            }
        }
        public bool IsRecipePrimaryKey { get { return GetValue<bool>(); } set { SetValue(value); } }
        public bool IsRecipeRequired
        {
            get
            {
                return GetValue<bool>();
            }
            set
            {
                SetValue(value);
                if (value)
                {
                    SetFocus(nameof(Recipe));
                }
            }
        }
        public bool IsStepNamePrimaryKey { get { return GetValue<bool>(); } set { SetValue(value); } }
        public bool IsStepNameRequired
        {
            get
            {
                return GetValue<bool>();
            }
            set
            {
                SetValue(value);
                if (value)
                {
                    SetFocus(nameof(StepName));
                }
                RaisePropertiesChanged(nameof(IsStepNameReadOnly));
            }
        }

        public bool IsStepNameReadOnly
        {
            get { return !IsStepNameRequired || Mode == FunctionMode.Modify; }
        }

        public bool IsStepNumberPrimaryKey { get { return GetValue<bool>(); } set { SetValue(value); } }
        public bool IsStepNumberRequired
        {
            get
            {
                return GetValue<bool>();
            }
            set
            {
                SetValue(value);
                if (value)
                {
                    SetFocus(nameof(StepNumber));
                }

                ClearError(nameof(StepName));
                RaisePropertiesChanged(nameof(IsStepNumberReadOnly));
            }
        }
        public bool IsStepNumberReadOnly
        {
            get { return !IsStepNumberRequired || Mode == FunctionMode.Modify; }
        }

        #endregion
    }
}
