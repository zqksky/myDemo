﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using AMAT.R2R.Client.Common.Enums;
using AMAT.R2R.Shared.Base.DTO;
using AMAT.R2R.Shared.Etch.DTO;
using DevExpress.Mvvm;
using DevExpress.Mvvm.DataAnnotations;
using DevExpress.Mvvm.Native;
using DevExpress.Mvvm.UI.Native;

namespace AMAT.R2R.Client.Etch.Modules.ProcessSettings
{
    public class ViewOutputSettingsViewModel : BindableBase
    {
        public Process OwnerProcess { get; private set; }

        public OutputSetting Settings { get; private set; }

        public ViewOutputSettingsViewModel(Process process, OutputSetting outputSetting)
        {
            OwnerProcess = process ?? throw new ArgumentNullException(nameof(process));
            Settings = outputSetting ?? throw new ArgumentNullException(nameof(outputSetting));

            Initialize();
        }

        internal void Initialize()
        {
            ZoneDefinitionList = new ObservableCollection<ZoneDefinition>()
            {
                new ZoneDefinition() { Zone = "Zone_1" },
                new ZoneDefinition() { Zone = "Zone_2" },
                new ZoneDefinition() { Zone = "Zone_3" },
                new ZoneDefinition() { Zone = "Zone_4" },
                new ZoneDefinition() { Zone = "Zone_5" },
                new ZoneDefinition() { Zone = "Zone_6" },
                new ZoneDefinition() { Zone = "Zone_7" },
                new ZoneDefinition() { Zone = "Zone_8" },
                new ZoneDefinition() { Zone = "Zone_9" },
                new ZoneDefinition() { Zone = "Zone_10" },
            };

            ZoneDefinitionList[0].Definition = Settings.ZonalDefinition001_Output;
            ZoneDefinitionList[1].Definition = Settings.ZonalDefinition002_Output;
            ZoneDefinitionList[2].Definition = Settings.ZonalDefinition003_Output;
            ZoneDefinitionList[3].Definition = Settings.ZonalDefinition004_Output;
            ZoneDefinitionList[4].Definition = Settings.ZonalDefinition005_Output;
            ZoneDefinitionList[5].Definition = Settings.ZonalDefinition006_Output;
            ZoneDefinitionList[6].Definition = Settings.ZonalDefinition007_Output;
            ZoneDefinitionList[7].Definition = Settings.ZonalDefinition008_Output;
            ZoneDefinitionList[8].Definition = Settings.ZonalDefinition009_Output;
            ZoneDefinitionList[9].Definition = Settings.ZonalDefinition010_Output;

            AvailableMetrologyList = new ObservableCollection<PostMetrologyModel>(OwnerProcess.AvailablePostMetrology.Select(m => new PostMetrologyModel(m)));

            SelectedMetrology = AvailableMetrologyList.FirstOrDefault(m => m.MetrologyKey == Settings.PostMetrologys?.FirstOrDefault()?.MetrologyKey);

            if (SelectedMetrology != null)
            {
                AvailableMetrologyList.ForEach(m => m.IsChecked = m == SelectedMetrology);
            }
            else
            {
                AvailableMetrologyList.ForEach(m => m.IsChecked = false);
            }
        }


        #region Properties

        public ObservableCollection<ZoneDefinition> ZoneDefinitionList
        {
            get { return GetValue<ObservableCollection<ZoneDefinition>>(); }
            set { SetValue(value); }
        }

        public ObservableCollection<PostMetrologyModel> AvailableMetrologyList
        {
            get { return GetValue<ObservableCollection<PostMetrologyModel>>(); }
            set { SetValue(value); }
        }


        public PostMetrologyModel SelectedMetrology
        {
            get { return GetValue<PostMetrologyModel>(); }
            set { SetValue(value); }
        }


        #endregion

    }

}
