﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Linq;
using System.Threading.Tasks;
using AMAT.R2R.Client.Common.Enums;
using AMAT.R2R.Client.Common.Views;
using AMAT.R2R.Client.Etch.Messages;
using AMAT.R2R.Shared.Base.DTO;
using AMAT.R2R.Shared.Etch.DTO;
using DevExpress.Mvvm;
using DevExpress.Mvvm.DataAnnotations;
using DevExpress.Mvvm.ModuleInjection;
using DevExpress.Mvvm.Native;

namespace AMAT.R2R.Client.Etch.Modules.ProcessSettings
{
    public class EditFeedforwardSettingsViewModel : EtchViewModelBase
    {
        public EditFeedforwardSettingsViewModel(Process process)
        {
            CurrentProcess = process;
            Mode = FunctionMode.View;
            SizeToContent = System.Windows.SizeToContent.Manual;
            Caption = $"Feed Forward Settings";
        }
        protected override void OnViewReadyAsync()
        {
            RefreshAll();
        }


        [Command]
        public async void RefreshAll()
        {
            if (IsDirty && MessageBoxService.ShowMessage("The unsaved changes will be abandoned if you proceed. Are your sure to continue?", "Confirm Refresh", MessageButton.YesNo, MessageIcon.Question) == MessageResult.No)
            {
                return;
            }
            ShowWait();
            CurrentProcess = await ProcessService.GetProcessAsync(CurrentProcess.ProcessId);

            QualityItemNameList = GlobalService.GetGOFItemList();

            ParameterList = await GlobalService.GetMetroParameterListAsync();

            CurrentProcess.FeedforwardSettings = await ProcessService.GetFeedforwardSettingListAsync(CurrentProcess.ProcessId);

            SettingVMList = new ObservableCollection<FeedforwardSettingsViewModel>(
                CurrentProcess.FeedforwardSettings.Select(o => new FeedforwardSettingsViewModel(CurrentProcess, o, FunctionMode.Modify)));

            foreach (var vm in SettingVMList)
            {
                vm.PropertyChanged += Vm_PropertyChanged;
            }

            SelectedSettingVM = SettingVMList.FirstOrDefault();

            IsDirty = false;
            HideWait();
        }


        [Command]
        public async void Refresh()
        {
            if (SelectedSettingVM.IsDirty && MessageBoxService.ShowMessage("The unsaved changes will be abandoned if you proceed. Are your sure to continue?", "Confirm Refresh", MessageButton.YesNo, MessageIcon.Question) == MessageResult.No)
            {
                return;
            }

            ShowWait();
            FeedforwardSetting originalSetting = null;

            if (SelectedSettingVM.Mode == FunctionMode.Modify)
            {
                originalSetting = await ProcessService.GetFeedforwardSettingAsync(SelectedSettingVM.OwnerProcess.ProcessId, SelectedSettingVM.OriginalSettings.PreMetroId);
            }

            SelectedSettingVM.Initialize(SelectedSettingVM.OwnerProcess, originalSetting, SelectedSettingVM.Mode);

            UpdateIsDirty();
            HideWait();
        }


        private void Vm_PropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            if (e.PropertyName == nameof(IsDirty))
            {
                IsDirty = SettingVMList.Any(v => v.IsDirty);
            }
            else if (e.PropertyName == nameof(FeedforwardSettingsViewModel.SelectedParameter))
            {
                // check duplidate parameter, if duplicated, reset it.
                var currentVM = sender as FeedforwardSettingsViewModel;
                if (currentVM != null && currentVM.SelectedParameter != null && currentVM.Mode == FunctionMode.Add && SettingVMList.Any(vm => vm != currentVM && vm.SelectedParameter?.ParameterName == currentVM.SelectedParameter.ParameterName))
                {
                    MessageBoxService.ShowMessage("An Feedforward Settings with the same Parameter already exists.", "Duplicated Parameter", MessageButton.OK, MessageIcon.Asterisk);
                    DispatcherHelperService.RunAsync(() => currentVM.SelectedParameter = null);
                    return;
                }
            }
        }

        private void UpdateIsDirty()
        {
            IsDirty = SettingVMList.Any(v => v.IsDirty);
        }

        [Command]
        public void AddMetrology()
        {
            if (ShowPopup("AddMetrology", new AddMetrologyViewModel(CurrentProcess, MetrologyType.Pre)).IsOK)
            {
                // refresh Metrology list for all settings.
                CurrentProcess.AvailablePreMetrology = ProcessService.GetPreMetrologyList(CurrentProcess.ProcessId);
                SettingVMList.ForEach(vm =>
                {
                    var previousSelectedMetrology = vm.SelectedMetrology;
                    bool originalIsDirty = vm.IsDirty;
                    vm.AvailableMetrologyList = new ObservableCollection<PreMetrologyModel>(CurrentProcess.AvailablePreMetrology.Select(m => new PreMetrologyModel(m)));
                    if (previousSelectedMetrology != null)
                    {
                        vm.SelectedMetrology = vm.AvailableMetrologyList.FirstOrDefault(m => m.MetrologyKey == previousSelectedMetrology.MetrologyKey);
                        vm.IsDirty = originalIsDirty;
                    }
                });
            }
        }

        [Command]
        public async void DeleteMetrology()
        {
            if (IsConfirmed(out var comment, "Delete Selected Metrology"))
            {
                ShowWait();
                await ProcessService.DeletePreMetrologyAsync(CurrentProcess.ProcessId, SelectedSettingVM.SelectedMetrology.MetrologyKey, comment);
                CurrentProcess.AvailablePreMetrology = ProcessService.GetPreMetrologyList(CurrentProcess.ProcessId);
                SettingVMList.ForEach(vm =>
                {
                    vm.AvailableMetrologyList = new ObservableCollection<PreMetrologyModel>(CurrentProcess.AvailablePreMetrology.Select(m => new PreMetrologyModel(m)));
                    var previousSelectedMetrology = vm.SelectedMetrology;
                    bool originalIsDirty = vm.IsDirty;
                    if (previousSelectedMetrology != null)
                    {
                        vm.SelectedMetrology = vm.AvailableMetrologyList.FirstOrDefault(m => m.MetrologyKey == previousSelectedMetrology.MetrologyKey);
                        if (vm.SelectedMetrology == null)
                        {
                            vm.IsDirty = true;
                        }
                        else
                        {
                            vm.IsDirty = originalIsDirty;
                        }
                    }
                });
                HideWait();
            }
        }

        public bool CanDeleteMetrology()
        {
            return SelectedSettingVM != null && SelectedSettingVM.SelectedMetrology != null;
        }

        [Command]
        public void CreateNew()
        {
            if (SettingVMList.Count >= 2)
            {
                MessageBoxService.ShowMessage("Cannot setup more than 2 settings.", "Error", MessageButton.OK, MessageIcon.Stop);
                return;
            }
            var newSetting = new FeedforwardSettingsViewModel(CurrentProcess, null, FunctionMode.Add);
            newSetting.PropertyChanged += Vm_PropertyChanged;
            SettingVMList.Add(newSetting);
            SelectedSettingVM = newSetting;

            UpdateIsDirty();
        }


        [Command]
        public async void Save()
        {
            SelectedSettingVM.Validate();

            if (SelectedSettingVM.HasErrors)
            {
                return;
            }

            if (IsConfirmed(out var comment))
            {
                await SaveSettingsAsync(comment, SelectedSettingVM);

                UpdateIsDirty();
            }
        }

        public bool CanSave()
        {
            return SelectedSettingVM != null && SelectedSettingVM.IsDirty;
        }

        private async Task SaveSettingsAsync(string comment, FeedforwardSettingsViewModel settingsVM)
        {
            try
            {
                ShowWait();
                var newSetting = new FeedforwardSetting
                {
                    ProcessId = CurrentProcess.ProcessId,
                    ProcessKey = CurrentProcess.ProcessKey,
                    Parameter = settingsVM.SelectedParameter,
                    Target = settingsVM.Target.Value,
                    LowerLimit = settingsVM.LowerLimit.Value,
                    UpperLimit = settingsVM.UpperLimit.Value,
                    Unit = settingsVM.Unit,
                    QualityItemName = settingsVM.QualityItemName,
                    QualityThreshold = settingsVM.QualityThreshold.Value,
                    OptUseOOLPreMetro = settingsVM.OptUseOOLPreMetro.Value,

                    OptUseOOLRange = settingsVM.OptUseOOLRange.Value,
                    OptRangeThreshold = settingsVM.OptRangeThreshold.Value,
                    OptUseOOLStdDev = settingsVM.OptUseOOLStdDev.Value,
                    OptStdDevThreshold = settingsVM.OptStdDevThreshold.Value,

                    OptNoOfSitePerWafer = (int)settingsVM.OptNoOfSitePerWafer.Value,
                    OptMinPercentRemaining = settingsVM.OptMinPercentRemaining.Value,
                    OptLowerBetterFilt = settingsVM.OptLowerBetterFilt.Value,

                    OptOffsetPerSlot = settingsVM.OptOffsetPerSlot.Value,
                    OptLambda = settingsVM.OptLambda.Value,

                    PreMetrologys = new List<PreMetrology>() { settingsVM.SelectedMetrology }
                };

                if (settingsVM.Mode == FunctionMode.Add)
                {
                    var updatedSettings = await ProcessService.CreateFeedforwardSettingAsync(CurrentProcess.ProcessId, newSetting, comment);

                    settingsVM.Initialize(settingsVM.OwnerProcess, updatedSettings, FunctionMode.Modify);
                }
                else
                {
                    newSetting.PreMetroId = settingsVM.OriginalSettings.PreMetroId;
                    await ProcessService.ModifyFeedforwardSettingAsync(CurrentProcess.ProcessId, newSetting.PreMetroId, newSetting, comment);
                    var updatedSettings = await ProcessService.GetFeedforwardSettingAsync(CurrentProcess.ProcessId, settingsVM.OriginalSettings.PreMetroId);
                    settingsVM.Initialize(settingsVM.OwnerProcess, updatedSettings, FunctionMode.Modify);
                }

                HideWait();

                Messenger.Default.Send(new ProcessChangedMessage() { ChangeType = ObjectChangeType.Updated, ProcessId = CurrentProcess.ProcessId });
                MessageBoxService.ShowMessage($"{settingsVM.SelectedParameter.ParameterName} saved successfully.",
                                                 "Success",
                                                 MessageButton.OK,
                                                 MessageIcon.Information);
            }
            catch (Exception ex)
            {
                ErrorHandler.HandleError(ex);
            }
        }

        [Command]
        public async void SaveAll()
        {
            foreach (var output in SettingVMList.Where(vm => vm.IsDirty))
            {
                SelectedSettingVM = output;
                output.Validate();

                if (output.HasErrors)
                {
                    return;
                }
            }

            if (IsConfirmed(out var comment))
            {
                foreach (var setting in SettingVMList)
                {
                    if (setting.IsDirty)
                    {
                        await SaveSettingsAsync(comment, setting);
                    }
                }

                UpdateIsDirty();
                if (!IsDirty)
                {
                    Refresh();
                }
            }
        }

        public bool CanSaveAll()
        {
            return SettingVMList != null && SettingVMList.Any(o => o.IsDirty) && SettingVMList.All(o => o.SelectedMetrology != null);
        }

        [Command]
        public void Delete()
        {
            if (SelectedSettingVM.Mode == FunctionMode.Modify)
            {
                if (IsConfirmed(out var comment))
                {
                    var toDeleteSettingName = SelectedSettingVM.ParameterName;
                    ProcessService.DeleteFeedforwardSetting(CurrentProcess.ProcessId, SelectedSettingVM.OriginalSettings.PreMetroId, comment);
                    Messenger.Default.Send(new ProcessChangedMessage() { ChangeType = ObjectChangeType.Updated, ProcessId = CurrentProcess.ProcessId });
                    SettingVMList.Remove(SelectedSettingVM);
                    MessageBoxService.ShowMessage($"Setting {toDeleteSettingName} is deleted.", "Delete Success!", MessageButton.OK, MessageIcon.Information);
                }
            }
            else
            {
                SettingVMList.Remove(SelectedSettingVM);
            }

            UpdateIsDirty();
        }

        public bool CanDelete()
        {
            return SelectedSettingVM != null;
        }


        public Process CurrentProcess
        {
            get { return GetValue<Process>(); }
            set { SetValue(value); }
        }

        public ObservableCollection<FeedforwardSettingsViewModel> SettingVMList
        {
            get { return GetValue<ObservableCollection<FeedforwardSettingsViewModel>>(); }
            set { SetValue(value); }
        }

        private FeedforwardSettingsViewModel _selectedFeedforwardSettingVM;
        public FeedforwardSettingsViewModel SelectedSettingVM
        {
            get { return _selectedFeedforwardSettingVM; }
            set
            {
                _selectedFeedforwardSettingVM = value;
                RaisePropertyChanged(nameof(SelectedSettingVM));
            }
        }

        public List<string> QualityItemNameList
        {
            get { return GetValue<List<string>>(); }
            set { SetValue(value); }
        }

        public List<Parameter> ParameterList
        {
            get { return GetValue<List<Parameter>>(); }
            set { SetValue(value); }
        }


    }
}
