﻿using System;
using AMAT.R2R.Client.Common.Enums;
using AMAT.R2R.Client.Common.Helpers;
using AMAT.R2R.Shared.Etch.DTO;
using DevExpress.Mvvm;
using DevExpress.Mvvm.DataAnnotations;

namespace AMAT.R2R.Client.Etch.Modules.ProcessSettings
{
    public enum MetrologyType
    {
        Pre,
        Post
    }

    public class AddMetrologyViewModel : EtchViewModelBase
    {
        private const string NA = "NA";

        public Process OwnerProcess { get; set; }

        public MetrologyType MetrologyType { get; set; }

        public AddMetrologyViewModel(Process process, MetrologyType type)
        {
            OwnerProcess = process;
            MetrologyType = type;
            Mode = FunctionMode.Add;
            SizeToContent = System.Windows.SizeToContent.WidthAndHeight;

            Fab = ClientInfo.LoginFab;

            IsFabPrimaryKey = true;
            IsStagePrimaryKey = true;
            IsRecipePrimaryKey = false;

            IsStepNumberPrimaryKey = false;
            IsStepNamePrimaryKey = false;

            IsFabRequired = IsFabPrimaryKey;
            IsStageRequired = IsStagePrimaryKey;
            IsRecipeRequired = true;
            IsStepNameRequired = false;
            IsStepNumberRequired = false;

            Fab = ClientInfo.LoginFab;
            StepName = NA;
            StepNumber = NA;

            if (MetrologyType == MetrologyType.Post)
            {
                Caption = "Add Post Metrology";
            }
            else
            {
                Caption = "Add Pre Metrology";
            }

            IsDirty = true;
        }

        protected override void OnViewReadyAsync()
        {
            if (Mode == FunctionMode.Add)
            {
                SetFocus(nameof(Stage));
            }
        }

        [Command]
        public void Save()
        {
            ValidateAndSetErrorFocus(nameof(Fab), nameof(Stage), nameof(Recipe), nameof(StepName), nameof(StepNumber));

            if (HasErrors)
            {
                return;
            }

            if (IsConfirmed(out string comment))
            {

                if (Mode == FunctionMode.Modify)
                {
                    //ProcessService.(newProcess.ProcessKey, newProcess, comment);
                }
                else
                {
                    if (MetrologyType == MetrologyType.Pre)
                    {
                        ProcessService.CreatePreMetrology(OwnerProcess.ProcessId, new PreMetrology
                        {
                            ProcessId = OwnerProcess.ProcessId,
                            ProcessKey = OwnerProcess.ProcessKey,
                            Fab = Fab,
                            MetroRecipe = Recipe,
                            MetroStepName = StepName,
                            MetroStepNumber = StepNumber,
                            MetroStage = Stage,
                        }, comment);
                    }
                    else
                    {
                        ProcessService.CreatePostMetrology(OwnerProcess.ProcessId, new PostMetrology
                        {
                            ProcessId = OwnerProcess.ProcessId,
                            ProcessKey = OwnerProcess.ProcessKey,
                            Fab = Fab,
                            MetroRecipe = Recipe,
                            MetroStepName = StepName,
                            MetroStepNumber = StepNumber,
                            MetroStage = Stage,
                        }, comment);
                    }
                }

                IsOK = true;
                CloseWindow();
            }
        }

        public bool CanSave()
        {
            switch (Mode)
            {
                case FunctionMode.Add:
                    return true;
                case FunctionMode.Modify:
                    return IsDirty;
                default:
                    return true;
            }
        }

        protected override string GetError(string columnName)
        {
            switch (columnName)
            {
                case nameof(Fab):
                    return DataValidator.ValidString(Fab);
                case nameof(Stage):
                    return DataValidator.ValidString(Stage);
                case nameof(Recipe):
                    return DataValidator.ValidString(Recipe);
                case nameof(StepNumber):
                    return DataValidator.ValidString(StepNumber);
                case nameof(StepName):
                    return DataValidator.ValidString(StepName);
                default:
                    return null;
            }
        }


        public void SetStepNameNA() => StepName = NA;
        public void SetStepNumberNA() => StepNumber = NA;
        public void SetRecipeNA() => Recipe = NA;


        public string Fab
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(Fab));
            }
        }

        public string Recipe
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(Recipe));
            }
        }
        public string StepName
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(StepName));
            }
        }
        public string StepNumber
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(StepNumber));
            }
        }
        public string Stage
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(Stage));
            }
        }


        public bool IsFabPrimaryKey { get { return GetValue<bool>(); } set { SetValue(value); } }
        public bool IsFabRequired
        {
            get
            {
                return GetValue<bool>();
            }
            set
            {
                SetValue(value);
                SetFocus(nameof(Fab));
            }
        }

        public bool IsStagePrimaryKey { get { return GetValue<bool>(); } set { SetValue(value); } }
        public bool IsStageRequired
        {
            get
            {
                return GetValue<bool>();
            }
            set
            {
                SetValue(value);
                if (value)
                {
                    SetFocus(nameof(Stage));
                }
            }
        }
        public bool IsRecipePrimaryKey { get { return GetValue<bool>(); } set { SetValue(value); } }
        public bool IsRecipeRequired
        {
            get
            {
                return GetValue<bool>();
            }
            set
            {
                SetValue(value);
                if (value)
                {
                    SetFocus(nameof(Recipe));
                }
                RaisePropertiesChanged(nameof(IsRecipeReadOnly));
            }
        }
        public bool IsStepNamePrimaryKey { get { return GetValue<bool>(); } set { SetValue(value); } }
        public bool IsStepNameRequired
        {
            get
            {
                return GetValue<bool>();
            }
            set
            {
                SetValue(value);
                if (value)
                {
                    SetFocus(nameof(StepName));
                }
                RaisePropertiesChanged(nameof(IsStepNameReadOnly));
            }
        }

        public bool IsStepNameReadOnly
        {
            get { return !IsStepNameRequired || Mode == FunctionMode.Modify; }
        }

        public bool IsStepNumberPrimaryKey { get { return GetValue<bool>(); } set { SetValue(value); } }
        public bool IsStepNumberRequired
        {
            get
            {
                return GetValue<bool>();
            }
            set
            {
                SetValue(value);
                if (value)
                {
                    SetFocus(nameof(StepNumber));
                }
                RaisePropertiesChanged(nameof(IsStepNumberReadOnly));
            }
        }
        public bool IsStepNumberReadOnly
        {
            get { return !IsStepNumberRequired || Mode == FunctionMode.Modify; }
        }


        public bool IsRecipeReadOnly
        {
            get { return !IsRecipeRequired || Mode == FunctionMode.Modify; }
        }
    }
}
