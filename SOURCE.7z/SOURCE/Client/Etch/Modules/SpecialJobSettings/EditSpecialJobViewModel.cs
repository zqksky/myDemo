﻿using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms.Design;
using AMAT.R2R.Client.Common.Enums;
using AMAT.R2R.Client.Common.Helpers;
using AMAT.R2R.Client.Common.Services;
using AMAT.R2R.Client.Etch.Messages;
using AMAT.R2R.Client.Etch.Modules.ContextSettings;
using AMAT.R2R.Shared.Base.DTO;
using AMAT.R2R.Shared.Etch.DTO;
using DevExpress.Mvvm;
using DevExpress.Mvvm.DataAnnotations;
using DevExpress.Xpf.Grid;
using Newtonsoft.Json;

namespace AMAT.R2R.Client.Etch.Modules.SpecialJobSettings
{
    public class EditSpecialJobViewModel : EtchViewModelBase
    {
        private const string NA = "NA";
        public EditSpecialJobViewModel(Context context, SpecialJob sourceSpecialJob, FunctionMode mode)
        {
            CurrentContext = context;
            SizeToContent = System.Windows.SizeToContent.Manual;
            WindowHeight = 600;
            WindowWidth = 1000;
            SourceSpecialJob = sourceSpecialJob;
            Mode = mode;

            switch (mode)
            {
                case FunctionMode.None:
                    break;
                case FunctionMode.Add:
                    Caption = "Create Special Job";
                    break;
                case FunctionMode.Copy:
                    Caption = "Copy Special Job";
                    break;
                case FunctionMode.Modify:
                    Caption = "Edit Special Job";
                    break;
                case FunctionMode.Delete:
                    break;
                case FunctionMode.View:
                    break;
                default:
                    break;
            }
        }

        protected override void OnViewReadyAsync()
        {
            Refresh();
        }

        private void Refresh()
        {
            ShowWait();

            if (Mode != FunctionMode.Add)
            {
                // clone source job.
                NewSpecialJob = JsonConvert.DeserializeObject<SpecialJob>(JsonConvert.SerializeObject(SourceSpecialJob));
            }
            else
            {
                NewSpecialJob = new SpecialJob
                {
                    Fab = CurrentContext.Fab,
                    ProductId = CurrentContext.ProductId,
                    Stage = CurrentContext.Stage,
                    Recipe = CurrentContext.Recipe,
                    StepName = CurrentContext.StepName,
                    StepNumber = CurrentContext.StepNumber,
                    Tool = CurrentContext.Tool,
                    Chamber = CurrentContext.Chamber,
                    ContextGroup = CurrentContext.ContextGroup,
                    ContextId = CurrentContext.ContextId,

                    // create default parameters
                    SpecialJobParameters = CurrentContext.GetDefaultSpecialJobParameters(),
                    LotId = string.Empty,
                    RuncardId = NA,
                    SplitId = NA,
                };
            }

            JobParameterList = new ObservableCollection<SpecialJobInputSetting>(NewSpecialJob.SpecialJobParameters.Select(p =>
            new SpecialJobInputSetting()
            {
                ParameterName = p.ParameterName,
                InputValue = p.InputValue,
                Min = p.Min,
                Max = p.Max,
                Unit = p.Unit
            }));

            foreach (var param in JobParameterList)
            {
                param.PropertyChanged += Param_PropertyChanged;
            }

            IsLot = NewSpecialJob.LotId != NA;
            LotId = NewSpecialJob.LotId;
            RunCardId = NewSpecialJob.RuncardId;
            SplitId = NewSpecialJob.SplitId;

            HideWait();

            IsDirty = false;
        }

        private void Param_PropertyChanged(object sender, System.ComponentModel.PropertyChangedEventArgs e)
        {
            if (e.PropertyName == nameof(SpecialJobInputSetting.InputValue))
            {
                IsDirty = true;

                ClearError($"{nameof(JobParameterList)}.{e.PropertyName}");
            }
        }

        [Command]
        public async void Save()
        {
            if (IsLot)
            {
                ValidateAndSetErrorFocus(nameof(LotId));
            }
            else
            {
                ValidateAndSetErrorFocus(nameof(RunCardId), nameof(SplitId));
            }

            if (HasErrors) return;

            foreach (var item in JobParameterList)
            {
                if (item.Error != null)
                {
                    SetError($"{nameof(JobParameterList)}.{item.Error}", item[item.Error]);
                    SetFocus(nameof(JobParameterList));
                    return;
                }
            }

            if (IsConfirmed(out var comment))
            {
                NewSpecialJob.LotId = LotId;
                NewSpecialJob.RuncardId = RunCardId;
                NewSpecialJob.SplitId = SplitId;

                foreach (var param in NewSpecialJob.SpecialJobParameters)
                {
                    param.InputValue = JobParameterList.FirstOrDefault(p => p.ParameterName == param.ParameterName)?.InputValue;
                }

                ShowWait();
                if (Mode == FunctionMode.Add || Mode == FunctionMode.Copy)
                {
                    NewSpecialJob.JobId = string.Empty;
                    var createdJob = await SpecialJobService.CreateSpecialJobAsync(NewSpecialJob, comment);
                    IsDirty = false;
                    HideWait();
                    Messenger.Default.Send(new SpecialJobChangedMessage() { ChangeType = ObjectChangeType.Created, JobId = createdJob.JobId });
                    MessageBoxService.ShowMessage($"Special Job is created!", "Success", MessageButton.OK, MessageIcon.Information);
                }
                else
                {
                    await SpecialJobService.UpdateSpecialJobAsync(NewSpecialJob.JobId, NewSpecialJob, comment);
                    IsDirty = false;
                    HideWait();
                    Messenger.Default.Send(new SpecialJobChangedMessage() { ChangeType = ObjectChangeType.Created, JobId = NewSpecialJob.JobId });
                    MessageBoxService.ShowMessage($"Special Job is updated!", "Success", MessageButton.OK, MessageIcon.Information);
                }
                CloseWindow();
            }
        }

        public bool CanSave()
        {
            return true;
        }

        protected override string GetError(string columnName)
        {
            switch (columnName)
            {
                case nameof(LotId):
                    if (IsLot)
                    {
                        return DataValidator.ValidateInOrder(
                            () => DataValidator.NotNull(LotId),
                            () => LotId == NA ? "Cannot be NA" : null);
                    }
                    else
                    {
                        return LotId == NA ? null : "Must be NA";
                    }
                case nameof(RunCardId):
                    if (IsLot)
                    {
                        return RunCardId == NA ? null : "Must be NA";
                    }
                    else
                    {
                        return DataValidator.ValidateInOrder(
                            () => DataValidator.NotNull(RunCardId),
                            () => DataValidator.UTF8StringMaxLength(RunCardId, 64),
                            () => RunCardId == NA ? "Cannot be NA" : null);
                    }
                case nameof(SplitId):
                    if (IsLot)
                    {
                        return SplitId == NA ? null : "Must be NA";
                    }
                    else
                    {
                        return DataValidator.ValidateInOrder(
                            () => DataValidator.NotNull(SplitId),
                            () => DataValidator.UTF8StringMaxLength(SplitId, 64),
                            () => SplitId == NA ? "Cannot be NA" : null);
                    }
                default:
                    return null;
            }
        }

        public void SetRunCardIdNA() => RunCardId = NA;
        public void SetSplitIdNA() => SplitId = NA;

        #region Properties

        public int ContextId { get; set; }

        public Context CurrentContext
        {
            get { return GetValue<Context>(); }
            set { SetValue(value); }
        }

        public SpecialJob SourceSpecialJob
        {
            get { return GetValue<SpecialJob>(); }
            set { SetValue(value); }
        }

        public SpecialJob NewSpecialJob
        {
            get { return GetValue<SpecialJob>(); }
            set { SetValue(value); }
        }

        public ObservableCollection<SpecialJobInputSetting> JobParameterList
        {
            get { return GetValue<ObservableCollection<SpecialJobInputSetting>>(); }
            set { SetValue(value); }
        }


        public string LotId
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(LotId));
            }
        }

        public string RunCardId
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(RunCardId));
            }
        }

        public string SplitId
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(SplitId));
            }
        }

        public bool IsLot
        {
            get { return GetValue<bool>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(IsLot));
                if (value)
                {
                    if (LotId == NA)
                    {
                        LotId = string.Empty;
                    }
                    RunCardId = NA;
                    SplitId = NA;
                }
                else
                {
                    if (RunCardId == NA)
                    {
                        RunCardId = string.Empty;
                    }
                    if (SplitId == NA)
                    {
                        SplitId = string.Empty;
                    }
                    LotId = NA;
                }
            }
        }
        #endregion
    }

    public class SpecialJobInputSetting : BindableBase, IDataErrorInfo
    {

        public string ParameterName { get; set; }
        public string Unit { get; set; }

        public decimal? InputValue
        {
            get { return GetValue<decimal?>(); }
            set { SetValue(value); }
        }

        public decimal? Min { get; set; }
        public decimal? Max { get; set; }
        public string Error
        {
            get
            {
                //return !string.IsNullOrEmpty(this[nameof(InputValue)]) ? $"{nameof(InputValue)}" : null;
                return DataValidator.ValidateInOrder(
                           () => DataValidator.NotNull(InputValue),
                           () => DataValidator.InRange(InputValue, Min, Max));
            }
        }


        public string this[string propertyName]
        {
            get
            {
                switch (propertyName)
                {
                    case nameof(InputValue):
                        return DataValidator.NotNull(InputValue);
                        
                    default:
                        return null;
                }
            }
        }
    }
}
