﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AMAT.R2R.Shared.Etch.DTO;

namespace AMAT.R2R.Client.Etch.Modules.SpecialJobSettings
{
    public class SpecialJobModel : SpecialJob, INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;

        public void NotifyChanges()
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(LotId)));
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(RuncardId)));
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(SplitId)));
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(JobCompleted)));
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(LastModifiedTime)));
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(LastModifiedBy)));
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(UsedTime)));
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(UserId)));
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(IsValid)));
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(SpecialJobParameters)));
        }
    }
}
