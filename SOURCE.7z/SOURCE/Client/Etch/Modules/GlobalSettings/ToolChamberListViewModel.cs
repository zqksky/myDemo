﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading.Tasks;
using AMAT.R2R.Client.Common.Enums;
using AMAT.R2R.Client.Common.Helpers;
using AMAT.R2R.Client.Common.Services;
using AMAT.R2R.Client.Etch.Messages;
using AMAT.R2R.Shared.Base.DTO;
using AMAT.R2R.Shared.Etch.DTO;
using DevExpress.Mvvm;
using DevExpress.Mvvm.DataAnnotations;

namespace AMAT.R2R.Client.Etch.Modules.ToolChamberSettings
{
    public class ToolChamberListViewModel : EtchViewModelBase
    {
        public const string Auth_Global = "GlobalSettings";
        public const string Auth_Global_Tool = "GlobalSettings:Tool";
        public const string Auth_Global_Tool_Add = "GlobalSettings:Tool:Add";
        public const string Auth_Global_Tool_Edit = "GlobalSettings:Tool:Edit";
        public const string Auth_Global_Tool_Delete = "GlobalSettings:Tool:Delete";
        public const string Auth_Global_Chamber = "GlobalSettings:Chamber";
        public const string Auth_Global_Chamber_Add = "GlobalSettings:Chamber:Add";
        public const string Auth_Global_Chamber_Edit = "GlobalSettings:Chamber:Edit";
        public const string Auth_Global_Chamber_Delete = "GlobalSettings:Chamber:Delete";
        public const string Auth_Global_Parameter = "GlobalSettings:Parameter";
        public const string Auth_Global_Parameter_Add = "GlobalSettings:Parameter:Add";
        public const string Auth_Global_Parameter_Edit = "GlobalSettings:Parameter:Edit";
        public const string Auth_Global_Parameter_Delete = "GlobalSettings:Parameter:Delete";

        public ToolChamberListViewModel()
        {
            Caption = "Tool Chamber Settings";
            Icon = "SvgImages/Business Objects/BO_Category.svg";

            PropertyChanged += OnPropertyChanged;
            Messenger.Default.Register<ToolChangedMessage>(this, OnToolChanged);
        }

        #region Events

        protected override void OnViewReadyAsync()
        {
            Refresh();
        }

        private async void OnPropertyChanged(object sender, System.ComponentModel.PropertyChangedEventArgs e)
        {
            if (e.PropertyName == nameof(SelectedTool))
            {
                if (SelectedTool != null)
                {
                    await GetToolParametersAsync();
                }
                else
                {
                    ParameterList?.Clear();
                }
            }
        }

        private async void OnToolChanged(ToolChangedMessage msg)
        {
            // refresh updated toolChamber. 
            var tool = ToolList.FirstOrDefault(p => p.ToolId == msg.ToolId);
            switch (msg.ChangeType)
            {
                case ObjectChangeType.Created:
                    Refresh();
                    break;
                case ObjectChangeType.Deleted:
                    ToolList.Remove(tool);
                    break;
                case ObjectChangeType.Updated:
                    await UpdateSingleTool(tool.ToolId);

                    break;
                default:
                    break;

            }
        }

        private async Task UpdateSingleTool(string toolId)
        {
            var tool = ToolList.FirstOrDefault(t => t.ToolId == toolId);
            if (tool == null) return;

            var newTool = await GlobalService.GetToolAsync(toolId);
            tool.ToolModel = newTool.ToolModel;
            tool.ToolProcessType = newTool.ToolProcessType;
            tool.ToolType = newTool.ToolType;
            tool.ToolVendor = newTool.ToolVendor;
            tool.Chambers = newTool.Chambers;

            tool.NotifyChanges();

            if (SelectedTool != null && tool.ToolId == SelectedTool.ToolId)
            {
                await GetToolParametersAsync();
            }
        }
        #endregion

        #region Commands

        [Command]
        public async void Refresh()
        {
            try
            {
                IsLoading = true;

                var selectedToolIdList = SelectedToolList.Select(t => t.ToolId).ToList();

                var toolList = await GlobalService.GetToolListAsync();
                var toolModelList = toolList.Select(t => new ToolModel()
                {
                    ToolId = t.ToolId,
                    ToolModel = t.ToolModel,
                    ToolType = t.ToolType,
                    ToolVendor = t.ToolVendor,
                    ToolProcessType = t.ToolProcessType,
                    Chambers = t.Chambers
                }).OrderBy(t => t.ToolId);

                ToolList = new ObservableCollection<ToolModel>(toolModelList);

                SelectedToolList.Clear();

                if (selectedToolIdList.Count > 0)
                {
                    foreach (var id in selectedToolIdList)
                    {
                        if (!SelectedToolList.Any(t => t.ToolId == id))
                        {
                            SelectedToolList.Add(ToolList.FirstOrDefault(t => t.ToolId == id));
                        }
                    }
                }
            }
            finally
            {
                IsLoading = false;
            }
        }
        public bool CanRefresh()
        {
            return !IsLoading;
        }

        [Command]
        public async void RefreshSingle()
        {
            await UpdateSingleTool(SelectedTool.ToolId);
        }
        public bool CanRefreshSingle()
        {
            return !IsLoading && !IsParameterLoading && SelectedTool != null;
        }

        private async Task GetToolParametersAsync()
        {
            if (SelectedTool != null)
            {
                try
                {
                    IsParameterLoading = true;

                    var selectedParameter = SelectedParameter;

                    var parameterList = new List<Parameter>();
                    foreach (var chamber in SelectedTool.Chambers)
                    {
                        var parameters = await GlobalService.GetProcessParameterListAsync(SelectedTool.ToolId, chamber.ChamberId);
                        parameterList.AddRange(parameters);
                    }
                    var totalParameters = parameterList.ToList();

                    var missingChambers = SelectedTool.Chambers.Where(c => !totalParameters.Any(p => p.Chamber.ChamberId == c.ChamberId)).ToList();

                    totalParameters.AddRange(missingChambers.Select(c => new Parameter
                    {
                        Chamber = c
                    }));

                    totalParameters = totalParameters.OrderBy(p => p.Chamber.ChamberId).ThenBy(p => p.ParameterName).ToList();

                    ParameterList = new ObservableCollection<ParameterModel>(totalParameters.Select(p => new ParameterModel
                    {
                        AliasName = p.AliasName,
                        Chamber = SelectedTool.Chambers.FirstOrDefault(c => c.ChamberId == p.Chamber.ChamberId),
                        ParameterName = p.ParameterName,
                        ParameterType = p.ParameterType,
                        Precision = p.Precision,
                        Tool = SelectedTool
                    }));

                    // restore selection.
                    SelectedParameter = ParameterList.FirstOrDefault(p => p?.Tool?.ToolId == selectedParameter?.Tool?.ToolId && p?.Chamber?.ChamberId == selectedParameter?.Chamber?.ChamberId && p?.ParameterName == selectedParameter?.ParameterName);
                }
                finally
                {
                    IsParameterLoading = false;
                }
            }
            else
            {
                ParameterList?.Clear();
            }
        }

        #region Tool Commands
        [Command]
        public void AddTool()
        {
            ShowPopup("EditTool", new EditToolViewModel(null, FunctionMode.Add));
        }

        public bool CanAddTool()
        {
            return AuthorityManager.HasAuthority(Auth_Global_Tool_Add);
        }

        [Command]
        public void CopyTool()
        {
            ShowPopup("EditTool", new EditToolViewModel(SelectedTool, FunctionMode.Copy));
        }

        public bool CanCopyTool()
        {
            return SelectedTool != null && SelectedToolList.Count == 1 && !IsLoading &&
                AuthorityManager.HasAuthority(Auth_Global_Tool_Add);
        }

        [Command]
        public async void EditTool()
        {
            await RefreshToolBeforeAction(SelectedTool);
            ShowPopup("EditTool", new EditToolViewModel(SelectedTool, FunctionMode.Modify));
        }

        public bool CanEditTool()
        {
            return SelectedTool != null && SelectedToolList.Count == 1 && !IsLoading &&
                AuthorityManager.HasAuthority(Auth_Global_Tool_Edit);
        }

        [Command]
        public async void DeleteTool()
        {
            if (IsConfirmed(out var comment, $"Delete Tool"))
            {
                var toDeleteTool = SelectedTool;
                await GlobalService.DeleteToolAsync(SelectedTool.ToolId, comment);
                Messenger.Default.Send(new ToolChangedMessage() { ChangeType = ObjectChangeType.Deleted, ToolId = toDeleteTool.ToolId });
                MessageBoxService.ShowMessage($"Tool {toDeleteTool.ToolId} is deleted.", "Success", MessageButton.OK, MessageIcon.Information);
            }
        }

        public bool CanDeleteTool()
        {
            return SelectedTool != null && SelectedToolList.Count == 1 && !IsLoading &&
                AuthorityManager.HasAuthority(Auth_Global_Tool_Delete);
        }


        public async Task RefreshToolBeforeAction(ToolModel tool)
        {
            ShowWait();
            await UpdateSingleTool(tool.ToolId);
            HideWait();
        }
        #endregion


        #region Chamber Commands
        [Command]
        public void AddChamber()
        {
            if (SelectedTool != null)
            {
                ShowPopup("EditChamber", new EditChamberViewModel(SelectedTool, null, FunctionMode.Add));
            }
        }

        public bool CanAddChamber()
        {
            return SelectedTool != null && SelectedToolList.Count == 1 && !IsLoading &&
                AuthorityManager.HasAuthority(Auth_Global_Chamber_Add);
        }

        [Command]
        public void CopyChamber()
        {
            if (SelectedTool != null && SelectedParameter?.Chamber != null)
            {
                ShowPopup("EditChamber", new EditChamberViewModel(SelectedTool, SelectedParameter.Chamber, FunctionMode.Copy));
            }
        }

        public bool CanCopyChamber()
        {
            return SelectedParameter != null && !IsLoading && !IsParameterLoading &&
                AuthorityManager.HasAuthority(Auth_Global_Chamber_Add);
        }

        [Command]
        public void EditChamber()
        {
            if (SelectedParameter != null)
            {
                ShowPopup("EditChamber", new EditChamberViewModel(SelectedTool, SelectedParameter.Chamber, FunctionMode.Modify));
            }
        }

        public bool CanEditChamber()
        {
            return SelectedParameter != null && !IsLoading && !IsParameterLoading &&
                AuthorityManager.HasAuthority(Auth_Global_Chamber_Edit);
        }

        [Command]
        public async void DeleteChamber()
        {
            if (SelectedParameter != null)
            {
                if (IsConfirmed(out var comment, $"Delete Chamber"))
                {
                    var toDeleteChamber = SelectedParameter.Chamber;
                    await GlobalService.DeleteChamberAsync(toDeleteChamber.ToolId, toDeleteChamber.ChamberId, comment);
                    Messenger.Default.Send(new ToolChangedMessage() { ChangeType = ObjectChangeType.Updated, ToolId = toDeleteChamber.ToolId });
                    MessageBoxService.ShowMessage($"Chamber {toDeleteChamber.ToolId}:{toDeleteChamber.ChamberId} is deleted.", "Success", MessageButton.OK, MessageIcon.Information);
                }
            }
        }

        public bool CanDeleteChamber()
        {
            return SelectedParameter != null && !IsLoading && !IsParameterLoading &&
                AuthorityManager.HasAuthority(Auth_Global_Chamber_Delete);
        }


        #endregion


        #region Parameter Commands
        [Command]
        public async void AddParameter()
        {
            await RefreshToolBeforeAction(SelectedTool);
            if (SelectedParameter != null)
            {
                ShowPopup("EditParameter", new EditParameterViewModel(SelectedParameter.Tool, SelectedParameter.Chamber, SelectedParameter, FunctionMode.Add));
            }
        }

        public bool CanAddParameter()
        {
            return SelectedParameter != null && !IsLoading && !IsParameterLoading &&
                AuthorityManager.HasAuthority(Auth_Global_Parameter_Add);
        }

        [Command]
        public void CopyParameter()
        {
            if (SelectedTool != null && SelectedParameter?.Chamber != null)
            {
                ShowPopup("EditParameter", new EditParameterViewModel(SelectedParameter.Tool, SelectedParameter.Chamber, SelectedParameter, FunctionMode.Copy));
            }
        }

        public bool CanCopyParameter()
        {
            return SelectedParameter != null && !IsLoading && !IsParameterLoading &&
                !string.IsNullOrEmpty(SelectedParameter.ParameterName) &&
                AuthorityManager.HasAuthority(Auth_Global_Chamber_Add);
        }

        [Command]
        public async void EditParameter()
        {
            await RefreshToolBeforeAction(SelectedTool);
            if (SelectedParameter != null)
            {
                ShowPopup("EditParameter", new EditParameterViewModel(SelectedParameter.Tool, SelectedParameter.Chamber, SelectedParameter, FunctionMode.Modify));
            }
        }

        public bool CanEditParameter()
        {
            return SelectedParameter != null && !IsLoading && !IsParameterLoading &&
                !string.IsNullOrEmpty(SelectedParameter.ParameterName) &&
                AuthorityManager.HasAuthority(Auth_Global_Parameter_Edit);
        }

        [Command]
        public async void DeleteParameter()
        {
            if (SelectedParameter != null)
            {
                if (IsConfirmed(out var comment, $"Delete Parameter"))
                {
                    var toDeleteParameter = SelectedParameter;
                    await GlobalService.DeleteParameterAsync(toDeleteParameter.Tool.ToolId, toDeleteParameter.Chamber.ChamberId, toDeleteParameter.ParameterName, comment);
                    Messenger.Default.Send(new ToolChangedMessage() { ChangeType = ObjectChangeType.Updated, ToolId = toDeleteParameter.Tool.ToolId });
                    MessageBoxService.ShowMessage($"Parameter {toDeleteParameter.Tool.ToolId}.{toDeleteParameter.Chamber.ChamberId}.{toDeleteParameter.ParameterName} is deleted.", "Success", MessageButton.OK, MessageIcon.Information);
                }
            }
        }

        public bool CanDeleteParameter()
        {
            return SelectedParameter != null && !IsLoading && !IsParameterLoading &&
                !string.IsNullOrEmpty(SelectedParameter.ParameterName) &&
                AuthorityManager.HasAuthority(Auth_Global_Parameter_Delete);
        }


        #endregion

        #endregion

        #region Properties

        public bool IsParameterLoading
        {
            get { return GetValue<bool>(); }
            set { SetValue(value); }
        }

        public ObservableCollection<ToolModel> ToolList
        {
            get { return GetValue<ObservableCollection<ToolModel>>(); }
            set { SetValue(value); }
        }


        public ToolModel SelectedTool
        {
            get { return GetValue<ToolModel>(); }
            set { SetValue(value); }
        }

        public ObservableCollection<ToolModel> SelectedToolList { get; } = new ObservableCollection<ToolModel>();


        public ObservableCollection<ParameterModel> ParameterList
        {
            get { return GetValue<ObservableCollection<ParameterModel>>(); }
            set { SetValue(value); }
        }

        public ParameterModel SelectedParameter
        {
            get { return GetValue<ParameterModel>(); }
            set { SetValue(value); }
        }
        //public ObservableCollection<ParameterModel> SelectedParameterList { get; } = new ObservableCollection<ParameterModel>();

        #endregion
    }
}
