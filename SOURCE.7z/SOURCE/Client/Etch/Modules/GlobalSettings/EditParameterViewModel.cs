﻿using System;
using AMAT.R2R.Client.Common.Enums;
using AMAT.R2R.Client.Common.Helpers;
using AMAT.R2R.Client.Common.ViewModels;
using AMAT.R2R.Client.Common.Views;
using AMAT.R2R.Client.Etch.Messages;
using AMAT.R2R.Shared.Base.DTO;
using AMAT.R2R.Shared.Etch.DTO;
using DevExpress.Mvvm;
using DevExpress.Mvvm.DataAnnotations;
using DevExpress.Mvvm.POCO;
using DevExpress.Xpf.Bars;

namespace AMAT.R2R.Client.Etch.Modules.ToolChamberSettings
{
    public class EditParameterViewModel : EtchViewModelBase
    {
        private const string NA = "NA";
        public EditParameterViewModel(Tool tool, Chamber chamber, Parameter parameter, FunctionMode mode)
        {
            if (tool is null)
            {
                throw new ArgumentNullException(nameof(tool));
            }

            if (chamber is null)
            {
                throw new ArgumentNullException(nameof(chamber));
            }
            Tool = tool;
            Chamber = chamber;

            OriginalParameter = parameter;
            Mode = mode;

            if (mode != FunctionMode.Add)
            {
                ParameterName = parameter.ParameterName;
                AliasName = parameter.AliasName;
                Precision = parameter.Precision;
                ParameterType = parameter.ParameterType;
            }
            else
            {
            }

            Caption = Mode == FunctionMode.Modify ? "Edit Parameter" : "New Parameter";
            IsDirty = false;
        }

        protected override void OnViewReadyAsync()
        {
            if (Mode == FunctionMode.Add)
            {
                SetFocus(nameof(ParameterName));
            }
        }


        [Command]
        public async void Save()
        {
            ValidateAndSetErrorFocus(nameof(ParameterName), nameof(ParameterType), nameof(Precision), nameof(AliasName));

            if (HasErrors)
            {
                return;
            }

            // 
            if (IsConfirmed(out string comment))
            {
                var newParameter = new Parameter
                {
                    Tool = Tool,
                    Chamber = Chamber,
                    ParameterName = ParameterName,
                    Precision = (int)Precision.Value,
                    AliasName = AliasName,
                    ParameterType = ParameterType
                };

                if (Mode == FunctionMode.Modify)
                {
                    ShowWait();
                    newParameter.ParameterName = OriginalParameter.ParameterName;
                    await GlobalService.UpdateParameterAsync(Tool.ToolId, Chamber.ChamberId, newParameter.ParameterName, newParameter, comment);
                    IsDirty = false;
                    HideWait();
                    Messenger.Default.Send(new ToolChangedMessage() { ChangeType = ObjectChangeType.Updated, ToolId = Tool.ToolId });
                    MessageBoxService.ShowMessage($"Parameter {Tool.ToolId}.{Chamber.ChamberId}.{newParameter.ParameterName} is updated!", "Success", MessageButton.OK, MessageIcon.Information);
                }
                else
                {
                    ShowWait();
                    var createdParameter = await GlobalService.CreateParameterAsync(Tool.ToolId, Chamber.ChamberId, newParameter, comment);
                    IsDirty = false;
                    HideWait();
                    Messenger.Default.Send(new ToolChangedMessage() { ChangeType = ObjectChangeType.Updated, ToolId = Tool.ToolId });
                    MessageBoxService.ShowMessage($"Parameter {Tool.ToolId}.{Chamber.ChamberId}.{createdParameter.ParameterName} is created!", "Success", MessageButton.OK, MessageIcon.Information);
                }

                IsOK = true;
                CloseWindow();
            }
        }

        public bool CanSave()
        {
            switch (Mode)
            {
                case FunctionMode.Add:
                    return true;
                case FunctionMode.Modify:
                    return IsDirty;
                default:
                    return true;
            }
        }

        protected override string GetError(string columnName)
        {
            switch (columnName)
            {
                case nameof(ParameterName):
                    return DataValidator.ValidString(ParameterName);
                case nameof(AliasName):
                    return DataValidator.ValidString(AliasName);
                case nameof(Precision):
                    return DataValidator.ValidateInOrder(
                        () => DataValidator.NotNull(Precision),
                        () => DataValidator.InRange(Precision, 1, 10));
                case nameof(ParameterType):
                    return DataValidator.ValidString(ParameterType);
                default:
                    return null;
            }
        }


        #region Properties
        public Parameter OriginalParameter { get; private set; }

        public Parameter SubmittedParameter { get; set; }

        public Tool Tool { get; set; }
        public Chamber Chamber { get; set; }

        public string ParameterName
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(ParameterName));
            }
        }

        public string AliasName
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(AliasName));
            }
        }

        public decimal? Precision
        {
            get { return GetValue<decimal?>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(Precision));
            }
        }

        public string ParameterType
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(ParameterType));
            }
        }


        #endregion
    }
}
