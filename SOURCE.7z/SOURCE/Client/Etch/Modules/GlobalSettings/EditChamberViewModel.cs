﻿using System;
using AMAT.R2R.Client.Common.Enums;
using AMAT.R2R.Client.Common.Helpers;
using AMAT.R2R.Client.Common.ViewModels;
using AMAT.R2R.Client.Common.Views;
using AMAT.R2R.Client.Etch.Messages;
using AMAT.R2R.Shared.Base.DTO;
using AMAT.R2R.Shared.Etch.DTO;
using DevExpress.Mvvm;
using DevExpress.Mvvm.DataAnnotations;
using DevExpress.Mvvm.POCO;

namespace AMAT.R2R.Client.Etch.Modules.ToolChamberSettings
{
    public class EditChamberViewModel : EtchViewModelBase
    {
        private const string NA = "NA";
        public EditChamberViewModel(Tool tool, Chamber chamber, FunctionMode mode)
        {
            if (tool is null)
            {
                throw new ArgumentNullException(nameof(tool));
            }

            ToolId = tool.ToolId;
            OriginalChamber = chamber;
            Mode = mode;

            Caption = Mode == FunctionMode.Modify ? "Edit Chamber" : "New Chamber";
        }

        protected override async void OnViewReadyAsync()
        {
            if (Mode != FunctionMode.Add)
            {
                OriginalChamber = await GlobalService.GetChamberAsync(ToolId, OriginalChamber.ChamberId);
                ChamberId = OriginalChamber.ChamberId;
                ProcessType = OriginalChamber.ProcessType;
                UnitType = OriginalChamber.UnitType;
            }
            else
            {
            }

            if (Mode == FunctionMode.Add)
            {
                SetFocus(nameof(ChamberId));
            }
            IsDirty = false;
        }


        [Command]
        public async void Save()
        {
            ValidateAndSetErrorFocus(nameof(ChamberId), nameof(ProcessType), nameof(UnitType));

            if (HasErrors)
            {
                return;
            }

            // 
            if (IsConfirmed(out string comment))
            {
                var newChamber = new Chamber
                {
                    ToolId = ToolId,
                    ChamberId = ChamberId,
                    ProcessType = ProcessType,
                    UnitType = UnitType,
                };

                if (Mode == FunctionMode.Modify)
                {
                    ShowWait();
                    newChamber.ChamberId = OriginalChamber.ChamberId;
                    await GlobalService.UpdateChamberAsync(newChamber.ToolId, newChamber.ChamberId, newChamber, comment);
                    IsDirty = false;
                    HideWait();
                    Messenger.Default.Send(new ToolChangedMessage() { ChangeType = ObjectChangeType.Updated, ToolId = OriginalChamber.ToolId });
                    MessageBoxService.ShowMessage($"Chamber {newChamber.ToolId}:{newChamber.ChamberId} is updated!", "Success", MessageButton.OK, MessageIcon.Information);
                }
                else
                {
                    ShowWait();
                    var createdChamber = await GlobalService.CreateChamberAsync(newChamber.ToolId, newChamber, comment);
                    IsDirty = false;
                    HideWait();
                    Messenger.Default.Send(new ToolChangedMessage() { ChangeType = ObjectChangeType.Updated, ToolId = createdChamber.ToolId });
                    MessageBoxService.ShowMessage($"Chamber {createdChamber.ToolId}:{createdChamber.ChamberId} is created!", "Success", MessageButton.OK, MessageIcon.Information);
                }

                IsOK = true;
                CloseWindow();
            }
        }

        public bool CanSave()
        {
            switch (Mode)
            {
                case FunctionMode.Add:
                    return true;
                case FunctionMode.Modify:
                    return IsDirty;
                default:
                    return true;
            }
        }

        protected override string GetError(string columnName)
        {
            switch (columnName)
            {
                case nameof(ChamberId):
                    return DataValidator.ValidString(ChamberId);
                case nameof(UnitType):
                    return DataValidator.ValidString(UnitType);
                case nameof(ProcessType):
                    return DataValidator.ValidString(ProcessType);
                default:
                    return null;
            }
        }


        #region Properties
        public Chamber OriginalChamber { get; private set; }

        public Chamber SubmittedChamber { get; set; }


        public string ToolId
        {
            get { return GetValue<string>(); }
            set { SetValue(value); }
        }


        public string ChamberId
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(ChamberId));
            }
        }

        public string UnitType
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(UnitType));
            }
        }


        public string ProcessType
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(ProcessType));
            }
        }


        #endregion
    }
}
