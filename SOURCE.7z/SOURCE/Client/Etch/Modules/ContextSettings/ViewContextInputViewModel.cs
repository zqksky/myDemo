﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Threading.Tasks;
using AMAT.R2R.Client.Common.Enums;
using AMAT.R2R.Client.Common.ViewModels;
using AMAT.R2R.Client.Etch.Messages;
using AMAT.R2R.Client.Etch.Properties;
using AMAT.R2R.Client.Etch.Services;
using AMAT.R2R.Shared.Base.DTO;
using AMAT.R2R.Shared.Etch.DTO;
using DevExpress.DirectX.Common.DXGI;
using DevExpress.Mvvm;
using DevExpress.Mvvm.DataAnnotations;
using DevExpress.Mvvm.Native;
using DevExpress.Mvvm.UI.Native;
using DevExpress.Utils;

namespace AMAT.R2R.Client.Etch.Modules.ContextSettings
{
    /// <summary>
    /// make this class as light as possible so that performance is the best
    /// </summary>
    public class ViewContextInputViewModel
    {
        public ViewContextInputViewModel(Context context)
        {
            OwnerContext = context ?? throw new ArgumentNullException(nameof(context));
            OriginalSettings = context.ContextInput;
            Initialize();
        }

        private void Initialize()
        {
            LinearConstraintEnabled = OriginalSettings.LinearConstraintEnabled;

            LoadParameterSettings();

            LoadFFCoeficientSettings();
        }

        private void LoadFFCoeficientSettings()
        {
            if (OwnerContext.Process?.FeedforwardSettings != null && OwnerContext.Process?.FeedforwardSettings.Count > 0)
            {
                var ffCoeficientSettings = OwnerContext.Process.FeedforwardSettings.Select(s => new FFCoefficientSetting() { ParameterName = s.Parameter.ParameterName })?.ToList();
                for (var i = 0; i < ffCoeficientSettings.Count; i++)
                {
                    var ffc = ffCoeficientSettings[i];
                    ffc.Coefficient = OwnerContext.ContextInput.ContextMisc.FFCoefficient[i];
                }

                FFCoefficientSettingList = new List<FFCoefficientSetting>(ffCoeficientSettings);
            }
        }

        private void LoadParameterSettings()
        {
            List<ParameterSetting> parameterSettings = new List<ParameterSetting>();

            if (OwnerContext.ContextInputParas != null)
            {
                for (var i = 0; i < OwnerContext.ContextInputParas.Count; i++)
                {
                    var item = OwnerContext.ContextInputParas[i];
                    var parameterSetting = new ParameterSetting
                    {
                        IsChecked = true,
                        ParameterName = item.ParameterName,
                        Default = item.DefaultRecommandValue,
                        Max = item.UpperLimit,
                        Min = item.LowerLimit,
                        Precision = item.Precision,
                        RecVsUsedLimit = (decimal)item.RecVsUsedLimit,
                        FBNegDelta = (decimal)item.FBNegDelta,
                        FBPostDelta = (decimal)item.FBPostDelta,
                        ModelSlope1 = (decimal)item.ModelSlope.Cells[0][0],
                        ModelSlope2 = (decimal)item.ModelSlope.Cells[0][1],
                        ModelSlope3 = (decimal)item.ModelSlope.Cells[0][2],
                        ModelSlope4 = (decimal)item.ModelSlope.Cells[0][3],
                        ModelSlope5 = (decimal)item.ModelSlope.Cells[0][4],
                        ModelSlope6 = (decimal)item.ModelSlope.Cells[0][5],
                        ModelSlope7 = (decimal)item.ModelSlope.Cells[0][6],
                        ModelSlope8 = (decimal)item.ModelSlope.Cells[0][7],
                        ModelSlope9 = (decimal)item.ModelSlope.Cells[0][8],
                        ModelSlope10 = (decimal)item.ModelSlope.Cells[0][9],

                        Slot1Compensation = (decimal)item.Slot1Compensation,
                        Slot2Compensation = (decimal)item.Slot2Compensation,

                        LinearConstraint1Coff = (decimal)OwnerContext.LinearConstraint1Coff[i],
                        LinearConstraint2Coff = (decimal)OwnerContext.LinearConstraint2Coff[i],

                        Unit = item.Unit,
                        Deadband = item.Deadband,
                        QsStatesEst = (decimal)item.QsStatesEst,
                        RsStatesEst = (decimal)item.RsStatesEst
                    };

                    parameterSettings.Add(parameterSetting);
                }
                Linear1Min = OwnerContext.Linear1Min;
                Linear1Max = OwnerContext.Linear1Max;
                Linear2Min = OwnerContext.Linear2Min;
                Linear2Max = OwnerContext.Linear2Max;
            }

            ParameterSettingList = new List<ParameterSetting>(parameterSettings);

            UpdateParamTable();
        }

        private void UpdateParamTable()
        {
            int outputNum = this.OwnerContext != null ? this.OwnerContext.OutputNum4Slope(): 0;

            for (var i = 0; i < ParameterSettingList.Count; i++)
            {
                var item = ParameterSettingList[i];
                item.Index = i + 1;

                if (!item.IsChecked)
                {
                    item.Default = 0;
                    item.Min = 0;
                    item.Max = 0;
                    item.Precision = 0;
                    item.RecVsUsedLimit = 0;
                    item.FBNegDelta = 0;
                    item.FBPostDelta = 0;
                    item.ModelSlope1 = 0;
                    item.ModelSlope2 = 0;
                    item.ModelSlope3 = 0;
                    item.ModelSlope4 = 0;
                    item.ModelSlope5 = 0;
                    item.ModelSlope6 = 0;
                    item.ModelSlope7 = 0;
                    item.ModelSlope8 = 0;
                    item.ModelSlope9 = 0;
                    item.ModelSlope10 = 0;

                    item.Slot1Compensation = 0;
                    item.Slot2Compensation = 0;
                    item.LinearConstraint1Coff = 0;
                    item.LinearConstraint2Coff = 0;

                    item.IsEnableModelSlop1 = false;
                    item.IsEnableModelSlop2 = false;
                    item.IsEnableModelSlop3 = false;
                    item.IsEnableModelSlop4 = false;
                    item.IsEnableModelSlop5 = false;
                    item.IsEnableModelSlop6 = false;
                    item.IsEnableModelSlop7 = false;
                    item.IsEnableModelSlop8 = false;
                    item.IsEnableModelSlop9 = false;
                    item.IsEnableModelSlop10 = false;

                    item.LinearConstraint1Coff = 0;
                    item.LinearConstraint2Coff = 0;
                    item.IsEnabledLinear1 = false;
                    item.IsEnabledLinear2 = false;
                }
                else
                {
                    switch (outputNum/*ParameterSettingList.Count(p => p.IsChecked)*/)
                    {
                        case 0:
                            item.IsEnableModelSlop1 = false;
                            item.IsEnableModelSlop2 = false;
                            item.IsEnableModelSlop3 = false;
                            item.IsEnableModelSlop4 = false;
                            item.IsEnableModelSlop5 = false;
                            item.IsEnableModelSlop6 = false;
                            item.IsEnableModelSlop7 = false;
                            item.IsEnableModelSlop8 = false;
                            item.IsEnableModelSlop9 = false;
                            item.IsEnableModelSlop10 = false;
                            break;

                        case 1:
                            item.IsEnableModelSlop1 = true;
                            item.IsEnableModelSlop2 = false;
                            item.IsEnableModelSlop3 = false;
                            item.IsEnableModelSlop4 = false;
                            item.IsEnableModelSlop5 = false;
                            item.IsEnableModelSlop6 = false;
                            item.IsEnableModelSlop7 = false;
                            item.IsEnableModelSlop8 = false;
                            item.IsEnableModelSlop9 = false;
                            item.IsEnableModelSlop10 = false;
                            break;
                        case 2:
                            item.IsEnableModelSlop1 = true;
                            item.IsEnableModelSlop2 = true;
                            item.IsEnableModelSlop3 = false;
                            item.IsEnableModelSlop4 = false;
                            item.IsEnableModelSlop5 = false;
                            item.IsEnableModelSlop6 = false;
                            item.IsEnableModelSlop7 = false;
                            item.IsEnableModelSlop8 = false;
                            item.IsEnableModelSlop9 = false;
                            item.IsEnableModelSlop10 = false;
                            break;
                        case 3:
                            item.IsEnableModelSlop1 = true;
                            item.IsEnableModelSlop2 = true;
                            item.IsEnableModelSlop3 = true;
                            item.IsEnableModelSlop4 = false;
                            item.IsEnableModelSlop5 = false;
                            item.IsEnableModelSlop6 = false;
                            item.IsEnableModelSlop7 = false;
                            item.IsEnableModelSlop8 = false;
                            item.IsEnableModelSlop9 = false;
                            item.IsEnableModelSlop10 = false;
                            break;
                        case 4:
                            item.IsEnableModelSlop1 = true;
                            item.IsEnableModelSlop2 = true;
                            item.IsEnableModelSlop3 = true;
                            item.IsEnableModelSlop4 = true;
                            item.IsEnableModelSlop5 = false;
                            item.IsEnableModelSlop6 = false;
                            item.IsEnableModelSlop7 = false;
                            item.IsEnableModelSlop8 = false;
                            item.IsEnableModelSlop9 = false;
                            item.IsEnableModelSlop10 = false;
                            break;
                        case 5:
                            item.IsEnableModelSlop1 = true;
                            item.IsEnableModelSlop2 = true;
                            item.IsEnableModelSlop3 = true;
                            item.IsEnableModelSlop4 = true;
                            item.IsEnableModelSlop5 = true;
                            item.IsEnableModelSlop6 = false;
                            item.IsEnableModelSlop7 = false;
                            item.IsEnableModelSlop8 = false;
                            item.IsEnableModelSlop9 = false;
                            item.IsEnableModelSlop10 = false;
                            break;
                        case 6:
                            item.IsEnableModelSlop1 = true;
                            item.IsEnableModelSlop2 = true;
                            item.IsEnableModelSlop3 = true;
                            item.IsEnableModelSlop4 = true;
                            item.IsEnableModelSlop5 = true;
                            item.IsEnableModelSlop6 = true;
                            item.IsEnableModelSlop7 = false;
                            item.IsEnableModelSlop8 = false;
                            item.IsEnableModelSlop9 = false;
                            item.IsEnableModelSlop10 = false;
                            break;
                        case 7:
                            item.IsEnableModelSlop1 = true;
                            item.IsEnableModelSlop2 = true;
                            item.IsEnableModelSlop3 = true;
                            item.IsEnableModelSlop4 = true;
                            item.IsEnableModelSlop5 = true;
                            item.IsEnableModelSlop6 = true;
                            item.IsEnableModelSlop7 = true;
                            item.IsEnableModelSlop8 = false;
                            item.IsEnableModelSlop9 = false;
                            item.IsEnableModelSlop10 = false;
                            break;
                        case 8:
                            item.IsEnableModelSlop1 = true;
                            item.IsEnableModelSlop2 = true;
                            item.IsEnableModelSlop3 = true;
                            item.IsEnableModelSlop4 = true;
                            item.IsEnableModelSlop5 = true;
                            item.IsEnableModelSlop6 = true;
                            item.IsEnableModelSlop7 = true;
                            item.IsEnableModelSlop8 = true;
                            item.IsEnableModelSlop9 = false;
                            item.IsEnableModelSlop10 = false;
                            break;
                        case 9:
                            item.IsEnableModelSlop1 = true;
                            item.IsEnableModelSlop2 = true;
                            item.IsEnableModelSlop3 = true;
                            item.IsEnableModelSlop4 = true;
                            item.IsEnableModelSlop5 = true;
                            item.IsEnableModelSlop6 = true;
                            item.IsEnableModelSlop7 = true;
                            item.IsEnableModelSlop8 = true;
                            item.IsEnableModelSlop9 = true;
                            item.IsEnableModelSlop10 = false;
                            break;
                        case 10:
                            item.IsEnableModelSlop1 = true;
                            item.IsEnableModelSlop2 = true;
                            item.IsEnableModelSlop3 = true;
                            item.IsEnableModelSlop4 = true;
                            item.IsEnableModelSlop5 = true;
                            item.IsEnableModelSlop6 = true;
                            item.IsEnableModelSlop7 = true;
                            item.IsEnableModelSlop8 = true;
                            item.IsEnableModelSlop9 = true;
                            item.IsEnableModelSlop10 = true;
                            break;
                        default:
                            break;
                    }

                    item.IsEnabledLinear1 = LinearConstraintEnabled;
                    item.IsEnabledLinear2 = LinearConstraintEnabled;
                }
            }
        }

        #region Properties
        public Context OwnerContext { get; private set; }

        public ContextInput OriginalSettings { get; private set; }

        public bool LinearConstraintEnabled { get; set; }

        public double Linear1Min { get; set; }

        public double Linear1Max { get; set; }

        public double Linear2Min { get; set; }

        public double Linear2Max { get; set; }

        public IList<ParameterSetting> ParameterSettingList { get; set; }

        public IList<FFCoefficientSetting> FFCoefficientSettingList { get; set; }

        #endregion
    }

    public class ParameterSetting
    {
        public int Index { get; set; }

        public bool IsChecked { get; set; }

        public bool IsReadOnlyIsChecked { get; set; }

        public string ParameterName { get; set; }

        public decimal? Default { get; set; }

        public decimal? Min { get; set; }

        public decimal? Max { get; set; }

        public int Precision { get; set; }

        public decimal? RecVsUsedLimit { get; set; }

        public decimal? FBNegDelta { get; set; }

        public decimal? FBPostDelta { get; set; }
        public decimal? ModelSlope1 { get; set; }
        public decimal? ModelSlope2 { get; set; }
        public decimal? ModelSlope3 { get; set; }
        public decimal? ModelSlope4 { get; set; }
        public decimal? ModelSlope5 { get; set; }
        public decimal? ModelSlope6 { get; set; }
        public decimal? ModelSlope7 { get; set; }
        public decimal? ModelSlope8 { get; set; }
        public decimal? ModelSlope9 { get; set; }
        public decimal? ModelSlope10 { get; set; }

        public decimal? Slot1Compensation { get; set; }

        public decimal? Slot2Compensation { get; set; }
        public decimal? LinearConstraint1Coff { get; set; }
        public decimal? LinearConstraint2Coff { get; set; }

        public bool IsEnableModelSlop1 { get; set; }
        public bool IsEnableModelSlop2 { get; set; }
        public bool IsEnableModelSlop3 { get; set; }
        public bool IsEnableModelSlop4 { get; set; }
        public bool IsEnableModelSlop5 { get; set; }
        public bool IsEnableModelSlop6 { get; set; }
        public bool IsEnableModelSlop7 { get; set; }
        public bool IsEnableModelSlop8 { get; set; }
        public bool IsEnableModelSlop9 { get; set; }
        public bool IsEnableModelSlop10 { get; set; }

        public bool IsEnabledLinear1 { get; set; }

        public bool IsEnabledLinear2 { get; set; }
        public string Unit { get; set; }
        public decimal? QsStatesEst { get; set; }

        public decimal? RsStatesEst { get; set; }

        public decimal? Deadband { get; set; }
    }

    public class FFCoefficientSetting
    {
        public string ParameterName { get; set; }

        public double Coefficient { get; set; }
    }
}
