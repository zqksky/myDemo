﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data.Objects;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Documents;
using AMAT.R2R.Client.Common.Enums;
using AMAT.R2R.Client.Common.Helpers;
using AMAT.R2R.Client.Common.Messages;
using AMAT.R2R.Client.Common.Services;
using AMAT.R2R.Client.Common.ViewModels;
using AMAT.R2R.Client.Common.Views;
using AMAT.R2R.Client.Etch.Messages;
using AMAT.R2R.Shared.Base.DTO;
using AMAT.R2R.Shared.Etch.DTO;
using DevExpress.Mvvm;
using DevExpress.Mvvm.DataAnnotations;
using DevExpress.Mvvm.POCO;
using DevExpress.Xpf.Editors.Internal.TypedStyles;

namespace AMAT.R2R.Client.Etch.Modules.ContextSettings
{
    public class EditContextViewModel : EtchViewModelBase
    {
        private const string NA = "NA";
        public EditContextViewModel(Process process, Context sourceContext, FunctionMode mode)
        {
            SizeToContent = System.Windows.SizeToContent.Manual;
            CurrentProcess = process;
            SourceContext = sourceContext;
            Mode = mode;

            switch (mode)
            {
                case FunctionMode.None:
                    break;
                case FunctionMode.Add:
                    Caption = "Create Context";
                    break;
                case FunctionMode.Copy:
                    Caption = "Copy Context";
                    break;
                case FunctionMode.Modify:
                    throw new NotSupportedException();
                case FunctionMode.Delete:
                    break;
                case FunctionMode.View:
                    break;
                default:
                    break;
            }

            PropertyChanged += OnPropertyChanged;

            ProcessContextList = new ObservableCollection<ContextModel>();
            IsDirty = false;
        }

        protected override void OnViewReadyAsync()
        {
            Refresh();
        }

        private async void OnPropertyChanged(object sender, System.ComponentModel.PropertyChangedEventArgs e)
        {
            if (e.PropertyName == nameof(Tool))
            {
                Chamber = null;
                if (Tool != null)
                {
                    ChamberList = await GlobalService.GetChamberListAsync(Tool.ToolId);
                }
            }
        }

        [Command]
        public async void Refresh()
        {
            Tool = null;
            Chamber = null;
            ContextGroup = null;

            if (Mode == FunctionMode.Add)
            {
                ControlFlag = null;
                ControlType = null;
                ControlLevel = null;
            }
            else
            {
                ControlFlag = SourceContext.ControlFlag;
                ControlType = SourceContext.ControlType;
                ControlLevel = SourceContext.ControlLevel;
            }

            ShowWait();

            //CurrentProcess = await ProcessService.GetProcessAsync(CurrentProcess.ProcessId);

            ProcessContextList = new ObservableCollection<ContextModel>(await ContextService.GetContextListAsync(new QueryFilter("processId", CurrentProcess.ProcessId)));

            // set copy source
            var sourceContext = ProcessContextList.FirstOrDefault(c => c.ContextId == SourceContext.ContextId);
            if (sourceContext != null)
            {
                sourceContext.IsCopySource = true;
                sourceContext.NotifyChanges();
            }

            ProcessContextList.CollectionChanged += ProcessContextList_CollectionChanged;

            ToolList = await GlobalService.GetToolListAsync();

            if (CurrentProcess.OptContextGroupEnabled)
            {
                ContextGroupList = await GlobalService.GetContextGroupListAsync();
            }
            else
            {
                ContextGroupList = new List<string>() { "NA" };
                ContextGroup = "NA";
            }

            HideWait();

            IsDirty = false;
        }

        private void ProcessContextList_CollectionChanged(object sender, System.Collections.Specialized.NotifyCollectionChangedEventArgs e)
        {
            IsDirty = ProcessContextList.Any(c => c.IsNew);
        }

        [Command]
        public void AddContext()
        {
            if (ProcessContextList.Any(c => c.Tool == Tool.ToolId && c.Chamber == Chamber.ChamberId && c.ContextGroup == ContextGroup))
            {
                MessageBoxService.ShowMessage("The context already exists.", "Duplicate Context", MessageButton.OK, MessageIcon.Stop);
                return;
            }


            if (Mode == FunctionMode.Add)
            {
                var newContext = new ContextModel()
                {
                    Tool = Tool.ToolId,
                    Chamber = Chamber.ChamberId,
                    ContextGroup = ContextGroup,
                    ControlFlag = ControlFlag.Value,
                    ControlType = ControlType.Value,
                    ControlLevel = ControlLevel.Value,
                    Process = CurrentProcess,
                    ProcessId = CurrentProcess.ProcessId,
                    Fab = CurrentProcess.Fab,
                    ProductId = CurrentProcess.ProductId,
                    Stage = CurrentProcess.Stage,
                    Recipe = CurrentProcess.Recipe,
                    StepName = CurrentProcess.StepName,
                    StepNumber = CurrentProcess.StepNumber,
                    IsNew = true
                };
                ProcessContextList.Add(newContext);
                SelectedContext = newContext;
            }
            else
            {
                var newContext = Newtonsoft.Json.JsonConvert.DeserializeObject<ContextModel>(Newtonsoft.Json.JsonConvert.SerializeObject(SourceContext));
                newContext.ContextConstants.ContextId = 0;
                newContext.ContextConstants.ContextKey = newContext.ContextKey;
                newContext.ContextInput.ContextId = 0;
                newContext.ContextInput.ContextKey = newContext.ContextKey;
                newContext.ContextInput.ContextMisc.ContextId = 0;
                newContext.ContextInput.ContextMisc.ContextKey = newContext.ContextKey;
                newContext.Tool = Tool.ToolId;
                newContext.Chamber = Chamber.ChamberId;
                newContext.ContextGroup = ContextGroup;
                newContext.IsNew = true;

                ProcessContextList.Add(newContext);
                SelectedContext = newContext;
            }
        }

        public bool CanAddContext()
        {
            return Tool != null && Chamber != null && !string.IsNullOrEmpty(ContextGroup) && ControlFlag.HasValue && ControlType.HasValue && ControlLevel.HasValue;
        }

        [Command]
        public async void DeleteContext()
        {
            if (SelectedContext.IsNew)
            {
                ProcessContextList.Remove(SelectedContext);
            }
            else
            {
                if (IsConfirmed(out var comment))
                {
                    var toDeleteId = SelectedContext.ContextId;
                    await ContextService.DeleteContextAsync(toDeleteId, comment);
                    Messenger.Default.Send(new ContextChangedMessage() { ChangeType = ObjectChangeType.Deleted, ContextId = toDeleteId });
                    Refresh();
                }
            }
        }

        public bool CanDeleteContext()
        {
            return SelectedContext != null && SelectedContext.IsNew;
        }

        [Command]
        public async void Save()
        {
            var newContextList = ProcessContextList.Where(c => c.IsNew).ToList();

            StringBuilder sb = new StringBuilder();
            // 
            if (IsConfirmed(out string comment))
            {
                ShowWait();

                var taskList = newContextList.Select(c => ContextService.CreateContextAsync(c, comment)).ToList();


                try
                {
                    await Task.WhenAll(taskList);
                }
                catch (Exception)
                {
                    // ignore.
                }

                HideWait();
                int successCount = taskList.Count - taskList.Count(t => t.IsFaulted);

                if (successCount > 0)
                {
                    Messenger.Default.Send(new ContextChangedMessage() { ChangeType = ObjectChangeType.Created, ContextId = 0 });
                }
                if (taskList.Any(t => t.IsFaulted))
                {
                    foreach (var ex in taskList.Where(t => t.IsFaulted).Select(t => t.Exception))
                    {
                        sb.AppendLine(LocalizationService.LocalizeException(ex));
                    }
                    MessageBoxService.ShowMessage(sb.ToString(), $"Success Count: {successCount} Failed Count: { taskList.Count(t => t.IsFaulted)} ", MessageButton.OK, MessageIcon.Error);
                }
                else
                {
                    if (Mode == FunctionMode.Add)
                    {
                        MessageBoxService.ShowMessage($"{newContextList.Count} Context created successfully.", "Success", MessageButton.OK, MessageIcon.Information);
                    }
                    else
                    {
                        MessageBoxService.ShowMessage($"{newContextList.Count} Context copied successfully.", "Success", MessageButton.OK, MessageIcon.Information);
                    }
                }
                // show updated list.
                Refresh();
            }
        }

        public bool CanSave()
        {
            switch (Mode)
            {
                case FunctionMode.Add:
                    return ProcessContextList.Any(c => c.IsNew);
                case FunctionMode.Modify:
                    return IsDirty;
                default:
                    return true;
            }
        }

        protected override string GetError(string columnName)
        {
            switch (columnName)
            {
                default:
                    return null;
            }
        }

        #region Properties
        public Process CurrentProcess { get; private set; }

        public Context SourceContext { get; private set; }

        public Tool Tool
        {
            get { return GetValue<Tool>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(Tool));
            }
        }

        public Chamber Chamber
        {
            get { return GetValue<Chamber>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(Chamber));
            }
        }

        public string ContextGroup
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(ContextGroup));
            }
        }

        public ObservableCollection<ContextModel> ProcessContextList
        {
            get { return GetValue<ObservableCollection<ContextModel>>(); }
            set { SetValue(value); }
        }

        public ContextModel SelectedContext
        {
            get { return GetValue<ContextModel>(); }
            set { SetValue(value); }
        }

        public List<Tool> ToolList
        {
            get { return GetValue<List<Tool>>(); }
            set { SetValue(value); }
        }

        public List<Chamber> ChamberList
        {
            get { return GetValue<List<Chamber>>(); }
            set { SetValue(value); }
        }

        public List<string> ContextGroupList
        {
            get { return GetValue<List<string>>(); }
            set { SetValue(value); }
        }

        public ControlFlag? ControlFlag
        {
            get { return GetValue<ControlFlag?>(); }
            set { SetValue(value); }
        }

        public ControlType? ControlType
        {
            get { return GetValue<ControlType?>(); }
            set { SetValue(value); }
        }
        public ControlLevel? ControlLevel
        {
            get { return GetValue<ControlLevel?>(); }
            set { SetValue(value); }
        }


        #endregion
    }
}
