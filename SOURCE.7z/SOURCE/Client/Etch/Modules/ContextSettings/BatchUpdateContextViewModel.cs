﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data.Objects;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Documents;
using AMAT.R2R.Client.Common.Enums;
using AMAT.R2R.Client.Common.Helpers;
using AMAT.R2R.Client.Common.Messages;
using AMAT.R2R.Client.Common.Services;
using AMAT.R2R.Client.Common.ViewModels;
using AMAT.R2R.Client.Common.Views;
using AMAT.R2R.Client.Etch.Messages;
using AMAT.R2R.Shared.Base.DTO;
using AMAT.R2R.Shared.Etch.DTO;
using DevExpress.Mvvm;
using DevExpress.Mvvm.DataAnnotations;
using DevExpress.Mvvm.Native;
using DevExpress.Mvvm.POCO;
using DevExpress.Xpf.Bars;
using Newtonsoft.Json;

namespace AMAT.R2R.Client.Etch.Modules.ContextSettings
{
    public class BatchUpdateContextViewModel : EtchViewModelBase
    {
        private const string NA = "NA";

        public BatchUpdateContextViewModel(List<ContextModel> contextList)
        {
            if (contextList is null)
            {
                throw new ArgumentNullException(nameof(contextList));
            }

            ContextList = new ObservableCollection<ContextModel>(contextList);

            SizeToContent = System.Windows.SizeToContent.Manual;
            Mode = FunctionMode.Modify;
            Caption = "Batch Update Context";
        }

        private void Initialize()
        {
            if (ContextList.Select(c => c.ControlFlag).Distinct().Count() > 1)
            {
                ControlFlag = null;
            }
            else
            {
                ControlFlag = ContextList.First().ControlFlag;
            }

            if (ContextList.Select(c => c.ControlType).Distinct().Count() > 1)
            {
                ControlType = null;
            }
            else
            {
                ControlType = ContextList.First().ControlType;
            }

            if (ContextList.Select(c => c.ControlLevel).Distinct().Count() > 1)
            {
                ControlLevel = null;
            }
            else
            {
                ControlLevel = ContextList.First().ControlLevel;
            }

            IsControlFlagChanged = false;
            IsControlLevelChanged = false;
            IsControlTypeChanged = false;
            IsDirty = false;
        }

        protected override void OnViewReadyAsync()
        {
            Initialize();
        }

        [Command]
        public async void UpdateContext(string fieldName)
        {
            List<ContextModel> failList = new List<ContextModel>();
            StringBuilder sb = new StringBuilder();
            // 
            if (IsConfirmed(out string comment))
            {
                ShowWait();

                foreach (var context in ContextList)
                {
                    try
                    {
                        // clone context.
                        var newContext = JsonConvert.DeserializeObject<Context>(JsonConvert.SerializeObject(context));
                        switch (fieldName)
                        {
                            case "ControlFlag":
                                newContext.ControlFlag = ControlFlag.Value;
                                break;
                            case "ControlLevel":
                                newContext.ControlLevel = ControlLevel.Value;
                                break;
                            case "ControlType":
                                newContext.ControlType = ControlType.Value;
                                break;
                            default:
                                break;
                        }
                        await ContextService.UpdateContextAsync(newContext.ContextId, newContext, comment);
                    }
                    catch (Exception ex)
                    {
                        failList.Add(context);
                        sb.AppendLine(LocalizationService.LocalizeException(ex));
                    }
                }

                HideWait();

                var successCount = ContextList.Count - failList.Count;

                if (successCount > 0)
                {
                    var successList = ContextList.Except(failList);
                    foreach (var context in successList)
                    {
                        Messenger.Default.Send(new ContextChangedMessage() { ChangeType = ObjectChangeType.Updated, ContextId = context.ContextId });
                    }
                }

                // show updated list.
                Initialize();
                // show error if any
                if (failList.Count <= 0)
                {
                    MessageBoxService.ShowMessage($"{successCount} updated successfully.", "Success", MessageButton.OK, MessageIcon.Information);
                }
                else if (successCount > 0)
                {
                    MessageBoxService.ShowMessage($"{successCount} updated successfully.\n{failList.Count} update failed.\n{sb}", "Partial Success", MessageButton.OK, MessageIcon.Error);
                }
                else
                {
                    MessageBoxService.ShowMessage($"Update failed.\n{sb}", "Error", MessageButton.OK, MessageIcon.Error);
                }
            }
        }

        public bool CanUpdateContext(string fieldName)
        {
            switch (fieldName)
            {
                case "ControlFlag":
                    return ControlFlag.HasValue && IsControlFlagChanged;
                case "ControlLevel":
                    return ControlLevel.HasValue && IsControlLevelChanged;
                case "ControlType":
                    return ControlType.HasValue && IsControlTypeChanged;
                default:
                    return false;
            }
        }

        protected override string GetError(string columnName)
        {
            switch (columnName)
            {
                default:
                    return null;
            }
        }

        #region Properties

        public ObservableCollection<ContextModel> ContextList
        {
            get { return GetValue<ObservableCollection<ContextModel>>(); }
            set { SetValue(value); }
        }

        public ControlFlag? ControlFlag
        {
            get { return GetValue<ControlFlag?>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                IsControlFlagChanged = true;
            }
        }

        public ControlType? ControlType
        {
            get { return GetValue<ControlType?>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                IsControlTypeChanged = true;
            }
        }
        public ControlLevel? ControlLevel
        {
            get { return GetValue<ControlLevel?>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                IsControlLevelChanged = true;
            }
        }

        public bool IsControlFlagChanged
        {
            get { return GetValue<bool>(); }
            set { SetValue(value); }
        }

        public bool IsControlTypeChanged
        {
            get { return GetValue<bool>(); }
            set { SetValue(value); }
        }

        public bool IsControlLevelChanged
        {
            get { return GetValue<bool>(); }
            set { SetValue(value); }
        }



        #endregion
    }
}
