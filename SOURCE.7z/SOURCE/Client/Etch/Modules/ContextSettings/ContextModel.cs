﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AMAT.R2R.Shared.Etch.DTO;
using Newtonsoft.Json;

namespace AMAT.R2R.Client.Etch.Modules.ContextSettings
{
    public class ContextModel : Context, INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;

        public void NotifyChanges()
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Parameters)));
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Default)));
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Min)));
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Max)));
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(PreMetrologyParameter)));
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(PreMetrologyTarget)));
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(PreMetrologyLowerLimit)));
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(PreMetrologyUpperLimit)));
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(OutputParameter)));
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(OutputTarget)));
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(OutputLowerLimit)));
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(OutputUpperLimit)));
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(ControlFlag)));
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(ControlLevel)));
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(ControlType)));
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(LastModifiedBy)));
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(LastModifiedTime)));
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(IsCopySource)));
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(IsNew)));
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(ContextInput)));
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(ContextConstants)));
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(HasConstants)));
        }


        [JsonIgnore]
        public string Parameters
        {
            get
            {
                return ContextInputParas == null ? string.Empty : string.Join(",", ContextInputParas.Select(p => p.ParameterName));
            }
        }


        [JsonIgnore]
        public string Default
        {
            get
            {
                return ContextInputParas == null ? string.Empty : string.Join(",", ContextInputParas.Select(p => p.DefaultRecommandValue));
            }
        }


        [JsonIgnore]
        public string Min
        {
            get
            {
                return ContextInputParas == null ? string.Empty : string.Join(",", ContextInputParas.Select(p => p.LowerLimit));
            }
        }


        [JsonIgnore]
        public string Max
        {
            get
            {
                return ContextInputParas == null ? string.Empty : string.Join(",", ContextInputParas.Select(p => p.UpperLimit));
            }
        }



        [JsonIgnore]
        public string PreMetrologyParameter
        {
            get
            {
                return Process?.FeedforwardSettings == null ? string.Empty : string.Join(",", Process?.FeedforwardSettings.Select(s => s.Parameter?.ParameterName));
            }
        }


        [JsonIgnore]
        public string PreMetrologyTarget
        {
            get
            {
                return Process?.FeedforwardSettings == null ? string.Empty : string.Join(",", Process?.FeedforwardSettings.Select(s => s.Target));
            }
        }


        [JsonIgnore]
        public string PreMetrologyLowerLimit
        {
            get
            {
                return Process?.FeedforwardSettings == null ? string.Empty : string.Join(",", Process?.FeedforwardSettings.Select(s => s.LowerLimit));
            }
        }


        [JsonIgnore]
        public string PreMetrologyUpperLimit
        {
            get
            {
                return Process?.FeedforwardSettings == null ? string.Empty : string.Join(",", Process?.FeedforwardSettings.Select(s => s.UpperLimit));
            }
        }


        [JsonIgnore]
        public string OutputParameter
        {
            get
            {
                return Process?.OutputSettings == null ? string.Empty : string.Join(",", Process?.OutputSettings.Select(o => o.Parameter?.ParameterName));
            }
        }


        [JsonIgnore]
        public string OutputTarget
        {
            get
            {
                return Process?.OutputSettings == null ? string.Empty : string.Join(",", Process?.OutputSettings.Select(o => o.Target));
            }
        }

        [JsonIgnore]
        public string OutputLowerLimit
        {
            get
            {
                return Process?.OutputSettings == null ? string.Empty : string.Join(",", Process?.OutputSettings.Select(o => o.LowerLimit));
            }
        }

        [JsonIgnore]
        public string OutputUpperLimit
        {
            get
            {
                return Process?.OutputSettings == null ? string.Empty : string.Join(",", Process?.OutputSettings.Select(o => o.UpperLimit));
            }
        }

        [JsonIgnore]
        public bool IsNew { get; set; }


        [JsonIgnore]
        public bool IsCopySource { get; set; }


        [JsonIgnore]
        public bool HasConstants
        {
            get
            {
                return ContextConstants.ContextId != 0;
            }
        }
    }
}
