﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Threading.Tasks;
using AMAT.R2R.Client.Common.Enums;
using AMAT.R2R.Client.Common.Helpers;
using AMAT.R2R.Client.Etch.Messages;
using AMAT.R2R.Client.Etch.Properties;
using AMAT.R2R.Client.Etch.Services;
using AMAT.R2R.Shared.Base.DTO;
using AMAT.R2R.Shared.Etch.DTO;
using DevExpress.DirectX.Common.DXGI;
using DevExpress.Mvvm;
using DevExpress.Mvvm.DataAnnotations;
using DevExpress.Mvvm.Native;
using DevExpress.Mvvm.UI.Native;
using DevExpress.Utils;

namespace AMAT.R2R.Client.Etch.Modules.ContextSettings
{

    public class EditContextInputViewModel : EtchViewModelBase
    {
        public EditContextInputViewModel(Context context, FunctionMode mode)
        {
            OwnerContext = context ?? throw new ArgumentNullException(nameof(context));
            OriginalSettings = context.ContextInput;
            Mode = mode;

            SizeToContent = System.Windows.SizeToContent.Manual;
            WindowHeight = 720;
            WindowWidth = 1600;

            Caption = "Update Context Input";
            ParameterSettingList = new ObservableCollection<ParameterSettingModel>();
            PropertyChanged += EditContextInputViewModel_PropertyChanged;
        }

        private void EditContextInputViewModel_PropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            if (e.PropertyName == nameof(LinearConstraintEnabled))
            {
                UpdateParamTable();
            }
        }

        protected override void OnViewReadyAsync()
        {
            Initialize();
        }

        private async void Initialize()
        {
            ShowWait();

            try
            {
                LinearConstraintEnabled = OriginalSettings.LinearConstraintEnabled;

                ParameterList = new ObservableCollection<Parameter>(await GlobalService.GetProcessParameterListAsync(OwnerContext.Tool, OwnerContext.Chamber));

                LoadParameterSettings();

                LoadFFCoeficientSettings();

                //Linear1Min = 0;
                // Linear1Max = 0;
                // Linear2Min = 0;
                // Linear2Max = 0;
            }
            finally
            {
                HideWait();
            }

            IsDirty = false;
        }

        private void LoadFFCoeficientSettings()
        {
            var ffCoeficientSettings = OwnerContext.Process?.FeedforwardSettings?.Select(s => new FFCoefficientSettingModel() { ParameterName = s.Parameter.ParameterName, Coefficient = 0 })?.ToList();

            if (ffCoeficientSettings != null)
            {
                for (var i = 0; i < ffCoeficientSettings.Count; i++)
                {
                    var ffc = ffCoeficientSettings[i];
                    ffc.Coefficient = OwnerContext.ContextInput.ContextMisc.FFCoefficient[i];
                }

                FFCoefficientSettingList = new ObservableCollection<FFCoefficientSettingModel>(ffCoeficientSettings);

                foreach (var ffc in FFCoefficientSettingList)
                {
                    ffc.PropertyChanged += OnFFCoeficient_PropertyChanged;
                }
            }

            IsDirty = false;
        }

        private void LoadParameterSettings()
        {
            List<ParameterSettingModel> parameterSettings = new List<ParameterSettingModel>();

            if (OwnerContext.ContextInputParas != null)
            {
                for (var i = 0; i < OwnerContext.ContextInputParas.Count; i++)
                {
                    var item = OwnerContext.ContextInputParas[i];
                    var parameterSetting = new ParameterSettingModel(this)
                    {
                        IsChecked = true,
                        Parameter = ParameterList.FirstOrDefault(p => p.ParameterName == item.Parameter?.ParameterName),
                        ParameterName = item.ParameterName,
                        Default = item.DefaultRecommandValue,
                        Max = item.UpperLimit,
                        Min = item.LowerLimit,
                        Precision = item.Precision,
                        RecVsUsedLimit = (decimal)item.RecVsUsedLimit,
                        FBNegDelta = (decimal)item.FBNegDelta,
                        FBPostDelta = (decimal)item.FBPostDelta,
                        ModelSlope1 = (decimal)item.ModelSlope.Cells[0][0],
                        ModelSlope2 = (decimal)item.ModelSlope.Cells[0][1],
                        ModelSlope3 = (decimal)item.ModelSlope.Cells[0][2],
                        ModelSlope4 = (decimal)item.ModelSlope.Cells[0][3],
                        ModelSlope5 = (decimal)item.ModelSlope.Cells[0][4],
                        ModelSlope6 = (decimal)item.ModelSlope.Cells[0][5],
                        ModelSlope7 = (decimal)item.ModelSlope.Cells[0][6],
                        ModelSlope8 = (decimal)item.ModelSlope.Cells[0][7],
                        ModelSlope9 = (decimal)item.ModelSlope.Cells[0][8],
                        ModelSlope10 = (decimal)item.ModelSlope.Cells[0][9],

                        Slot1Compensation = (decimal)item.Slot1Compensation,
                        Slot2Compensation = (decimal)item.Slot2Compensation,

                        LinearConstraint1Coff = (decimal)OwnerContext.LinearConstraint1Coff[i],
                        LinearConstraint2Coff = (decimal)OwnerContext.LinearConstraint2Coff[i],
                        Unit = item.Unit,
                        Deadband = item.Deadband,
                        QsStatesEst = (decimal)item.QsStatesEst,
                        RsStatesEst = (decimal)item.RsStatesEst
                    };

                    parameterSettings.Add(parameterSetting);
                }

                Linear1Min = (decimal)OwnerContext.Linear1Min;
                Linear1Max = (decimal)OwnerContext.Linear1Max;
                Linear2Min = (decimal)OwnerContext.Linear2Min;
                Linear2Max = (decimal)OwnerContext.Linear2Max;
            }

            int currentCount = parameterSettings.Count;
            // make up 10 parameter settings.
            if (parameterSettings.Count < 10)
            {
                for (int i = 0; i < 10 - currentCount; i++)
                {
                    var newInputSetting = new ParameterSettingModel(this);

                    parameterSettings.Add(newInputSetting);
                }
            }

            ParameterSettingList = new ObservableCollection<ParameterSettingModel>(parameterSettings);

            UpdateParamTable();

            foreach (var ps in ParameterSettingList)
            {
                ps.PropertyChanged += OnParameterSetting_PropertyChanged;
            }

            IsDirty = false;
        }

        private void OnParameterSetting_PropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            IsDirty = true;

            if (e.PropertyName == nameof(ParameterSettingModel.IsChecked))
            {
                UpdateParamTable();
            }
            else
            {
                ClearError($"{nameof(ParameterSettingList)}.{e.PropertyName}");
            }
        }

        private void UpdateParamTable()
        {
            var newInputSettingDTO = new ContextInputPara();
            int outputNum = this.OwnerContext != null ? this.OwnerContext.OutputNum4Slope() : 0;
            for (var i = 0; i < ParameterSettingList.Count; i++)
            {
                var item = ParameterSettingList[i];
                item.Index = i + 1;

                if (i == 0)
                {
                    item.IsReadOnlyIsChecked = ParameterSettingList[i + 1].IsChecked;
                }
                else if (i < 9)
                {
                    item.IsReadOnlyIsChecked = !ParameterSettingList[i - 1].IsChecked || ParameterSettingList[i + 1].IsChecked;
                }
                else
                {
                    item.IsReadOnlyIsChecked = !ParameterSettingList[i - 1].IsChecked;
                }

                if (!item.IsChecked)
                {
                    item.Parameter = null;
                    item.Default = 0;
                    item.Min = 0;
                    item.Max = 0;
                    item.Precision = 1;
                    item.Unit = "";
                    item.RecVsUsedLimit = 0;
                    item.FBNegDelta = 0;
                    item.FBPostDelta = 0;
                    item.Deadband = 0;
                    item.ModelSlope1 = 0;
                    item.ModelSlope2 = 0;
                    item.ModelSlope3 = 0;
                    item.ModelSlope4 = 0;
                    item.ModelSlope5 = 0;
                    item.ModelSlope6 = 0;
                    item.ModelSlope7 = 0;
                    item.ModelSlope8 = 0;
                    item.ModelSlope9 = 0;
                    item.ModelSlope10 = 0;

                    item.QsStatesEst = 0;
                    item.RsStatesEst = 0;

                    item.Slot1Compensation = 0;
                    item.Slot2Compensation = 0;
                    item.LinearConstraint1Coff = 0;
                    item.LinearConstraint2Coff = 0;

                    item.IsEnableModelSlop1 = false;
                    item.IsEnableModelSlop2 = false;
                    item.IsEnableModelSlop3 = false;
                    item.IsEnableModelSlop4 = false;
                    item.IsEnableModelSlop5 = false;
                    item.IsEnableModelSlop6 = false;
                    item.IsEnableModelSlop7 = false;
                    item.IsEnableModelSlop8 = false;
                    item.IsEnableModelSlop9 = false;
                    item.IsEnableModelSlop10 = false;

                    item.LinearConstraint1Coff = 0;
                    item.LinearConstraint2Coff = 0;
                    item.IsEnabledLinear1 = false;
                    item.IsEnabledLinear2 = false;

                    // set default value.
                    item.FBNegDelta = (decimal)newInputSettingDTO.FBNegDelta;
                    item.FBPostDelta = (decimal)newInputSettingDTO.FBPostDelta;
                    item.LinearConstraint1Coff = (decimal)newInputSettingDTO.LinearConstraint1Coff;
                    item.LinearConstraint2Coff = (decimal)newInputSettingDTO.LinearConstraint2Coff;
                    item.Slot1Compensation = (decimal)newInputSettingDTO.Slot1Compensation;
                    item.QsStatesEst = (decimal)newInputSettingDTO.QsStatesEst;
                    item.RsStatesEst = (decimal)newInputSettingDTO.RsStatesEst;
                }
                else
                {
                    switch (outputNum/*ParameterSettingList.Count(p => p.IsChecked)*/)
                    {
                        case 0:
                            item.IsEnableModelSlop1 = false;
                            item.IsEnableModelSlop2 = false;
                            item.IsEnableModelSlop3 = false;
                            item.IsEnableModelSlop4 = false;
                            item.IsEnableModelSlop5 = false;
                            item.IsEnableModelSlop6 = false;
                            item.IsEnableModelSlop7 = false;
                            item.IsEnableModelSlop8 = false;
                            item.IsEnableModelSlop9 = false;
                            item.IsEnableModelSlop10 = false;

                            item.ModelSlope1 = 0;
                            item.ModelSlope2 = 0;
                            item.ModelSlope3 = 0;
                            item.ModelSlope4 = 0;
                            item.ModelSlope5 = 0;
                            item.ModelSlope6 = 0;
                            item.ModelSlope7 = 0;
                            item.ModelSlope8 = 0;
                            item.ModelSlope9 = 0;
                            item.ModelSlope10 = 0;
                            break;

                        case 1:
                            item.IsEnableModelSlop1 = true;
                            item.IsEnableModelSlop2 = false;
                            item.IsEnableModelSlop3 = false;
                            item.IsEnableModelSlop4 = false;
                            item.IsEnableModelSlop5 = false;
                            item.IsEnableModelSlop6 = false;
                            item.IsEnableModelSlop7 = false;
                            item.IsEnableModelSlop8 = false;
                            item.IsEnableModelSlop9 = false;
                            item.IsEnableModelSlop10 = false;

                            item.ModelSlope2 = 0;
                            item.ModelSlope3 = 0;
                            item.ModelSlope4 = 0;
                            item.ModelSlope5 = 0;
                            item.ModelSlope6 = 0;
                            item.ModelSlope7 = 0;
                            item.ModelSlope8 = 0;
                            item.ModelSlope9 = 0;
                            item.ModelSlope10 = 0;
                            break;
                        case 2:
                            item.IsEnableModelSlop1 = true;
                            item.IsEnableModelSlop2 = true;
                            item.IsEnableModelSlop3 = false;
                            item.IsEnableModelSlop4 = false;
                            item.IsEnableModelSlop5 = false;
                            item.IsEnableModelSlop6 = false;
                            item.IsEnableModelSlop7 = false;
                            item.IsEnableModelSlop8 = false;
                            item.IsEnableModelSlop9 = false;
                            item.IsEnableModelSlop10 = false;

                            item.ModelSlope3 = 0;
                            item.ModelSlope4 = 0;
                            item.ModelSlope5 = 0;
                            item.ModelSlope6 = 0;
                            item.ModelSlope7 = 0;
                            item.ModelSlope8 = 0;
                            item.ModelSlope9 = 0;
                            item.ModelSlope10 = 0;
                            break;
                        case 3:
                            item.IsEnableModelSlop1 = true;
                            item.IsEnableModelSlop2 = true;
                            item.IsEnableModelSlop3 = true;
                            item.IsEnableModelSlop4 = false;
                            item.IsEnableModelSlop5 = false;
                            item.IsEnableModelSlop6 = false;
                            item.IsEnableModelSlop7 = false;
                            item.IsEnableModelSlop8 = false;
                            item.IsEnableModelSlop9 = false;
                            item.IsEnableModelSlop10 = false;

                            item.ModelSlope4 = 0;
                            item.ModelSlope5 = 0;
                            item.ModelSlope6 = 0;
                            item.ModelSlope7 = 0;
                            item.ModelSlope8 = 0;
                            item.ModelSlope9 = 0;
                            item.ModelSlope10 = 0;
                            break;
                        case 4:
                            item.IsEnableModelSlop1 = true;
                            item.IsEnableModelSlop2 = true;
                            item.IsEnableModelSlop3 = true;
                            item.IsEnableModelSlop4 = true;
                            item.IsEnableModelSlop5 = false;
                            item.IsEnableModelSlop6 = false;
                            item.IsEnableModelSlop7 = false;
                            item.IsEnableModelSlop8 = false;
                            item.IsEnableModelSlop9 = false;
                            item.IsEnableModelSlop10 = false;

                            item.ModelSlope5 = 0;
                            item.ModelSlope6 = 0;
                            item.ModelSlope7 = 0;
                            item.ModelSlope8 = 0;
                            item.ModelSlope9 = 0;
                            item.ModelSlope10 = 0;
                            break;
                        case 5:
                            item.IsEnableModelSlop1 = true;
                            item.IsEnableModelSlop2 = true;
                            item.IsEnableModelSlop3 = true;
                            item.IsEnableModelSlop4 = true;
                            item.IsEnableModelSlop5 = true;
                            item.IsEnableModelSlop6 = false;
                            item.IsEnableModelSlop7 = false;
                            item.IsEnableModelSlop8 = false;
                            item.IsEnableModelSlop9 = false;
                            item.IsEnableModelSlop10 = false;

                            item.ModelSlope6 = 0;
                            item.ModelSlope7 = 0;
                            item.ModelSlope8 = 0;
                            item.ModelSlope9 = 0;
                            item.ModelSlope10 = 0;
                            break;
                        case 6:
                            item.IsEnableModelSlop1 = true;
                            item.IsEnableModelSlop2 = true;
                            item.IsEnableModelSlop3 = true;
                            item.IsEnableModelSlop4 = true;
                            item.IsEnableModelSlop5 = true;
                            item.IsEnableModelSlop6 = true;
                            item.IsEnableModelSlop7 = false;
                            item.IsEnableModelSlop8 = false;
                            item.IsEnableModelSlop9 = false;
                            item.IsEnableModelSlop10 = false;

                            item.ModelSlope7 = 0;
                            item.ModelSlope8 = 0;
                            item.ModelSlope9 = 0;
                            item.ModelSlope10 = 0;
                            break;
                        case 7:
                            item.IsEnableModelSlop1 = true;
                            item.IsEnableModelSlop2 = true;
                            item.IsEnableModelSlop3 = true;
                            item.IsEnableModelSlop4 = true;
                            item.IsEnableModelSlop5 = true;
                            item.IsEnableModelSlop6 = true;
                            item.IsEnableModelSlop7 = true;
                            item.IsEnableModelSlop8 = false;
                            item.IsEnableModelSlop9 = false;
                            item.IsEnableModelSlop10 = false;

                            item.ModelSlope8 = 0;
                            item.ModelSlope9 = 0;
                            item.ModelSlope10 = 0;
                            break;
                        case 8:
                            item.IsEnableModelSlop1 = true;
                            item.IsEnableModelSlop2 = true;
                            item.IsEnableModelSlop3 = true;
                            item.IsEnableModelSlop4 = true;
                            item.IsEnableModelSlop5 = true;
                            item.IsEnableModelSlop6 = true;
                            item.IsEnableModelSlop7 = true;
                            item.IsEnableModelSlop8 = true;
                            item.IsEnableModelSlop9 = false;
                            item.IsEnableModelSlop10 = false;

                            item.ModelSlope9 = 0;
                            item.ModelSlope10 = 0;
                            break;
                        case 9:
                            item.IsEnableModelSlop1 = true;
                            item.IsEnableModelSlop2 = true;
                            item.IsEnableModelSlop3 = true;
                            item.IsEnableModelSlop4 = true;
                            item.IsEnableModelSlop5 = true;
                            item.IsEnableModelSlop6 = true;
                            item.IsEnableModelSlop7 = true;
                            item.IsEnableModelSlop8 = true;
                            item.IsEnableModelSlop9 = true;
                            item.IsEnableModelSlop10 = false;

                            item.ModelSlope10 = 0;
                            break;
                        case 10:
                            item.IsEnableModelSlop1 = true;
                            item.IsEnableModelSlop2 = true;
                            item.IsEnableModelSlop3 = true;
                            item.IsEnableModelSlop4 = true;
                            item.IsEnableModelSlop5 = true;
                            item.IsEnableModelSlop6 = true;
                            item.IsEnableModelSlop7 = true;
                            item.IsEnableModelSlop8 = true;
                            item.IsEnableModelSlop9 = true;
                            item.IsEnableModelSlop10 = true;
                            break;
                        default:
                            break;
                    }

                    item.IsEnabledLinear1 = LinearConstraintEnabled;

                    item.IsEnabledLinear2 = LinearConstraintEnabled;

                    if(!LinearConstraintEnabled)
                    {
                        item.LinearConstraint1Coff = 0;
                        item.LinearConstraint2Coff = 0;
                    }
                }
            }
        }

        private void OnFFCoeficient_PropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            if (e.PropertyName == nameof(FFCoefficientSettingModel.Coefficient))
            {
                ClearError($"{nameof(FFCoefficientSettingList)}.{e.PropertyName}");
                IsDirty = true;
            }
        }

        [Command]
        public async void Update()
        {
            var checkedInputList = ParameterSettingList.Where(p => p.IsChecked).ToList();
            if (checkedInputList.Any(p => p != null && checkedInputList.Any(p2 => p2.Parameter == p.Parameter && p != p2)))
            {
                MessageBoxService.ShowMessage("An input with the same Parameter already exists.", "Duplicate Input", MessageButton.OK, MessageIcon.Error);
                return;
            }

            foreach (var item in checkedInputList)
            {
                if (item.Error != null)
                {
                    SetError($"{nameof(ParameterSettingList)}.{item.Error}", item[item.Error]);
                    SetFocus(nameof(ParameterSettingList));
                    return;
                }
            }

            foreach (var item in FFCoefficientSettingList)
            {
                if (item.Error != null)
                {
                    SetError($"{nameof(FFCoefficientSettingList)}.{item.Error}", item[item.Error]);
                    SetFocus(nameof(FFCoefficientSettingList));
                    return;
                }
            }

            if (!HasErrors)
            {
                ValidateAndSetErrorFocus(nameof(Linear1Min), nameof(Linear1Max), nameof(Linear2Min), nameof(Linear2Max));

                if (HasErrors)
                {
                    return;
                }
            }


            if (IsConfirmed(out var comment))
            {
                ShowWait();
                // encapsulate ContextInput
                var input = new ContextInput
                {
                    ContextId = OwnerContext.ContextId,
                    ContextKey = OwnerContext.ContextKey
                };

                // input parameters
                foreach (var ps in ParameterSettingList.Where(p => p.IsChecked))
                {
                    var inputPara = new ContextInputPara
                    {
                        ContextId = OwnerContext.ContextId,
                        ContextKey = OwnerContext.ContextKey,
                        DefaultRecommandValue = ps.Default.Value,
                        UpperLimit = ps.Max.Value,
                        LowerLimit = ps.Min.Value,
                        Precision = ps.Precision,
                        Parameter = ps.Parameter,
                        RecVsUsedLimit = (double)ps.RecVsUsedLimit.Value,
                        FBNegDelta = (double)ps.FBNegDelta.Value,
                        FBPostDelta = (double)ps.FBPostDelta.Value,
                        ModelSlope = new Matrix<double>(1, 10, 0)
                    };

                    inputPara.ModelSlope.Cells[0][0] = (double)ps.ModelSlope1;
                    inputPara.ModelSlope.Cells[0][1] = (double)ps.ModelSlope2;
                    inputPara.ModelSlope.Cells[0][2] = (double)ps.ModelSlope3;
                    inputPara.ModelSlope.Cells[0][3] = (double)ps.ModelSlope4;
                    inputPara.ModelSlope.Cells[0][4] = (double)ps.ModelSlope5;
                    inputPara.ModelSlope.Cells[0][5] = (double)ps.ModelSlope6;
                    inputPara.ModelSlope.Cells[0][6] = (double)ps.ModelSlope7;
                    inputPara.ModelSlope.Cells[0][7] = (double)ps.ModelSlope8;
                    inputPara.ModelSlope.Cells[0][8] = (double)ps.ModelSlope9;
                    inputPara.ModelSlope.Cells[0][9] = (double)ps.ModelSlope10;

                    inputPara.LinearConstraint1Coff = (double)ps.LinearConstraint1Coff;
                    inputPara.LinearConstraint2Coff = (double)ps.LinearConstraint2Coff;

                    inputPara.Slot1Compensation = (double)ps.Slot1Compensation;
                    inputPara.Slot2Compensation = (double)ps.Slot2Compensation;

                    inputPara.LinearConstraint1Coff = (double)ps.LinearConstraint1Coff;
                    inputPara.LinearConstraint2Coff = (double)ps.LinearConstraint2Coff;

                    inputPara.InputIndex = ps.Index;
                    inputPara.Unit = ps.Unit;
                    inputPara.QsStatesEst = (double)ps.QsStatesEst;
                    inputPara.RsStatesEst = (double)ps.RsStatesEst;
                    inputPara.Deadband = ps.Deadband.Value;
                    //inputPara.

                    input.ContextInputParas.Add(inputPara);
                }

                // Context Misc
                input.ContextMisc.ContextId = OwnerContext.ContextId;
                input.ContextMisc.ContextKey = OwnerContext.ContextKey;
                input.ContextMisc.Linear1Min = (double)Linear1Min;
                input.ContextMisc.Linear1Max = (double)Linear1Max;
                input.ContextMisc.Linear2Min = (double)Linear2Min;
                input.ContextMisc.Linear2Max = (double)Linear2Max;
                input.ContextMisc.FFCoefficient = new Matrix<double>(1, 10, 0).RowArray(0);
                for (var i = 0; i < FFCoefficientSettingList.Count; i++)
                {
                    var item = FFCoefficientSettingList[i];
                    input.ContextMisc.FFCoefficient[i] = item.Coefficient.Value;
                }

                // submit
                await ContextService.UpdateContextInputAsync(input, input.ContextId, comment);

                IsDirty = false;
                HideWait();

                // notify ContextList for update.
                Messenger.Default.Send(new ContextChangedMessage() { ChangeType = ObjectChangeType.Updated, ContextId = OwnerContext.ContextId });
                MessageBoxService.ShowMessage("Context Input Updated.", "Success", MessageButton.OK, MessageIcon.Information);


                IsOK = true;
                CloseWindow();
            }
        }

        public bool CanUpdate()
        {
            return IsDirty && ParameterSettingList.Any(p => p.IsChecked);
        }

        protected override string GetError(string columnName)
        {
            switch (columnName)
            {
                case nameof(Linear1Min):
                    return DataValidator.ValidateInOrder(
                        () => DataValidator.NotNull(Linear1Min),
                        () => DataValidator.SmallerThanOrEqualTo(Linear1Min, Linear1Max)
                        );
                case nameof(Linear1Max):
                    return DataValidator.NotNull(Linear1Max);
                case nameof(Linear2Min):
                    return DataValidator.ValidateInOrder(
                        () => DataValidator.NotNull(Linear2Min),
                        () => DataValidator.SmallerThanOrEqualTo(Linear2Min, Linear2Max)
                        );
                case nameof(Linear2Max):
                    return DataValidator.NotNull(Linear2Max);
                default:
                    return null;
            }
        }

        #region Properties
        public Context OwnerContext { get; private set; }

        public ContextInput OriginalSettings { get; private set; }

        public bool LinearConstraintEnabled
        {
            get { return GetValue<bool>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(LinearConstraintEnabled));
            }
        }

        public decimal? Linear1Min
        {
            get { return GetValue<decimal?>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(Linear1Min));
            }
        }

        public decimal? Linear1Max
        {
            get { return GetValue<decimal?>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(Linear1Max));
                ClearError(nameof(Linear1Min));
            }
        }

        public decimal? Linear2Min
        {
            get { return GetValue<decimal?>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(Linear2Min));
            }
        }

        public decimal? Linear2Max
        {
            get { return GetValue<decimal?>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(Linear2Max));
                ClearError(nameof(Linear2Min));
            }
        }

        public ObservableCollection<Parameter> ParameterList
        {
            get { return GetValue<ObservableCollection<Parameter>>(); }
            set { SetValue(value); }
        }


        public ObservableCollection<ParameterSettingModel> ParameterSettingList
        {
            get { return GetValue<ObservableCollection<ParameterSettingModel>>(); }
            set { SetValue(value); }
        }

        public ObservableCollection<FFCoefficientSettingModel> FFCoefficientSettingList
        {
            get { return GetValue<ObservableCollection<FFCoefficientSettingModel>>(); }
            set { SetValue(value); }
        }


        #endregion
    }

    public class ParameterSettingModel : BindableBase, IDataErrorInfo
    {
        public EditContextInputViewModel ViewModel { get; set; }
        public ParameterSettingModel(EditContextInputViewModel viewModel)
        {
            ViewModel = viewModel;
        }


        public int Index
        {
            get { return GetValue<int>(); }
            set { SetValue(value); }
        }


        public bool IsChecked
        {
            get { return GetValue<bool>(); }
            set { SetValue(value); }
        }

        public bool IsReadOnlyIsChecked
        {
            get { return GetValue<bool>(); }
            set { SetValue(value); }
        }

        public Parameter Parameter
        {
            get { return GetValue<Parameter>(); }
            set { SetValue(value); }
        }

        public string ParameterName
        {
            get { return GetValue<string>(); }
            set { SetValue(value); }
        }

        public decimal? Default
        {
            get { return GetValue<decimal?>(); }
            set { SetValue(value); }
        }

        public decimal? Min
        {
            get { return GetValue<decimal?>(); }
            set { SetValue(value); }
        }

        public decimal? Max
        {
            get { return GetValue<decimal?>(); }
            set { SetValue(value); }
        }

        public int Precision
        {
            get { return GetValue<int>(); }
            set { SetValue(value); }
        }

        public decimal? RecVsUsedLimit
        {
            get { return GetValue<decimal?>(); }
            set { SetValue(value); }
        }

        public decimal? FBNegDelta
        {
            get { return GetValue<decimal?>(); }
            set { SetValue(value); }
        }

        public decimal? FBPostDelta
        {
            get { return GetValue<decimal?>(); }
            set { SetValue(value); }
        }
        public decimal? ModelSlope1
        {
            get { return GetValue<decimal?>(); }
            set { SetValue(value); }
        }
        public decimal? ModelSlope2
        {
            get { return GetValue<decimal?>(); }
            set { SetValue(value); }
        }
        public decimal? ModelSlope3
        {
            get { return GetValue<decimal?>(); }
            set { SetValue(value); }
        }
        public decimal? ModelSlope4
        {
            get { return GetValue<decimal?>(); }
            set { SetValue(value); }
        }
        public decimal? ModelSlope5
        {
            get { return GetValue<decimal?>(); }
            set { SetValue(value); }
        }
        public decimal? ModelSlope6
        {
            get { return GetValue<decimal?>(); }
            set { SetValue(value); }
        }
        public decimal? ModelSlope7
        {
            get { return GetValue<decimal?>(); }
            set { SetValue(value); }
        }
        public decimal? ModelSlope8
        {
            get { return GetValue<decimal?>(); }
            set { SetValue(value); }
        }
        public decimal? ModelSlope9
        {
            get { return GetValue<decimal?>(); }
            set { SetValue(value); }
        }
        public decimal? ModelSlope10
        {
            get { return GetValue<decimal?>(); }
            set { SetValue(value); }
        }

        public decimal? Slot1Compensation
        {
            get { return GetValue<decimal?>(); }
            set { SetValue(value); }
        }

        public decimal? Slot2Compensation
        {
            get { return GetValue<decimal?>(); }
            set { SetValue(value); }
        }
        public decimal? LinearConstraint1Coff
        {
            get { return GetValue<decimal?>(); }
            set { SetValue(value); }
        }
        public decimal? LinearConstraint2Coff
        {
            get { return GetValue<decimal?>(); }
            set { SetValue(value); }
        }

        public bool IsEnableModelSlop1
        {
            get { return GetValue<bool>(); }
            set { SetValue(value); }
        }
        public bool IsEnableModelSlop2
        {
            get { return GetValue<bool>(); }
            set { SetValue(value); }
        }
        public bool IsEnableModelSlop3
        {
            get { return GetValue<bool>(); }
            set { SetValue(value); }
        }
        public bool IsEnableModelSlop4
        {
            get { return GetValue<bool>(); }
            set { SetValue(value); }
        }
        public bool IsEnableModelSlop5
        {
            get { return GetValue<bool>(); }
            set { SetValue(value); }
        }
        public bool IsEnableModelSlop6
        {
            get { return GetValue<bool>(); }
            set { SetValue(value); }
        }
        public bool IsEnableModelSlop7
        {
            get { return GetValue<bool>(); }
            set { SetValue(value); }
        }
        public bool IsEnableModelSlop8
        {
            get { return GetValue<bool>(); }
            set { SetValue(value); }
        }
        public bool IsEnableModelSlop9
        {
            get { return GetValue<bool>(); }
            set { SetValue(value); }
        }
        public bool IsEnableModelSlop10
        {
            get { return GetValue<bool>(); }
            set { SetValue(value); }
        }

        public bool IsEnabledLinear1
        {
            get { return GetValue<bool>(); }
            set { SetValue(value); }
        }

        public bool IsEnabledLinear2
        {
            get { return GetValue<bool>(); }
            set { SetValue(value); }
        }

        public string Unit
        {
            get { return GetValue<string>(); }
            set { SetValue(value); }
        }

        public decimal? QsStatesEst
        {
            get { return GetValue<decimal?>(); }
            set { SetValue(value); }
        }

        public decimal? RsStatesEst
        {
            get { return GetValue<decimal?>(); }
            set { SetValue(value); }
        }

        public decimal? Deadband
        {
            get { return GetValue<decimal?>(); }
            set { SetValue(value); }
        }

        public string Error
        {
            get
            {
                if (!string.IsNullOrEmpty(this[nameof(Parameter)]))
                {
                    return $"{nameof(Parameter)}";
                }
                else if (!string.IsNullOrEmpty(this[nameof(Default)]))
                {
                    return $"{nameof(Default)}";
                }
                else if (!string.IsNullOrEmpty(this[nameof(Min)]))
                {
                    return $"{nameof(Min)}";
                }
                else if (!string.IsNullOrEmpty(this[nameof(Max)]))
                {
                    return $"{nameof(Max)}";
                }
                else if (!string.IsNullOrEmpty(this[nameof(Precision)]))
                {
                    return $"{nameof(Precision)}";
                }
                else if (!string.IsNullOrEmpty(this[nameof(RecVsUsedLimit)]))
                {
                    return $"{nameof(RecVsUsedLimit)}";
                }
                else if (!string.IsNullOrEmpty(this[nameof(FBNegDelta)]))
                {
                    return $"{nameof(FBNegDelta)}";
                }
                else if (!string.IsNullOrEmpty(this[nameof(FBPostDelta)]))
                {
                    return $"{nameof(FBPostDelta)}";
                }
                else if (!string.IsNullOrEmpty(this[nameof(ModelSlope1)]))
                {
                    return $"{nameof(ModelSlope1)}";
                }
                else if (!string.IsNullOrEmpty(this[nameof(ModelSlope2)]))
                {
                    return $"{nameof(ModelSlope2)}";
                }
                else if (!string.IsNullOrEmpty(this[nameof(ModelSlope3)]))
                {
                    return $"{nameof(ModelSlope3)}";
                }
                else if (!string.IsNullOrEmpty(this[nameof(ModelSlope4)]))
                {
                    return $"{nameof(ModelSlope4)}";
                }
                else if (!string.IsNullOrEmpty(this[nameof(ModelSlope5)]))
                {
                    return $"{nameof(ModelSlope5)}";
                }
                else if (!string.IsNullOrEmpty(this[nameof(ModelSlope6)]))
                {
                    return $"{nameof(ModelSlope6)}";
                }
                else if (!string.IsNullOrEmpty(this[nameof(ModelSlope7)]))
                {
                    return $"{nameof(ModelSlope7)}";
                }
                else if (!string.IsNullOrEmpty(this[nameof(ModelSlope8)]))
                {
                    return $"{nameof(ModelSlope8)}";
                }
                else if (!string.IsNullOrEmpty(this[nameof(ModelSlope9)]))
                {
                    return $"{nameof(ModelSlope9)}";
                }
                else if (!string.IsNullOrEmpty(this[nameof(ModelSlope10)]))
                {
                    return $"{nameof(ModelSlope10)}";
                }
                else if (!string.IsNullOrEmpty(this[nameof(Slot1Compensation)]))
                {
                    return $"{nameof(Slot1Compensation)}";
                }
                else if (!string.IsNullOrEmpty(this[nameof(Slot2Compensation)]))
                {
                    return $"{nameof(Slot2Compensation)}";
                }
                else if (!string.IsNullOrEmpty(this[nameof(LinearConstraint1Coff)]))
                {
                    return $"{nameof(LinearConstraint1Coff)}";
                }
                else if (!string.IsNullOrEmpty(this[nameof(LinearConstraint2Coff)]))
                {
                    return $"{nameof(LinearConstraint2Coff)}";
                }
                else if (!string.IsNullOrEmpty(this[nameof(QsStatesEst)]))
                {
                    return $"{nameof(QsStatesEst)}";
                }
                else if (!string.IsNullOrEmpty(this[nameof(RsStatesEst)]))
                {
                    return $"{nameof(RsStatesEst)}";
                }
                else if (!string.IsNullOrEmpty(this[nameof(Unit)]))
                {
                    return $"{nameof(Unit)}";
                }
                else if (!string.IsNullOrEmpty(this[nameof(Deadband)]))
                {
                    return $"{nameof(Deadband)}";
                }
                else
                {
                    return null;
                }
            }
        }


        public string this[string propertyName]
        {
            get
            {
                if (!IsChecked) return null;
                switch (propertyName)
                {
                    case nameof(Parameter):
                        return DataValidator.NotNull(Parameter);
                    case nameof(Default):
                        return DataValidator.ValidateInOrder(
                            () => DataValidator.NotNull(Default),
                            () => DataValidator.LargerThanOrEqualTo(Default, Min),
                            () => DataValidator.SmallerThanOrEqualTo(Default, Max)
                            );
                    case nameof(Min):
                        return DataValidator.ValidateInOrder(
                            () => DataValidator.NotNull(Min),
                            () => DataValidator.SmallerThanOrEqualTo(Min, Max)
                            );
                    case nameof(Max):
                        return DataValidator.ValidateInOrder(
                            () => DataValidator.NotNull(Max),
                            () => DataValidator.LargerThanOrEqualTo(Max, Min)
                            );
                    case nameof(Precision):
                        return DataValidator.ValidateInOrder(
                            () => DataValidator.NotNull(Precision),
                            () => DataValidator.InRange(Precision, 1, 8)
                            );
                    case nameof(RecVsUsedLimit):
                        return DataValidator.ValidateInOrder(
                            () => DataValidator.NotNull(RecVsUsedLimit),
                            () => DataValidator.LargerThanOrEqualTo(RecVsUsedLimit, 0)
                            );
                    case nameof(FBNegDelta):
                        return DataValidator.ValidateInOrder(
                            () => DataValidator.NotNull(FBNegDelta),
                            () => DataValidator.SmallerThanOrEqualTo(FBNegDelta, 0)
                            );
                    case nameof(FBPostDelta):
                        return DataValidator.ValidateInOrder(
                            () => DataValidator.NotNull(FBPostDelta),
                            () => DataValidator.LargerThanOrEqualTo(FBPostDelta, 0)
                            );

                    case nameof(ModelSlope1):
                    case nameof(ModelSlope2):
                    case nameof(ModelSlope3):
                    case nameof(ModelSlope4):
                    case nameof(ModelSlope5):
                    case nameof(ModelSlope6):
                    case nameof(ModelSlope7):
                    case nameof(ModelSlope8):
                    case nameof(ModelSlope9):
                    case nameof(ModelSlope10):
                        return DataValidator.ValidateInOrder(
                        () => DataValidator.NotNull(ModelSlope1),
                        () => DataValidator.NotNull(ModelSlope2),
                        () => DataValidator.NotNull(ModelSlope3),
                        () => DataValidator.NotNull(ModelSlope4),
                        () => DataValidator.NotNull(ModelSlope5),
                        () => DataValidator.NotNull(ModelSlope6),
                        () => DataValidator.NotNull(ModelSlope7),
                        () => DataValidator.NotNull(ModelSlope8),
                        () => DataValidator.NotNull(ModelSlope9),
                        () => DataValidator.NotNull(ModelSlope10),
                        () => IsEnableModelSlop10 ? DataValidator.NotZero(new decimal?[] { ModelSlope1, ModelSlope2, ModelSlope3, ModelSlope4, ModelSlope5, ModelSlope6, ModelSlope7, ModelSlope8, ModelSlope9, ModelSlope10 }) :
                              IsEnableModelSlop9 ? DataValidator.NotZero(new decimal?[] { ModelSlope1, ModelSlope2, ModelSlope3, ModelSlope4, ModelSlope5, ModelSlope6, ModelSlope7, ModelSlope8, ModelSlope9 }):
                              IsEnableModelSlop8 ? DataValidator.NotZero(new decimal?[] { ModelSlope1, ModelSlope2, ModelSlope3, ModelSlope4, ModelSlope5, ModelSlope6, ModelSlope7, ModelSlope8}) :
                              IsEnableModelSlop7 ? DataValidator.NotZero(new decimal?[] { ModelSlope1, ModelSlope2, ModelSlope3, ModelSlope4, ModelSlope5, ModelSlope6, ModelSlope7}) :
                              IsEnableModelSlop6 ? DataValidator.NotZero(new decimal?[] { ModelSlope1, ModelSlope2, ModelSlope3, ModelSlope4, ModelSlope5, ModelSlope6}) :
                              IsEnableModelSlop5 ? DataValidator.NotZero(new decimal?[] { ModelSlope1, ModelSlope2, ModelSlope3, ModelSlope4, ModelSlope5}) :
                              IsEnableModelSlop4 ? DataValidator.NotZero(new decimal?[] { ModelSlope1, ModelSlope2, ModelSlope3, ModelSlope4 }) :
                              IsEnableModelSlop3 ? DataValidator.NotZero(new decimal?[] { ModelSlope1, ModelSlope2, ModelSlope3 }) :
                              IsEnableModelSlop2 ? DataValidator.NotZero(new decimal?[] { ModelSlope1, ModelSlope2 }) :
                              IsEnableModelSlop1 ? DataValidator.NotZero(new decimal?[] { ModelSlope1 }) :
                              null
                        );
                    /*
                case nameof(ModelSlope1):
                    return DataValidator.ValidateInOrder(
                        () => DataValidator.NotNull(ModelSlope1),
                        () => IsEnableModelSlop1 ? (Index == 1 ? DataValidator.NotZero(new decimal?[] { ModelSlope1 }) : null) : null
                        );
                case nameof(ModelSlope2):
                    return DataValidator.ValidateInOrder(
                        () => DataValidator.NotNull(ModelSlope2),
                        () => IsEnableModelSlop2 ? (Index == 2 ? DataValidator.NotZero(new decimal?[] { ModelSlope1, ModelSlope2 }) : null) : null
                        );
                case nameof(ModelSlope3):
                    return DataValidator.ValidateInOrder(
                        () => DataValidator.NotNull(ModelSlope3),
                        () => IsEnableModelSlop3 ? (Index == 3 ? DataValidator.NotZero(new decimal?[] { ModelSlope1, ModelSlope2 , ModelSlope3}) : null) : null
                        );
                case nameof(ModelSlope4):
                    return DataValidator.ValidateInOrder(
                        () => DataValidator.NotNull(ModelSlope4),
                        () => IsEnableModelSlop4 ? (Index == 4 ? DataValidator.NotZero(new decimal?[] { ModelSlope1, ModelSlope2, ModelSlope3, ModelSlope4 }) : null) : null
                        );
                case nameof(ModelSlope5):
                    return DataValidator.ValidateInOrder(
                        () => DataValidator.NotNull(ModelSlope5),
                        () => IsEnableModelSlop5 ? (Index == 5 ? DataValidator.NotZero(new decimal?[] { ModelSlope1, ModelSlope2, ModelSlope3, ModelSlope4, ModelSlope5 }) : null) : null
                        );
                case nameof(ModelSlope6):
                    return DataValidator.ValidateInOrder(
                        () => DataValidator.NotNull(ModelSlope6),
                        () => IsEnableModelSlop6 ? (Index == 6 ? DataValidator.NotZero(new decimal?[] { ModelSlope1, ModelSlope2, ModelSlope3, ModelSlope4, ModelSlope5, ModelSlope6 }) : null) : null
                        );
                case nameof(ModelSlope7):
                    return DataValidator.ValidateInOrder(
                        () => DataValidator.NotNull(ModelSlope7),
                        () => IsEnableModelSlop7 ? (Index == 7 ? DataValidator.NotZero(new decimal?[] { ModelSlope1, ModelSlope2, ModelSlope3, ModelSlope4, ModelSlope5, ModelSlope6, ModelSlope7 }) : null) : null
                        );
                case nameof(ModelSlope8):
                    return DataValidator.ValidateInOrder(
                        () => DataValidator.NotNull(ModelSlope8),
                        () => IsEnableModelSlop8 ? (Index == 8 ? DataValidator.NotZero(new decimal?[] { ModelSlope1, ModelSlope2, ModelSlope3, ModelSlope4, ModelSlope5, ModelSlope6, ModelSlope7, ModelSlope8 }) : null) : null
                        );
                case nameof(ModelSlope9):
                    return DataValidator.ValidateInOrder(
                        () => DataValidator.NotNull(ModelSlope9),
                        () => IsEnableModelSlop9 ? (Index == 9 ? DataValidator.NotZero(new decimal?[] { ModelSlope1, ModelSlope2, ModelSlope3, ModelSlope4, ModelSlope5, ModelSlope6, ModelSlope7, ModelSlope8, ModelSlope9 }) : null) : null
                        );
                case nameof(ModelSlope10):
                    return DataValidator.ValidateInOrder(
                        () => DataValidator.NotNull(ModelSlope10),
                        () => IsEnableModelSlop10 ? (Index == 10 ? DataValidator.NotZero(new decimal?[] { ModelSlope1, ModelSlope2, ModelSlope3, ModelSlope4, ModelSlope5, ModelSlope6, ModelSlope7, ModelSlope8, ModelSlope9, ModelSlope10 }) : null) : null
                        );
                        */
                    case nameof(Slot1Compensation):
                        return DataValidator.NotNull(Slot1Compensation);
                    case nameof(Slot2Compensation):
                        return DataValidator.NotNull(Slot2Compensation);
                    case nameof(LinearConstraint1Coff):
                        return DataValidator.ValidateInOrder(
                            () => DataValidator.NotNull(LinearConstraint1Coff),
                            () => DataValidator.InRange(LinearConstraint1Coff, ViewModel.Linear1Min, ViewModel.Linear1Max)
                            );
                    case nameof(LinearConstraint2Coff):
                        return DataValidator.ValidateInOrder(
                            () => DataValidator.NotNull(LinearConstraint2Coff),
                            () => DataValidator.InRange(LinearConstraint2Coff, ViewModel.Linear2Min, ViewModel.Linear2Max)
                            );
                    case nameof(QsStatesEst):
                        return DataValidator.ValidateInOrder(
                            () => DataValidator.NotNull(QsStatesEst),
                            () => DataValidator.NotZero(QsStatesEst)
                            );
                    case nameof(RsStatesEst):
                        return DataValidator.ValidateInOrder(
                            () => DataValidator.NotNull(RsStatesEst),
                            () => DataValidator.NotZero(RsStatesEst)
                            );
                    case nameof(Unit):
                        return DataValidator.ValidateInOrder(
                            () => DataValidator.NotNull(Unit),
                            () => DataValidator.UTF8StringMaxLength(Unit, 40)
                            );
                    case nameof(Deadband):
                        return DataValidator.NotNull(Deadband);

                    default:
                        return null;
                }
            }
        }
    }

    public class FFCoefficientSettingModel : BindableBase, IDataErrorInfo
    {

        public string ParameterName
        {
            get { return GetValue<string>(); }
            set { SetValue(value); }
        }

        public double? Coefficient
        {
            get { return GetValue<double?>(); }
            set { SetValue(value); }
        }

        public string Error
        {
            get
            {
                return !string.IsNullOrEmpty(this[nameof(Coefficient)]) ? $"{nameof(Coefficient)}" : null;
            }
        }


        public string this[string propertyName]
        {
            get
            {
                switch (propertyName)
                {
                    case nameof(Coefficient):
                        return DataValidator.NotNull(Coefficient);
                    default:
                        return null;
                }
            }
        }
    }
}
