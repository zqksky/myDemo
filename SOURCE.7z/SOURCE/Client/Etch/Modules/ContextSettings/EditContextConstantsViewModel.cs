﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Threading.Tasks;
using AMAT.R2R.Client.Common.Enums;
using AMAT.R2R.Client.Common.Helpers;
using AMAT.R2R.Client.Etch.Messages;
using AMAT.R2R.Client.Etch.Properties;
using AMAT.R2R.Client.Etch.Services;
using AMAT.R2R.Shared.Base.DTO;
using AMAT.R2R.Shared.Etch.DTO;
using DevExpress.DirectX.Common.DXGI;
using DevExpress.Mvvm;
using DevExpress.Mvvm.DataAnnotations;
using DevExpress.Mvvm.Native;
using DevExpress.Mvvm.UI.Native;
using DevExpress.Utils;

namespace AMAT.R2R.Client.Etch.Modules.ContextSettings
{

    public class EditContextConstantsViewModel : EtchViewModelBase
    {
        public EditContextConstantsViewModel(Context context)
        {
            WindowWidth = 1200;
            //WindowHeight = 400;
            SizeToContent = System.Windows.SizeToContent.Height;
            OwnerContext = context ?? throw new ArgumentNullException(nameof(context));
            OriginalSettings = context.ContextConstants;

            if (OwnerContext.ContextConstants.ContextId == 0)
            {
                Mode = FunctionMode.Add;
                //ControlFlag = ControlFlag.Fixed;
                Caption = "Create Context Constants";
            }
            else
            {
                Mode = FunctionMode.Modify;
                Caption = "Update Context Constants";
            }

            PropertyChanged += EditContextConstantsViewModel_PropertyChanged;
        }

        private void EditContextConstantsViewModel_PropertyChanged(object sender, PropertyChangedEventArgs e)
        {
        }

        protected override void OnViewReadyAsync()
        {
            Initialize();
        }

        private void Initialize()
        {
            if (OriginalSettings != null && Mode == FunctionMode.Modify)
            {
                OptUseTarget = OriginalSettings.OptUseTarget;
                OptAllowMissingPreMetro = OriginalSettings.OptAllowMissingPreMetro;
                OptHydraAllowMissingData = OriginalSettings.OptHydraAllowMissingData;
                OptHydraFlag = OriginalSettings.OptHydraFlag;
                OptHydraManualDataEntry = OriginalSettings.OptHydraManualDataEntry;
                OptHydraUseWaferMean = OriginalSettings.OptHydraUseWaferMean;
                OptHydraUseZoneMean = OriginalSettings.OptHydraUseZoneMean;
                OptLotHoldMissingPreMet = OriginalSettings.OptLotHoldMissingPreMet;
                OptLotHoldPredicitonOOL = OriginalSettings.OptLotHoldPredicitonOOL;
                OptLotHoldRecommendedOOL = OriginalSettings.OptLotHoldRecommendedOOL;
                OptLotStageWaferUseCalcualtePre = OriginalSettings.OptLotStageWaferUseCalcualtePre;
                OptLimitLotsWithoutMetro = OriginalSettings.OptLimitLotsWithoutMetro;
                OptLimitNoConsecutiveMaxAdjust = OriginalSettings.OptLimitNoConsecutiveMaxAdjust;
                OptHydraAllowMissingDataNumber = (decimal)OriginalSettings.OptHydraAllowMissingDataNumber;
                OptLotStageWaferUseCalcualteOffset = (decimal)OriginalSettings.OptLotStageWaferUseCalcualteOffset;
                OptMaxTimeLastEstDays = (decimal)OriginalSettings.OptMaxTimeLastEstDays;
                OptPreLineAvgExpiredDay = (decimal)OriginalSettings.OptPreLineAvgExpiredDay;
                OptPreMetrologyExpiredDay = (decimal)OriginalSettings.OptPreMetrologyExpiredDay;
                OptLimitMaxConsecutiveOos = OriginalSettings.OptLimitMaxConsecutiveOos;
                OptLimitMaxConsecutiveGof = OriginalSettings.OptLimitMaxConsecutiveGof;
            }
            else
            {
                // set default values.
                OptUseTarget = false;
                OptAllowMissingPreMetro = false;
                OptHydraAllowMissingData = false;
                OptHydraFlag = false;
                OptHydraManualDataEntry = false;
                OptHydraUseWaferMean = false;
                OptHydraUseZoneMean = false;
                OptLotHoldMissingPreMet = false;
                OptLotHoldPredicitonOOL = false;
                OptLotHoldRecommendedOOL = false;
                OptLotStageWaferUseCalcualtePre = false;
            }

            //ControlFlag = OwnerContext.ControlFlag;
            //ControlType = OwnerContext.ControlType;
            //ControlLevel = OwnerContext.ControlLevel;

            IsDirty = false;
        }


        [Command]
        public async void CreateOrUpdate()
        {
            ValidateAndSetErrorFocus(
                nameof(OptMaxTimeLastEstDays),
                nameof(OptLotStageWaferUseCalcualteOffset),
                nameof(OptLimitNoConsecutiveMaxAdjust),
                nameof(OptLimitLotsWithoutMetro),
                nameof(OptHydraAllowMissingDataNumber),
                nameof(OptPreLineAvgExpiredDay),
                nameof(OptUseTarget),
                nameof(OptLotStageWaferUseCalcualtePre),
                nameof(OptLotHoldRecommendedOOL),
                nameof(OptLotHoldPredicitonOOL),
                nameof(OptLotHoldMissingPreMet),
                nameof(OptHydraUseZoneMean),
                nameof(OptHydraUseWaferMean),
                nameof(OptHydraManualDataEntry),
                nameof(OptHydraFlag),
                nameof(OptAllowMissingPreMetro),
                nameof(OptHydraAllowMissingData),
                nameof(OptLimitMaxConsecutiveGof),
                nameof(OptLimitMaxConsecutiveOos),
                nameof(OptPreMetrologyExpiredDay));

            if (HasErrors)
            {
                return;
            }

            if (IsConfirmed(out var comment))
            {
                ShowWait();

                var newSettings = new ContextConstants
                {
                    ContextId = OwnerContext.ContextId,
                    ContextKey = OwnerContext.ContextKey,
                    OptAllowMissingPreMetro = OptAllowMissingPreMetro.Value,
                    OptHydraAllowMissingData = OptHydraAllowMissingData.Value,
                    OptHydraAllowMissingDataNumber = (double)OptHydraAllowMissingDataNumber,
                    OptHydraFlag = OptHydraFlag.Value,
                    OptHydraManualDataEntry = OptHydraManualDataEntry.Value,
                    OptHydraUseWaferMean = OptHydraUseWaferMean.Value,
                    OptHydraUseZoneMean = OptHydraUseZoneMean.Value,
                    OptLimitLotsWithoutMetro = OptLimitLotsWithoutMetro.Value,
                    OptLimitNoConsecutiveMaxAdjust = OptLimitNoConsecutiveMaxAdjust.Value,
                    OptLotHoldMissingPreMet = OptLotHoldMissingPreMet.Value,
                    OptLotHoldPredicitonOOL = OptLotHoldPredicitonOOL.Value,
                    OptLotHoldRecommendedOOL = OptLotHoldRecommendedOOL.Value,
                    OptLotStageWaferUseCalcualteOffset = (double)OptLotStageWaferUseCalcualteOffset,
                    OptLotStageWaferUseCalcualtePre = OptLotStageWaferUseCalcualtePre.Value,
                    OptMaxTimeLastEstDays = (double)OptMaxTimeLastEstDays,
                    OptUseTarget = OptUseTarget.Value,
                    OptPreLineAvgExpiredDay = (double)OptPreLineAvgExpiredDay,
                    OptPreMetrologyExpiredDay = (double)OptPreMetrologyExpiredDay,
                    OptLimitMaxConsecutiveOos = OptLimitMaxConsecutiveOos.Value,
                    OptLimitMaxConsecutiveGof = OptLimitMaxConsecutiveGof.Value,
                };

                if (Mode == FunctionMode.Add)
                {
                    await ContextService.CreateContextConstantsAsync(newSettings, OwnerContext.ContextId, comment);
                    IsDirty = false;
                    HideWait();
                    Messenger.Default.Send(new ContextChangedMessage() { ChangeType = ObjectChangeType.Updated, ContextId = OwnerContext.ContextId });
                    MessageBoxService.ShowMessage("Context Constants Created.", "Success", MessageButton.OK, MessageIcon.Information);
                }
                else
                {
                    await ContextService.UpdateContextConstantsAsync(newSettings, OwnerContext.ContextId, comment);
                    IsDirty = false;
                    HideWait();
                    Messenger.Default.Send(new ContextChangedMessage() { ChangeType = ObjectChangeType.Updated, ContextId = OwnerContext.ContextId });
                    MessageBoxService.ShowMessage("Context Constants Updated.", "Success", MessageButton.OK, MessageIcon.Information);
                }

                IsOK = true;
                CloseWindow();
            }
        }

        public bool CanCreateOrUpdate()
        {
            return IsDirty;
        }

        protected override string GetError(string columnName)
        {
            switch (columnName)
            {
                case nameof(OptMaxTimeLastEstDays):
                    return DataValidator.ValidateInOrder(
                        () => DataValidator.NotNull(OptMaxTimeLastEstDays),
                        () => DataValidator.LargerThanOrEqualTo(OptMaxTimeLastEstDays, 1));
                case nameof(OptLotStageWaferUseCalcualteOffset):
                    return DataValidator.NotNull(OptLotStageWaferUseCalcualteOffset);
                case nameof(OptLimitNoConsecutiveMaxAdjust):
                    return DataValidator.ValidateInOrder(
                        () => DataValidator.NotNull(OptLimitNoConsecutiveMaxAdjust),
                        () => DataValidator.InRange(OptLimitNoConsecutiveMaxAdjust, 1, 100));
                case nameof(OptLimitLotsWithoutMetro):
                    return DataValidator.ValidateInOrder(
                        () => DataValidator.NotNull(OptLimitLotsWithoutMetro),
                        () => DataValidator.LargerThanOrEqualTo(OptLimitLotsWithoutMetro, 1));
                case nameof(OptHydraAllowMissingDataNumber):
                    return DataValidator.ValidateInOrder(
                        () => DataValidator.NotNull(OptHydraAllowMissingDataNumber),
                        () => DataValidator.LargerThanOrEqualTo(OptHydraAllowMissingDataNumber, 1));
                case nameof(OptPreLineAvgExpiredDay):
                    return DataValidator.ValidateInOrder(
                        () => DataValidator.NotNull(OptPreLineAvgExpiredDay),
                        () => DataValidator.InRangeRightOpen(OptPreLineAvgExpiredDay, 0, 100));

                case nameof(OptUseTarget):
                    return DataValidator.NotNull(OptUseTarget);
                case nameof(OptLotStageWaferUseCalcualtePre):
                    return DataValidator.NotNull(OptLotStageWaferUseCalcualtePre);
                case nameof(OptLotHoldRecommendedOOL):
                    return DataValidator.NotNull(OptLotHoldRecommendedOOL);
                case nameof(OptLotHoldPredicitonOOL):
                    return DataValidator.NotNull(OptLotHoldPredicitonOOL);
                case nameof(OptLotHoldMissingPreMet):
                    return DataValidator.NotNull(OptLotHoldMissingPreMet);
                case nameof(OptHydraUseZoneMean):
                    return DataValidator.NotNull(OptHydraUseZoneMean);
                case nameof(OptHydraUseWaferMean):
                    return DataValidator.NotNull(OptHydraUseWaferMean);
                case nameof(OptHydraManualDataEntry):
                    return DataValidator.NotNull(OptHydraManualDataEntry);
                case nameof(OptHydraFlag):
                    return DataValidator.NotNull(OptHydraFlag);
                case nameof(OptAllowMissingPreMetro):
                    return DataValidator.NotNull(OptAllowMissingPreMetro);
                case nameof(OptHydraAllowMissingData):
                    return DataValidator.NotNull(OptHydraAllowMissingData);
                case nameof(OptLimitMaxConsecutiveGof):
                    return DataValidator.NotNull(OptLimitMaxConsecutiveGof);
                case nameof(OptLimitMaxConsecutiveOos):
                    return DataValidator.NotNull(OptLimitMaxConsecutiveOos);
                case nameof(OptPreMetrologyExpiredDay):
                    return DataValidator.ValidateInOrder(
                        () => DataValidator.NotNull(OptPreMetrologyExpiredDay),
                        () => DataValidator.InRangeRightOpen(OptPreMetrologyExpiredDay, 0, 100));
                default:
                    return null;
            }
        }

        #region Properties
        public Context OwnerContext { get; private set; }

        public ContextConstants OriginalSettings { get; private set; }

        public bool? OptUseTarget
        {
            get { return GetValue<bool?>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(OptUseTarget));
            }
        }
        public decimal? OptMaxTimeLastEstDays
        {
            get { return GetValue<decimal?>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(OptMaxTimeLastEstDays));
            }
        }
        public bool? OptLotStageWaferUseCalcualtePre
        {
            get { return GetValue<bool?>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(OptLotStageWaferUseCalcualtePre));
            }
        }
        public decimal? OptLotStageWaferUseCalcualteOffset
        {
            get { return GetValue<decimal?>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(OptLotStageWaferUseCalcualteOffset));
            }
        }
        public bool? OptLotHoldRecommendedOOL
        {
            get { return GetValue<bool?>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(OptLotHoldRecommendedOOL));
            }
        }
        public bool? OptLotHoldPredicitonOOL
        {
            get { return GetValue<bool?>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(OptLotHoldPredicitonOOL));
            }
        }
        public bool? OptLotHoldMissingPreMet
        {
            get { return GetValue<bool?>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(OptLotHoldMissingPreMet));
            }
        }
        public int? OptLimitNoConsecutiveMaxAdjust
        {
            get { return GetValue<int?>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(OptLimitNoConsecutiveMaxAdjust));
            }
        }
        public int? OptLimitLotsWithoutMetro
        {
            get { return GetValue<int?>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(OptLimitLotsWithoutMetro));
            }
        }
        public bool? OptHydraUseZoneMean
        {
            get { return GetValue<bool?>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(OptHydraUseZoneMean));
            }
        }
        public bool? OptHydraUseWaferMean
        {
            get { return GetValue<bool?>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(OptHydraUseWaferMean));
            }
        }
        public bool? OptHydraManualDataEntry
        {
            get { return GetValue<bool?>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(OptHydraManualDataEntry));
            }
        }
        public bool? OptHydraFlag
        {
            get { return GetValue<bool?>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(OptHydraFlag));
            }
        }
        public bool? OptAllowMissingPreMetro
        {
            get { return GetValue<bool?>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(OptAllowMissingPreMetro));
            }
        }
        public bool? OptHydraAllowMissingData
        {
            get { return GetValue<bool?>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(OptHydraAllowMissingData));
            }
        }
        public decimal? OptHydraAllowMissingDataNumber
        {
            get { return GetValue<decimal?>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(OptHydraAllowMissingDataNumber));
            }
        }
        public decimal? OptPreLineAvgExpiredDay
        {
            get { return GetValue<decimal?>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(OptPreLineAvgExpiredDay));
            }
        }
        public int? OptLimitMaxConsecutiveOos
        {
            get { return GetValue<int?>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(OptLimitMaxConsecutiveOos));
            }
        }
        public int? OptLimitMaxConsecutiveGof
        {
            get { return GetValue<int?>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(OptLimitMaxConsecutiveGof));
            }
        }
        public decimal? OptPreMetrologyExpiredDay
        {
            get { return GetValue<decimal?>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(OptPreMetrologyExpiredDay));
            }
        }

        public ControlFlag ControlFlag
        {
            get { return GetValue<ControlFlag>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(ControlFlag));
            }
        }

        public ControlLevel ControlLevel
        {
            get { return GetValue<ControlLevel>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(ControlLevel));
            }
        }

        public ControlType ControlType
        {
            get { return GetValue<ControlType>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(ControlType));
            }
        }



        #endregion
    }
}
