﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AMAT.R2R.Shared.Etch.DTO;
using Newtonsoft.Json;

namespace AMAT.R2R.Client.Etch.Modules.MaterializedViewSettings
{
    public class MaterializedViewModel : MaterializedView, INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;

        public void NotifyChanges()
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(ControlFlag)));
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(ControlLevel)));
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(ControlType)));
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(LastModifiedBy)));
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(LastModifiedTime)));
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Context)));
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(ThreadStatus)));
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(BookedPiLotId)));
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(MaterializeViewParameters)));
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(OnTargetEstimate)));
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(States)));
        }

        [JsonIgnore]
        public Context Context
        {
            get; set;
        }


    }
}
