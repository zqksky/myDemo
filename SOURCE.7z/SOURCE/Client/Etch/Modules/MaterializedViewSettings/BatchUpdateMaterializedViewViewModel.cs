﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data.Objects;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Documents;
using AMAT.R2R.Client.Common.Enums;
using AMAT.R2R.Client.Common.Helpers;
using AMAT.R2R.Client.Common.Messages;
using AMAT.R2R.Client.Common.Services;
using AMAT.R2R.Client.Common.ViewModels;
using AMAT.R2R.Client.Common.Views;
using AMAT.R2R.Client.Etch.Messages;
using AMAT.R2R.Shared.Base.DTO;
using AMAT.R2R.Shared.Etch.DTO;
using DevExpress.Mvvm;
using DevExpress.Mvvm.DataAnnotations;
using DevExpress.Mvvm.Native;
using DevExpress.Mvvm.POCO;
using DevExpress.Xpf.Bars;
using Newtonsoft.Json;

namespace AMAT.R2R.Client.Etch.Modules.MaterializedViewSettings
{
    public class BatchUpdateMaterializedViewViewModel : EtchViewModelBase
    {
        private const string NA = "NA";
        private readonly List<int> _originalContextIdList;

        public BatchUpdateMaterializedViewViewModel(List<MaterializedViewModel> materializedViewList)
        {
            if (materializedViewList is null)
            {
                throw new ArgumentNullException(nameof(materializedViewList));
            }


            _originalContextIdList = materializedViewList.Select(m => m.ContextId).ToList();

            MaterializedViewList = new ObservableCollection<MaterializedViewModel>(materializedViewList);

            WindowHeight = 500;
            WindowWidth = 1280;
            SizeToContent = System.Windows.SizeToContent.Manual;
            Mode = FunctionMode.Modify;
            Caption = "Batch Change/Reset MaterializedView";
        }

        public async Task RefreshList()
        {
            IsLoading = true;
            try
            {
                MaterializedViewList = new ObservableCollection<MaterializedViewModel>(await Task.WhenAll(_originalContextIdList.Select(id => MaterializedViewService.GetMaterializedViewAsync(id))));
            }
            finally
            {
                IsLoading = false;
            }
        }

        private void Initialize()
        {
            if (MaterializedViewList.Select(c => c.ControlFlag).Distinct().Count() > 1)
            {
                ControlFlag = null;
            }
            else
            {
                ControlFlag = MaterializedViewList.First().ControlFlag;
            }

            if (MaterializedViewList.Select(c => c.ControlType).Distinct().Count() > 1)
            {
                ControlType = null;
            }
            else
            {
                ControlType = MaterializedViewList.First().ControlType;
            }

            if (MaterializedViewList.Select(c => c.ControlLevel).Distinct().Count() > 1)
            {
                ControlLevel = null;
            }
            else
            {
                ControlLevel = MaterializedViewList.First().ControlLevel;
            }

            if (MaterializedViewList.Select(c => c.ThreadStatus).Distinct().Count() > 1)
            {
                Status = null;
            }
            else
            {
                Status = MaterializedViewList.First().ThreadStatus;
            }

            if (MaterializedViewList.Select(c => c.BookedPiLotId).Distinct().Count() > 1)
            {
                PiLotId = null;
            }
            else
            {
                PiLotId = MaterializedViewList.First().BookedPiLotId;
            }


            IsControlFlagChanged = false;
            IsControlLevelChanged = false;
            IsControlTypeChanged = false;
            IsThreadStatusChanged = false;
            IsPiLotIdChanged = false;
            IsDirty = false;
        }

        protected override void OnViewReadyAsync()
        {
            Initialize();
        }

        [Command]
        public async void UpdateMaterializedView(string fieldName)
        {
            if (fieldName == "ChangeStatus")
            {
                ValidateAndSetErrorFocus(nameof(PiLotId));
                if (HasErrors)
                {
                    return;
                }
            }

            List<MaterializedViewModel> failList = new List<MaterializedViewModel>();
            StringBuilder sb = new StringBuilder();
            // 
            if (IsConfirmed(out string comment))
            {
                ShowWait();

                foreach (var materializedView in MaterializedViewList)
                {
                    try
                    {
                        var context = await ContextService.GetContextAsync(materializedView.ContextId);
                        switch (fieldName)
                        {
                            case "ControlFlag":
                                context.ControlFlag = ControlFlag.Value;
                                await ContextService.UpdateContextAsync(context.ContextId, context, comment);
                                break;
                            case "ControlLevel":
                                context.ControlLevel = ControlLevel.Value;
                                await ContextService.UpdateContextAsync(context.ContextId, context, comment);
                                break;
                            case "ControlType":
                                context.ControlType = ControlType.Value;
                                await ContextService.UpdateContextAsync(context.ContextId, context, comment);
                                break;
                            case "ChangeStatus":
                                materializedView.ThreadStatus = Status.Value;
                                materializedView.BookedPiLotId = PiLotId;
                                await MaterializedViewService.ChangeStatus(materializedView, materializedView.ContextId, comment);
                                break;
                            case "ResetStatus":
                                await MaterializedViewService.ResetStatus(materializedView, materializedView.ContextId, comment);
                                break;
                            default:
                                break;
                        }
                    }
                    catch (Exception ex)
                    {
                        failList.Add(materializedView);
                        sb.AppendLine(LocalizationService.LocalizeException(ex));
                    }
                }

                HideWait();

                var successCount = MaterializedViewList.Count - failList.Count;

                if (successCount > 0)
                {
                    await RefreshList();
                    var successMaterializedViewList = MaterializedViewList.Except(failList);
                    foreach (var materializedView in successMaterializedViewList)
                    {
                        Messenger.Default.Send(new ContextChangedMessage() { ChangeType = ObjectChangeType.Updated, ContextId = materializedView.ContextId });
                    }
                }

                // show updated list.
                Initialize();
                // show error if any
                if (failList.Count <= 0)
                {
                    MessageBoxService.ShowMessage($"{successCount} updated successfully.", "Success", MessageButton.OK, MessageIcon.Information);
                }
                else if (successCount > 0)
                {
                    MessageBoxService.ShowMessage($"{successCount} updated successfully.\n{failList.Count} update failed.\n{sb}", $"Partial Success", MessageButton.OK, MessageIcon.Information);
                }
                else
                {
                    MessageBoxService.ShowMessage($"Update failed.\n{sb}", $"Error", MessageButton.OK, MessageIcon.Error);
                }
            }
        }

        public bool CanUpdateMaterializedView(string fieldName)
        {
            switch (fieldName)
            {
                case "ControlFlag":
                    return ControlFlag.HasValue && IsControlFlagChanged;
                case "ControlLevel":
                    return ControlLevel.HasValue && IsControlLevelChanged;
                case "ControlType":
                    return ControlType.HasValue && IsControlTypeChanged;
                case "ChangeStatus":
                    return Status != null && (IsPiLotIdChanged || IsThreadStatusChanged);
                case "ResetStatus":
                    return true;
                default:
                    return false;
            }
        }

        protected override string GetError(string columnName)
        {
            switch (columnName)
            {
                case nameof(PiLotId):
                    return DataValidator.ValidString(PiLotId, 40, false);
                default:
                    return null;
            }
        }

        #region Properties


        public ObservableCollection<MaterializedViewModel> MaterializedViewList
        {
            get { return GetValue<ObservableCollection<MaterializedViewModel>>(); }
            set { SetValue(value); }
        }

        public ControlFlag? ControlFlag
        {
            get { return GetValue<ControlFlag?>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                IsControlFlagChanged = true;
            }
        }

        public ControlType? ControlType
        {
            get { return GetValue<ControlType?>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                IsControlTypeChanged = true;
            }
        }
        public ControlLevel? ControlLevel
        {
            get { return GetValue<ControlLevel?>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                IsControlLevelChanged = true;
            }
        }
        public ThreadStatus? Status
        {
            get { return GetValue<ThreadStatus?>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                IsThreadStatusChanged = true;
            }
        }

        public string PiLotId
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(PiLotId));
                IsPiLotIdChanged = true;
            }
        }


        public bool IsControlFlagChanged
        {
            get { return GetValue<bool>(); }
            set { SetValue(value); }
        }

        public bool IsControlTypeChanged
        {
            get { return GetValue<bool>(); }
            set { SetValue(value); }
        }

        public bool IsControlLevelChanged
        {
            get { return GetValue<bool>(); }
            set { SetValue(value); }
        }

        public bool IsThreadStatusChanged
        {
            get { return GetValue<bool>(); }
            set { SetValue(value); }
        }

        public bool IsPiLotIdChanged
        {
            get { return GetValue<bool>(); }
            set { SetValue(value); }
        }




        #endregion
    }
}
