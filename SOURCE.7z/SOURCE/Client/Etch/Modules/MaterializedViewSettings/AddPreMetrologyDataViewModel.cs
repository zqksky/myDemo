﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Data.Objects;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Data;
using System.Windows.Documents;
using AMAT.R2R.Client.Common.Enums;
using AMAT.R2R.Client.Common.Helpers;
using AMAT.R2R.Client.Common.Messages;
using AMAT.R2R.Client.Common.Services;
using AMAT.R2R.Client.Common.ViewModels;
using AMAT.R2R.Client.Common.Views;
using AMAT.R2R.Client.Etch.Messages;
using AMAT.R2R.Shared.Base.DTO;
using AMAT.R2R.Shared.Etch.DTO;
using DevExpress.Mvvm;
using DevExpress.Mvvm.DataAnnotations;
using DevExpress.Mvvm.Native;
using DevExpress.Mvvm.POCO;
using DevExpress.Xpf.Bars;
using Newtonsoft.Json;

namespace AMAT.R2R.Client.Etch.Modules.MaterializedViewSettings
{
    public class AddPreMetrologyDataViewModel : EtchViewModelBase
    {
        private const string NA = "NA";

        public AddPreMetrologyDataViewModel(int processId)
        {
            if (processId <= 0)
            {
                throw new ArgumentNullException(nameof(processId));
            }

            ProcessId = processId;

            SizeToContent = System.Windows.SizeToContent.Manual;
            Mode = FunctionMode.Modify;
            Caption = "Add Manual PreMetrology Data";
            ManualPreMetrologyItemList = new ObservableCollection<ManualPreMetrologyItemExtend>();

            PropertyChanged += AddPreMetrologyDataViewModel_PropertyChanged;
        }

        private void AddPreMetrologyDataViewModel_PropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            if (e.PropertyName == nameof(SelectedMetrology))
            {
                UpdateFilteredItemList();
            }
        }

        protected override void OnViewReadyAsync()
        {
            _ = RefreshList();
        }

        public async Task RefreshList()
        {
            ShowWait();
            try
            {
                var manualPreMetrology = await ProcessService.GetManualPreMetrologyInfoAsync(ProcessId);


                PreMetrologyList = manualPreMetrology.ProcessPreMetrologys;
                SelectedMetrology = null;

                ManualPreMetrologyItemList = new ObservableCollection<ManualPreMetrologyItemExtend>(
                    manualPreMetrology.ManualPreMetrologyItems.Select(i => JsonConvert.DeserializeObject<ManualPreMetrologyItemExtend>(JsonConvert.SerializeObject(i))));

                FilteredItemList = ManualPreMetrologyItemList;

                ManualPreMetrologyItemList.CollectionChanged += ManualPreMetrologyItemList_CollectionChanged;

                MeasureItemList = await GlobalService.GetMetroParameterListAsync();

                MeasureItem = MeasureItemList.FirstOrDefault(m => m.ParameterName == MeasureItem?.ParameterName);

                QualityItemList = GlobalService.GetGOFItemList();

                IsDirty = false;
            }
            finally
            {
                HideWait();
            }
        }

        private void ManualPreMetrologyItemList_CollectionChanged(object sender, System.Collections.Specialized.NotifyCollectionChangedEventArgs e)
        {
            IsDirty = ManualPreMetrologyItemList.Any(i => i.IsDelete || i.IsAdd);

            UpdateFilteredItemList();
        }

        private void UpdateFilteredItemList()
        {
            if (SelectedMetrology != null)
            {
                FilteredItemList = new ObservableCollection<ManualPreMetrologyItemExtend>(ManualPreMetrologyItemList.Where(i => i.MetrologyKey == SelectedMetrology.MetrologyKey));
            }
            else
            {
                FilteredItemList = ManualPreMetrologyItemList;
            }
        }

        [Command]
        public void OpenAdd()
        {
            IsAddOpen = true;
            SetFocus(nameof(LotId));
        }

        [Command]
        public void CancelAdd()
        {
            IsAddOpen = false;
            LotId = null;
            WaferId = null;
            Unit = null;
            DcolTime = null;
            MeasureItem = null;
            MeasureValue = null;
            QualityItem = null;
            QualityValue = null;
        }

        [Command]
        public void Add()
        {
            ValidateAndSetErrorFocus(nameof(LotId), nameof(WaferId), nameof(Unit), nameof(DcolTime), nameof(MeasureItem), nameof(MeasureValue), nameof(QualityItem), nameof(QualityValue));

            if (HasErrors)
            {
                return;
            }

            var newItem = new ManualPreMetrologyItemExtend()
            {
                MetrologyKey = SelectedMetrology.MetrologyKey,
                LotId = LotId,
                WaferId = WaferId,
                Unit = Unit,
                DcollTime = DcolTime.Value,
                MeasureItem = MeasureItem.ParameterName,
                MeasureValue = (double)MeasureValue.Value,
                QualityItem = QualityItem,
                QualityValue = (double)QualityValue.Value,
                ProcessId = ProcessId,
                IsAdd = true
            };
            ManualPreMetrologyItemList.Add(newItem);
            //CancelAdd();
        }

        public bool CanAdd()
        {
            return SelectedMetrology != null;
        }

        [Command]
        public void Delete()
        {
            var toDeleteItemsList = SelectedItemList.ToList();
            foreach (var item in toDeleteItemsList)
            {
                if (item.IsAdd)
                {
                    ManualPreMetrologyItemList.Remove(item);
                }
                else
                {
                    item.IsDelete = true;
                }
            }
        }

        public bool CanDelete()
        {
            return SelectedItem != null && !SelectedItem.IsDelete;
        }

        [Command]
        public void Undelete()
        {
            foreach (var item in SelectedItemList.Where(i => i.IsDelete))
            {
                item.IsDelete = false;
            }
        }

        public bool CanUndelete()
        {
            return SelectedItem != null && SelectedItem.IsDelete;
        }

        [Command]
        public async void Refresh()
        {
            if (IsDirty)
            {

            }

            await RefreshList();
        }

        [Command]
        public async void Save()
        {
            var saveList = ManualPreMetrologyItemList.Where(i => i.IsAdd || i.IsDelete).ToList();
            List<ManualPreMetrologyItemExtend> failedList = new List<ManualPreMetrologyItemExtend>();
            StringBuilder sb = new StringBuilder();
            // 
            if (IsConfirmed(out string comment))
            {
                ShowWait();


                foreach (var item in saveList)
                {
                    try
                    {
                        if (item.IsDelete)
                        {
                            await ProcessService.DeleteManualPreMetrologyItemAsync(ProcessId, item.uniqueId, comment);
                        }
                        else
                        {
                            await ProcessService.AddManualPreMetrologyItemAsync(item, ProcessId, comment);
                        }
                    }
                    catch (Exception ex)
                    {
                        failedList.Add(item);
                        sb.AppendLine(LocalizationService.LocalizeException(ex));
                    }
                }

                HideWait();

                var successCount = saveList.Count - failedList.Count;

                if (successCount > 0)
                {
                    await RefreshList();
                }

                // restore failed item
                foreach (var item in failedList)
                {

                }

                // show error if any
                if (failedList.Count <= 0)
                {
                    MessageBoxService.ShowMessage($"{successCount} items saved successfully.", "Success", MessageButton.OK, MessageIcon.Information);
                }
                else if (successCount > 0)
                {
                    MessageBoxService.ShowMessage($"{successCount} items saved successfully.\n{failedList.Count} items save failed.\n{sb}", "Partial Success", MessageButton.OK, MessageIcon.Information);
                }
                else
                {
                    MessageBoxService.ShowMessage($"Save failed.\n{sb}", "Error", MessageButton.OK, MessageIcon.Error);
                }
            }
        }

        public bool CanSave()
        {
            return ManualPreMetrologyItemList.Any(i => i.IsDelete || i.IsAdd);
        }

        protected override string GetError(string columnName)
        {
            switch (columnName)
            {
                case nameof(LotId):
                    return DataValidator.ValidString(LotId);
                case nameof(WaferId):
                    return DataValidator.ValidString(WaferId);
                case nameof(Unit):
                    return DataValidator.ValidString(Unit);
                case nameof(DcolTime):
                    return DataValidator.NotNull(DcolTime);
                case nameof(MeasureItem):
                    return DataValidator.NotNull(MeasureItem);
                case nameof(MeasureValue):
                    return DataValidator.NotNull(MeasureValue);
                case nameof(QualityItem):
                    return DataValidator.NotNull(QualityItem);
                case nameof(QualityValue):
                    return DataValidator.NotNull(QualityValue);
                default:
                    return null;
            }
        }

        #region Properties
        public int ProcessId { get; }

        public bool IsAddOpen
        {
            get { return GetValue<bool>(); }
            set { SetValue(value); }
        }

        public List<PreMetrology> PreMetrologyList
        {
            get { return GetValue<List<PreMetrology>>(); }
            set { SetValue(value); }
        }

        public PreMetrology SelectedMetrology
        {
            get { return GetValue<PreMetrology>(); }
            set { SetValue(value); }
        }


        public ObservableCollection<ManualPreMetrologyItemExtend> ManualPreMetrologyItemList
        {
            get { return GetValue<ObservableCollection<ManualPreMetrologyItemExtend>>(); }
            set { SetValue(value); }
        }
        public ObservableCollection<ManualPreMetrologyItemExtend> FilteredItemList
        {
            get { return GetValue<ObservableCollection<ManualPreMetrologyItemExtend>>(); }
            set { SetValue(value); }
        }

        public ObservableCollection<ManualPreMetrologyItemExtend> SelectedItemList { get; } = new ObservableCollection<ManualPreMetrologyItemExtend>();

        public ManualPreMetrologyItemExtend SelectedItem
        {
            get { return GetValue<ManualPreMetrologyItemExtend>(); }
            set { SetValue(value); }
        }

        public List<Parameter> MeasureItemList
        {
            get { return GetValue<List<Parameter>>(); }
            set { SetValue(value); }
        }

        public List<string> QualityItemList
        {
            get { return GetValue<List<string>>(); }
            set { SetValue(value); }
        }

        public string LotId
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(LotId));
            }
        }

        public string Unit
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(Unit));
            }
        }
        public string WaferId
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(WaferId));
            }
        }
        public DateTime? DcolTime
        {
            get { return GetValue<DateTime?>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(DcolTime));
            }
        }

        public Parameter MeasureItem
        {
            get { return GetValue<Parameter>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(MeasureItem));
            }
        }

        public decimal? MeasureValue
        {
            get { return GetValue<decimal?>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(MeasureValue));
            }
        }
        public string QualityItem
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(QualityItem));
            }
        }
        public decimal? QualityValue
        {
            get { return GetValue<decimal?>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(QualityValue));
            }
        }

        #endregion
    }

    public class ManualPreMetrologyItemExtend : ManualPreMetrologyItem, INotifyPropertyChanged
    {
        public bool IsAdd { get; set; }


        bool _isDelete;
        public bool IsDelete
        {
            get
            {
                return _isDelete;
            }
            set
            {
                _isDelete = value;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(IsDelete)));
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;
    }
}
