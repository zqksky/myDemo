﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Threading.Tasks;
using AMAT.R2R.Client.Common.Enums;
using AMAT.R2R.Client.Common.Helpers;
using AMAT.R2R.Client.Common.Services;
using AMAT.R2R.Client.Etch.Messages;
using AMAT.R2R.Client.Etch.Modules.SpecialJobSettings;
using AMAT.R2R.Shared.Base.DTO;
using AMAT.R2R.Shared.Etch.DTO;
using DevExpress.Mvvm;
using DevExpress.Mvvm.DataAnnotations;
using DevExpress.Xpf.Core.HandleDecorator.Helpers;
using DevExpress.Xpf.Core.Native;
using DevExpress.Xpf.Data;

namespace AMAT.R2R.Client.Etch.Modules.MaterializedViewSettings
{
    public class MaterializedViewListViewModel : EtchViewModelBase
    {
        public const string Auth_MaterialView = "MaterialView";
        public const string Auth_MaterialView_CreateSpecialJob = "SpecialJob:Create";
        public const string Auth_MaterialView_AddPreMetrologyData = "MaterialView:AddPreMetrologyData";
        public const string Auth_MaterialView_Change = "MaterialView:Change";
        public const string Auth_MaterialView_ChamberOffset = "MaterialView:ChamberOffset";

        public MaterializedViewListViewModel()
        {
            Caption = "Materialized View Settings";
            Icon = "SvgImages/XAF/ModelEditor_Business_Object_Model.svg";
            PropertyChanged += OnPropertyChanged;
            Messenger.Default.Register<MaterializedViewChangedMessage>(this, OnMaterializedViewChanged);
            Messenger.Default.Register<ContextChangedMessage>(this, OnContextChanged);


            InitializePagedSource();
        }

        #region Filtering & Paging

        private void InitializePagedSource()
        {
            #region Paged Source
            var pagedSource = new PagedAsyncSource()
            {
                ElementType = typeof(MaterializedViewModel),
                KeyProperty = nameof(MaterializedViewModel.ContextId),
                PageSize = 100,
                PageNavigationMode = PageNavigationMode.ArbitraryWithTotalPageCount
            };

#if DEBUG
            pagedSource.PageSize = 10;
#endif

            pagedSource.FetchPage += (o, e) =>
            {
                e.Result = FetchPageRowsAsync(e);
            };

            pagedSource.GetTotalSummaries += (o, e) =>
            {
                e.Result = GetSummariesAsync(e);
            };

            pagedSource.GetUniqueValues += (o, e) =>
            {
                e.Result = GetValueListAsync(e);
            };

            pagedSource.PropertyChanged += (o, e) =>
            {
                if (e.PropertyName == nameof(PagedAsyncSource.AreRowsFetching))
                {
                    IsLoading = PagedSource.AreRowsFetching;

                    // restore selection.
                    if (!IsLoading)
                    {
                        if (_lastSelectedItem != null)
                        {
                            foreach (var item in PagedSource)
                            {
                                var view = item as MaterializedViewModel;
                                if (view.ContextId == _lastSelectedItem.ContextId)
                                {
                                    SelectedMaterializedView = view;
                                    break;
                                }
                            }
                        }
                    }
                }
            };

            PagedSource = pagedSource;
            #endregion
        }

        MaterializedViewModel _lastSelectedItem = null;
        private async Task<FetchRowsResult> FetchPageRowsAsync(FetchPageAsyncEventArgs e)
        {
            try
            {
                if (SelectedMaterializedView != null)
                {
                    _lastSelectedItem = SelectedMaterializedView;
                }

                var items = await MaterializedViewService.GetMaterializedViewListAsync(e.Filter.MakeFilters(), e.MakeSorters(), e.Skip, e.Take);
                return new FetchRowsResult(items.ToArray(), hasMoreRows: items.Count == e.Take);
            }
            catch (Exception ex)
            {
                Logger.Error(ex);
                throw;
            }
        }

        private async Task<object[]> GetSummariesAsync(GetSummariesAsyncEventArgs e)
        {
            try
            {
                var summary = await MaterializedViewService.GetMaterializedViewCount(e.Filter.MakeFilters());
                return e.Summaries.Select(x =>
                {
                    return x.SummaryType == SummaryType.Count ? (object)summary : throw new InvalidOperationException();
                }).ToArray();
            }
            catch (Exception ex)
            {
                Logger.Error(ex);
                throw;
            }
        }

        private async Task<object[]> GetValueListAsync(GetUniqueValuesAsyncEventArgs e)
        {
            try
            {
                if (e.PropertyName == nameof(MaterializedView.ControlFlag))
                {
                    var values = Enum.GetValues(typeof(ControlFlag)).Cast<object>().Select(f => f.ToString()).ToArray();
                    return await Task.Factory.StartNew(() => values);
                }
                else if (e.PropertyName == nameof(MaterializedView.ControlType))
                {
                    var values = Enum.GetValues(typeof(ControlType)).Cast<object>().Select(f => f.ToString()).ToArray();
                    return await Task.Factory.StartNew(() => values);
                }
                else if (e.PropertyName == nameof(MaterializedView.ControlLevel))
                {
                    var values = Enum.GetValues(typeof(ControlLevel)).Cast<object>().Select(f => f.ToString()).ToArray();
                    return await Task.Factory.StartNew(() => values);
                }
                else if (e.PropertyName == nameof(MaterializedView.ThreadStatus))
                {
                    var values = Enum.GetValues(typeof(ThreadStatus)).Cast<object>().Select(f => f.ToString()).ToArray();
                    return await Task.Factory.StartNew(() => values);
                }
                else if (e.PropertyName == nameof(MaterializedView.IsValid))
                {
                    var values = new object[] { true, false };
                    return await Task.Factory.StartNew(() => values);
                }
                else
                {
                    return await MaterializedViewService.GetMaterializedViewValueListAsync(e.PropertyName, e.Filter.MakeFilters());
                }
            }
            catch (Exception ex)
            {
                Logger.Error(ex);
                throw;
            }
        }

        #endregion

        #region Events

        protected override void OnViewReadyAsync()
        {
            //Refresh();
        }
        public override void OnRemoving(CancelEventArgs e)
        {
            base.OnRemoving(e);

            PagedSource?.Dispose();
            Messenger.Default.Unregister<ContextChangedMessage>(this, OnContextChanged);
            Messenger.Default.Unregister<MaterializedViewChangedMessage>(this, OnMaterializedViewChanged);
        }

        private async void OnPropertyChanged(object sender, System.ComponentModel.PropertyChangedEventArgs e)
        {
            if (e.PropertyName == nameof(SelectedMaterializedView))
            {
                if (SelectedMaterializedView == null)
                {
                    ClearDetails();
                }
                else
                {
                    if (SelectedMaterializedView.Context == null)
                    {
                        SelectedMaterializedView.Context = await ContextService.GetContextAsync(SelectedMaterializedView.ContextId);
                    }

                    await UpdateCurrentDetailPage();
                }
            }
            else if (e.PropertyName == nameof(SelectedDetailPageIndex))
            {
                await UpdateCurrentDetailPage();
            }
        }

        private async Task UpdateCurrentDetailPage()
        {
            switch (SelectedDetailPageIndex)
            {
                case 0:
                    try
                    {
                        MaterializedViewInputList?.Clear();
                        IsInputLoading = true;
                        if (SelectedMaterializedView != null)
                        {
                            var view = SelectedMaterializedView;
                            var list = await MaterializedViewService.GetMaterializedViewInputListAsync(view.ContextId);
                            list.ForEach(p => p.Index = $"Input {list.IndexOf(p) + 1}");

                            if (SelectedMaterializedView != null && SelectedMaterializedView.ContextId == view.ContextId)
                            {
                                MaterializedViewInputList = new ObservableCollection<MaterializeViewParameterExtend>(list);
                            }
                        }
                    }
                    finally
                    {
                        IsInputLoading = false;
                    }
                    break;
                case 1:
                    try
                    {
                        MaterializedViewRunHisList?.Clear();
                        IsRunHisLoading = true;
                        if (SelectedMaterializedView != null)
                        {
                            MaterializedViewRunHisList = new ObservableCollection<RunHist>(await MaterializedViewService.GetMaterializedViewRunHisListAsync(SelectedMaterializedView.ContextId));
                        }
                    }
                    finally
                    {
                        IsRunHisLoading = false;
                    }
                    break;
                case 2:
                    try
                    {
                        IsHistoryLoading = true;
                        HistoryList?.Clear();
                        if (SelectedMaterializedView != null)
                        {
                            HistoryList = new ObservableCollection<TransactionHistory>(await GlobalService.GetHistoryAsync(ClientInfo.LoginArea, "Context", SelectedMaterializedView.ContextKey, null));
                        }
                    }
                    finally
                    {
                        IsHistoryLoading = false;
                    }
                    break;
                default:
                    break;
            }
        }

        private void OnMaterializedViewChanged(MaterializedViewChangedMessage msg)
        {
            Refresh();
        }


        private void OnContextChanged(ContextChangedMessage msg)
        {
            Refresh();
        }

        private async Task UpdateSingleMaterializedView(MaterializedViewModel materializedView)
        {
            var lastModifiedTime = materializedView.LastModifiedTime;
            var newMaterializedView = await MaterializedViewService.GetMaterializedViewAsync(materializedView.ContextId);


            materializedView.ControlFlag = newMaterializedView.ControlFlag;
            materializedView.ControlLevel = newMaterializedView.ControlLevel;
            materializedView.ControlType = newMaterializedView.ControlType;
            materializedView.ThreadStatus = newMaterializedView.ThreadStatus;
            materializedView.BookedPiLotId = newMaterializedView.BookedPiLotId;
            materializedView.LastModifiedBy = newMaterializedView.LastModifiedBy;
            materializedView.LastModifiedTime = newMaterializedView.LastModifiedTime;
            materializedView.MaterializeViewParameters = newMaterializedView.MaterializeViewParameters;
            materializedView.States = newMaterializedView.States;
            materializedView.Context = await ContextService.GetContextAsync(SelectedMaterializedView.ContextId);
            materializedView.NotifyChanges();

            if (SelectedMaterializedView != null && materializedView.ContextId == SelectedMaterializedView.ContextId && lastModifiedTime != newMaterializedView.LastModifiedTime)
            {
                await UpdateCurrentDetailPage();
            }
        }
        #endregion

        #region Commands

        [Command]
        public void Refresh()
        {
            PagedSource.UpdateSummaries();
            PagedSource.RefreshRows();
        }

        public bool CanRefresh()
        {
            return !IsLoading;
        }

        [Command]
        public void AddPreMetrologyData()
        {
            ShowPopup("AddPreMetrologyData", new AddPreMetrologyDataViewModel(SelectedMaterializedView.ProcessId));
        }


        public bool CanAddPreMetrologyData()
        {
            return SelectedMaterializedView != null && SelectedMaterializedViewList.Count == 1 &&
                AuthorityManager.HasAuthority(Auth_MaterialView_AddPreMetrologyData);
        }

        [Command]
        public void ChangeChamberOffset()
        {
            ShowPopup("ChangeChamberOffset", new ChangeChamberOffsetViewModel());
        }

        public bool CanChangeChamberOffset()
        {
            return AuthorityManager.HasAuthority(Auth_MaterialView_ChamberOffset);
        }

        [Command]
        public async void BatchUpdate()
        {
            await UpdateBeforeAction();
            ShowPopup("BatchUpdateMaterializedView", new BatchUpdateMaterializedViewViewModel(SelectedMaterializedViewList.ToList()));
        }

        public bool CanBatchUpdate()
        {
            return SelectedMaterializedViewList != null && SelectedMaterializedViewList.Count > 0 && !IsLoading &&
                AuthorityManager.HasAuthority(Auth_MaterialView_Change);
        }

        private void ClearDetails()
        {
            _lastSelectedItem = null;
            HistoryList?.Clear();
            MaterializedViewInputList?.Clear();
            MaterializedViewRunHisList?.Clear();
        }

        [Command]
        public async void CreateSpecialJob()
        {
            await UpdateBeforeAction();
            ShowPopup("EditSpecialJob", new EditSpecialJobViewModel(SelectedMaterializedView.Context, new SpecialJob(), FunctionMode.Add));
        }

        public bool CanCreateSpecialJob()
        {
            return SelectedMaterializedView != null && SelectedMaterializedViewList.Count == 1 &&
                SelectedMaterializedView.Context != null &&
                SelectedMaterializedView.Context.ContextInputParas.Count > 0 && !IsLoading &&
                AuthorityManager.HasAuthority(Auth_MaterialView_CreateSpecialJob);
        }

        public async Task UpdateBeforeAction()
        {
            ShowWait();
            await Task.WhenAll(SelectedMaterializedViewList.Select(materializedView => UpdateSingleMaterializedView(materializedView)));
            HideWait();
        }

        #endregion

        #region Properties


        public PagedAsyncSource PagedSource
        {
            get { return GetValue<PagedAsyncSource>(); }
            set { SetValue(value); }
        }
        public bool IsInputLoading
        {
            get { return GetValue<bool>(); }
            set { SetValue(value); }
        }

        public bool IsRunHisLoading
        {
            get { return GetValue<bool>(); }
            set { SetValue(value); }
        }

        public ObservableCollection<MaterializedViewModel> MaterializedViewList
        {
            get { return GetValue<ObservableCollection<MaterializedViewModel>>(); }
            set { SetValue(value); }
        }

        public MaterializedViewModel SelectedMaterializedView
        {
            get { return GetValue<MaterializedViewModel>(); }
            set { SetValue(value); }
        }

        public ObservableCollection<MaterializedViewModel> SelectedMaterializedViewList { get; } = new ObservableCollection<MaterializedViewModel>();

        public int SelectedDetailPageIndex
        {
            get { return GetValue<int>(); }
            set { SetValue(value); }
        }


        public ObservableCollection<MaterializeViewParameterExtend> MaterializedViewInputList
        {
            get { return GetValue<ObservableCollection<MaterializeViewParameterExtend>>(); }
            set { SetValue(value); }
        }
        public ObservableCollection<RunHist> MaterializedViewRunHisList
        {
            get { return GetValue<ObservableCollection<RunHist>>(); }
            set { SetValue(value); }
        }


        public ObservableCollection<string> FabList
        {
            get { return GetValue<ObservableCollection<string>>(); }
            set { SetValue(value); }
        }

        public ObservableCollection<string> ProductList
        {
            get { return GetValue<ObservableCollection<string>>(); }
            set { SetValue(value); }
        }

        public ObservableCollection<string> RecipeList
        {
            get { return GetValue<ObservableCollection<string>>(); }
            set { SetValue(value); }
        }
        #endregion

    }

    public class MaterializeViewParameterExtend : MaterializeViewParameter
    {
        public string Index { get; set; }
    }
}
