﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Data.Objects;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Documents;
using AMAT.R2R.Client.Common.Enums;
using AMAT.R2R.Client.Common.Helpers;
using AMAT.R2R.Client.Common.Messages;
using AMAT.R2R.Client.Common.Services;
using AMAT.R2R.Client.Common.ViewModels;
using AMAT.R2R.Client.Common.Views;
using AMAT.R2R.Client.Etch.Messages;
using AMAT.R2R.Shared.Base.DTO;
using AMAT.R2R.Shared.Etch.DTO;
using DevExpress.Mvvm;
using DevExpress.Mvvm.DataAnnotations;
using DevExpress.Mvvm.Native;
using DevExpress.Mvvm.POCO;
using DevExpress.Xpf.Bars;
using Newtonsoft.Json;

namespace AMAT.R2R.Client.Etch.Modules.MaterializedViewSettings
{
    public class ChangeChamberOffsetViewModel : EtchViewModelBase
    {
        private const string NA = "NA";

        public ChangeChamberOffsetViewModel()
        {
            SizeToContent = System.Windows.SizeToContent.Manual;
            WindowWidth = 1200;
            WindowHeight = 600;
            Mode = FunctionMode.Modify;
            Caption = "Change Chamber Offset";

            PropertyChanged += ChangeChamberOffsetViewModel_PropertyChanged;
        }

        private async void ChangeChamberOffsetViewModel_PropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            if (e.PropertyName == nameof(SelectedOffset))
            {
                if (SelectedOffset != null)
                {
                    Offset = SelectedOffset.ParameterValue;
                    IsDirty = false;
                }
            }
            else if (e.PropertyName == nameof(SelectedTool))
            {
                ChamberList = SelectedTool?.Chambers;
            }
            else if (e.PropertyName == nameof(SelectedChamber))
            {
                ChamberOffsetItemList?.Clear();
                if (SelectedChamber != null)
                {
                    try
                    {
                        IsLoading = true;
                        ChamberOffsetItemList = new ObservableCollection<ChamberOffsetItem>(await MaterializedViewService.GetChamberOffsetList(SelectedTool.ToolId, SelectedChamber.ChamberId));
                    }
                    finally
                    {
                        IsLoading = false;
                    }
                }
            }
        }

        protected override void OnViewReadyAsync()
        {
            _ = RefreshList();
        }

        public async Task RefreshList()
        {
            ShowWait();
            try
            {
                var originalTool = SelectedTool?.ToolId;
                var originalChamber = SelectedChamber?.ChamberId;
                ToolList = await GlobalService.GetToolListAsync();
                if (originalTool != null)
                {
                    SelectedTool = ToolList.FirstOrDefault(t => t.ToolId == originalTool);
                }

                if (originalChamber != null)
                {
                    SelectedChamber = ChamberList.FirstOrDefault(c => c.ChamberId == originalChamber);
                }

                IsDirty = false;
            }
            finally
            {
                HideWait();
            }
        }

        [Command]
        public async void Delete()
        {
            if (IsConfirmed(out var comment))
            {
                var parameterName = SelectedOffset.ParameterName;
                await MaterializedViewService.DeleteChamberOffset(SelectedTool.ToolId, SelectedChamber.ChamberId, SelectedOffset.ParameterName, comment);
                await RefreshList();
                MessageBoxService.ShowMessage($"{parameterName} Offset deleted.", "Success", MessageButton.OK, MessageIcon.Information);
            }
        }

        public bool CanDelete()
        {
            return SelectedOffset != null;
        }

        [Command]
        public async void Update()
        {
            if (IsConfirmed(out var comment))
            {
                var parameterName = SelectedOffset.ParameterName;
                SelectedOffset.ParameterValue = Offset.Value;
                await MaterializedViewService.UpdateChamberOffset(SelectedOffset, SelectedTool.ToolId, SelectedChamber.ChamberId, SelectedOffset.ParameterName, comment);
                await RefreshList();
                MessageBoxService.ShowMessage($"{parameterName} Offset updated.", "Success", MessageButton.OK, MessageIcon.Information);
            }
        }

        public bool CanUpdate()
        {
            return SelectedOffset != null && Offset != null;
        }


        [Command]
        public async void Refresh()
        {
            if (IsDirty)
            {

            }

            await RefreshList();
        }


        protected override string GetError(string columnName)
        {
            switch (columnName)
            {
                case nameof(Offset):
                    return DataValidator.NotNull(Offset);
                default:
                    return null;
            }
        }

        #region Properties

        public List<Tool> ToolList
        {
            get { return GetValue<List<Tool>>(); }
            set { SetValue(value); }
        }
        public List<Chamber> ChamberList
        {
            get { return GetValue<List<Chamber>>(); }
            set { SetValue(value); }
        }

        public ObservableCollection<ChamberOffsetItem> ChamberOffsetItemList
        {
            get { return GetValue<ObservableCollection<ChamberOffsetItem>>(); }
            set { SetValue(value); }
        }

        public Tool SelectedTool
        {
            get { return GetValue<Tool>(); }
            set { SetValue(value); }
        }
        public Chamber SelectedChamber
        {
            get { return GetValue<Chamber>(); }
            set { SetValue(value); }
        }

        public ChamberOffsetItem SelectedOffset
        {
            get { return GetValue<ChamberOffsetItem>(); }
            set { SetValue(value); }
        }


        public decimal? Offset
        {
            get { return GetValue<decimal?>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(Offset));
            }
        }

        #endregion
    }

}
