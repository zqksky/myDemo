﻿using System;
using System.Collections.Generic;
using System.Dynamic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using AMAT.R2R.Client.Common.Extensions;
using AMAT.R2R.Client.Common.Helpers;
using AMAT.R2R.Client.Common.Services;
using AMAT.R2R.Shared.Etch.DTO;
using DevExpress.Mvvm;
using DevExpress.Xpf.Bars;
using DevExpress.Xpf.Grid;
using DevExpress.Xpf.Utils;

namespace AMAT.R2R.Client.Etch.Modules.RunHistory
{
    /// <summary>
    /// Interaction logic for LotRunHistoryList.xaml
    /// </summary>
    public partial class LotRunHistoryList : UserControl
    {
        public LotRunHistoryList()
        {
            InitializeComponent();
            CopyCellInfo = new DelegateCommand<object>(OnCopyCellInfo);
            //CopyRowInfo = new DelegateCommand<object>(OnCopyRowInfo);
            Loaded += LotRunHistoryList_Loaded;
            Unloaded += LotRunHistoryList_Unloaded;
            //masterGrid.MasterRowExpanding += MasterGrid_MasterRowExpanding;
            //masterGrid.MasterRowExpanded += MasterGrid_MasterRowExpanded;

            SetRangeFilterDefaultValue();
        }

        private void LotRunHistoryList_Unloaded(object sender, RoutedEventArgs e)
        {
            var viewModel = DataContext as LotRunHistoryListViewModel;
            if (viewModel != null)
            {
                viewModel.PropertyChanged -= ViewModel_PropertyChanged;
            }
        }

        private void LotRunHistoryList_Loaded(object sender, RoutedEventArgs e)
        {
            var viewModel = DataContext as LotRunHistoryListViewModel;
            if (viewModel != null)
            {
                viewModel.PropertyChanged += ViewModel_PropertyChanged;
            }
        }

        /// <summary>
        /// double click to expand master row.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void MasterView_RowDoubleClick(object sender, RowDoubleClickEventArgs e)
        {
            var rowHandle = e.HitInfo.RowHandle;
            //if (!masterGrid.IsMasterRowExpanded(rowHandle))
            //{
            //    masterGrid.ExpandMasterRow(rowHandle);
            //}
            //else
            //{
            //    masterGrid.CollapseMasterRow(rowHandle);
            //}
        }
        private void TreeListView_RowDoubleClick(object sender, RowDoubleClickEventArgs e)
        {
            var rowHandle = e.HitInfo.RowHandle;
            var treeListView = sender as TreeListView;
            //treeListView.CollapseNode(rowHandle);
            //var grid = treeListView.Parent as GridControl;
            //var row = grid.GetRow(rowHandle);
            //treeListView.ShowExpandButtons = true;
        }

        private void MasterGrid_MasterRowExpanded(object sender, RowEventArgs e)
        {
            if (DataContext is LotRunHistoryListViewModel viewModel)
            {
                viewModel.HideWait();
            }
        }

        private void MasterGrid_MasterRowExpanding(object sender, RowAllowEventArgs e)
        {
            if (DataContext is LotRunHistoryListViewModel viewModel)
            {
                viewModel.ShowWait();
            }
        }

        // https://supportcenter.devexpress.com/ticket/details/t522280/selection-of-row-overrides-the-back-colors-of-cells-in-gridcontrol

        private void MasterView_CustomCellAppearance(object sender, DevExpress.Xpf.Grid.CustomCellAppearanceEventArgs e)
        {
            e.Result = e.ConditionalValue;
            e.Handled = true;
        }

        public static readonly DependencyProperty CellMenuInfoProperty = DependencyPropertyManager.Register("CellMenuInfo", typeof(GridCellMenuInfo), typeof(LotRunHistoryList), new FrameworkPropertyMetadata(null));

        public ICommand CopyCellInfo { get; private set; }
        //public ICommand CopyRowInfo { get; private set; }

        public GridCellMenuInfo CellMenuInfo
        {
            get { return (GridCellMenuInfo)GetValue(CellMenuInfoProperty); }
            set { SetValue(CellMenuInfoProperty, value); }
        }


        private void TableView_ShowGridMenu(object sender, DevExpress.Xpf.Grid.GridMenuEventArgs e)
        {
            CellMenuInfo = e.MenuType == GridMenuType.RowCell ? (GridCellMenuInfo)e.MenuInfo : null;
        }

        void OnCopyCellInfo(object parameter)
        {
            if (parameter is GridCellMenuInfo menuInfo && menuInfo.Row != null)
            {
                string text = GetCellText(menuInfo.Row.RowHandle.Value, menuInfo.Column);
                SetClibboardText(text);
            }
        }

        //void OnCopyRowInfo(object parameter)
        //{
        //    if (parameter is int)
        //    {
        //        masterGrid.ClipboardCopyMode = ClipboardCopyMode.ExcludeHeader;
        //        masterGrid.CopyRowsToClipboard(new int[] { Convert.ToInt32(parameter) });
        //        masterGrid.ClipboardCopyMode = ClipboardCopyMode.IncludeHeader;
        //    }
        //}

        void SetClibboardText(string text)
        {
            try
            {
                Clipboard.SetText(text);
            }
            catch { }
        }

        string GetCellText(int rowHandle, ColumnBase column)
        {
            return Convert.ToString(((column.View as TreeListView).Parent as GridControl).GetCellValue(rowHandle, (GridColumn)column));
        }

        private void DetailGrid_ItemsSourceChanged(object sender, ItemsSourceChangedEventArgs e)
        {
            var detailGrid = sender as GridControl;

            var processValueBand = detailGrid.Bands.First(b => b.Name.Contains("processValueBand"));
            var estimateValueBand = detailGrid.Bands.First(b => b.Name.Contains("estimateValueBand"));
            var preMetroValueBand = detailGrid.Bands.First(b => b.Name.Contains("preMetroValueBand"));
            var postMetroValueBand = detailGrid.Bands.First(b => b.Name.Contains("postMetroValueBand"));
            var defaultRecSettingsValueBand = detailGrid.Bands.First(b => b.Name.Contains("defaultRecSettingsValueBand"));
            var recSettingsValueBand = detailGrid.Bands.First(b => b.Name.Contains("recSettingsValueBand"));
            var finalSettingsValueBand = detailGrid.Bands.First(b => b.Name.Contains("finalSettingsValueBand"));
            var chamberOffsetValueBand = detailGrid.Bands.First(b => b.Name.Contains("chamberOffsetValueBand"));

            if (processValueBand != null)
            {
                processValueBand.Columns.Clear();
            }
            if (estimateValueBand != null)
            {
                estimateValueBand.Columns.Clear();
            }
            if (preMetroValueBand != null)
            {
                preMetroValueBand.Columns.Clear();
            }
            if (postMetroValueBand != null)
            {
                postMetroValueBand.Columns.Clear();
            }
            if (defaultRecSettingsValueBand != null)
            {
                defaultRecSettingsValueBand.Columns.Clear();
            }
            if (recSettingsValueBand != null)
            {
                recSettingsValueBand.Columns.Clear();
            }
            if (finalSettingsValueBand != null)
            {
                finalSettingsValueBand.Columns.Clear();
            }
            if (chamberOffsetValueBand != null)
            {
                chamberOffsetValueBand.Columns.Clear();
            }

            var processColumns = new List<string>();
            var estimateColumns = new List<string>();
            var preMetroColumns = new List<string>();
            var postMetroColumns = new List<string>();
            var defaultRecSettingsColumns = new List<string>();
            var recSettingsColumns = new List<string>();
            var finalSettingsColumns = new List<string>();
            var chamberOffsetColumns = new List<string>();

            if (e.NewItemsSource is List<ExpandoObject> detailList && detailList.Count > 0)
            {
                foreach (var item in detailList)
                {
                    var dic = item as IDictionary<string, object>;
                    processColumns.AddRange(dic.Keys.Where(k => k.StartsWith("P_")));
                    estimateColumns.AddRange(dic.Keys.Where(k => k.StartsWith("E_")));
                    preMetroColumns.AddRange(dic.Keys.Where(k => k.StartsWith("M2_")));
                    postMetroColumns.AddRange(dic.Keys.Where(k => k.StartsWith("M1_")));
                    defaultRecSettingsColumns.AddRange(dic.Keys.Where(k => k.StartsWith("D_")));
                    recSettingsColumns.AddRange(dic.Keys.Where(k => k.StartsWith("R_")));
                    finalSettingsColumns.AddRange(dic.Keys.Where(k => k.StartsWith("F_")));
                    chamberOffsetColumns.AddRange(dic.Keys.Where(k => k.StartsWith("C_")));
                }

                processColumns = processColumns.Distinct().ToList();
                estimateColumns = estimateColumns.Distinct().ToList();
                preMetroColumns = preMetroColumns.Distinct().ToList();
                postMetroColumns = postMetroColumns.Distinct().ToList();
                defaultRecSettingsColumns = defaultRecSettingsColumns.Distinct().ToList();
                recSettingsColumns = recSettingsColumns.Distinct().ToList();
                finalSettingsColumns = finalSettingsColumns.Distinct().ToList();
                chamberOffsetColumns = chamberOffsetColumns.Distinct().ToList();

                processColumns.ForEach(name => processValueBand.Columns.Add(CreateDynamicColumn(name)));
                estimateColumns.ForEach(name => estimateValueBand.Columns.Add(CreateDynamicColumn(name)));
                preMetroColumns.ForEach(name => preMetroValueBand.Columns.Add(CreateDynamicColumn(name)));
                postMetroColumns.ForEach(name => postMetroValueBand.Columns.Add(CreateDynamicColumn(name)));
                defaultRecSettingsColumns.ForEach(name => defaultRecSettingsValueBand.Columns.Add(CreateDynamicColumn(name)));
                recSettingsColumns.ForEach(name => recSettingsValueBand.Columns.Add(CreateDynamicColumn(name)));
                finalSettingsColumns.ForEach(name => finalSettingsValueBand.Columns.Add(CreateDynamicColumn(name)));
                chamberOffsetColumns.ForEach(name => chamberOffsetValueBand.Columns.Add(CreateDynamicColumn(name)));

            }
        }

        private static GridColumn CreateDynamicColumn(string propertyName)
        {
            var splits = propertyName.SplitToList("_");
            var displayIndex = int.Parse(splits[1]);
            var realName = string.Join("_", splits.Skip(2));
            var newColumn = new GridColumn
            {
                Binding = new Binding(propertyName) { Mode = BindingMode.OneWay },
                Header = realName,
                VisibleIndex = displayIndex
            };
            return newColumn;
        }

        private void MasterGrid_ItemsSourceChanged(object sender, ItemsSourceChangedEventArgs e)
        {
            var masterGrid = sender as GridControl;

            //lastProcessValueBand.Columns.Clear();
            //lastEstimateValueBand.Columns.Clear();
            //lastOutputValueBand.Columns.Clear();


            //if (e.NewItemsSource is List<ExpandoObject> masterList && masterList.Count > 0)
            //{
            //    var firstObject = masterList.First();
            //    foreach (var propertyName in firstObject.Select(o => o.Key))
            //    {
            //        if (propertyName.Count(c => c == '_') != 2)
            //        {
            //            continue;
            //        }

            //        var splits = propertyName.SplitToList("_");
            //        var displayIndex = int.Parse(splits[1]);
            //        var realName = string.Join("_", splits.Skip(2));
            //        var newColumn = new GridColumn
            //        {
            //            Binding = new Binding(propertyName) { Mode = BindingMode.OneWay },
            //            Header = realName,
            //            VisibleIndex = displayIndex
            //        };

            //        if (lastProcessValueBand != null && propertyName.StartsWith("P_"))
            //        {
            //            lastProcessValueBand.Columns.Add(newColumn);
            //        }
            //        else if (lastEstimateValueBand != null && propertyName.StartsWith("E_"))
            //        {
            //            lastEstimateValueBand.Columns.Add(newColumn);
            //        }
            //        else if (lastOutputValueBand != null && propertyName.StartsWith("M1_"))
            //        {
            //            lastOutputValueBand.Columns.Add(newColumn);
            //        }
            //        else { }
            //    }
            //}

        }

        private async void BtnRefresh_Click(object sender, RoutedEventArgs e)
        {
            await Refresh();
        }

        private async Task Refresh()
        {
            var viewModel = DataContext as LotRunHistoryListViewModel;
            if (viewModel == null) return;

            var filters = new List<QueryFilter>();
            var sorters = new List<QuerySorter>();
            sorters.Add(new QuerySorter("UsedTimeStamp", System.ComponentModel.ListSortDirection.Descending));
            int? skip = null;
            int? take = null;
            if (lbeTool.SelectedItems != null && lbeTool.SelectedItems.Count > 0)
            {
                if (lbeTool.SelectedItems.Count > 1)
                {
                    filters.Add(new QueryFilter(nameof(LotRunHistory.Tool), lbeTool.SelectedItems.Select(o => o as string).ToArray(), QueryOperator.In));
                }
                else
                {
                    filters.Add(new QueryFilter(nameof(LotRunHistory.Tool), lbeTool.SelectedItems.First() as string, QueryOperator.Equals));
                }
            }

            if (lbeChamber.SelectedItems != null && lbeChamber.SelectedItems.Count > 0)
            {
                if (lbeChamber.SelectedItems.Count > 1)
                {
                    filters.Add(new QueryFilter(nameof(LotRunHistory.Chamber), lbeChamber.SelectedItems.Select(o => o as string).ToArray(), QueryOperator.In));
                }
                else
                {
                    filters.Add(new QueryFilter(nameof(LotRunHistory.Chamber), lbeChamber.SelectedItems.First() as string, QueryOperator.Equals));
                }
            }

            if (lbeProduct.SelectedItems != null && lbeProduct.SelectedItems.Count > 0)
            {
                if (lbeProduct.SelectedItems.Count > 1)
                {
                    filters.Add(new QueryFilter(nameof(LotRunHistory.ProductId), lbeProduct.SelectedItems.Select(o => o as string).ToArray(), QueryOperator.In));
                }
                else
                {
                    filters.Add(new QueryFilter(nameof(LotRunHistory.ProductId), lbeProduct.SelectedItems.First() as string, QueryOperator.Equals));
                }
            }


            if (lbeStage.SelectedItems != null && lbeStage.SelectedItems.Count > 0)
            {
                if (lbeStage.SelectedItems.Count > 1)
                {
                    filters.Add(new QueryFilter(nameof(LotRunHistory.Stage), lbeStage.SelectedItems.Select(o => o as string).ToArray(), QueryOperator.In));
                }
                else
                {
                    filters.Add(new QueryFilter(nameof(LotRunHistory.Stage), lbeStage.SelectedItems.First() as string, QueryOperator.Equals));
                }
            }

            if (lbeRecipe.SelectedItems != null && lbeRecipe.SelectedItems.Count > 0)
            {
                if (lbeRecipe.SelectedItems.Count > 1)
                {
                    filters.Add(new QueryFilter(nameof(LotRunHistory.Recipe), lbeRecipe.SelectedItems.Select(o => o as string).ToArray(), QueryOperator.In));
                }
                else
                {
                    filters.Add(new QueryFilter(nameof(LotRunHistory.Recipe), lbeRecipe.SelectedItems.First() as string, QueryOperator.Equals));
                }
            }

            if (!string.IsNullOrEmpty(teRootLot.Text))
            {
                filters.Add(new QueryFilter(nameof(LotRunHistory.LotId), teRootLot.Text, QueryOperator.Contains));
            }

            if (viewModel.IsTimeRangeMode)
            {
                if (deFromDate.EditValue != null && DateTime.TryParse(deFromDate.EditValue.ToString(), out var fromDate))
                {
                    filters.Add(new QueryFilter("UsedTimeStamp", deFromDate.DateTime, QueryOperator.GreaterThanOrEqualsTo));
                }
                else
                {
                    viewModel.MessageBoxService.ShowMessage("From Date must be provided!", "Invalid Filter!", MessageButton.OK, MessageIcon.Stop);
                    return;
                }

                if (deToDate.EditValue != null && DateTime.TryParse(deToDate.EditValue.ToString(), out var toDate))
                {
                    if (fromDate < toDate)
                    {
                        filters.Add(new QueryFilter("UsedTimeStamp", deToDate.DateTime, QueryOperator.LessThanOrEqualsTo));
                    }
                    else
                    {
                        viewModel.MessageBoxService.ShowMessage("To Date must be greater than From Date!", "Invalid Filter!", MessageButton.OK, MessageIcon.Stop);
                        return;
                    }
                }
                else
                {
                    viewModel.MessageBoxService.ShowMessage("To Date must be provided!", "Invalid Filter!", MessageButton.OK, MessageIcon.Stop);
                    return;
                }
            }
            else if (viewModel.IsLastNDayMode)
            {
                if (cbeLastNDay.EditValue != null && int.TryParse(cbeLastNDay.EditValue.ToString(), out var lastNDay))
                {
                    filters.Add(new QueryFilter("UsedTimeStamp", DateTime.Now.AddDays(0 - lastNDay), QueryOperator.GreaterThanOrEqualsTo));
                    filters.Add(new QueryFilter("UsedTimeStamp", DateTime.Now, QueryOperator.LessThanOrEqualsTo));
                }
                else
                {
                    viewModel.MessageBoxService.ShowMessage("Please input Last N Day!", "Invalid Filter!", MessageButton.OK, MessageIcon.Stop);
                    return;
                }
            }
            else if (viewModel.IsLastNRunMode)
            {
                if (cbeLastNRun.EditValue != null && int.TryParse(cbeLastNRun.EditValue.ToString(), out var lastNRun))
                {
                    skip = 0;
                    take = lastNRun;
                }
                else
                {
                    viewModel.MessageBoxService.ShowMessage("Please input Last N Run!", "Invalid Filter!", MessageButton.OK, MessageIcon.Stop);
                    return;
                }
            }

            await viewModel.RefreshAsync(filters, sorters, skip, take);
        }

        private void SetRangeFilterDefaultValue()
        {
            deFromDate.DateTime = DateTime.Now.AddDays(-7);
            deToDate.DateTime = DateTime.Now;
            cbeLastNDay.EditValue = 7;
            cbeLastNRun.EditValue = 200;
        }

        private async void BtnReset_Click(object sender, RoutedEventArgs e)
        {
            lbeTool.EditValue = null;
            lbeProduct.EditValue = null;
            lbeChamber.EditValue = null;
            lbeStage.EditValue = null;
            lbeRecipe.EditValue = null;
            teRootLot.EditValue = null;

            SetRangeFilterDefaultValue();

            if (DataContext is LotRunHistoryListViewModel viewModel)
            {
                await viewModel.ResetFilterValueListAsync();
            }
        }

        private async void ViewModel_PropertyChanged(object sender, System.ComponentModel.PropertyChangedEventArgs e)
        {
            if (DataContext is LotRunHistoryListViewModel viewModel)
            {
                if (e.PropertyName == nameof(LotRunHistoryListViewModel.ViewType))
                {
                    if (viewModel.ViewType == ViewType.ByTool)
                    {
                        viewModel.IsVisibleBasicTool = true;
                        viewModel.IsVisibleBasicRecipe = false;
                        viewModel.IsVisibleInfoTool = false;
                        viewModel.IsVisibleInfoRecipe = true;
                    }
                    else if (viewModel.ViewType == ViewType.ByRecipe)
                    {
                        viewModel.IsVisibleBasicTool = false;
                        viewModel.IsVisibleBasicRecipe = true;
                        viewModel.IsVisibleInfoTool = true;
                        viewModel.IsVisibleInfoRecipe = false;
                    }
                    else
                    {
                        viewModel.IsVisibleBasicTool = true;
                        viewModel.IsVisibleBasicRecipe = true;
                        viewModel.IsVisibleInfoTool = false;
                        viewModel.IsVisibleInfoRecipe = false;
                    }
                    await Refresh();
                }
            }
        }

        private void GridControl_CustomColumnDisplayText(object sender, CustomColumnDisplayTextEventArgs e)
        {
            if (DataContext is ExpandoObject row && e.Value is bool b)
            {
                e.DisplayText = b.ToString();
            }
        }

        private void Export_ItemClick(object sender, ItemClickEventArgs e)
        {
            DataAwareExportHelper.ExportToXlsx(detailView);
        }
    }
}
