﻿using System;
using System.Windows.Media.Imaging;
using DevExpress.Xpf.Core;

namespace AMAT.R2R.Client.Main
{
    public partial class MainWindow : ThemedWindow
    {
        public MainWindow()
        {
            InitializeComponent();
        }
    }
}
