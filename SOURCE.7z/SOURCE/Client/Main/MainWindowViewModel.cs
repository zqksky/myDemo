﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AMAT.R2R.Client.Common.Constants;
using AMAT.R2R.Client.Common.Helpers;
using AMAT.R2R.Client.Common.Messages;
using AMAT.R2R.Client.Common.Services;
using AMAT.R2R.Client.Main.Properties;
using DevExpress.Data.Helpers;
using DevExpress.Mvvm;
using DevExpress.Mvvm.DataAnnotations;
using DevExpress.Mvvm.ModuleInjection;
using DevExpress.Mvvm.POCO;

namespace AMAT.R2R.Client.Main
{
    [POCOViewModel]
    public class MainWindowViewModel
    {
        private const string ProductName = "Applied R2R Client";
        protected IModuleManager ModuleManager { get { return DevExpress.Mvvm.ModuleInjection.ModuleManager.DefaultManager; } }
        protected ISplashScreenManagerService SplashScreenManagerService { get { return this.GetService<ISplashScreenManagerService>("WaitIndicatorSplashScreenService"); } }

        public MainWindowViewModel()
        {
            if (this.IsInDesignMode())
            {
                return;
            }

            Messenger.Default.Register<LoginMessage>(this, OnUserLogin);
            Messenger.Default.Register<WaitMessage>(this, OnWaitMessage);
        }

        private void OnWaitMessage(WaitMessage waitMessage)
        {
            if (SplashScreenManagerService == null) return;

            if (waitMessage.WaitArea == "MainWindow" || waitMessage.Mode == WaitMode.HideAll)
            {
                if (waitMessage.Mode == WaitMode.Show)
                {
                    if (SplashScreenManagerService.ViewModel != null)
                    {
                        SplashScreenManagerService.ViewModel.Status = waitMessage.WaitText;
                    }
                    else
                    {
                        SplashScreenManagerService.ViewModel = new DXSplashScreenViewModel()
                        {
                            Status = waitMessage.WaitText,
                        };
                    }
                    SplashScreenManagerService.Show();
                }
                else
                {
                    SplashScreenManagerService.Close();
                }
            }
        }

        public virtual string Title { get; set; }

        private void OnUserLogin(LoginMessage loginMessage)
        {
            Title = $"{ProductName} - {loginMessage.LoginArea} Control";
        }
    }
}
