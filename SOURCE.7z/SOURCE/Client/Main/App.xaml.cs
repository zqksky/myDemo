﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Documents;
using AMAT.R2R.Client.Common.Constants;
using AMAT.R2R.Client.Common.Helpers;
using AMAT.R2R.Client.Common.Interfaces;
using AMAT.R2R.Client.Common.Services;
using AMAT.R2R.Client.Common.Views;
using AMAT.R2R.Client.Main.Properties;
using DevExpress.Mvvm;
using DevExpress.Mvvm.ModuleInjection;
using DevExpress.Mvvm.UI;
using DevExpress.Xpf.Core;
using Module = DevExpress.Mvvm.ModuleInjection.Module;

namespace AMAT.R2R.Client.Main
{
    public partial class App : Application
    {
        public App()
        {
            Common.Helpers.DispatcherHelper.Initialize();
            DispatcherUnhandledException += App_DispatcherUnhandledException;
            AppDomain.CurrentDomain.UnhandledException += CurrentDomain_UnhandledException;
            TaskScheduler.UnobservedTaskException += TaskScheduler_UnobservedTaskException;
            
            //Theme.RegisterPredefinedPaletteThemes();

            SplashScreenManager.CreateThemed(new DXSplashScreenViewModel
            {
                Copyright = "Copyright © 2021 Applied Materials Inc.\nAll rights reserved.",
                IsIndeterminate = true,
                Status = "Starting...",
                Title = "R2R Client",
                Logo = null,
                Subtitle = "Designed by Applied Materials"
            }
            ).ShowOnStartup();
            Logger.Trace("Application Started.");
        }

        IErrorHandler ErrorHandler { get { return ServiceContainer.Default.GetService<IErrorHandler>(); } }

        private void TaskScheduler_UnobservedTaskException(object sender, UnobservedTaskExceptionEventArgs e)
        {
            ErrorHandler.HandleError(e.Exception);
        }

        private void CurrentDomain_UnhandledException(object sender, UnhandledExceptionEventArgs e)
        {
            ErrorHandler.HandleError(e.ExceptionObject as Exception);
            Environment.Exit(1);
        }

        private void App_DispatcherUnhandledException(object sender, System.Windows.Threading.DispatcherUnhandledExceptionEventArgs e)
        {
            e.Handled = true;
            ErrorHandler.HandleError(e.Exception);
        }

        protected override void OnStartup(StartupEventArgs e)
        {
            base.OnStartup(e);

            ApplicationThemeHelper.UpdateApplicationThemeName();
            new Bootstrapper().Run();
        }
        protected override void OnExit(ExitEventArgs e)
        {
            ApplicationThemeHelper.SaveApplicationThemeName();
            base.OnExit(e);
        }
    }
    public class Bootstrapper
    {
        const string StateVersion = "1.0";
        public virtual void Run()
        {
            // initialize user info.
            ClientInfo.Initialize();
            ConfigureServices();
            ConfigureNavigation();

            InjectViews();
            ShowMainWindow();
        }

        private void InjectViews()
        {
            ModuleManager.RegisterOrInjectOrNavigate(RegionNames.Main, new Module(nameof(LoginView), LoginViewModel.Create, typeof(LoginView)));
        }

        private void ConfigureServices()
        {
            ServiceContainer.Default.RegisterService(new DispatcherHelperService());
            ServiceContainer.Default.RegisterService(new GlobalService());
            ServiceContainer.Default.RegisterService(new MessageBoxService());
            ServiceContainer.Default.RegisterService(new LocalizationService());
            ServiceContainer.Default.RegisterService(new ErrorHandler());
        }
        protected virtual void ConfigureNavigation()
        {
            ModuleManager.GetEvents(RegionNames.Main).Navigation += OnMainViewNavigation;
        }

        void OnMainViewNavigation(object sender, NavigationEventArgs e)
        {
            if (e.NewViewModelKey == null) return;
        }


        protected IModuleManager ModuleManager { get { return DevExpress.Mvvm.ModuleInjection.ModuleManager.DefaultManager; } }

        //protected virtual bool RestoreState()
        //{
        //    if (Settings.Default.StateVersion != StateVersion)
        //    {
        //        return false;
        //    }

        //    return ModuleManager.Restore(Settings.Default.LogicalState, Settings.Default.VisualState);
        //}

        protected virtual void ShowMainWindow()
        {
            Application.Current.MainWindow = new MainWindow();
            Application.Current.MainWindow.Show();
            Application.Current.MainWindow.Closing += OnClosing;
        }

        void OnClosing(object sender, CancelEventArgs e)
        {
            IMessageBoxService messageBoxService = ServiceContainer.Default.GetRequiredService<IMessageBoxService>();
            var result = messageBoxService.ShowMessage("Are your sure to Close R2R Client?", "Exit?", MessageButton.YesNo, MessageIcon.Question);

            if (result == MessageResult.No)
            {
                e.Cancel = true;
            }
            else
            {
                //ModuleManager.Clear(RegionNames.Documents);
                //ModuleManager.Save(out var logicalState, out var visualState);
                //Settings.Default.StateVersion = StateVersion;
                //Settings.Default.LogicalState = logicalState;
                //Settings.Default.VisualState = visualState;
                //Settings.Default.Save();
                Logger.Info("Application exited.");
            }
        }
    }
}
