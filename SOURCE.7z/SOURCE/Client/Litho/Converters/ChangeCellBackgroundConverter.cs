﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Data;
using System.Windows.Markup;
using System.Windows.Media;

namespace AMAT.R2R.Client.Litho.Converters
{
    public class ChangeCellBackgroundConverter : MarkupExtension, IMultiValueConverter
    {
        bool flag = false;
        public object Convert(object[] values, Type targetType, object parameter, CultureInfo culture)
        {
            if (values[1] == null)
            {
                values[1] = "";
            }
            if (values[2] == null)
            {
                values[2] = "";
            }
            if (!values[1].ToString().Equals(values[2].ToString()))
            {
                flag = true;
            }

            return flag ? Brushes.Yellow : DependencyProperty.UnsetValue;

        }
        public object[] ConvertBack(object value, Type[] targetTypes, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
        public override object ProvideValue(IServiceProvider serviceProvider)
        {
            return this;
        }
    }
}
