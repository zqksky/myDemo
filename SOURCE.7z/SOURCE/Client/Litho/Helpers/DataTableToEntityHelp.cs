﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using AMAT.R2R.Client.Litho.Modules.ToolSettings;
using Newtonsoft.Json;

namespace AMAT.R2R.Client.Litho.Helpers
{
    public class DataTableToEntityHelp
    {
        public static List<T> DatatableToEntity<T>(DataTable dt)
        {
            try
            {
                var res = JsonConvert.SerializeObject(dt);
                var result = JsonConvert.DeserializeObject<List<T>>(res);
                if (result.Count > 0)
                    return result;
                return default(List<T>);
            }
            catch (Exception e)
            {
                e = e.GetBaseException();
                return default(List<T>);
            }

        }

        public DataTable GetJsonToDataTable(string json)
        {
            List<ToolEntityModel> arrayList = JsonConvert.DeserializeObject<List<ToolEntityModel>>(json);
            if (arrayList.Count > 0)
            {
                DataTable dataTable = new DataTable();
                //循环类属性
                Type type = arrayList[0].GetType();
                PropertyInfo[] propertyInfos = type.GetProperties();
                foreach (var item in propertyInfos)
                {
                    dataTable.Columns.Add(item.Name);
                }
                //循环类属性值
                foreach (ToolEntityModel item in arrayList)
                {
                    DataRow dataRow = dataTable.NewRow();
                    foreach (PropertyInfo item1 in propertyInfos)
                    {
                        dataRow[item1.Name] = (item1.GetValue(item, null) == null ? "" : item1.GetValue(item, null)).ToString();
                    }
                    dataTable.Rows.Add(dataRow);
                }
                return dataTable;
            }
            return null;
        }

        public static DataTable EntitiesToDataTable<T>(List<T> entitys)
        {
            Type t = typeof(T);
            DataTable dt = new DataTable(t.Name);
            PropertyInfo[] pArray = t.GetProperties();


            Array.ForEach<PropertyInfo>(pArray, p =>
            {
                dt.Columns.Add(p.Name);
            });

            entitys.ForEach(item =>
            {
                var row = dt.NewRow();
                Array.ForEach<PropertyInfo>(pArray, p =>
                {
                    var value = t.GetProperty(p.Name).GetValue(item, null);
                    row[p.Name] = value;
                });
                dt.Rows.Add(row);
            });

            return dt;
        }

        /// <summary>
        /// 实体类转换成DataTable
        /// 调用示例：DataTable dt= FillDataTable(Entitylist.ToList());
        /// </summary>
        /// <param name="modelList">实体类列表</param>
        /// <returns></returns>
        public DataTable FillDataTable<T>(List<T> modelList)
        {
            if (modelList == null || modelList.Count == 0)
            {
                return null;
            }
            DataTable dt = CreateData(modelList[0]);//创建表结构

            foreach (T model in modelList)
            {
                DataRow dataRow = dt.NewRow();
                foreach (PropertyInfo propertyInfo in typeof(T).GetProperties())
                {
                    dataRow[propertyInfo.Name] = propertyInfo.GetValue(model, null);
                }
                dt.Rows.Add(dataRow);
            }
            return dt;
        }
        /// <summary>
        /// 根据实体类得到表结构
        /// </summary>
        /// <param name="model">实体类</param>
        /// <returns></returns>
        private DataTable CreateData<T>(T model)
        {
            DataTable dataTable = new DataTable(typeof(T).Name);
            foreach (PropertyInfo propertyInfo in typeof(T).GetProperties())
            {
                if (propertyInfo.Name != "CTimestamp")//些字段为oracle中的Timesstarmp类型
                {
                    dataTable.Columns.Add(new DataColumn(propertyInfo.Name, propertyInfo.PropertyType));
                }
                else
                {
                    dataTable.Columns.Add(new DataColumn(propertyInfo.Name, typeof(DateTime)));
                }
            }
            return dataTable;
        }

    }
}
