﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace AMAT.R2R.Client.Litho.Helpers
{
    public class CommonHelp
    {
        public static string GetMiddleStr(string sourse, string startstr, string endstr)
        {
            Regex rg = new Regex("(?<=(" + startstr + "))[.\\s\\S]*?(?=(" + endstr + "))", RegexOptions.Multiline | RegexOptions.Singleline);
            return rg.Match(sourse).Value;
        }

        public static bool IsDoubleValue(string str)
        {
            bool flag = false;
            flag = Regex.IsMatch(str, @"^[+-]?\d*[.]?\d*$");
            return flag;
        }
        public static bool IsPositiveDoubleValue(string str)
        {
            bool flag = false;
            flag = Regex.IsMatch(str, @"^\d*[.]?\d*$");
            return flag;
        }
        
        public static bool IsIntValue(string str)
        {
            bool flag = false;
            flag = Regex.IsMatch(str, @"^[+-]?\d*$");
            return flag;
        }
        public static bool IsPositiveIntValue(string str)
        {
            bool flag = false;
            flag = Regex.IsMatch(str, @"^\d*$");
            return flag;
        }

        public static List<string> StrCsvToList(string strCsv)
        {
            List<string> strList = new List<string>();

            if (string.IsNullOrEmpty(strCsv))
            {
                return strList;
            }


            strList = strCsv.Split(',').ToList();

            return strList;
        }

        public static void StrChuckCsvToList(string strCsv,ref List<string> listChuck1, ref List<string> listChuck2)
        {
            if (string.IsNullOrEmpty(strCsv))
            {
                return;
            }
            listChuck1 = new List<string>();
            listChuck2 = new List<string>();
            List<string> strList = new List<string>();
            strList = strCsv.Split(';').ToList();
            if (strList.Count > 1)
            {
                if (!string.IsNullOrEmpty(strList[0]))
                {
                    listChuck1 = strList[0].Split(',').ToList();
                }
                if (!string.IsNullOrEmpty(strList[1]))
                {
                    listChuck2 = strList[1].Split(',').ToList();
                }
            }
            else
            {
                listChuck1 = strList[0].Split(',').ToList();
                listChuck2 = strList[0].Split(',').ToList();
            }
        }

        public static double add(double? v1, decimal v2)
        {
            v1 = v1 == null ? 0.0 : v1;
            decimal b1 = decimal.Parse(v1.ToString());
            //decimal b2 = decimal.Parse(v2.ToString());
            return double.Parse((b1 + v2).ToString());
        }

        public static double sub(double? v1, decimal v2)
        {
            v1 = v1 == null ? 0.0:v1;

            decimal b1 = decimal.Parse(v1.ToString());
            //decimal b2 = decimal.Parse(v2.ToString());
            return double.Parse((b1 - v2).ToString());
        }
    }
}
