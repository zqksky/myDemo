﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using AMAT.R2R.Client.Common.Services;
using AMAT.R2R.Client.Litho.Constants;

namespace AMAT.R2R.Client.Litho.Helpers
{
    public class DataTableHelp
    {
        public static void ReplaceColumnValue(ref DataTable dt, string strColumn, string strOldValue, string strNewValue)
        {
            if (dt == null)
            {
                //MessageBox.Show("DataTable is null","Error");
                return ;
            }
            else
            {
                if (dt.Columns.Contains(strColumn))
                {
                    for (int i = 0; i < dt.Rows.Count; i++)
                    {
                        string str = dt.Rows[i][strColumn].ToString().ToLower();
                        if (str == strOldValue)
                        {
                            dt.Rows[i][strColumn] = strNewValue;
                        }
                    }
                }
            }
        }

        public static bool CheckDataTable(DataTable dt, int columnNumber, string[] strColumns, ref string strMsg)
        {
            if (dt == null)
            {
                strMsg = $"None data found";
                return true;
            }
            else
            {
                if (dt.Columns.Count != columnNumber)
                {
                    strMsg = @"Column number error";
                    return true;
                }

                foreach (var strColumn in strColumns)
                {
                    if (!dt.Columns.Contains(strColumn))
                    {
                        strMsg = strColumn + " not found";
                        return true;
                    }
                }
                return false;
            }
        }

        public static bool CheckKeyColumnFormat(DataTable dt, ref string strMsg)
        {
            bool flag = false;

            if (dt == null)
            {
                strMsg = $"None data found";
                return true;
            }
            else
            {
                if (dt.Columns.Contains("Product"))
                {
                    if (RegexFormatChecked(dt, "Product", RegexConst.ProductRegex))
                    {
                        strMsg = $"Product Contains invalid value";
                        return true;
                    }
                }
                if (dt.Columns.Contains("Layer"))
                {
                    if (RegexFormatChecked(dt, "Layer", RegexConst.LayerRegex))
                    {
                        strMsg = $"Layer Contains invalid value";
                        return true;
                    }
                }
                if (dt.Columns.Contains("Tool"))
                {
                    if (RegexFormatChecked(dt, "Tool", RegexConst.ToolRegex))
                    {
                        strMsg = $"Tool Contains invalid value";
                        return true;
                    }
                }
                if (dt.Columns.Contains("Reticle"))
                {
                    if (RegexFormatChecked(dt, "Reticle", RegexConst.ReticleRegex))
                    {
                        strMsg = $"Reticle Contains invalid value";
                        return true;
                    }
                }
                if (dt.Columns.Contains("Recipe"))
                {
                    if (RegexFormatChecked(dt, "Recipe", RegexConst.RecipeRegex))
                    {
                        strMsg = $"Recipe Contains invalid value";
                        return true;
                    }
                }
                if (dt.Columns.Contains("PreTool"))
                {
                    if (RegexFormatChecked(dt, "PreTool", RegexConst.PreToolRegex))
                    {
                        strMsg = $"PreTool Contains invalid value";
                        return true;
                    }
                }
                if (dt.Columns.Contains("PreReticle"))
                {
                    if (RegexFormatChecked(dt, "PreReticle", RegexConst.PreReticleRegex))
                    {
                        strMsg = $"PreReticle Contains invalid value";
                        return true;
                    }
                }
            }
            return flag;
        }
        public static bool ChecColumnRegexFormat(DataTable dt, string[] strColumns, string strRegex, ref string strMsg)
        {
            bool flag = false;

            if (dt == null)
            {
                strMsg = $"None data found";
                return true;
            }
            else
            {
                foreach (var strColumn in strColumns)
                {
                    if (dt.Columns.Contains(strColumn))
                    {
                        if (RegexFormatChecked(dt, strColumn, strRegex))
                        {
                            strMsg = $"Invalid value of " + strColumn;
                            return true;
                        }
                    }
                }
            }
            return flag;
        }

        public static bool RegexFormatChecked(DataTable dt, string strColumn, string regexFormat)
        {
            if (dt == null)
            {
                //MessageBox.Show("DataTable is null","Error");
                return true;
            }
            else
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    bool flag = Regex.IsMatch(dt.Rows[i][strColumn].ToString(), regexFormat);
                    if (!flag)
                    {
                        //MessageBox.Show(strColumn + " Contains Invalid values", "Error");
                        return true;
                    }
                }
                return false;
            }
        }
        public static bool RegexFormatChecked(DataTable dt, string strColumn, string regexFormat, bool EmptyFlag)
        {
            if (dt == null)
            {
                //MessageBox.Show("DataTable is null","Error");
                return true;
            }
            else
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    if (EmptyFlag)
                    {
                        if (string.IsNullOrEmpty(dt.Rows[i][strColumn].ToString()))
                        {
                            continue;
                        }
                    }
                    else
                    {
                        if (string.IsNullOrEmpty(dt.Rows[i][strColumn].ToString()))
                        {
                            return true;
                        }

                        bool flag = Regex.IsMatch(dt.Rows[i][strColumn].ToString(), regexFormat);
                        if (!flag)
                        {
                            //MessageBox.Show(strColumn + " Contains Invalid values", "Error");
                            return true;
                        }
                    }

                }
                return false;
            }
        }

        public static bool BoolColumnChecked(DataTable dt, string strColumn, bool EmptyFlag)
        {
            if (dt == null)
            {
                //MessageBox.Show("DataTable is null","Error");
                return true;
            }
            else
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    if (EmptyFlag)
                    {
                        if (string.IsNullOrEmpty(dt.Rows[i][strColumn].ToString()))
                        {
                            continue;
                        }
                    }
                    else
                    {
                        if (string.IsNullOrEmpty(dt.Rows[i][strColumn].ToString()))
                        {
                            return true;
                        }
                        else
                        {
                            string strValue = dt.Rows[i][strColumn].ToString().ToLower();
                            bool flag = Regex.IsMatch(strValue, @"^(true|false)$");
                            if (!flag)
                            {
                                //MessageBox.Show(strColumn + " Contains Invalid values", "Error");
                                return true;
                            }

                            //if (strValue.Equals("true") || strValue.Equals("false"))
                            //{

                            //}
                            //else
                            //{
                            //    return true;
                            //}
                        }
                    }                    
                }
                return false;
            }
        }

        public static bool IsContainsEmptyData(DataTable dt, string[] strColumns)
        {
            if (dt == null)
            {
                //MessageBox.Show("DataTable is null","Error");
                return true;
            }
            else
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    foreach (string strColumn in strColumns)
                    {
                        bool flag = Convert.IsDBNull(dt.Rows[i][strColumn]);
                        if (flag)
                        {
                            //MessageBox.Show(strColumn + " Contains null values", "Error");
                            return true;
                        }
                    }
                }
                return false;
            }
        }

        public static bool IsContainsDuplicateData(DataTable dt, string[] strColumnsKey)
        {
            if (dt == null)
            {
                //MessageBox.Show("DataTable is null", "Error");
                return true;
            }
            else
            {
                DataView myDataView = new DataView(dt);
                if (myDataView.ToTable(true, strColumnsKey).Rows.Count < dt.Rows.Count)
                {
                    //MessageBox.Show("The key is not unique", "Error");
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }      
    }
}
