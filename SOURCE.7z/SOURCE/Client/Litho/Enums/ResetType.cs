﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AMAT.R2R.Client.Litho.Enums
{
    public enum ResetType
    {
        None,
        CD,
        OVL
    }
}
