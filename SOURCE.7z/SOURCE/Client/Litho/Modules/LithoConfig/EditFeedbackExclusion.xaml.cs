﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace AMAT.R2R.Client.Litho.Modules.LithoConfig
{
    /// <summary>
    /// Interaction logic for EditFeedbackExclusion.xaml
    /// </summary>
    public partial class EditFeedbackExclusion : UserControl
    {
        public EditFeedbackExclusion()
        {
            InitializeComponent();
        }
        private void productTextEdit_Validate(object sender, DevExpress.Xpf.Editors.ValidationEventArgs e)
        {
            // e.Value - the processed input value
            if (e.Value == null) return;
            if (e.Value.ToString().Length == 5) return;
            // Set the e.IsValid property to 'false' if the input value is invalid
            e.IsValid = false;
            // Specifies the error icon type
            e.ErrorType = DevExpress.XtraEditors.DXErrorProvider.ErrorType.Default;
            // Specifies the error text
            e.ErrorContent = "Product must contain five symbols. Please correct.";
        }
    }
}
