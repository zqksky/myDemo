﻿using System;
using AMAT.R2R.Client.Common.Enums;
using AMAT.R2R.Client.Common.Helpers;
using AMAT.R2R.Client.Litho.Messages;
using AMAT.R2R.Shared.Litho.DTO;
using DevExpress.Mvvm;
using DevExpress.Mvvm.DataAnnotations;

namespace AMAT.R2R.Client.Litho.Modules.LithoConfig
{
    public class EditFEMViewModel : LithoViewModelBase
    {
        private const string NA = "NA";
        public EditFEMViewModel(ADVConfig fem, FunctionMode mode)
        {
            OriginalFEM = fem;
            SizeToContent = System.Windows.SizeToContent.WidthAndHeight;

            if (fem != null)
            {
                Item = fem.Item;
                Index = fem.Index;
                Value = fem.Value;
                Remark = fem.Remark;
                LastModifyUser = fem.LastModifyUser;
                LastModifyTime = fem.LastModifyTime;
            }
            else
            {

            }
            Mode = mode;

            switch (mode)
            {
                case FunctionMode.None:
                    break;
                case FunctionMode.Add:
                    Caption = "Create FEM ";
                    break;
                case FunctionMode.Copy:
                    Caption = "Copy FEM ";
                    break;
                case FunctionMode.Delete:
                    break;
                case FunctionMode.View:
                    break;
                default:
                    break;
            }
            IsDirty = false;

            PropertyChanged += OnPropertyChanged;
        }

        private void OnPropertyChanged(object sender, System.ComponentModel.PropertyChangedEventArgs e)
        {
            if (e.PropertyName == nameof(Item))
            {

            }
        }

        protected override void OnViewReadyAsync()
        {
            if (Mode == FunctionMode.Add)
            {
                SetFocus(nameof(Item));
            }
        }


        [Command]
        public async void Save()
        {
            ValidateAndSetErrorFocus(nameof(Index), nameof(Value));

            if (HasErrors)
            {
                return;
            }

            if (IsConfirmed(out string comment))
            {
                var newFEM = new ADVConfig
                {
                    Item = Item,
                    Index = Index.Value,
                    Value = Value,
                    Remark = Remark,
                    LastModifyUser = ClientInfo.UserName, //LastModifyUser,
                    LastModifyTime = DateTime.Now, //LastModifyTime,                        
                };

                //ShowWait();
                await LithoGlobalService.CreateFEMAsync(newFEM, comment);

                IsDirty = false;
                //HideWait();
                Messenger.Default.Send(new FEMChangedMessage() { ChangeType = ObjectChangeType.Created, key = newFEM.Item });
                MessageBoxService.ShowMessage($"FEM {newFEM.Item} is created!", "Success", MessageButton.OK, MessageIcon.Information);

                IsOK = true;
                CloseWindow();
            }
        }

        public bool CanSave()
        {
            switch (Mode)
            {
                case FunctionMode.Add:
                    return true;
                case FunctionMode.Modify:
                    return IsDirty;
                default:
                    return true;
            }
        }

        protected override string GetError(string columnName)
        {
            switch (columnName)
            {
                case nameof(Index):
                    return DataValidator.ValidString(Index.ToString());
                case nameof(Remark):
                    return DataValidator.ValidString(Remark);
                default:
                    return null;
            }
        }


        #region Properties
        public ADVConfig OriginalFEM { get; private set; }

        public string Item
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(Item));
            }
        }
        public int? Index
        {
            get { return GetValue<int?>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(Index));
            }
        }
        public string Value
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(Value));
            }
        }
        public string Remark
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(Remark));
            }
        }

        public string LastModifyUser
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(LastModifyUser));
            }
        }
        public DateTime LastModifyTime
        {
            get { return GetValue<DateTime>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(LastModifyTime));
            }
        }
        #endregion
    }
}
