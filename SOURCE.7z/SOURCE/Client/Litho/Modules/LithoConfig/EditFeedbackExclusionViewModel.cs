﻿using System;
using System.Collections.ObjectModel;
using AMAT.R2R.Client.Common.Enums;
using AMAT.R2R.Client.Common.Helpers;
using AMAT.R2R.Client.Litho.Messages;
using AMAT.R2R.Shared.Litho.DTO;
using DevExpress.Mvvm;
using DevExpress.Mvvm.DataAnnotations;

namespace AMAT.R2R.Client.Litho.Modules.LithoConfig
{
    public class EditFeedbackExclusionViewModel : LithoViewModelBase
    {
        private const string NA = "NA";
        public EditFeedbackExclusionViewModel(FBExclusionConfig fbExclusionConfig, FunctionMode mode)
        {
            OriginalFBExclusionConfig = fbExclusionConfig;
            SizeToContent = System.Windows.SizeToContent.WidthAndHeight;

            ProductList = new ObservableCollection<string>(LithoGlobalService.GetProductIdList());
            ExclusionTypeList = new ObservableCollection<string>() { "LotType", "LotHeader" };
            if (fbExclusionConfig != null)
            {
                Fab = fbExclusionConfig.Fab;
                Product = fbExclusionConfig.Product;
                ExclusionType = fbExclusionConfig.ExclusionType;
                Value = fbExclusionConfig.Value;
                Remark = fbExclusionConfig.Remark;
                LastModifyUser = fbExclusionConfig.LastModifyUser;
                LastModifyTime = fbExclusionConfig.LastModifyTime;

                if (ExclusionType == "LotType")
                {
                    LotTypeValue = fbExclusionConfig.Value;
                }
            }
            else
            {
                Fab = ClientInfo.LoginFab;

            }
            Mode = mode;

            switch (mode)
            {
                case FunctionMode.None:
                    break;
                case FunctionMode.Add:
                    Caption = "Create Feedback Exclusion ";
                    break;
                case FunctionMode.Copy:
                    Caption = "Copy Feedback Exclusion ";
                    break;
                case FunctionMode.Delete:
                    break;
                case FunctionMode.View:
                    break;
                default:
                    break;
            }
            IsDirty = false;

            PropertyChanged += OnPropertyChanged;
        }

        private void OnPropertyChanged(object sender, System.ComponentModel.PropertyChangedEventArgs e)
        {
            if (e.PropertyName == nameof(Value))
            {
                IsDirty = true;
            }
        }

        protected override void OnViewReadyAsync()
        {
            if (Mode == FunctionMode.Add)
            {
                SetFocus(nameof(Fab));
            }
        }


        [Command]
        public void ExclusionTypeSelectedIndexChanged()
        {
            if (!string.IsNullOrEmpty(ExclusionType) && ExclusionType == "LotType")
            {
                LotTypeValueList = new ObservableCollection<string>(LithoGlobalService.GetLotTypeList());
                //Value = "NA";
            }
            else
            {
                //LotTypeValue = "PROD";
                return;
            }
        }
        public bool CanExclusionTypeSelectedIndexChanged()
        {
            return true;
        }

        [Command]
        public async void Save()
        {
            if (!string.IsNullOrEmpty(ExclusionType) && ExclusionType =="LotType")
            {
                Value = "NA";
            }
            else
            {
                LotTypeValue = "NA";
            }
            ValidateAndSetErrorFocus(nameof(Fab), nameof(Value), nameof(LotTypeValue), nameof(Product), nameof(Remark), nameof(ExclusionType));

            if (HasErrors)
            {
                return;
            }

            if (IsConfirmed(out string comment))
            {
                var newFBExclusionConfig = new FBExclusionConfig
                {
                    Fab = Fab,
                    Product=Product,
                    ExclusionType = ExclusionType,
                    Value = Value,
                    Remark = Remark,
                    LastModifyUser = ClientInfo.UserName, //LastModifyUser,
                    LastModifyTime = DateTime.Now, //LastModifyTime,                        
                };
                if (ExclusionType == "LotType")
                {
                    newFBExclusionConfig.Value = LotTypeValue;
                }

                //ShowWait();
                await LithoGlobalService.CreateFBExclusionConfigAsync(newFBExclusionConfig, comment);

                IsDirty = false;
                //HideWait();
                Messenger.Default.Send(new FeedbackExclusionChangedMessage() { ChangeType = ObjectChangeType.Created, FBExclusionConfigKey = newFBExclusionConfig.Fab });
                MessageBoxService.ShowMessage($"Feedback Exclusion {newFBExclusionConfig.Fab} is created!", "Success", MessageButton.OK, MessageIcon.Information);


                IsOK = true;
                CloseWindow();
            }
        }

        public bool CanSave()
        {
            switch (Mode)
            {
                case FunctionMode.Add:
                    return true;
                case FunctionMode.Modify:
                    return IsDirty;
                default:
                    return true;
            }
        }

        protected override string GetError(string columnName)
        {
            switch (columnName)
            {
                case nameof(Fab):
                    return DataValidator.ValidString(Fab);
                case nameof(Product):
                    return DataValidator.ValidString(Product);
                case nameof(ExclusionType):
                    return DataValidator.ValidString(ExclusionType);
                case nameof(Value):
                    return DataValidator.ValidString(Value);
                case nameof(LotTypeValue):
                    return DataValidator.ValidString(LotTypeValue);
                case nameof(Remark):
                    return DataValidator.ValidString(Remark);
                default:
                    return null;
            }
        }


        #region Properties
        public FBExclusionConfig OriginalFBExclusionConfig { get; private set; }

        public string Fab
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(Fab));
            }
        }
        public string Product
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(Product));
            }
        }

        public string ExclusionType
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(ExclusionType));
            }
        }
        public string Value
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(Value));
            }
        }
        public string LotTypeValue
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(LotTypeValue));
            }
        }
        public string Remark
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(Remark));
            }
        }

        public string LastModifyUser
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(LastModifyUser));
            }
        }
        public DateTime LastModifyTime
        {
            get { return GetValue<DateTime>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(LastModifyTime));
            }
        }
        public ObservableCollection<string> ProductList
        {
            get { return GetValue<ObservableCollection<string>>(); }
            set { SetValue(value); }
        }
        public ObservableCollection<string> LotTypeValueList
        {
            get { return GetValue<ObservableCollection<string>>(); }
            set { SetValue(value); }
        }

        public ObservableCollection<string> ExclusionTypeList
        {
            get { return GetValue<ObservableCollection<string>>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(ExclusionTypeList));
            }
        }
        #endregion
    }
}
