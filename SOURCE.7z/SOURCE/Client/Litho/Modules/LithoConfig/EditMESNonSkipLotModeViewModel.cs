﻿using System.Collections.ObjectModel;
using AMAT.R2R.Client.Common.Enums;
using AMAT.R2R.Client.Common.Helpers;
using AMAT.R2R.Client.Litho.Messages;
using DevExpress.Mvvm;
using DevExpress.Mvvm.DataAnnotations;

namespace AMAT.R2R.Client.Litho.Modules.LithoConfig
{
    public class EditMESNonSkipLotModeViewModel : LithoViewModelBase
    {
        private const string NA = "NA";
        public EditMESNonSkipLotModeViewModel(string mesNonSkipLotMode, FunctionMode mode)
        {
            OriginalMESNonSkipLotMode = mesNonSkipLotMode;
            SizeToContent = System.Windows.SizeToContent.WidthAndHeight;

            if (mesNonSkipLotMode != null)
            {
                MESNonSkipLotModeList = new ObservableCollection<string>(LithoGlobalService.GetMESNonSkipLotModeList());
                MESNonSkipLotMode = mesNonSkipLotMode;
            }
            else
            {
                //Fab = ClientInfo.LoginFab;
                MESNonSkipLotModeList = new ObservableCollection<string>() {"None" , "PiLot", "AnyLot" };

            }
            Mode = mode;

            switch (mode)
            {
                case FunctionMode.None:
                    break;
                case FunctionMode.Add:
                    Caption = "Create MESNonSkipLotMode ";
                    break;
                case FunctionMode.Copy:
                    Caption = "Copy MESNonSkipLotMode ";
                    break;
                case FunctionMode.Modify:
                    Caption = "Edit MESNonSkipLotMode ";
                    break;
                case FunctionMode.Delete:
                    break;
                case FunctionMode.View:
                    break;
                default:
                    break;
            }
            IsDirty = false;

            PropertyChanged += OnPropertyChanged;
        }

        private void OnPropertyChanged(object sender, System.ComponentModel.PropertyChangedEventArgs e)
        {
            if (e.PropertyName == nameof(MESNonSkipLotMode))
            {

            }
        }

        protected override void OnViewReadyAsync()
        {
            if (Mode == FunctionMode.Add)
            {
                SetFocus(nameof(MESNonSkipLotMode));
            }
        }


        [Command]
        public async void Save()
        {
            ValidateAndSetErrorFocus(nameof(MESNonSkipLotMode));

            if (HasErrors)
            {
                return;
            }

            if (IsConfirmed(out string comment))
            {
                var newMESNonSkipLotMode = MESNonSkipLotMode;
                if (Mode == FunctionMode.Modify)
                {
                    //ShowWait();
                    await LithoGlobalService.ModifyMESNonSkipLotModeAsync(newMESNonSkipLotMode, comment);
                    IsDirty = false;
                    //HideWait();
                    Messenger.Default.Send(new MESNonSkipLotModeChangedMessage() { ChangeType = ObjectChangeType.Updated, key = OriginalMESNonSkipLotMode });
                    MessageBoxService.ShowMessage($"MESNonSkipLotMode {MESNonSkipLotMode} is updated!", "Success", MessageButton.OK, MessageIcon.Information);

                }

                IsOK = true;
                CloseWindow();
            }
        }

        public bool CanSave()
        {
            switch (Mode)
            {
                case FunctionMode.Add:
                    return true;
                case FunctionMode.Modify:
                    return IsDirty;
                default:
                    return true;
            }
        }

        protected override string GetError(string columnName)
        {
            switch (columnName)
            {
                case nameof(MESNonSkipLotMode):
                    return DataValidator.ValidString(MESNonSkipLotMode);
                default:
                    return null;
            }
        }


        #region Properties
        public string OriginalMESNonSkipLotMode { get; private set; }

        public string MESNonSkipLotMode
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(MESNonSkipLotMode));
            }
        }
        public ObservableCollection<string> MESNonSkipLotModeList
        {
            get { return GetValue<ObservableCollection<string>>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(MESNonSkipLotModeList));
            }
        }
        #endregion
    }
}
