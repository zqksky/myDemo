﻿using System.Collections.ObjectModel;
using System.Linq;
using System.Threading.Tasks;
using AMAT.R2R.Client.Common.Enums;
using AMAT.R2R.Client.Litho.Messages;
using AMAT.R2R.Shared.Litho.DTO;
using DevExpress.Mvvm;
using DevExpress.Mvvm.DataAnnotations;

namespace AMAT.R2R.Client.Litho.Modules.LithoConfig
{
    public class LithoConfigMainViewModel : LithoViewModelBase
    {
        public const string Auth_Global = "GlobalSettings";
        public const string Auth_FeedbackExclusion = "GlobalSettings:FeedbackExclusion";
        public const string Auth_FeedbackExclusion_Add = "GlobalSettings:FeedbackExclusion:Add";
        public const string Auth_FeedbackExclusion_Copy = "GlobalSettings:FeedbackExclusion:Copy";
        public const string Auth_FeedbackExclusion_Edit = "GlobalSettings:FeedbackExclusion:Edit";
        public const string Auth_FeedbackExclusion_Delete = "GlobalSettings:FeedbackExclusion:Delete";

        public const string Auth_FEM = "GlobalSettings:FEM";
        public const string Auth_FEM_Add = "GlobalSettings:FEM:Add";
        public const string Auth_FEM_Copy = "GlobalSettings:FEM:Copy";
        public const string Auth_FEM_Edit = "GlobalSettings:FEM:Edit";
        public const string Auth_FEM_Delete = "GlobalSettings:FEM:Delete";

        public const string Auth_LithoConfig = "GlobalSettings:LithoConfig";

        public LithoConfigMainViewModel()
        {
            Caption = "Config Settings";
            Icon = "SvgImages/Outlook Inspired/ShipmentReceived.svg";

            Messenger.Default.Register<MESNonSkipLotModeChangedMessage>(this, OnMESNonSkipLotModeChanged);
            Messenger.Default.Register<FeedbackExclusionChangedMessage>(this, OnFeedbackExclusionChanged);
            Messenger.Default.Register<FEMChangedMessage>(this, OnFEMChanged);
            

        }
        protected override void OnViewReadyAsync()
        {
            Refresh();
        }

        private async void OnMESNonSkipLotModeChanged(MESNonSkipLotModeChangedMessage msg)
        {
            switch (msg.ChangeType)
            {
                case ObjectChangeType.Updated:
                    await UpdateMESNonSkipLotMode();
                    break;
                default:
                    break;

            }
        }
        private async Task UpdateMESNonSkipLotMode()
        {
            var newMESNonSkipLotMode = await LithoGlobalService.GetMESNonSkipLotModeAsync();

            MESNonSkipLotMode = newMESNonSkipLotMode;
        }

        private async void OnFeedbackExclusionChanged(FeedbackExclusionChangedMessage msg)
        {
            var fbExclusionConfigy = FBExclusionConfigList.FirstOrDefault(p => p.Fab == msg.FBExclusionConfigKey);
            switch (msg.ChangeType)
            {
                case ObjectChangeType.Created:
                    Refresh();
                    break;
                case ObjectChangeType.Deleted:
                    FBExclusionConfigList.Remove(fbExclusionConfigy);
                    break;
                case ObjectChangeType.Updated:
                    await UpdateSingleFeedbackExclusion(fbExclusionConfigy);
                    break;
                default:
                    break;

            }
        }

        private async Task UpdateSingleFeedbackExclusion(FBExclusionConfigModel fbExclusionConfig)
        {
            var newFBExclusionConfig = await LithoGlobalService.GetFBExclusionConfigAsync(fbExclusionConfig.Fab);

            fbExclusionConfig.LastModifyUser = newFBExclusionConfig.LastModifyUser;
            fbExclusionConfig.LastModifyTime = newFBExclusionConfig.LastModifyTime;
            fbExclusionConfig.Fab = newFBExclusionConfig.Fab;
            fbExclusionConfig.Product = newFBExclusionConfig.Product;
            fbExclusionConfig.ExclusionType = newFBExclusionConfig.ExclusionType;
            fbExclusionConfig.Value = newFBExclusionConfig.Value;
            fbExclusionConfig.Remark = newFBExclusionConfig.Remark;

            fbExclusionConfig.NotifyChanges();
        }

        private async void OnFEMChanged(FEMChangedMessage msg)
        {
            var fem = FEMList.FirstOrDefault(p => p.Item == msg.key);
            switch (msg.ChangeType)
            {
                case ObjectChangeType.Created:
                    Refresh();
                    break;
                case ObjectChangeType.Deleted:
                    FEMList.Remove(fem);
                    break;
                case ObjectChangeType.Updated:
                    await UpdateSingleFEM(fem);
                    break;
                default:
                    break;

            }
        }

        private async Task UpdateSingleFEM(FEMEntityModel fem)
        {
            var newFEM = await LithoGlobalService.GetFEMAsync(fem.Item);

            fem.LastModifyUser = newFEM.LastModifyUser;
            fem.LastModifyTime = newFEM.LastModifyTime;
            fem.Item= newFEM.Item;
            fem.Index = newFEM.Index;
            fem.Value = newFEM.Value;
            fem.Remark = newFEM.Remark;

            fem.NotifyChanges();
        }

        #region Commands
        [Command]
        public async void Refresh()
        {
            try
            {
                IsLoading = true;
                RefreshMESNonSkipLotMode();
                RefreshFBExclusionConfig();
                RefreshFEM();
            }
            finally
            {
                IsLoading = false;
            }
        }
        public async void RefreshMESNonSkipLotMode()
        {
            try
            {
                MESNonSkipLotMode = await LithoGlobalService.GetMESNonSkipLotModeAsync();
            }
            finally
            {

            }
        }
        public async void RefreshFBExclusionConfig()
        {
            try
            {
                var preSelectedFeedbackExclusion = SelectedFBExclusionConfig;
                var fbExclusionConfigList = await LithoGlobalService.GetFBExclusionConfigListAsync();
                //var fbExclusionConfigList = await LithoGlobalService.GetFBExclusionConfigListAsync(new QueryParameter("fab", ClientInfo.LoginFab));
                FBExclusionConfigList = new ObservableCollection<FBExclusionConfigModel>(fbExclusionConfigList);

                if (preSelectedFeedbackExclusion != null)
                {
                    SelectedFBExclusionConfig = fbExclusionConfigList.FirstOrDefault(p => p.Fab == preSelectedFeedbackExclusion.Fab);
                }
            }
            finally
            {

            }
        }
        public async void RefreshFEM()
        {
            try
            {
                var preSelectedFEM = SelectedFEM;
                var femList = await LithoGlobalService.GetFEMListAsync();
                //var femList = await LithoGlobalService.GetFEMListAsync(new QueryParameter("fab", ClientInfo.LoginFab));
                FEMList = new ObservableCollection<FEMEntityModel>(femList);

                if (preSelectedFEM != null)
                {
                    SelectedFEM = femList.FirstOrDefault(p => p.Item == preSelectedFEM.Item);
                }
            }
            finally
            {

            }
        }
        public bool CanRefresh()
        {
            return !IsLoading;
        }

        [Command]
        public void ModifyMESNonSkipLotMode()
        {
            ShowEditMESNonSkipLotMode(MESNonSkipLotMode, FunctionMode.Modify);
        }

        private void ShowEditMESNonSkipLotMode(string mesNonSkipLotMode, FunctionMode mode)
        {
            if (ShowPopup("EditMESNonSkipLotMode", new EditMESNonSkipLotModeViewModel(mesNonSkipLotMode, mode)).IsOK)
            {
                RefreshMESNonSkipLotMode();
            }
        }

        [Command]
        public void AddFeedbackExclusion()
        {
            ShowEditFeedbackExclusion(null, FunctionMode.Add);
        }

        public bool CanAddFeedbackExclusion()
        {
            return true;
            //return AuthorityManager.HasAuthority(Auth_FeedbackExclusion_Add);
        }

        [Command]
        public void CopyFeedbackExclusion()
        {
            ShowEditFeedbackExclusion(SelectedFBExclusionConfig, FunctionMode.Copy);
        }

        public bool CanCopyFeedbackExclusion()
        {
            return SelectedFBExclusionConfig != null && SelectedFeedbackExclusionList.Count == 1 && !IsLoading;// && AuthorityManager.HasAuthority(Auth_FeedbackExclusion_Copy);
        }

        [Command]
        public void ModifyFeedbackExclusion()
        {
            ShowEditFeedbackExclusion(SelectedFBExclusionConfig, FunctionMode.Modify);
        }

        public bool CanModifyFeedbackExclusion()
        {
            return SelectedFBExclusionConfig != null && SelectedFeedbackExclusionList.Count == 1 && !IsLoading;// && AuthorityManager.HasAuthority(Auth_FeedbackExclusion_Edit);
        }

        private void ShowEditFeedbackExclusion(FBExclusionConfig originalFeedbackExclusion, FunctionMode mode)
        {
            if (ShowPopup("EditFeedbackExclusion", new EditFeedbackExclusionViewModel(originalFeedbackExclusion, mode)).IsOK)
            {
                RefreshFBExclusionConfig();
            }
        }

        [Command]
        public async void DeleteFeedbackExclusion()
        {
            if (IsConfirmed(out var comment))
            {
                var toDeleteFeedbackExclusion = SelectedFBExclusionConfig;
                if (SelectedFBExclusionConfig == null)
                {
                    return;
                }
                string key = SelectedFBExclusionConfig.Fab + ":" + SelectedFBExclusionConfig.Product + ":" + SelectedFBExclusionConfig.ExclusionType + ":" + SelectedFBExclusionConfig.Value;
                await LithoGlobalService.DeleteFBExclusionConfigAsync(key, comment);
                Refresh();
                Messenger.Default.Send(new FeedbackExclusionChangedMessage() { ChangeType = ObjectChangeType.Deleted, FBExclusionConfigKey = SelectedFBExclusionConfig.Fab });
                MessageBoxService.ShowMessage($"FeedbackExclusion {key} is deleted.", "Success", MessageButton.OK, MessageIcon.Information);
            }
        }

        public bool CanDeleteFeedbackExclusion()
        {
            return SelectedFBExclusionConfig != null && SelectedFeedbackExclusionList.Count == 1 && !IsLoading;// && AuthorityManager.HasAuthority(Auth_FeedbackExclusion_Delete);
        }

        [Command]
        public void AddFEM()
        {
            ShowEditFEM(null, FunctionMode.Add);
        }

        public bool CanAddFEM()
        {
            return true;
            //return AuthorityManager.HasAuthority(Auth_FEM_Add);
        }
        private void ShowEditFEM(ADVConfig originalFEM, FunctionMode mode)
        {
            if (ShowPopup("EditFEM", new EditFEMViewModel(originalFEM, mode)).IsOK)
            {
                RefreshFEM();
            }
        }
        [Command]
        public void CopyFEM()
        {
            ShowEditFEM(SelectedFEM, FunctionMode.Copy);
        }

        public bool CanCopyFEM()
        {
            return SelectedFEM != null && SelectedFEMList.Count == 1 && !IsLoading;// && AuthorityManager.HasAuthority(Auth_FEM_Copy);
        }

        [Command]
        public async void DeleteFEM()
        {
            if (IsConfirmed(out var comment))
            {
                var toDeleteFEM = SelectedFEM;
                await LithoGlobalService.DeleteFEMAsync(SelectedFEM.Value, comment);
                Refresh();
                Messenger.Default.Send(new FEMChangedMessage() { ChangeType = ObjectChangeType.Deleted, key = SelectedFEM.Value });
                MessageBoxService.ShowMessage($"FEM {toDeleteFEM.Value} is deleted.", "Success", MessageButton.OK, MessageIcon.Information);
            }
        }

        public bool CanDeleteFEM()
        {
            return SelectedFEM != null && SelectedFEMList.Count == 1 && !IsLoading;// && AuthorityManager.HasAuthority(Auth_FEM_Delete);
        }
        #endregion

        #region Properties
        public ObservableCollection<FBExclusionConfigModel> FBExclusionConfigList
        {
            get { return GetValue<ObservableCollection<FBExclusionConfigModel>>(); }
            set { SetValue(value); }
        }

        public ObservableCollection<FBExclusionConfig> SelectedFeedbackExclusionList { get; } = new ObservableCollection<FBExclusionConfig>();

        public FBExclusionConfig SelectedFBExclusionConfig
        {
            get { return GetValue<FBExclusionConfig>(); }
            set { SetValue(value); }
        }

        public ObservableCollection<FEMEntityModel> FEMList
        {
            get { return GetValue<ObservableCollection<FEMEntityModel>>(); }
            set { SetValue(value); }
        }

        public ObservableCollection<ADVConfig> SelectedFEMList { get; } = new ObservableCollection<ADVConfig>();

        public ADVConfig SelectedFEM
        {
            get { return GetValue<ADVConfig>(); }
            set { SetValue(value); }
        }

        public string MESNonSkipLotMode
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(MESNonSkipLotMode));
            }
        }

        #endregion
    }
}
