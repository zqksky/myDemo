﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AMAT.R2R.Client.Common.Enums;
using AMAT.R2R.Client.Common.Helpers;
using AMAT.R2R.Client.Litho.Messages;
using AMAT.R2R.Shared.Litho.DTO;
using DevExpress.Mvvm;
using DevExpress.Mvvm.DataAnnotations;
using Newtonsoft.Json;

namespace AMAT.R2R.Client.Litho.Modules.ContextSettings
{
    public class BatchEditContextViemModel : LithoViewModelBase
    {
        private const string NA = "NA";
        public BatchEditContextViemModel(List<Context> contextList)
        {
            Caption = "Batch Edit Context";
            ContextList = new ObservableCollection<Context>(contextList);
            OriginalContextList = contextList;
            SizeToContent = System.Windows.SizeToContent.WidthAndHeight;

            // TODO: read from config for Primary Keys.
            IsCDControlFlagPrimaryKey = true;
            IsCDFBEffectiveDaysPrimaryKey = true;
            IsDoseSensitivityPrimaryKey = true;
            IsOVLControlFlagPrimaryKey = true;
            IsOVLFBEffectiveDaysPrimaryKey = true;
            IsChuckControlPrimaryKey = true;
            IsDedicationTypePrimaryKey = true;

            IsCDControlFlagRequired = IsCDControlFlagPrimaryKey;
            IsCDFBEffectiveDaysRequired = IsCDFBEffectiveDaysPrimaryKey;
            IsDoseSensitivityRequired = IsDoseSensitivityPrimaryKey;
            IsOVLControlFlagRequired = IsOVLControlFlagPrimaryKey;
            IsOVLFBEffectiveDaysRequired = IsOVLFBEffectiveDaysPrimaryKey;
            IsChuckControlRequired = IsChuckControlPrimaryKey;
            IsDedicationTypeRequired = IsDedicationTypePrimaryKey;

            ChuckDedicationTypeList = new ObservableCollection<string>() { "No Chuck Dedication", "First Chuck", "Chuck Dedication with Wafer List" };
            if (ContextList != null && ContextList.Count > 0)
            {
                Context context = ContextList[0];
                Fab = context.Fab;
                Product = context.Product;
                Layer = context.Layer;
                Tool = context.Tool;
                Reticle = context.Reticle;
                Recipe = context.Recipe;
                PreTool = context.PreTool;
                PreReticle = context.PreReticle;
                CDAssignPilot = context.CDAssignPilot;
                CDControlFlag = context.CDControlFlag;
                CDFBAllowCount = context.CDFBAllowLotCnt;
                CDFBEffectiveDays = context.CDFBEffectiveDays;
                CDFBLotCount = context.CDFBLotCounter;
                CDFBLotList = context.CDFBLotList;
                DCDValuesEntity = context.DCDValues;
                DoseFixedValue = DCDValuesEntity.DoseFixedValue;
                FocusFixedValue = DCDValuesEntity.FocusFixedValue;
                DoseSensitivity = DCDValuesEntity.DoseSensitivity;
                Target = DCDValuesEntity.Target;
                ReworkBias = DCDValuesEntity.ReworkBias;
                CDGOFThreshold = context.CDGOFThreshold;
                CDMinPointLimit = context.CDMinPointLimit;

                OVLAssignPilot = context.OVLAssignPilot;
                OVLControlFlag = context.OVLControlFlag;
                OVLFBAllowCount = context.OVLFBAllowLotCnt;
                OVLFBEffectiveDays = context.OVLFBEffectiveDays;
                OVLFBLotCount = context.OVLFBLotCounter;
                OVLFBLotList = context.OVLFBLotList;
                TwoDMetrologyFlag = context.TwoDMetrologyEnabled == 1;
                ChuckControl = context.ChuckControl == 1;
                ChuckDedicationType = context.ChuckDedicationType;
                if (ChuckDedicationType == 1)
                {
                    StrChuckDedicationType = "No Chuck Dedication";
                }
                else if (ChuckDedicationType == 2)
                {
                    StrChuckDedicationType = "First Chuck";
                }
                else if (ChuckDedicationType == 3)
                {
                    StrChuckDedicationType = "Chuck Dedication with Wafer List";
                }
                else
                {
                    StrChuckDedicationType = "No Chuck Dedication";
                }
                ModelName = context.ModelName;
                OVLGOFThreshold = context.OVLGOFThreshold;
                LstOVLValues = context.LstOVLValues;

                //LastModifyUser = context.LastModifyUser;
                //LastModifyTime = context.LastModifyTime;

            }
            CDControlFlagList = new ObservableCollection<string>(ContextService.GetControlFlagList());
            OVLControlFlagList = new ObservableCollection<string>(ContextService.GetControlFlagList());
            ModelNameList = new ObservableCollection<string>();
            if (!string.IsNullOrEmpty(Tool))
            {
                ModelNameList = new ObservableCollection<string>(ContextService.GetOVLModelNameList(Tool));
            }

            IsDirty = false;
            PropertyChanged += OnPropertyChanged;
        }
        private async void OnPropertyChanged(object sender, System.ComponentModel.PropertyChangedEventArgs e)
        {
            if (e.PropertyName == nameof(SelectedContext))
            {
                if (SelectedContext != null)
                {
                    await GetContextDetailsAsync();

                    if (!string.IsNullOrEmpty(Tool))
                    {
                        ModelNameList = new ObservableCollection<string>(ContextService.GetOVLModelNameList(Tool));
                    }
                }
            }
        }

        protected override void OnViewReadyAsync()
        {

        }

        private async Task GetContextDetailsAsync()
        {
            if (SelectedContext != null)
            {
                #region 
                Fab = SelectedContext.Fab;
                Product = SelectedContext.Product;
                Layer = SelectedContext.Layer;
                Tool = SelectedContext.Tool;
                Reticle = SelectedContext.Reticle;
                Recipe = SelectedContext.Recipe;
                PreTool = SelectedContext.PreTool;
                PreReticle = SelectedContext.PreReticle;
                CDAssignPilot = SelectedContext.CDAssignPilot;
                CDGOFThreshold = SelectedContext.CDGOFThreshold;
                CDMinPointLimit = SelectedContext.CDMinPointLimit;
                CDControlFlag = SelectedContext.CDControlFlag;
                CDFBAllowCount = SelectedContext.CDFBAllowLotCnt;
                CDFBLotCount = SelectedContext.CDFBLotCounter;
                CDFBLotList = SelectedContext.CDFBLotList;
                CDFBEffectiveDays = SelectedContext.CDFBEffectiveDays;
                DCDValuesEntity = SelectedContext.DCDValues;
                if (DCDValuesEntity != null)
                {
                    DoseFixedValue = DCDValuesEntity.DoseFixedValue;
                    FocusFixedValue = DCDValuesEntity.FocusFixedValue;
                    DoseSensitivity = DCDValuesEntity.DoseSensitivity;
                    Target = DCDValuesEntity.Target;
                    ReworkBias = DCDValuesEntity.ReworkBias;
                }

                OVLAssignPilot = SelectedContext.OVLAssignPilot;
                OVLControlFlag = SelectedContext.OVLControlFlag;
                OVLFBAllowCount = SelectedContext.OVLFBAllowLotCnt;
                OVLFBLotCount = SelectedContext.OVLFBLotCounter;
                OVLFBLotList = SelectedContext.OVLFBLotList;
                OVLFBEffectiveDays = SelectedContext.OVLFBEffectiveDays;
                ModelName = SelectedContext.ModelName;
                TwoDMetrologyFlag = SelectedContext.TwoDMetrologyEnabled == 1;
                ChuckControl = SelectedContext.ChuckControl == 1;
                ChuckDedicationType = SelectedContext.ChuckDedicationType;
                if (ChuckDedicationType == 1)
                {
                    StrChuckDedicationType = "No Chuck Dedication";
                }
                else if (ChuckDedicationType == 2)
                {
                    StrChuckDedicationType = "First Chuck";
                }
                else if (ChuckDedicationType == 3)
                {
                    StrChuckDedicationType = "Chuck Dedication with Wafer List";
                }
                else
                {
                    StrChuckDedicationType = "No Chuck Dedication";
                }
                OVLGOFThreshold = SelectedContext.OVLGOFThreshold;

                LstOVLValues = new List<OVLValues>(SelectedContext.LstOVLValues);
                #endregion

                //var contextSpecList = await ContextService.GetContextSpecListAsync(SelectedContext.OVLContextKey);
            }

        }

        [Command]
        public async void Save()
        {
            ValidateAndSetErrorFocus(nameof(CDControlFlag), nameof(CDFBEffectiveDays), nameof(DoseSensitivity), nameof(CDGOFThreshold), nameof(CDMinPointLimit),
                nameof(OVLControlFlag), nameof(OVLFBEffectiveDays), nameof(ModelName), nameof(ModelName), nameof(StrChuckDedicationType), nameof(OVLGOFThreshold));

            if (HasErrors)
            {
                return;
            }

            List<Context> failedContextList = new List<Context>();
            StringBuilder sb = new StringBuilder();
            // 
            if (IsConfirmed(out string comment))
            {
                ShowWait();

                foreach (var context in ContextList)
                {
                    try
                    {
                        // clone context.
                        var newContext = JsonConvert.DeserializeObject<Context>(JsonConvert.SerializeObject(context));
                        DCDValuesEntity = newContext.DCDValues;

                        DCDValuesEntity.DoseFixedValue = DoseFixedValue;
                        DCDValuesEntity.FocusFixedValue = FocusFixedValue;
                        DCDValuesEntity.Target = Target;
                        DCDValuesEntity.DoseSensitivity = DoseSensitivity;
                        DCDValuesEntity.ReworkBias = ReworkBias;
                        DCDValuesEntity.Comment = comment;
                        DCDValuesEntity.LastModifyUser = ClientInfo.UserName; //LastModifyUser;
                        DCDValuesEntity.LastModifyTime = DateTime.Now; //LastModifyTime;

                        if (StrChuckDedicationType.Equals("No Chuck Dedication"))
                        {
                            ChuckDedicationType = 1;
                        }
                        else if (StrChuckDedicationType.Equals("First Chuck"))
                        {
                            ChuckDedicationType = 2;
                        }
                        else if (StrChuckDedicationType.Equals("Chuck Dedication with Wafer List"))
                        {
                            ChuckDedicationType = 3;
                        }

                        newContext.CDGOFThreshold = CDGOFThreshold;
                        newContext.CDMinPointLimit = CDMinPointLimit;
                        newContext.CDAssignPilot = CDAssignPilot;
                        newContext.CDControlFlag = CDControlFlag;
                        newContext.CDFBAllowLotCnt = CDFBAllowCount;
                        newContext.CDFBLotCounter = CDFBLotCount;
                        newContext.CDFBLotList = CDFBLotList;
                        newContext.CDFBEffectiveDays = CDFBEffectiveDays;
                        newContext.DCDValues = DCDValuesEntity;

                        newContext.OVLAssignPilot = OVLAssignPilot;
                        newContext.OVLControlFlag = OVLControlFlag;
                        newContext.OVLFBAllowLotCnt = OVLFBAllowCount;
                        newContext.OVLFBLotCounter = OVLFBLotCount;
                        newContext.OVLFBLotList = OVLFBLotList;
                        newContext.OVLFBEffectiveDays = OVLFBEffectiveDays;
                        newContext.ModelName = ModelName;
                        newContext.TwoDMetrologyEnabled = TwoDMetrologyFlag ? 1 : 0;
                        newContext.LstOVLValues = LstOVLValues;
                        newContext.OVLGOFThreshold = OVLGOFThreshold;
                        newContext.ChuckControl = ChuckControl ? 1 : 0;
                        newContext.ChuckDedicationType = ChuckDedicationType;

                        newContext.Comment = comment;
                        newContext.LastModifyUser = ClientInfo.UserName; //LastModifyUser,
                        newContext.LastModifyTime = DateTime.Now;  // LastModifyTime

                        await ContextService.ModifyContextAsync(newContext.OVLContextKey, newContext, comment);
                    }
                    catch (Exception ex)
                    {
                        failedContextList.Add(context);
                        sb.AppendLine(LocalizationService.LocalizeException(ex));
                    }
                }

                HideWait();

                var successCount = ContextList.Count - failedContextList.Count;

                if (successCount > 0)
                {
                    var successContextList = ContextList.Except(failedContextList);
                    foreach (var context in successContextList)
                    {
                        Messenger.Default.Send(new ContextChangedMessage() { ChangeType = ObjectChangeType.Updated, ContextKey = context.OVLContextKey });
                    }
                }


                // show error if any
                if (failedContextList.Count <= 0)
                {
                    MessageBoxService.ShowMessage($"{ContextList.Count} Context's Updated successfully.", "Success", MessageButton.OK, MessageIcon.Information);
                }
                else
                {
                    MessageBoxService.ShowMessage(sb.ToString(), $"Success Count: {successCount} Failed Count: { failedContextList.Count} ", MessageButton.OK, MessageIcon.Error);
                }

                IsOK = true;
                CloseWindow();
            }
        }

        public bool CanSave()
        {
            switch (Mode)
            {
                case FunctionMode.Add:
                    return true;
                case FunctionMode.Modify:
                    return IsDirty;
                default:
                    return true;
            }
        }

        protected override string GetError(string columnName)
        {
            switch (columnName)
            {
                case nameof(CDAssignPilot):
                    return DataValidator.ValidString(CDAssignPilot);
                case nameof(CDControlFlag):
                    return DataValidator.ValidString(CDControlFlag);
                case nameof(CDFBAllowCount):
                    return DataValidator.ValidString(CDFBAllowCount.ToString()); ;
                case nameof(CDFBEffectiveDays):
                    return DataValidator.ValidString(CDFBEffectiveDays.ToString());
                case nameof(Target):
                    return DataValidator.ValidString(Target.ToString());

                case nameof(ModelName):
                    return DataValidator.ValidString(ModelName);
                case nameof(OVLAssignPilot):
                    return DataValidator.ValidString(OVLAssignPilot);
                case nameof(OVLControlFlag):
                    return DataValidator.ValidString(OVLControlFlag);
                case nameof(OVLFBAllowCount):
                    return DataValidator.ValidString(OVLFBAllowCount.ToString());
                case nameof(OVLFBEffectiveDays):
                    return DataValidator.ValidString(OVLFBEffectiveDays.ToString());
                case nameof(ChuckDedicationType):
                    return DataValidator.ValidString(ChuckDedicationType.ToString());
                //case nameof(ChuckControl):
                //    return DataValidator.ValidString(ChuckControl.ToString());

                default:
                    return null;
            }
        }

        #region Properties
        public List<Context> OriginalContextList { get; private set; }

        public ObservableCollection<Context> ContextList
        {
            get { return GetValue<ObservableCollection<Context>>(); }
            set { SetValue(value); }
        }
        public Context SelectedContext
        {
            get { return GetValue<Context>(); }
            set { SetValue(value); }
        }

        public Context OriginalContext { get; private set; }

        public ObservableCollection<string> OVLControlFlagList
        {
            get { return GetValue<ObservableCollection<string>>(); }
            set { SetValue(value); }
        }

        public ObservableCollection<string> CDControlFlagList
        {
            get { return GetValue<ObservableCollection<string>>(); }
            set { SetValue(value); }
        }

        public ObservableCollection<string> ModelNameList
        {
            get { return GetValue<ObservableCollection<string>>(); }
            set { SetValue(value); }
        }
        public ObservableCollection<string> ChuckDedicationTypeList
        {
            get { return GetValue<ObservableCollection<string>>(); }
            set { SetValue(value); }
        }
        
        public string Fab
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(Fab));
            }
        }

        public string Tool
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(Tool));
            }
        }

        public string Product
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(Product));
            }
        }

        public string Layer
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(Layer));
            }
        }

        public string Recipe
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(Recipe));
            }
        }

        public string Reticle
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(Reticle));
            }
        }
        public string PreTool
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(PreTool));
            }
        }

        public string PreReticle
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(PreReticle));
            }
        }

        public string CDControlFlag
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(CDControlFlag));
            }
        }

        public int CDFBAllowCount
        {
            get { return GetValue<int>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(CDFBAllowCount));
            }
        }

        public int CDFBLotCount
        {
            get { return GetValue<int>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(CDFBLotCount));
            }
        }

        public string CDFBLotList
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(CDFBLotList));
            }
        }

        public string CDAssignPilot
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(CDAssignPilot));
            }
        }
        public double CDGOFThreshold
        {
            get { return GetValue<double>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(CDGOFThreshold));
            }
        }

        public double CDMinPointLimit
        {
            get { return GetValue<double>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(CDMinPointLimit));
            }
        }

        public int CDFBEffectiveDays
        {
            get { return GetValue<int>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(CDFBEffectiveDays));
            }
        }

        public DCDValues DCDValuesEntity
        {
            get { return GetValue<DCDValues>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(DCDValuesEntity));
            }
        }
        public double? DoseFixedValue
        {
            get { return GetValue<double?>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(DoseFixedValue));
            }
        }

        public double? FocusFixedValue
        {
            get { return GetValue<double?>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(FocusFixedValue));
            }
        }

        public double Target
        {
            get { return GetValue<double>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(Target));
            }
        }

        public double? DoseSensitivity
        {
            get { return GetValue<double?>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(DoseSensitivity));
            }
        }

        public double ReworkBias
        {
            get { return GetValue<double>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(ReworkBias));
            }
        }

        public string ModelName
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(ModelName));
            }
        }
        public bool TwoDMetrologyFlag
        {
            get { return GetValue<bool>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(TwoDMetrologyFlag));
            }
        }
        public string OVLControlFlag
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(OVLControlFlag));
            }
        }

        public int OVLFBAllowCount
        {
            get { return GetValue<int>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(OVLFBAllowCount));
            }
        }

        public int OVLFBLotCount
        {
            get { return GetValue<int>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(OVLFBLotCount));
            }
        }

        public string OVLFBLotList
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(OVLFBLotList));
            }
        }

        public string OVLAssignPilot
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(OVLAssignPilot));
            }
        }
        public double OVLGOFThreshold
        {
            get { return GetValue<double>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(OVLGOFThreshold));
            }
        }

        public int OVLFBEffectiveDays
        {
            get { return GetValue<int>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(OVLFBEffectiveDays));
            }
        }

        public int ChuckDedicationType
        {
            get { return GetValue<int>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(ChuckDedicationType));
            }
        }
        public string StrChuckDedicationType
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(StrChuckDedicationType));
            }
        }
        public bool ChuckControl
        {
            get { return GetValue<bool>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(ChuckControl));
            }
        }

        public List<OVLValues> LstOVLValues
        {
            get { return GetValue<List<OVLValues>>(); }
            set
            {
                SetValue(value);
                //IsDirty = true;
                ClearError(nameof(LstOVLValues));
            }
        }

        public List<Specs> LstSpecs
        {
            get { return GetValue<List<Specs>>(); }
            set
            {
                SetValue(value);
                //IsDirty = true;
                ClearError(nameof(LstSpecs));
            }
        }

        public DateTime LastModifyTime
        {
            get { return GetValue<DateTime>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(LastModifyTime));
            }
        }

        public string LastModifyUser
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(LastModifyUser));
            }
        }

        public bool IsCDControlFlagPrimaryKey { get { return GetValue<bool>(); } set { SetValue(value); } }
        public bool IsCDControlFlagRequired
        {
            get
            {
                return GetValue<bool>();
            }
            set
            {
                SetValue(value);
                if (value)
                {
                    SetFocus(nameof(CDControlFlag));
                }
                RaisePropertiesChanged(nameof(IsCDControlFlagReadOnly));
            }
        }

        public bool IsCDControlFlagReadOnly
        {
            get { return IsCDControlFlagRequired; }
        }

        public bool IsCDFBEffectiveDaysPrimaryKey { get { return GetValue<bool>(); } set { SetValue(value); } }
        public bool IsCDFBEffectiveDaysRequired
        {
            get
            {
                return GetValue<bool>();
            }
            set
            {
                SetValue(value);
                if (value)
                {
                    SetFocus(nameof(CDFBEffectiveDays));
                }
                RaisePropertiesChanged(nameof(IsCDFBEffectiveDaysReadOnly));
            }
        }

        public bool IsCDFBEffectiveDaysReadOnly
        {
            get { return IsCDFBEffectiveDaysRequired; }
        }

        public bool IsDoseSensitivityPrimaryKey { get { return GetValue<bool>(); } set { SetValue(value); } }
        public bool IsDoseSensitivityRequired
        {
            get
            {
                return GetValue<bool>();
            }
            set
            {
                SetValue(value);
                if (value)
                {
                    SetFocus(nameof(DoseSensitivity));
                }
                RaisePropertiesChanged(nameof(IsDoseSensitivityReadOnly));
            }
        }

        public bool IsDoseSensitivityReadOnly
        {
            get { return IsDoseSensitivityRequired; }
        }

        public bool IsOVLControlFlagPrimaryKey { get { return GetValue<bool>(); } set { SetValue(value); } }
        public bool IsOVLControlFlagRequired
        {
            get
            {
                return GetValue<bool>();
            }
            set
            {
                SetValue(value);
                if (value)
                {
                    SetFocus(nameof(OVLControlFlag));
                }
                RaisePropertiesChanged(nameof(IsOVLControlFlagReadOnly));
            }
        }

        public bool IsOVLControlFlagReadOnly
        {
            get { return IsOVLControlFlagRequired; }
        }

        public bool IsOVLFBEffectiveDaysPrimaryKey { get { return GetValue<bool>(); } set { SetValue(value); } }
        public bool IsOVLFBEffectiveDaysRequired
        {
            get
            {
                return GetValue<bool>();
            }
            set
            {
                SetValue(value);
                if (value)
                {
                    SetFocus(nameof(OVLFBEffectiveDays));
                }
                RaisePropertiesChanged(nameof(IsOVLFBEffectiveDaysReadOnly));
            }
        }

        public bool IsOVLFBEffectiveDaysReadOnly
        {
            get { return IsOVLFBEffectiveDaysRequired; }
        }

        public bool IsModelNamePrimaryKey { get { return GetValue<bool>(); } set { SetValue(value); } }
        public bool IsModelNameRequired
        {
            get
            {
                return GetValue<bool>();
            }
            set
            {
                SetValue(value);
                if (value)
                {
                    SetFocus(nameof(ModelName));
                }
                RaisePropertiesChanged(nameof(IsModelNameReadOnly));
            }
        }

        public bool IsModelNameReadOnly
        {
            get { return IsModelNameRequired; }
        }

        public bool IsChuckControlPrimaryKey { get { return GetValue<bool>(); } set { SetValue(value); } }
        public bool IsChuckControlRequired
        {
            get
            {
                return GetValue<bool>();
            }
            set
            {
                SetValue(value);
                if (value)
                {
                    SetFocus(nameof(ChuckControl));
                }
                RaisePropertiesChanged(nameof(IsChuckControlReadOnly));
            }
        }

        public bool IsChuckControlReadOnly
        {
            get { return IsChuckControlRequired; }
        }

        public bool IsDedicationTypePrimaryKey { get { return GetValue<bool>(); } set { SetValue(value); } }
        public bool IsDedicationTypeRequired
        {
            get
            {
                return GetValue<bool>();
            }
            set
            {
                SetValue(value);
                if (value)
                {
                    SetFocus(nameof(ChuckDedicationType));
                }
                RaisePropertiesChanged(nameof(IsDedicationTypeReadOnly));
            }
        }

        public bool IsDedicationTypeReadOnly
        {
            get { return IsDedicationTypeRequired; }
        }
        #endregion
    }
}
