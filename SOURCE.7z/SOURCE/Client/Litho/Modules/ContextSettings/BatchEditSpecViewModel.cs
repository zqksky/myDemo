﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AMAT.R2R.Client.Common.Enums;
using AMAT.R2R.Client.Common.Helpers;
using AMAT.R2R.Client.Litho.Helpers;
using AMAT.R2R.Client.Litho.Messages;
using AMAT.R2R.Shared.Litho.DTO;
using DevExpress.Mvvm;
using DevExpress.Mvvm.DataAnnotations;
using Newtonsoft.Json;

namespace AMAT.R2R.Client.Litho.Modules.ContextSettings
{
    public class BatchEditSpecViewModel : LithoViewModelBase
    {
        private decimal dStep = 0.1M;
        public BatchEditSpecViewModel(List<Context> contextList)
        {
            ContextList = new ObservableCollection<Context>(contextList);
            Mode = FunctionMode.Modify;
            Caption = $"Batch Edit Spec Settings";
            SizeToContent = System.Windows.SizeToContent.Manual;

            if (ContextList.Count > 1)
            {
                var contextSpecList = ContextService.GetContextSpecList(ContextList[0].OVLContextKey);
                ContextSpecList = new ObservableCollection<Specs>(contextSpecList);
            }


            PropertyChanged += OnPropertyChanged;

            IsDirty = false;
        }

        private async void OnPropertyChanged(object sender, System.ComponentModel.PropertyChangedEventArgs e)
        {
            if (e.PropertyName == nameof(SelectedContext))
            {
                if (SelectedContext != null)
                {
                    await GetSpecDetailsAsync();

                    NoChuckFlag = SelectedContext.ChuckControl == 0;
                    HaveChuckFlag = !NoChuckFlag;
                }
            }

            if (e.PropertyName == nameof(ContextSpecList))
            {
                IsDirty = true;
            }
        }

        protected override void OnViewReadyAsync()
        {

        }

        private async Task GetSpecDetailsAsync()
        {
            if (SelectedContext != null)
            {
                #region 
                var contextSpecList = await ContextService.GetContextSpecListAsync(SelectedContext.OVLContextKey);
                ContextSpecList = new ObservableCollection<Specs>(contextSpecList);
                #endregion
            }

        }

        [Command]
        public void MinusStep(object obj)
        {
            var btnMinus = obj as DevExpress.Xpf.Editors.ImageButtonInfo;
            string strBtnName = btnMinus.Name;
            string strParameterName = CommonHelp.GetMiddleStr(strBtnName, "btn", "Minus");
            var btnParent = btnMinus.Parent as DevExpress.Xpf.Editors.ButtonEdit;

            if (btnParent.EditValue != null)
            {
                dStep = decimal.Parse(btnParent.EditValue.ToString());
            }

            switch (strParameterName)
            {
                case "FixValueNA":
                    foreach (var entity in ContextSpecList)
                    {
                        entity.FixValueNA = CommonHelp.sub(entity.FixValueNA, dStep);
                        //entity.FixValue -= dStep;
                    }
                    break;
                case "FixValueC1":
                    foreach (var entity in ContextSpecList)
                    {
                        entity.FixValueC1 = CommonHelp.sub(entity.FixValueC1, dStep);
                        //entity.FixValue -= dStep;
                    }
                    break;
                case "FixValueC2":
                    foreach (var entity in ContextSpecList)
                    {
                        entity.FixValueC2 = CommonHelp.sub(entity.FixValueC2, dStep);
                        //entity.FixValue -= dStep;
                    }
                    break;
                case "Max":
                    foreach (var entity in ContextSpecList)
                    {
                        entity.Max = CommonHelp.sub(entity.Max, dStep);
                        //entity.Max -= dStep;
                    }
                    break;
                case "Min":
                    foreach (var entity in ContextSpecList)
                    {
                        entity.Min = CommonHelp.sub(entity.Min, dStep);
                        //entity.Min -= dStep;
                    }
                    break;
                case "MaxDelta":
                    foreach (var entity in ContextSpecList)
                    {
                        entity.MaxDelta = CommonHelp.sub(entity.MaxDelta, dStep);
                        //entity.MaxDelta -= dStep;
                    }
                    break;
                case "Deadband":
                    foreach (var entity in ContextSpecList)
                    {
                        entity.Deadband = CommonHelp.sub(entity.Deadband, dStep);
                        //entity.Deadband -= dStep;
                    }
                    break;
                case "Lambda":
                    foreach (var entity in ContextSpecList)
                    {
                        entity.Lambda = CommonHelp.sub(entity.Lambda, dStep);
                        //entity.Lambda -= dStep;
                    }
                    break;
                case "LambdaForPirun":
                    foreach (var entity in ContextSpecList)
                    {
                        entity.LambdaForPirun = CommonHelp.sub(entity.LambdaForPirun, dStep);
                        //entity.LambdaForPirun -= dStep;
                    }
                    break;
                case "MinPointsForAvg":
                    foreach (var entity in ContextSpecList)
                    {
                        var tmp = CommonHelp.sub(entity.MinPointsForAvg, dStep);
                        if (tmp < 1)
                        {
                            entity.MinPointsForAvg = 1;
                        }
                        else
                        {
                            entity.MinPointsForAvg = tmp;
                        }
                        //entity.MinPointsForAvg = CommonHelp.sub(entity.MinPointsForAvg, dStep);
                        //entity.MinPointsForAvg -= dStep;
                    }
                    break;
                case "OutputMax":
                    foreach (var entity in ContextSpecList)
                    {
                        entity.OutputMax = CommonHelp.sub(entity.OutputMax, dStep);
                        //entity.OutputMax -= dStep;
                    }
                    break;
                case "OutputMin":
                    foreach (var entity in ContextSpecList)
                    {
                        entity.OutputMin = CommonHelp.sub(entity.OutputMin, dStep);
                        //entity.OutputMin -= dStep;
                    }
                    break;
                default:
                    break;

            }

            ContextSpecList = new ObservableCollection<Specs>(ContextSpecList);
        }

        [Command]
        public void PlusStep(object obj)
        {
            var btn = obj as DevExpress.Xpf.Editors.ImageButtonInfo;
            string strBtnName = btn.Name;
            string strParameterName = CommonHelp.GetMiddleStr(strBtnName, "btn", "Plus");
            var btnParent = btn.Parent as DevExpress.Xpf.Editors.ButtonEdit;

            if (btnParent.EditValue != null)
            {
                dStep = decimal.Parse(btnParent.EditValue.ToString());
            }

            switch (strParameterName)
            {
                case "FixValueNA":
                    foreach (var entity in ContextSpecList)
                    {
                        entity.FixValueNA = CommonHelp.add(entity.FixValueNA, dStep);
                        //entity.FixValue += dStep;
                    }
                    break;
                case "FixValueC1":
                    foreach (var entity in ContextSpecList)
                    {
                        entity.FixValueC1 = CommonHelp.add(entity.FixValueC1, dStep);
                        //entity.FixValue += dStep;
                    }
                    break;
                case "FixValueC2":
                    foreach (var entity in ContextSpecList)
                    {
                        entity.FixValueC1 = CommonHelp.add(entity.FixValueC1, dStep);
                        //entity.FixValue += dStep;
                    }
                    break;
                case "Max":
                    foreach (var entity in ContextSpecList)
                    {
                        entity.Max = CommonHelp.add(entity.Max, dStep);
                        //entity.Max += dStep;
                    }
                    break;
                case "Min":
                    foreach (var entity in ContextSpecList)
                    {
                        entity.Min = CommonHelp.add(entity.Min, dStep);
                        //entity.Min += dStep;
                    }
                    break;
                case "MaxDelta":
                    foreach (var entity in ContextSpecList)
                    {
                        entity.MaxDelta = CommonHelp.add(entity.MaxDelta, dStep);
                        //entity.MaxDelta += dStep;
                    }
                    break;
                case "Deadband":
                    foreach (var entity in ContextSpecList)
                    {
                        entity.Deadband = CommonHelp.add(entity.Deadband, dStep);
                        //entity.Deadband += dStep;
                    }
                    break;
                case "Lambda":
                    foreach (var entity in ContextSpecList)
                    {
                        entity.Lambda = CommonHelp.add(entity.Lambda, dStep);
                        //entity.Lambda += dStep;
                    }
                    break;
                case "LambdaForPirun":
                    foreach (var entity in ContextSpecList)
                    {
                        entity.LambdaForPirun = CommonHelp.add(entity.LambdaForPirun, dStep);
                        //entity.LambdaForPirun += dStep;
                    }
                    break;
                case "MinPointsForAvg":
                    foreach (var entity in ContextSpecList)
                    {
                        var tmp = CommonHelp.add(entity.MinPointsForAvg, dStep);
                        if (tmp < 1)
                        {
                            entity.MinPointsForAvg = 1;
                        }
                        else
                        {
                            entity.MinPointsForAvg = tmp;
                        }
                        //entity.MinPointsForAvg = CommonHelp.add(entity.MinPointsForAvg, dStep);
                        //entity.MinPointsForAvg += dStep;
                    }
                    break;
                case "OutputMax":
                    foreach (var entity in ContextSpecList)
                    {
                        entity.OutputMax = CommonHelp.add(entity.OutputMax, dStep);
                        //entity.OutputMax += dStep;
                    }
                    break;
                case "OutputMin":
                    foreach (var entity in ContextSpecList)
                    {
                        entity.OutputMin = CommonHelp.add(entity.OutputMin, dStep);
                        //entity.OutputMin += dStep;
                    }
                    break;
                default:
                    break;

            }

            ContextSpecList = new ObservableCollection<Specs>(ContextSpecList);
        }

        public bool CanPlus()
        {
            return true;
        }
        public bool CanMinus()
        {
            return true;
        }

        [Command]
        public async void Save()
        {
            //ValidateAndSetErrorFocus(nameof(CDControlFlag), nameof(CDFBEffectiveDays), nameof(DoseSensitivity),
            //    nameof(OVLControlFlag), nameof(OVLFBEffectiveDays), nameof(ModelName));

            if (HasErrors)
            {
                return;
            }

            List<Context> failedContextList = new List<Context>();
            StringBuilder sb = new StringBuilder();
            // 
            if (IsConfirmed(out string comment))
            {
                foreach (var context in ContextList)
                {
                    try
                    {
                        // clone context.
                        var newContext = JsonConvert.DeserializeObject<Context>(JsonConvert.SerializeObject(context));
                        SpecSetting newSpecSetting = new SpecSetting();
                        foreach (var specs in ContextSpecList)
                        {
                            specs.ContextKey = context.OVLContextKey;
                            specs.ModelName = context.ModelName;
                        }
                        newSpecSetting.Specs = new List<Specs>(ContextSpecList);
                        newSpecSetting.LastModifyTime = DateTime.Now;
                        newSpecSetting.Comment = comment;
                        newSpecSetting.LastModifyUser = ClientInfo.UserName;

                        ShowWait();
                        await ContextService.ModifyContextSpecAsync(newSpecSetting, comment);

                        IsDirty = false;
                        HideWait();

                    }
                    catch (Exception ex)
                    {
                        failedContextList.Add(context);
                        sb.AppendLine(LocalizationService.LocalizeException(ex));
                    }
                }

                var successCount = ContextList.Count - failedContextList.Count;

                if (successCount > 0)
                {
                    var successContextList = ContextList.Except(failedContextList);
                    foreach (var context in successContextList)
                    {
                        Messenger.Default.Send(new ContextChangedMessage() { ChangeType = ObjectChangeType.Updated, ContextKey = context.OVLContextKey });
                    }
                }


                // show error if any
                if (failedContextList.Count <= 0)
                {
                    MessageBoxService.ShowMessage($"{ContextList.Count} Context's Updated successfully.", "Success", MessageButton.OK, MessageIcon.Information);
                }
                else
                {
                    MessageBoxService.ShowMessage(sb.ToString(), $"Success Count: {successCount} Failed Count: { failedContextList.Count} ", MessageButton.OK, MessageIcon.Error);
                }

                IsOK = true;
                CloseWindow();
            }
        }

        public bool CanSave()
        {
            return true;
        }

        protected override string GetError(string columnName)
        {
            switch (columnName)
            {
                default:
                    return null;
            }
        }

        #region Properties
        public bool NoChuckFlag
        {
            get { return GetValue<bool>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(NoChuckFlag));
            }
        }

        public bool HaveChuckFlag
        {
            get { return GetValue<bool>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(HaveChuckFlag));
            }
        }
        public Context CurrentContext { get; private set; }
        public ObservableCollection<Specs> ContextSpecList
        {
            get { return GetValue<ObservableCollection<Specs>>(); }
            set
            {
                SetValue(value);
                RaisePropertyChanged(nameof(ContextSpecList));
            }
        }

        public ObservableCollection<Context> ContextList
        {
            get { return GetValue<ObservableCollection<Context>>(); }
            set { SetValue(value); }
        }
        public Context SelectedContext
        {
            get { return GetValue<Context>(); }
            set { SetValue(value); }
        }
        #endregion
    }
}
