﻿using System.Collections.Generic;
using System.Collections.ObjectModel;
using AMAT.R2R.Shared.Litho.DTO;
using DevExpress.Mvvm;
using DevExpress.Mvvm.DataAnnotations;
using DevExpress.Xpf.Core;

namespace AMAT.R2R.Client.Litho.Modules.ContextSettings
{
    public class ImportVerifyViewModel : LithoViewModelBase
    {
        public ImportVerifyViewModel(XMLStructure importEntity, List<ImportVerifyEntity> importVerifyEntityList)
        {
            SizeToContent = System.Windows.SizeToContent.Manual;
            Caption = "Import – Verify Result";

            ImportEntity = importEntity;
            ImportList = new ObservableCollection<ImportVerifyEntity>(importVerifyEntityList);
            SelectedImportItemList = new ObservableCollection<ImportVerifyEntity>();
        }

        protected override void OnViewReadyAsync()
        {

        }
        #region Commands
        [Command]
        public void UpdateExist()
        {
            foreach (var s in ImportList)
            {
                s.UpdateExistFlag = UpdateExistDataFlag;
                if (string.IsNullOrEmpty(s.Process) || string.IsNullOrEmpty(s.CD) || string.IsNullOrEmpty(s.OVL))
                {
                    s.CanSelectedFlag = false;
                }
                else if (s.Process == "Exception" || s.CD == "Exception" || s.OVL == "Exception")
                {
                    s.CanSelectedFlag = false;
                }
                else if (s.Process == "New" || s.CD == "New" || s.OVL == "New")
                {
                    s.CanSelectedFlag = true;
                }
                else if (s.Process == "Exist" || s.CD == "Exist" || s.OVL == "Exist")
                {
                    s.CanSelectedFlag = s.UpdateExistFlag;
                }
            }
            ImportList = new ObservableCollection<ImportVerifyEntity>(ImportList);

            if (!UpdateExistDataFlag)
            {
                if (SelectedImportItemList.Count > 0)
                {
                    List<string> listKey = new List<string>();
                    foreach (var s in SelectedImportItemList)
                    {
                        listKey.Add(s.ContextKey);
                    }

                    SelectedImportItemList.Clear();

                    foreach (var s in ImportList)
                    {
                        if (listKey.Contains(s.ContextKey))
                        {
                            bool flag = false;
                            string str = s.Process + ":" + s.CD + ":" + s.OVL;
                            if (str.Contains("New"))
                            {
                                flag = true;
                            }
                            else if (str.Contains("Exception"))
                            {
                                flag = false;
                            }
                            else if (str.Contains("Exist"))
                            {
                                flag = false;
                            }
                            if (flag)
                            {
                                SelectedImportItemList.Add(s);
                            }
                        }
                    }
                }
            }
        }
        public bool CanUpdateExist()
        {
            return true;
        }

        [Command]
        public async void Import()
        {
            XMLStructure ImportItemEntity = new XMLStructure();
            if (SelectedImportItem != null && SelectedImportItemList.Count > 0)
            {
                foreach (var s in SelectedImportItemList)
                {
                    foreach (var p in ImportEntity.LstProcess)
                    {
                        if (s.Product == p.Product && s.Layer == p.Layer)
                        {
                            ImportItemEntity.LstProcess.Add(p);
                        }
                    }
                    foreach (var p in ImportEntity.LstCDContext)
                    {
                        if (s.Product == p.Product && s.Layer == p.Layer && s.Tool == p.Tool && s.Reticle == p.Reticle && s.Recipe == p.Recipe)
                        {
                            ImportItemEntity.LstCDContext.Add(p);
                        }
                    }
                    foreach (var p in ImportEntity.LstCDValues)
                    {
                        if (s.Product == p.Product && s.Layer == p.Layer && s.Tool == p.Tool && s.Reticle == p.Reticle && s.Recipe == p.Recipe)
                        {
                            ImportItemEntity.LstCDValues.Add(p);
                        }
                    }
                    foreach (var p in ImportEntity.LstOVLContext)
                    {
                        if (s.Product == p.Product && s.Layer == p.Layer && s.Tool == p.Tool && s.Reticle == p.Reticle && s.Recipe == p.Recipe && s.PreTool == p.PreTool && s.PreReticle == p.PreReticle)
                        {
                            ImportItemEntity.LstOVLContext.Add(p);
                        }
                    }
                    foreach (var p in ImportEntity.LstOVLValues)
                    {
                        if (s.Product == p.Product && s.Layer == p.Layer && s.Tool == p.Tool && s.Reticle == p.Reticle && s.Recipe == p.Recipe && s.PreTool == p.PreTool && s.PreReticle == p.PreReticle)
                        {
                            ImportItemEntity.LstOVLValues.Add(p);
                        }
                    }
                }

                XMLStructure NewImportItemEntity = new XMLStructure();
                if (IsConfirmed(out string comment))
                {
                    DXSplashScreen.Show<ImportSplashScreenView>();

                    NewImportItemEntity = await ContextService.CreateImportByXmlAsync(ImportItemEntity, UpdateExistDataFlag, comment);
                    IsDirty = false;

                    DXSplashScreen.Close();

                    MessageBoxService.ShowMessage($"Import Config successfully", "Success", MessageButton.OK, MessageIcon.Information);

                    IsOK = true;
                    //CloseWindow();
                }

                foreach (var v in NewImportItemEntity.LstOVLContext)
                {
                    string strKey = "";
                    strKey = string.Format("{0}:{1}:{2}:{3}:{4}:{5}:{6}", v.Tool, v.Product, v.Layer, v.Reticle, v.Recipe, v.PreTool, v.PreReticle);
                    foreach (var import in ImportList)
                    {
                        if (import.ContextKey.Equals(strKey))
                        {
                            import.Process = v.VerifyResult.Process;
                            import.CD = v.VerifyResult.CD;
                            import.OVL = v.VerifyResult.OVL;
                            import.Comment = v.VerifyResult.Comment;
                            break;
                        }
                    }
                }
                ImportList = new ObservableCollection<ImportVerifyEntity>(ImportList);
                SelectedImportItemList = new ObservableCollection<ImportVerifyEntity>();
            }
        }
        public bool CanImport()
        {
            return true && SelectedImportItem != null && SelectedImportItemList.Count > 0;
        }
        #endregion

        #region Properties
        public bool UpdateExistDataFlag
        {
            get { return GetValue<bool>(); }
            set { SetValue(value); }
        }
        XMLStructure ImportEntity;
        public ObservableCollection<ImportVerifyEntity> ImportList
        {
            get { return GetValue<ObservableCollection<ImportVerifyEntity>>(); }
            set { SetValue(value); }
        }

        public ImportVerifyEntity SelectedImportItem
        {
            get { return GetValue<ImportVerifyEntity>(); }
            set { SetValue(value); }
        }
        public ObservableCollection<ImportVerifyEntity> SelectedImportItemList
        {
            get { return GetValue<ObservableCollection<ImportVerifyEntity>>(); }
            set { SetValue(value); }
        }

        public List<ImportVerifyEntity> SelectedImportItemListNew
        {
            get { return GetValue<List<ImportVerifyEntity>>(); }
            set { SetValue(value); }
        }

        //public ObservableCollection<ImportVerifyEntity> SelectedImportItemList { get; } = new ObservableCollection<ImportVerifyEntity>();
        #endregion
    }

    public class ImportVerifyEntity : BindableBase
    {
        public string ContextKey { get { return string.Format("{0}:{1}:{2}:{3}:{4}:{5}:{6}", Tool, Product, Layer, Reticle, Recipe, PreTool, PreReticle); } }
        public string Product { get; set; }
        public string Layer { get; set; }
        public string Tool { get; set; }
        public string Reticle { get; set; }
        public string Recipe { get; set; }
        public string PreTool { get; set; }
        public string PreReticle { get; set; }
        public string Process { get; set; }
        public string CD { get; set; }
        public string OVL { get; set; }
        public string ProcessComment { get; set; }
        public string OVLComment { get; set; }
        public string CDComment { get; set; }
        public string Comment { get; set; }

        public bool UpdateExistFlag { get; set; }
        public bool CanSelectedFlag { get; set; }
    }
}
