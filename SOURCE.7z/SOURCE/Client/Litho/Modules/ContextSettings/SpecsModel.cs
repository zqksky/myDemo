﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AMAT.R2R.Shared.Litho.DTO;

namespace AMAT.R2R.Client.Litho.Modules.ContextSettings
{
    public class SpecsModel : Specs, INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;

        public void NotifyChanges()
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(FixValueNA)));
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(FixValueC1)));
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(FixValueC2)));

            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Max)));

            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Min)));
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(MaxDelta)));
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Deadband)));

            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Lambda)));

            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(LambdaForPirun)));

            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(MinPointsForAvg)));

            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(OutputMax)));

            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(OutputMin)));

            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Precision)));

            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(LastModifyUser)));

            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(LastModifyTime)));
        }
    }
}
