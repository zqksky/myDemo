﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using AMAT.R2R.Client.Common.Enums;
using AMAT.R2R.Client.Common.Helpers;
using AMAT.R2R.Client.Litho.Helpers;
using AMAT.R2R.Client.Litho.Messages;
using AMAT.R2R.Shared.Litho.DTO;
using DevExpress.Mvvm;
using DevExpress.Mvvm.DataAnnotations;
using Newtonsoft.Json;

namespace AMAT.R2R.Client.Litho.Modules.ContextSettings
{
    public class EditSpecSettingViewModel : LithoViewModelBase
    {
        private decimal dStep = 0.1M;
        public EditSpecSettingViewModel(Context context, List<Specs> contextSpecList)
        {
            CurrentContext = context;
            Mode = FunctionMode.Modify;
            Caption = $"Edit Spec Settings";
            SizeToContent = System.Windows.SizeToContent.Manual;
            //WindowHeight = 480;
            //WindowWidth = 1200;
            strOriginalContextSpecList = JsonConvert.SerializeObject(contextSpecList);
            ContextSpecList = new ObservableCollection<Specs>(contextSpecList);

            CDContextSpecList = new ObservableCollection<Specs>(ContextSpecList.Where(p => p.ModelName == "DCD").ToList());
            OVLContextSpecList = new ObservableCollection<Specs>(ContextSpecList.Where(p => p.ModelName != "DCD").ToList());

            PropertyChanged += OnPropertyChanged;

            NoChuckFlag = context.ChuckControl == 0;
            HaveChuckFlag = !NoChuckFlag;

            IsDirty = false;
        }

        private void OnPropertyChanged(object sender, System.ComponentModel.PropertyChangedEventArgs e)
        {
            if (e.PropertyName == nameof(ContextSpecList))
            {
                IsDirty = true;
            }
            if (e.PropertyName == nameof(CDContextSpecList))
            {
                IsDirty = true;
            }
            if (e.PropertyName == nameof(OVLContextSpecList))
            {
                IsDirty = true;
            }
        }

        protected override void OnViewReadyAsync()
        {

        }
        [Command]
        public void CopyTest()
        {
           
        }
        public bool CanCopyTest()
        {
            return true;
        }
        [Command]
        public void PasteTest()
        {

        }
        public bool CanPasteTest()
        {
            return true;
        }
        [Command]
        public void OnCDEscKeyDown()
        {
            OriginalContextSpecList = new List<Specs>();
            OriginalContextSpecList = JsonConvert.DeserializeObject<List<Specs>>(strOriginalContextSpecList);
            CDContextSpecList = new ObservableCollection<Specs>(OriginalContextSpecList.Where(p => p.ModelName == "DCD").ToList());
            System.Windows.Clipboard.Clear();
        }
        public bool CanCDOnEscKeyDown()
        {
            return true;
        }
        [Command]
        public void OnOVLEscKeyDown()
        {
            OriginalContextSpecList = new List<Specs>();
            OriginalContextSpecList = JsonConvert.DeserializeObject<List<Specs>>(strOriginalContextSpecList);
            OVLContextSpecList = new ObservableCollection<Specs>(OriginalContextSpecList.Where(p => p.ModelName != "DCD").ToList());
            System.Windows.Clipboard.Clear();
        }
        public bool CanOVLOnEscKeyDown()
        {
            return true;
        }
        [Command]
        public void CDUndo()
        {
            OriginalContextSpecList = new List<Specs>();
            OriginalContextSpecList = JsonConvert.DeserializeObject<List<Specs>>(strOriginalContextSpecList);
            CDContextSpecList = new ObservableCollection<Specs>(OriginalContextSpecList.Where(p => p.ModelName == "DCD").ToList());
            //System.Windows.Clipboard.Clear();
        }
        public bool CanCDUndo()
        {
            return true;
        }
        [Command]
        public void OVLUndo()
        {
            OriginalContextSpecList = new List<Specs>();
            OriginalContextSpecList = JsonConvert.DeserializeObject<List<Specs>>(strOriginalContextSpecList);
            OVLContextSpecList = new ObservableCollection<Specs>(OriginalContextSpecList.Where(p => p.ModelName != "DCD").ToList());
            //System.Windows.Clipboard.Clear();  
        }
        public bool CanOVLUndo()
        {
            return true;
        }
        [Command]
        public void OnCellValueChanged(object obj)
        {
            IsDirty = true;
        }
        [Command]
        public void MinusStep(object obj)
        {
            var btnMinus = obj as DevExpress.Xpf.Editors.ImageButtonInfo;
            string strBtnName = btnMinus.Name;
            string strParameterName = CommonHelp.GetMiddleStr(strBtnName, "btn", "Minus");
            var btnParent = btnMinus.Parent as DevExpress.Xpf.Editors.ButtonEdit;

            if (btnParent.EditValue != null)
            {
                dStep = decimal.Parse(btnParent.EditValue.ToString());
            }

            switch (strParameterName)
            {
                case "FixValueNA":
                    foreach (var entity in CDContextSpecList)
                    {
                        entity.FixValueNA = CommonHelp.sub(entity.FixValueNA, dStep);
                        //entity.FixValue -= dStep;
                    }
                    break;
                case "FixValueC1":
                    foreach (var entity in CDContextSpecList)
                    {
                        entity.FixValueC1 = CommonHelp.sub(entity.FixValueC1, dStep);
                        //entity.FixValue -= dStep;
                    }
                    break;
                case "FixValueC2":
                    foreach (var entity in CDContextSpecList)
                    {
                        entity.FixValueC2 = CommonHelp.sub(entity.FixValueC2, dStep);
                        //entity.FixValue -= dStep;
                    }
                    break;
                case "Max":
                    foreach (var entity in CDContextSpecList)
                    {
                        entity.Max = CommonHelp.sub(entity.Max, dStep);
                        //entity.Max -= dStep;
                    }
                    break;
                case "Min":
                    foreach (var entity in CDContextSpecList)
                    {
                        entity.Min = CommonHelp.sub(entity.Min, dStep);
                        //entity.Min -= dStep;
                    }
                    break;
                case "MaxDelta":
                    foreach (var entity in CDContextSpecList)
                    {
                        entity.MaxDelta = CommonHelp.sub(entity.MaxDelta, dStep);
                        //entity.MaxDelta -= dStep;
                    }
                    break;
                case "Deadband":
                    foreach (var entity in CDContextSpecList)
                    {
                        entity.Deadband = CommonHelp.sub(entity.Deadband, dStep);
                        //entity.Deadband -= dStep;
                    }
                    break;
                case "Lambda":
                    foreach (var entity in CDContextSpecList)
                    {
                        entity.Lambda = CommonHelp.sub(entity.Lambda, dStep);
                        //entity.Lambda -= dStep;
                    }
                    break;
                case "LambdaForPirun":
                    foreach (var entity in CDContextSpecList)
                    {
                        entity.LambdaForPirun = CommonHelp.sub(entity.LambdaForPirun, dStep);
                        //entity.LambdaForPirun -= dStep;
                    }
                    break;
                case "MinPointsForAvg":
                    foreach (var entity in CDContextSpecList)
                    {
                        var tmp = CommonHelp.sub(entity.MinPointsForAvg, dStep);
                        if (tmp < 1)
                        {
                            entity.MinPointsForAvg = 1;
                        }
                        else
                        {
                            entity.MinPointsForAvg = tmp;
                        }

                        //entity.MinPointsForAvg = CommonHelp.sub(entity.MinPointsForAvg, dStep);
                        //entity.MinPointsForAvg -= dStep;
                    }
                    break;
                case "OutputMax":
                    foreach (var entity in CDContextSpecList)
                    {
                        entity.OutputMax = CommonHelp.sub(entity.OutputMax, dStep);
                        //entity.OutputMax -= dStep;
                    }
                    break;
                case "OutputMin":
                    foreach (var entity in CDContextSpecList)
                    {
                        entity.OutputMin = CommonHelp.sub(entity.OutputMin, dStep);
                        //entity.OutputMin -= dStep;
                    }
                    break;
                case "Precision":
                    foreach (var entity in CDContextSpecList)
                    {
                        entity.Precision = int.Parse(CommonHelp.sub(entity.Precision, dStep).ToString());
                    }
                    break;
                default:
                    break;

            }

            CDContextSpecList = new ObservableCollection<Specs>(CDContextSpecList);
        }

        [Command]
        public void PlusStep(object obj)
        {
            var btn = obj as DevExpress.Xpf.Editors.ImageButtonInfo;
            string strBtnName = btn.Name;
            string strParameterName = CommonHelp.GetMiddleStr(strBtnName, "btn", "Plus");
            var btnParent = btn.Parent as DevExpress.Xpf.Editors.ButtonEdit;

            if (btnParent.EditValue != null)
            {
                dStep = decimal.Parse(btnParent.EditValue.ToString());
            }

            switch (strParameterName)
            {
                case "FixValueNA":
                    foreach (var entity in CDContextSpecList)
                    {
                        entity.FixValueNA = CommonHelp.add(entity.FixValueNA, dStep);
                        //entity.FixValue += dStep;
                    }
                    break;
                case "Max":
                    foreach (var entity in CDContextSpecList)
                    {
                        entity.Max = CommonHelp.add(entity.Max, dStep);
                        //entity.Max += dStep;
                    }
                    break;
                case "Min":
                    foreach (var entity in CDContextSpecList)
                    {
                        entity.Min = CommonHelp.add(entity.Min, dStep);
                        //entity.Min += dStep;
                    }
                    break;
                case "MaxDelta":
                    foreach (var entity in CDContextSpecList)
                    {
                        entity.MaxDelta = CommonHelp.add(entity.MaxDelta, dStep);
                        //entity.MaxDelta += dStep;
                    }
                    break;
                case "Deadband":
                    foreach (var entity in CDContextSpecList)
                    {
                        entity.Deadband = CommonHelp.add(entity.Deadband, dStep);
                        //entity.Deadband += dStep;
                    }
                    break;
                case "Lambda":
                    foreach (var entity in CDContextSpecList)
                    {
                        entity.Lambda = CommonHelp.add(entity.Lambda, dStep);
                        //entity.Lambda += dStep;
                    }
                    break;
                case "LambdaForPirun":
                    foreach (var entity in CDContextSpecList)
                    {
                        entity.LambdaForPirun = CommonHelp.add(entity.LambdaForPirun, dStep);
                        //entity.LambdaForPirun += dStep;
                    }
                    break;
                case "MinPointsForAvg":
                    foreach (var entity in CDContextSpecList)
                    {
                        var tmp = CommonHelp.add(entity.MinPointsForAvg, dStep);
                        if (tmp < 1)
                        {
                            entity.MinPointsForAvg = 1;
                        }
                        else
                        {
                            entity.MinPointsForAvg = tmp;
                        }

                        //entity.MinPointsForAvg = CommonHelp.add(entity.MinPointsForAvg, dStep);
                        //entity.MinPointsForAvg += dStep;
                    }
                    break;
                case "OutputMax":
                    foreach (var entity in CDContextSpecList)
                    {
                        entity.OutputMax = CommonHelp.add(entity.OutputMax, dStep);
                        //entity.OutputMax += dStep;
                    }
                    break;
                case "OutputMin":
                    foreach (var entity in CDContextSpecList)
                    {
                        entity.OutputMin = CommonHelp.add(entity.OutputMin, dStep);
                        //entity.OutputMin += dStep;
                    }
                    break;
                case "Precision":
                    foreach (var entity in CDContextSpecList)
                    {
                        entity.Precision = int.Parse(CommonHelp.add(entity.Precision, dStep).ToString());
                    }
                    break;
                default:
                    break;

            }

            CDContextSpecList = new ObservableCollection<Specs>(CDContextSpecList);
        }

        public bool CanPlus()
        {
            return true;
        }
        public bool CanMinus()
        {
            return true;
        }

        [Command]
        public void OVLMinusStep(object obj)
        {
            var btnMinus = obj as DevExpress.Xpf.Editors.ImageButtonInfo;
            string strBtnName = btnMinus.Name;
            string strParameterName = CommonHelp.GetMiddleStr(strBtnName, "btn", "Minus");
            var btnParent = btnMinus.Parent as DevExpress.Xpf.Editors.ButtonEdit;

            if (btnParent.EditValue != null)
            {
                dStep = decimal.Parse(btnParent.EditValue.ToString());
            }

            switch (strParameterName)
            {
                case "FixValueNA":
                    foreach (var entity in OVLContextSpecList)
                    {
                        entity.FixValueNA = CommonHelp.sub(entity.FixValueNA, dStep);
                        //entity.FixValue -= dStep;
                    }
                    break;
                case "FixValueC1":
                    foreach (var entity in OVLContextSpecList)
                    {
                        entity.FixValueC1 = CommonHelp.sub(entity.FixValueC1, dStep);
                        //entity.FixValue -= dStep;
                    }
                    break;
                case "FixValueC2":
                    foreach (var entity in OVLContextSpecList)
                    {
                        entity.FixValueC2 = CommonHelp.sub(entity.FixValueC2, dStep);
                        //entity.FixValue -= dStep;
                    }
                    break;
                case "Max":
                    foreach (var entity in OVLContextSpecList)
                    {
                        entity.Max = CommonHelp.sub(entity.Max, dStep);
                        //entity.Max -= dStep;
                    }
                    break;
                case "Min":
                    foreach (var entity in OVLContextSpecList)
                    {
                        entity.Min = CommonHelp.sub(entity.Min, dStep);
                        //entity.Min -= dStep;
                    }
                    break;
                case "MaxDelta":
                    foreach (var entity in OVLContextSpecList)
                    {
                        entity.MaxDelta = CommonHelp.sub(entity.MaxDelta, dStep);
                        //entity.MaxDelta -= dStep;
                    }
                    break;
                case "Deadband":
                    foreach (var entity in OVLContextSpecList)
                    {
                        entity.Deadband = CommonHelp.sub(entity.Deadband, dStep);
                        //entity.Deadband -= dStep;
                    }
                    break;
                case "Lambda":
                    foreach (var entity in OVLContextSpecList)
                    {
                        entity.Lambda = CommonHelp.sub(entity.Lambda, dStep);
                        //entity.Lambda -= dStep;
                    }
                    break;
                case "LambdaForPirun":
                    foreach (var entity in OVLContextSpecList)
                    {
                        entity.LambdaForPirun = CommonHelp.sub(entity.LambdaForPirun, dStep);
                        //entity.LambdaForPirun -= dStep;
                    }
                    break;
                case "MinPointsForAvg":
                    foreach (var entity in OVLContextSpecList)
                    {
                        var tmp = CommonHelp.sub(entity.MinPointsForAvg, dStep);
                        if (tmp < 1)
                        {
                            entity.MinPointsForAvg = 1;
                        }
                        else
                        {
                            entity.MinPointsForAvg = tmp;
                        }

                        //entity.MinPointsForAvg = CommonHelp.sub(entity.MinPointsForAvg, dStep);
                        //entity.MinPointsForAvg -= dStep;
                    }
                    break;
                case "OutputMax":
                    foreach (var entity in OVLContextSpecList)
                    {
                        entity.OutputMax = CommonHelp.sub(entity.OutputMax, dStep);
                        //entity.OutputMax -= dStep;
                    }
                    break;
                case "OutputMin":
                    foreach (var entity in OVLContextSpecList)
                    {
                        entity.OutputMin = CommonHelp.sub(entity.OutputMin, dStep);
                        //entity.OutputMin -= dStep;
                    }
                    break;
                case "Precision":
                    foreach (var entity in OVLContextSpecList)
                    {
                        entity.Precision = int.Parse(CommonHelp.sub(entity.Precision, dStep).ToString());
                    }
                    break;
                default:
                    break;

            }

            OVLContextSpecList = new ObservableCollection<Specs>(OVLContextSpecList);
        }

        [Command]
        public void OVLPlusStep(object obj)
        {
            var btn = obj as DevExpress.Xpf.Editors.ImageButtonInfo;
            string strBtnName = btn.Name;
            string strParameterName = CommonHelp.GetMiddleStr(strBtnName, "btn", "Plus");
            var btnParent = btn.Parent as DevExpress.Xpf.Editors.ButtonEdit;

            if (btnParent.EditValue != null)
            {
                dStep = decimal.Parse(btnParent.EditValue.ToString());
            }

            switch (strParameterName)
            {
                case "FixValueNA":
                    foreach (var entity in OVLContextSpecList)
                    {
                        entity.FixValueNA = CommonHelp.add(entity.FixValueNA, dStep);
                        //entity.FixValue += dStep;
                    }
                    break;
                case "FixValueC1":
                    foreach (var entity in OVLContextSpecList)
                    {
                        entity.FixValueC1 = CommonHelp.add(entity.FixValueC1, dStep);
                        //entity.FixValue += dStep;
                    }
                    break;
                case "FixValueC2":
                    foreach (var entity in OVLContextSpecList)
                    {
                        entity.FixValueC2 = CommonHelp.add(entity.FixValueC2, dStep);
                        //entity.FixValue += dStep;
                    }
                    break;
                case "Max":
                    foreach (var entity in OVLContextSpecList)
                    {
                        entity.Max = CommonHelp.add(entity.Max, dStep);
                        //entity.Max += dStep;
                    }
                    break;
                case "Min":
                    foreach (var entity in OVLContextSpecList)
                    {
                        entity.Min = CommonHelp.add(entity.Min, dStep);
                        //entity.Min += dStep;
                    }
                    break;
                case "MaxDelta":
                    foreach (var entity in OVLContextSpecList)
                    {
                        entity.MaxDelta = CommonHelp.add(entity.MaxDelta, dStep);
                        //entity.MaxDelta += dStep;
                    }
                    break;
                case "Deadband":
                    foreach (var entity in OVLContextSpecList)
                    {
                        entity.Deadband = CommonHelp.add(entity.Deadband, dStep);
                        //entity.Deadband += dStep;
                    }
                    break;
                case "Lambda":
                    foreach (var entity in OVLContextSpecList)
                    {
                        entity.Lambda = CommonHelp.add(entity.Lambda, dStep);
                        //entity.Lambda += dStep;
                    }
                    break;
                case "LambdaForPirun":
                    foreach (var entity in OVLContextSpecList)
                    {
                        entity.LambdaForPirun = CommonHelp.add(entity.LambdaForPirun, dStep);
                        //entity.LambdaForPirun += dStep;
                    }
                    break;
                case "MinPointsForAvg":
                    foreach (var entity in OVLContextSpecList)
                    {
                        var tmp = CommonHelp.add(entity.MinPointsForAvg, dStep);
                        if (tmp < 1)
                        {
                            entity.MinPointsForAvg = 1;
                        }
                        else
                        {
                            entity.MinPointsForAvg = tmp;
                        }

                        //entity.MinPointsForAvg = CommonHelp.add(entity.MinPointsForAvg, dStep);
                        //entity.MinPointsForAvg += dStep;
                    }
                    break;
                case "OutputMax":
                    foreach (var entity in OVLContextSpecList)
                    {
                        entity.OutputMax = CommonHelp.add(entity.OutputMax, dStep);
                        //entity.OutputMax += dStep;
                    }
                    break;
                case "OutputMin":
                    foreach (var entity in OVLContextSpecList)
                    {
                        entity.OutputMin = CommonHelp.add(entity.OutputMin, dStep);
                        //entity.OutputMin += dStep;
                    }
                    break;
                case "Precision":
                    foreach (var entity in OVLContextSpecList)
                    {
                        entity.Precision = int.Parse(CommonHelp.add(entity.Precision, dStep).ToString());
                    }
                    break;
                    
                default:
                    break;

            }

            OVLContextSpecList = new ObservableCollection<Specs>(OVLContextSpecList);
        }

        public bool CanOVLPlus()
        {
            return true;
        }
        public bool CanOVLMinus()
        {
            return true;
        }

        [Command]
        public async void Save()
        {
            try
            {
                if (!IsDirty)
                {
                    MessageBoxService.ShowMessage($"No change!", "Message", MessageButton.OK, MessageIcon.Information);
                    return;
                }

                if (HasErrors) return;

                if (IsConfirmed(out string comment))
                {
                    SpecSetting newSpecSetting = new SpecSetting();
                    //newSpecSetting.Specs = new List<Specs>(ContextSpecList);

                    newSpecSetting.Specs = new List<Specs>(CDContextSpecList);
                    newSpecSetting.Specs.AddRange(OVLContextSpecList);

                    newSpecSetting.LastModifyTime = DateTime.Now;
                    newSpecSetting.Comment = comment;
                    newSpecSetting.LastModifyUser = ClientInfo.UserName;

                    ShowWait();
                    await ContextService.ModifyContextSpecAsync(newSpecSetting, comment);

                    IsDirty = false;
                    HideWait();

                    Messenger.Default.Send(new ContextChangedMessage() { ChangeType = ObjectChangeType.Updated, ContextKey = CurrentContext.OVLContextKey });

                    MessageBoxService.ShowMessage($"Specs saved successfully.",
                                                     "Success",
                                                     MessageButton.OK,
                                                     MessageIcon.Information);
                    IsOK = true;
                    CloseWindow();
                }
            }
            catch (Exception ex)
            {
                ErrorHandler.HandleError(ex);
            }
        }

        public bool CanSave()
        {
            return true;
        }

        protected override string GetError(string columnName)
        {
            switch (columnName)
            {
                default:
                    return null;
            }
        }

        #region Properties
        public bool NoChuckFlag
        {
            get { return GetValue<bool>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(NoChuckFlag));
            }
        }

        public bool HaveChuckFlag
        {
            get { return GetValue<bool>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(HaveChuckFlag));
            }
        }

        public ObservableCollection<Specs> SelectedSpecCDList
        {
            get { return GetValue<ObservableCollection<Specs>>(); }
            set { SetValue(value); }
        }

        public Context CurrentContext { get; private set; }

        public ObservableCollection<Specs> CDContextSpecList
        {
            get { return GetValue<ObservableCollection<Specs>>(); }
            set { SetValue(value); }
        }
        public ObservableCollection<Specs> OVLContextSpecList
        {
            get { return GetValue<ObservableCollection<Specs>>(); }
            set { SetValue(value); }
        }

        public ObservableCollection<Specs> ContextSpecList
        {
            get { return GetValue<ObservableCollection<Specs>>(); }
            set
            {
                SetValue(value);
                RaisePropertyChanged(nameof(ContextSpecList));
            }
        }
        string strOriginalContextSpecList = "";
        public List<Specs> OriginalContextSpecList;
        #endregion
    }

    public class ClipboardObject
    {
        public string TypeName { get; set; }
        public byte[] Payload { get; set; }

        public ClipboardObject()
        {
        }

        public ClipboardObject(Type type, byte[] load) : this()
        {
            TypeName = type.FullName;
            Payload = load;
        }
    }
}
