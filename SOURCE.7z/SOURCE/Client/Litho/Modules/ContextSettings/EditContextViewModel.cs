﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using AMAT.R2R.Client.Common.Enums;
using AMAT.R2R.Client.Common.Helpers;
using AMAT.R2R.Client.Litho.Messages;
using AMAT.R2R.Shared.Litho.DTO;
using DevExpress.Mvvm;
using DevExpress.Mvvm.DataAnnotations;

namespace AMAT.R2R.Client.Litho.Modules.ContextSettings
{
    public class EditContextViewModel : LithoViewModelBase
    {
        private const string NA = "NA";
        public EditContextViewModel(Context context, FunctionMode mode)
        {
            OriginalContext = context;
            SizeToContent = System.Windows.SizeToContent.WidthAndHeight;

            // TODO: read from config for Primary Keys.
            IsFabPrimaryKey = true;
            IsToolPrimaryKey = true;
            IsProductPrimaryKey = true;
            IsLayerPrimaryKey = true;
            IsReticlePrimaryKey = true;
            IsRecipePrimaryKey = true;
            IsPreToolPrimaryKey = true;
            IsPreReticlePrimaryKey = true;
            IsCDControlFlagPrimaryKey = true;
            IsCDFBEffectiveDaysPrimaryKey = true;
            IsDoseSensitivityPrimaryKey = true;
            IsOVLControlFlagPrimaryKey = true;
            IsOVLFBEffectiveDaysPrimaryKey = true;
            IsModelNamePrimaryKey = true;
            IsChuckControlPrimaryKey = true;
            IsDedicationTypePrimaryKey = true;


            IsFabRequired = IsFabPrimaryKey;
            IsToolRequired = IsToolPrimaryKey;
            IsProductRequired = IsProductPrimaryKey;
            IsLayerRequired = IsLayerPrimaryKey;
            IsReticleRequired = IsReticlePrimaryKey;
            IsRecipeRequired = IsRecipePrimaryKey;
            IsPreToolRequired = IsPreToolPrimaryKey;
            IsPreReticleRequired = IsPreReticlePrimaryKey;

            IsCDControlFlagRequired = IsCDControlFlagPrimaryKey;
            IsCDFBEffectiveDaysRequired = IsCDFBEffectiveDaysPrimaryKey;
            IsDoseSensitivityRequired = IsDoseSensitivityPrimaryKey;
            IsOVLControlFlagRequired = IsOVLControlFlagPrimaryKey;
            IsOVLFBEffectiveDaysRequired = IsOVLFBEffectiveDaysPrimaryKey;
            IsModelNameRequired = IsModelNamePrimaryKey;
            IsChuckControlRequired = IsChuckControlPrimaryKey;
            IsDedicationTypeRequired = IsDedicationTypePrimaryKey;

            ChuckDedicationTypeList = new ObservableCollection<string>() { "No Chuck Dedication", "First Chuck", "Chuck Dedication with Wafer List" };

            if (context != null)
            {
                CopySpecContextKey = context.OVLContextKey;

                Fab = context.Fab;
                Product = context.Product;
                Layer = context.Layer;
                Tool = context.Tool;
                Reticle = context.Reticle;
                Recipe = context.Recipe;
                PreTool = context.PreTool;
                PreReticle = context.PreReticle;
                CDAssignPilot = context.CDAssignPilot;
                CDControlFlag = context.CDControlFlag;
                CDFBAllowCount = context.CDFBAllowLotCnt;
                CDFBEffectiveDays = context.CDFBEffectiveDays;
                CDFBLotCount = context.CDFBLotCounter;
                CDFBLotList = context.CDFBLotList;
                DCDValuesEntity = context.DCDValues;
                DoseFixedValue = DCDValuesEntity.DoseFixedValue;
                FocusFixedValue = DCDValuesEntity.FocusFixedValue;
                DoseSensitivity = DCDValuesEntity.DoseSensitivity;
                Target = DCDValuesEntity.Target;
                ReworkBias = DCDValuesEntity.ReworkBias;
                CDGOFThreshold = context.CDGOFThreshold;
                CDMinPointLimit = context.CDMinPointLimit;

                OVLAssignPilot = context.OVLAssignPilot;
                OVLControlFlag = context.OVLControlFlag;
                OVLFBAllowCount = context.OVLFBAllowLotCnt;
                OVLFBEffectiveDays = context.OVLFBEffectiveDays;
                OVLFBLotCount = context.OVLFBLotCounter;
                OVLFBLotList = context.OVLFBLotList;
                TwoDMetrologyFlag = context.TwoDMetrologyEnabled == 1;
                ChuckControl = context.ChuckControl == 1;
                ChuckDedicationType = context.ChuckDedicationType;
                if (ChuckDedicationType == 1)
                {
                    StrChuckDedicationType = "No Chuck Dedication";
                }
                else if (ChuckDedicationType == 2)
                {
                    StrChuckDedicationType = "First Chuck";
                }
                else if (ChuckDedicationType == 3)
                {
                    StrChuckDedicationType = "Chuck Dedication with Wafer List";
                }
                else
                {
                    StrChuckDedicationType = "No Chuck Dedication";
                }

                ModelName = context.ModelName;
                OVLGOFThreshold = context.OVLGOFThreshold;
                LstOVLValues = context.LstOVLValues;

                LastModifyUser = context.LastModifyUser;
                LastModifyTime = context.LastModifyTime;

                CDReadOnlyFlag = false;
                OVLReadOnlyFlag = false;

            }
            else
            {
                CDReadOnlyFlag = true;
                OVLReadOnlyFlag = true;

                Fab = ClientInfo.LoginFab;
                //CDFBEffectiveDays = 1;
                //OVLFBEffectiveDays = 1;
                

                CopySpecContextKey = "";               
            }
            Mode = mode;
            if (Mode != FunctionMode.Modify)
            {
                ProductList = new ObservableCollection<string>(LithoGlobalService.GetProductIdList());
                ToolList = new ObservableCollection<string>(LithoGlobalService.GetToolIdList());
            }

            CDControlFlagList = new ObservableCollection<string>(ContextService.GetControlFlagList());
            OVLControlFlagList = new ObservableCollection<string>(ContextService.GetControlFlagList());
            ModelNameList = new ObservableCollection<string>();
            if (!string.IsNullOrEmpty(Tool))
            {
                ModelNameList = new ObservableCollection<string>(ContextService.GetOVLModelNameList(Tool));
            }
            
            switch (mode)
            {
                case FunctionMode.None:
                    break;
                case FunctionMode.Add:
                    Caption = "Create Context";
                    break;
                case FunctionMode.Copy:
                    Caption = "Copy Context";
                    break;
                case FunctionMode.Modify:
                    Caption = "Edit Context";
                    break;
                case FunctionMode.Delete:
                    break;
                case FunctionMode.View:
                    break;
                default:
                    break;
            }
            IsDirty = false;

            PropertyChanged += OnPropertyChanged;
        }

        private void OnPropertyChanged(object sender, System.ComponentModel.PropertyChangedEventArgs e)
        {
            if (e.PropertyName == nameof(Product))
            {

            }
        }

        protected override void OnViewReadyAsync()
        {
            if (Mode == FunctionMode.Add)
            {
                SetFocus(nameof(Tool));
            }
        }

        [Command]
        public void KeyEditValueChanged()
        {
            if (Mode == FunctionMode.Modify)
            {
                return;
            }
            if (string.IsNullOrEmpty(Fab) || string.IsNullOrEmpty(Tool) || string.IsNullOrEmpty(Product) || string.IsNullOrEmpty(Layer) ||
                string.IsNullOrEmpty(Reticle) || string.IsNullOrEmpty(Recipe) || string.IsNullOrEmpty(PreTool) || string.IsNullOrEmpty(PreReticle))
            {
                return;
            }
            else
            {
                CDGOFThreshold = 1;
                CDMinPointLimit = 1;
                CDControlFlag = "FIXED";
                OVLGOFThreshold = 1;
                ChuckDedicationType = 1;
                OVLControlFlag = "FIXED";
                ChuckDedicationType = 1;
                StrChuckDedicationType = "No Chuck Dedication";

                ContextInfo = ContextService.GetContextInfo(Fab,Tool,Product,Layer,Reticle,Recipe,PreTool,PreReticle);
                if (!string.IsNullOrEmpty(ContextInfo.CDContextKey) && !string.IsNullOrEmpty(ContextInfo.CDControlFlag))
                {
                    CDAssignPilot = ContextInfo.CDAssignPilot;
                    CDControlFlag = ContextInfo.CDControlFlag;
                    CDFBAllowCount = ContextInfo.CDFBAllowLotCnt;
                    CDFBEffectiveDays = ContextInfo.CDFBEffectiveDays;
                    CDFBLotCount = ContextInfo.CDFBLotCounter;
                    CDFBLotList = ContextInfo.CDFBLotList;
                    DCDValuesEntity = ContextInfo.DCDValues;
                    DoseFixedValue = DCDValuesEntity.DoseFixedValue;
                    FocusFixedValue = DCDValuesEntity.FocusFixedValue;
                    DoseSensitivity = DCDValuesEntity.DoseSensitivity;
                    Target = DCDValuesEntity.Target;
                    ReworkBias = DCDValuesEntity.ReworkBias;
                    CDGOFThreshold = ContextInfo.CDGOFThreshold;
                    CDMinPointLimit = ContextInfo.CDMinPointLimit;



                }
                else
                {
                    CDReadOnlyFlag = false;
                }
                if (!string.IsNullOrEmpty(ContextInfo.OVLContextKey) && !string.IsNullOrEmpty(ContextInfo.OVLControlFlag) && !string.IsNullOrEmpty(ContextInfo.ModelName))
                {
                    OVLAssignPilot = ContextInfo.OVLAssignPilot;
                    OVLControlFlag = ContextInfo.OVLControlFlag;
                    OVLFBAllowCount = ContextInfo.OVLFBAllowLotCnt;
                    OVLFBEffectiveDays = ContextInfo.OVLFBEffectiveDays;
                    OVLFBLotCount = ContextInfo.OVLFBLotCounter;
                    OVLFBLotList = ContextInfo.OVLFBLotList;
                    TwoDMetrologyFlag = ContextInfo.TwoDMetrologyEnabled == 1;
                    ChuckControl = ContextInfo.ChuckControl == 1;
                    ChuckDedicationType = ContextInfo.ChuckDedicationType;
                    if (ChuckDedicationType == 1)
                    {
                        StrChuckDedicationType = "No Chuck Dedication";
                    }
                    else if (ChuckDedicationType == 2)
                    {
                        StrChuckDedicationType = "First Chuck";
                    }
                    else if (ChuckDedicationType == 3)
                    {
                        StrChuckDedicationType = "Chuck Dedication with Wafer List";
                    }
                    else
                    {
                        StrChuckDedicationType = "No Chuck Dedication";
                    }

                    ModelName = ContextInfo.ModelName;
                    OVLGOFThreshold = ContextInfo.OVLGOFThreshold;
                    if (ContextInfo.LstOVLValues.Count > 0)
                    {
                        LstOVLValues = ContextInfo.LstOVLValues;
                    }

                }
                else
                {
                    OVLReadOnlyFlag = false;
                }
            }
        }
        public bool CanKeyEditValueChanged()
        {
            return true;
        }

        [Command]
        public void ToolSelectedIndexChanged()
        {
            if (Mode == FunctionMode.Modify)
            {
                return;
            }
            if (!string.IsNullOrEmpty(Tool))
            {
                ModelNameList = new ObservableCollection<string>(ContextService.GetOVLModelNameList(Tool));
                KeyEditValueChanged();
            }

        }
        public bool CanToolSelectedIndex()
        {
            return true;
        }

        [Command]
        public void ProductSelectedIndexChanged()
        {
            if (Mode == FunctionMode.Modify)
            {
                return;
            }
            if (!string.IsNullOrEmpty(Product))
            {
                LayerList = new ObservableCollection<string>(LithoGlobalService.GetLayerIdList(Product));
                KeyEditValueChanged();
            }
        }
        public bool CanProductSelectedIndex()
        {
            return true;
        }

        [Command]
        public void LayerSelectedIndexChanged()
        {
            if (Mode == FunctionMode.Modify)
            {
                return;
            }
            if (!string.IsNullOrEmpty(Layer))
            {
                KeyEditValueChanged();
            }
        }
        public bool CanLayerSelectedIndex()
        {
            return true;
        }


        [Command]
        public async void Save()
        {
            ValidateAndSetErrorFocus(nameof(Fab), nameof(Tool), nameof(Product), nameof(Layer), nameof(Reticle), nameof(Recipe), nameof(PreTool), nameof(PreReticle),
                nameof(CDControlFlag), nameof(CDFBEffectiveDays), nameof(CDFBAllowCount), nameof(DoseSensitivity), nameof(Target), nameof(CDGOFThreshold), nameof(CDMinPointLimit),
                nameof(OVLControlFlag), nameof(OVLFBEffectiveDays), nameof(OVLFBAllowCount), nameof(ModelName), nameof(StrChuckDedicationType), nameof(OVLGOFThreshold));

            if (HasErrors)
            {
                return;
            }

            if (IsConfirmed(out string comment))
            {
                DCDValuesEntity = new DCDValues();

                DCDValuesEntity.DoseFixedValue = DoseFixedValue;
                DCDValuesEntity.FocusFixedValue = FocusFixedValue;
                DCDValuesEntity.Target = Target.Value;
                DCDValuesEntity.DoseSensitivity = DoseSensitivity;
                DCDValuesEntity.ReworkBias = ReworkBias.Value;
                DCDValuesEntity.Comment = comment;
                DCDValuesEntity.LastModifyUser = ClientInfo.UserName; //LastModifyUser;
                DCDValuesEntity.LastModifyTime = DateTime.Now; //LastModifyTime;

                if (StrChuckDedicationType.Equals("No Chuck Dedication"))
                {
                    ChuckDedicationType = 1;
                }
                else if (StrChuckDedicationType.Equals("First Chuck"))
                {
                    ChuckDedicationType = 2;
                }
                else if (StrChuckDedicationType.Equals("Chuck Dedication with Wafer List"))
                {
                    ChuckDedicationType = 3;
                }

                var newContext = new Context
                {
                    Fab = Fab,
                    Tool = Tool,
                    Product = Product,
                    Layer = Layer,
                    Reticle = Reticle,
                    Recipe = Recipe,
                    PreTool = PreTool,
                    PreReticle = PreReticle,
                    CDAssignPilot = CDAssignPilot,
                    CDControlFlag = CDControlFlag,
                    CDFBAllowLotCnt = CDFBAllowCount.Value,
                    CDFBLotCounter = CDFBLotCount,
                    CDFBLotList = CDFBLotList,
                    CDFBEffectiveDays = CDFBEffectiveDays.Value,
                    DCDValues = DCDValuesEntity,
                    CDContextKey = string.Format("{0}:{1}:{2}:{3}:{4}:{5}", Fab, Tool, Product, Layer, Reticle, Recipe),
                    OVLContextKey = string.Format("{0}:{1}:{2}:{3}:{4}:{5}:{6}:{7}", Fab, Tool, Product, Layer, Reticle, Recipe, PreTool, PreReticle),

                    CDGOFThreshold = CDGOFThreshold.Value,
                    CDMinPointLimit = CDMinPointLimit.Value,

                    OVLAssignPilot = OVLAssignPilot,
                    OVLControlFlag = OVLControlFlag,
                    OVLFBAllowLotCnt = OVLFBAllowCount.Value,
                    OVLFBLotCounter = OVLFBLotCount,
                    OVLFBLotList = OVLFBLotList,
                    OVLFBEffectiveDays = OVLFBEffectiveDays.Value,
                    ModelName = ModelName,
                    TwoDMetrologyEnabled = TwoDMetrologyFlag ? 1 : 0,
                    ChuckControl = ChuckControl ? 1 : 0,
                    ChuckDedicationType = ChuckDedicationType,
                    OVLGOFThreshold = OVLGOFThreshold.Value,
                    LstOVLValues = LstOVLValues,
                    //LstSpecs = LstSpecs,
                   
                    Comment = comment,
                    LastModifyUser = ClientInfo.UserName,   //LastModifyUser,
                    LastModifyTime = DateTime.Now   // LastModifyTime
                };

                DCDValuesEntity.ContextKey = string.Format("{0}:{1}:{2}:{3}:{4}:{5}", Fab, Tool, Product, Layer, Reticle, Recipe);
                if (Mode == FunctionMode.Modify)
                {
                    //ShowWait();
                    await ContextService.ModifyContextAsync(newContext.OVLContextKey, newContext, comment);
                    IsDirty = false;
                    //HideWait();
                    Messenger.Default.Send(new ContextChangedMessage() { ChangeType = ObjectChangeType.Updated, ContextKey = OriginalContext.OVLContextKey });
                    MessageBoxService.ShowMessage($"Context {newContext.OVLContextKey} is updated!", "Success", MessageButton.OK, MessageIcon.Information);

                }
                else
                {
                    //ShowWait();
                    if (string.IsNullOrEmpty(CopySpecContextKey))
                    {
                        await ContextService.CreateContextAsync(newContext, comment);
                    }
                    else
                    {
                        await ContextService.CreateContextAndSpecAsync(newContext, CopySpecContextKey, comment);
                    }

                    IsDirty = false;
                    //HideWait();
                    Messenger.Default.Send(new ContextChangedMessage() { ChangeType = ObjectChangeType.Created, ContextKey = newContext.OVLContextKey });
                    MessageBoxService.ShowMessage($"Context {newContext.OVLContextKey} is created!", "Success", MessageButton.OK, MessageIcon.Information);

                }

                IsOK = true;
                CloseWindow();
            }
        }

        public bool CanSave()
        {
            switch (Mode)
            {
                case FunctionMode.Add:
                    return true;
                case FunctionMode.Modify:
                    return IsDirty;
                default:
                    return true;
            }
        }

        protected override string GetError(string columnName)
        {
            switch (columnName)
            {
                case nameof(Fab):
                    return DataValidator.ValidString(Fab);
                case nameof(Tool):
                    return DataValidator.ValidString(Tool);
                case nameof(Product):
                    return DataValidator.ValidString(Product);
                case nameof(Layer):
                    return DataValidator.ValidString(Layer);
                case nameof(Reticle):
                    return DataValidator.ValidString(Reticle);
                case nameof(Recipe):
                    return DataValidator.ValidString(Recipe);
                case nameof(PreTool):
                    return DataValidator.ValidString(PreTool);
                case nameof(PreReticle):
                    return DataValidator.ValidString(PreReticle);
                case nameof(CDAssignPilot):
                    return DataValidator.ValidString(CDAssignPilot);
                case nameof(CDControlFlag):
                    return DataValidator.ValidString(CDControlFlag);
                case nameof(CDFBAllowCount):
                    return DataValidator.ValidateInOrder(
                        () => DataValidator.NotNull(CDFBAllowCount),
                        () => DataValidator.LargerThanOrEqualTo(CDFBAllowCount, 0));
                case nameof(DoseSensitivity):
                    return DataValidator.ValidString(DoseSensitivity.ToString());
                case nameof(CDFBEffectiveDays):
                    return DataValidator.ValidateInOrder(
                        () => DataValidator.NotNull(CDFBEffectiveDays),
                        () => DataValidator.LargerThanOrEqualTo(CDFBEffectiveDays, 0));
                case nameof(Target):
                    return DataValidator.ValidString(Target.ToString());
                case nameof(CDGOFThreshold):
                    return DataValidator.ValidateInOrder(
                        () => DataValidator.NotNull(CDGOFThreshold),
                        () => DataValidator.InRange((decimal)CDGOFThreshold, 0, 100));
                case nameof(CDMinPointLimit):
                    return DataValidator.ValidateInOrder(
                        () => DataValidator.NotNull(CDMinPointLimit),
                        () => DataValidator.LargerThanOrEqualTo((decimal)CDMinPointLimit, 1));

                case nameof(ModelName):
                    return DataValidator.ValidString(ModelName);
                case nameof(OVLAssignPilot):
                    return DataValidator.ValidString(OVLAssignPilot);
                case nameof(OVLControlFlag):
                    return DataValidator.ValidString(OVLControlFlag);
                case nameof(OVLFBAllowCount):
                    return DataValidator.ValidateInOrder(
                        () => DataValidator.NotNull(OVLFBAllowCount),
                        () => DataValidator.LargerThanOrEqualTo(OVLFBAllowCount, 0));
                case nameof(OVLFBEffectiveDays):
                    return DataValidator.ValidateInOrder(
                        () => DataValidator.NotNull(OVLFBEffectiveDays),
                        () => DataValidator.LargerThanOrEqualTo(decimal.Parse(OVLFBEffectiveDays.ToString()), 0));
                case nameof(OVLGOFThreshold):
                    return DataValidator.ValidateInOrder(
                        () => DataValidator.NotNull(OVLGOFThreshold),
                        () => DataValidator.InRange((decimal)OVLGOFThreshold, 0, 100));

                case nameof(ChuckDedicationType):
                    return DataValidator.ValidString(StrChuckDedicationType);
                default:
                    return null;
            }
        }


        #region Properties
        public bool CDReadOnlyFlag
        {
            get { return GetValue<bool>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(CDReadOnlyFlag));
            }
        }
        public bool OVLReadOnlyFlag
        {
            get { return GetValue<bool>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(OVLReadOnlyFlag));
            }
        }
        public ContextModel ContextInfo { get; private set; }
        public Context OriginalContext { get; private set; }
        public string CopySpecContextKey { get; private set; }

        public string Fab
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(Fab));
            }
        }

        public string Tool
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(Tool));
            }
        }

        public string Product
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(Product));
            }
        }
        public ObservableCollection<string> ProductList
        {
            get { return GetValue<ObservableCollection<string>>(); }
            set { SetValue(value); }
        }
        public ObservableCollection<string> LayerList
        {
            get { return GetValue<ObservableCollection<string>>(); }
            set { SetValue(value); }
        }
        public ObservableCollection<string> ToolList
        {
            get { return GetValue<ObservableCollection<string>>(); }
            set { SetValue(value); }
        }

        public ObservableCollection<string> OVLControlFlagList
        {
            get { return GetValue<ObservableCollection<string>>(); }
            set { SetValue(value); }
        }

        public ObservableCollection<string> CDControlFlagList
        {
            get { return GetValue<ObservableCollection<string>>(); }
            set { SetValue(value); }
        }

        public ObservableCollection<string> ModelNameList
        {
            get { return GetValue<ObservableCollection<string>>(); }
            set { SetValue(value); }
        }

        public ObservableCollection<string> ChuckDedicationTypeList
        {
            get { return GetValue<ObservableCollection<string>>(); }
            set { SetValue(value); }
        }

        public string Layer
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(Layer));
            }
        }

        public string Recipe
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(Recipe));
            }
        }

        public string Reticle
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(Reticle));
            }
        }
        public string PreTool
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(PreTool));
            }
        }

        public string PreReticle
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(PreReticle));
            }
        }

        public string CDControlFlag
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(CDControlFlag));
            }
        }

        public int? CDFBAllowCount
        {
            get { return GetValue<int?>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(CDFBAllowCount));
            }
        }

        public int CDFBLotCount
        {
            get { return GetValue<int>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(CDFBLotCount));
            }
        }

        public string CDFBLotList
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(CDFBLotList));
            }
        }

        public string CDAssignPilot
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(CDAssignPilot));
            }
        }

        public double? CDGOFThreshold
        {
            get { return GetValue<double?>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(CDGOFThreshold));
            }
        }

        public double? CDMinPointLimit
        {
            get { return GetValue<double?>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(CDMinPointLimit));
            }
        }

        public int? CDFBEffectiveDays
        {
            get { return GetValue<int?>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(CDFBEffectiveDays));
            }
        }

        public DCDValues DCDValuesEntity
        {
            get { return GetValue<DCDValues>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(DCDValuesEntity));
            }
        }
        public double? DoseFixedValue
        {
            get { return GetValue<double?>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(DoseFixedValue));
            }
        }

        public double? FocusFixedValue
        {
            get { return GetValue<double?>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(FocusFixedValue));
            }
        }

        public double? Target
        {
            get { return GetValue<double?>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(Target));
            }
        }

        public double? DoseSensitivity
        {
            get { return GetValue<double?>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(DoseSensitivity));
            }
        }

        public double? ReworkBias
        {
            get { return GetValue<double?>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(ReworkBias));
            }
        }

        public string ModelName
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(ModelName));
            }
        }
        public bool TwoDMetrologyFlag
        {
            get { return GetValue<bool>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(TwoDMetrologyFlag));
            }
        }
        public string OVLControlFlag
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(OVLControlFlag));
            }
        }

        public int? OVLFBAllowCount
        {
            get { return GetValue<int?>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(OVLFBAllowCount));
            }
        }

        public int OVLFBLotCount
        {
            get { return GetValue<int>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(OVLFBLotCount));
            }
        }

        public string OVLFBLotList
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(OVLFBLotList));
            }
        }

        public string OVLAssignPilot
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(OVLAssignPilot));
            }
        }

        public double? OVLGOFThreshold
        {
            get { return GetValue<double?>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(OVLGOFThreshold));
            }
        }

        public string OVLMode
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(OVLMode));
            }
        }
        public int? OVLFBEffectiveDays
        {
            get { return GetValue<int?>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(OVLFBEffectiveDays));
            }
        }

        public int ChuckDedicationType
        {
            get { return GetValue<int>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(ChuckDedicationType));
            }
        }

        public string StrChuckDedicationType
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(StrChuckDedicationType));
            }
        }

        public bool ChuckControl
        {
            get { return GetValue<bool>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(ChuckControl));
            }
        }

        public List<OVLValues> LstOVLValues
        {
            get { return GetValue<List<OVLValues>>(); }
            set
            {
                SetValue(value);
                //IsDirty = true;
                ClearError(nameof(LstOVLValues));
            }
        }

        public List<Specs> LstSpecs
        {
            get { return GetValue<List<Specs>>(); }
            set
            {
                SetValue(value);
                //IsDirty = true;
                ClearError(nameof(LstSpecs));
            }
        }

        public DateTime LastModifyTime
        {
            get { return GetValue<DateTime>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(LastModifyTime));
            }
        }

        public string LastModifyUser
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(LastModifyUser));
            }
        }

        public bool IsFabPrimaryKey { get { return GetValue<bool>(); } set { SetValue(value); } }
        public bool IsFabRequired
        {
            get
            {
                return GetValue<bool>();
            }
            set
            {
                SetValue(value);
                SetFocus(nameof(Fab));
            }
        }

        public bool IsToolPrimaryKey { get { return GetValue<bool>(); } set { SetValue(value); } }
        public bool IsToolRequired
        {
            get
            {
                return GetValue<bool>();
            }
            set
            {
                SetValue(value);
                SetFocus(nameof(Tool));
            }
        }

        public bool IsProductPrimaryKey { get { return GetValue<bool>(); } set { SetValue(value); } }
        public bool IsProductRequired
        {
            get
            {
                return GetValue<bool>();
            }
            set
            {
                SetValue(value);
                if (value)
                {
                    SetFocus(nameof(Product));
                }
            }
        }
        public bool IsLayerPrimaryKey { get { return GetValue<bool>(); } set { SetValue(value); } }
        public bool IsLayerRequired
        {
            get
            {
                return GetValue<bool>();
            }
            set
            {
                SetValue(value);
                if (value)
                {
                    SetFocus(nameof(Layer));
                }
            }
        }
        public bool IsRecipePrimaryKey { get { return GetValue<bool>(); } set { SetValue(value); } }
        public bool IsRecipeRequired
        {
            get
            {
                return GetValue<bool>();
            }
            set
            {
                SetValue(value);
                if (value)
                {
                    SetFocus(nameof(Recipe));
                }
            }
        }
        public bool IsReticlePrimaryKey { get { return GetValue<bool>(); } set { SetValue(value); } }
        public bool IsReticleRequired
        {
            get
            {
                return GetValue<bool>();
            }
            set
            {
                SetValue(value);
                if (value)
                {
                    SetFocus(nameof(Reticle));
                }
            }
        }

        public bool IsPreToolPrimaryKey { get { return GetValue<bool>(); } set { SetValue(value); } }
        public bool IsPreToolRequired
        {
            get
            {
                return GetValue<bool>();
            }
            set
            {
                SetValue(value);
                if (value)
                {
                    SetFocus(nameof(PreTool));
                }
                RaisePropertiesChanged(nameof(IsPreToolReadOnly));
            }
        }

        public bool IsPreToolReadOnly
        {
            get { return IsPreToolRequired; }
        }

        public bool IsPreReticlePrimaryKey { get { return GetValue<bool>(); } set { SetValue(value); } }
        public bool IsPreReticleRequired
        {
            get
            {
                return GetValue<bool>();
            }
            set
            {
                SetValue(value);
                if (value)
                {
                    SetFocus(nameof(PreReticle));
                }
                RaisePropertiesChanged(nameof(IsPreReticleReadOnly));
            }
        }

        public bool IsPreReticleReadOnly
        {
            get { return IsPreReticleRequired; }
        }

        public bool IsCDControlFlagPrimaryKey { get { return GetValue<bool>(); } set { SetValue(value); } }
        public bool IsCDControlFlagRequired
        {
            get
            {
                return GetValue<bool>();
            }
            set
            {
                SetValue(value);
                if (value)
                {
                    SetFocus(nameof(CDControlFlag));
                }
                RaisePropertiesChanged(nameof(IsCDControlFlagReadOnly));
            }
        }

        public bool IsCDControlFlagReadOnly
        {
            get { return IsCDControlFlagRequired; }
        }

        public bool IsCDFBEffectiveDaysPrimaryKey { get { return GetValue<bool>(); } set { SetValue(value); } }
        public bool IsCDFBEffectiveDaysRequired
        {
            get
            {
                return GetValue<bool>();
            }
            set
            {
                SetValue(value);
                if (value)
                {
                    SetFocus(nameof(CDFBEffectiveDays));
                }
                RaisePropertiesChanged(nameof(IsCDFBEffectiveDaysReadOnly));
            }
        }

        public bool IsCDFBEffectiveDaysReadOnly
        {
            get { return IsCDFBEffectiveDaysRequired; }
        }

        public bool IsDoseSensitivityPrimaryKey { get { return GetValue<bool>(); } set { SetValue(value); } }
        public bool IsDoseSensitivityRequired
        {
            get
            {
                return GetValue<bool>();
            }
            set
            {
                SetValue(value);
                if (value)
                {
                    SetFocus(nameof(DoseSensitivity));
                }
                RaisePropertiesChanged(nameof(IsDoseSensitivityReadOnly));
            }
        }

        public bool IsDoseSensitivityReadOnly
        {
            get { return IsDoseSensitivityRequired; }
        }

        public bool IsOVLControlFlagPrimaryKey { get { return GetValue<bool>(); } set { SetValue(value); } }
        public bool IsOVLControlFlagRequired
        {
            get
            {
                return GetValue<bool>();
            }
            set
            {
                SetValue(value);
                if (value)
                {
                    SetFocus(nameof(OVLControlFlag));
                }
                RaisePropertiesChanged(nameof(IsOVLControlFlagReadOnly));
            }
        }

        public bool IsOVLControlFlagReadOnly
        {
            get { return IsOVLControlFlagRequired; }
        }

        public bool IsOVLFBEffectiveDaysPrimaryKey { get { return GetValue<bool>(); } set { SetValue(value); } }
        public bool IsOVLFBEffectiveDaysRequired
        {
            get
            {
                return GetValue<bool>();
            }
            set
            {
                SetValue(value);
                if (value)
                {
                    SetFocus(nameof(OVLFBEffectiveDays));
                }
                RaisePropertiesChanged(nameof(IsOVLFBEffectiveDaysReadOnly));
            }
        }

        public bool IsOVLFBEffectiveDaysReadOnly
        {
            get { return IsOVLFBEffectiveDaysRequired; }
        }

        public bool IsModelNamePrimaryKey { get { return GetValue<bool>(); } set { SetValue(value); } }
        public bool IsModelNameRequired
        {
            get
            {
                return GetValue<bool>();
            }
            set
            {
                SetValue(value);
                if (value)
                {
                    SetFocus(nameof(ModelName));
                }
                RaisePropertiesChanged(nameof(IsModelNameReadOnly));
            }
        }

        public bool IsModelNameReadOnly
        {
            get { return IsModelNameRequired; }
        }

        public bool IsChuckControlPrimaryKey { get { return GetValue<bool>(); } set { SetValue(value); } }
        public bool IsChuckControlRequired
        {
            get
            {
                return GetValue<bool>();
            }
            set
            {
                SetValue(value);
                if (value)
                {
                    SetFocus(nameof(ChuckControl));
                }
                RaisePropertiesChanged(nameof(IsChuckControlReadOnly));
            }
        }

        public bool IsChuckControlReadOnly
        {
            get { return IsChuckControlRequired; }
        }

        public bool IsDedicationTypePrimaryKey { get { return GetValue<bool>(); } set { SetValue(value); } }
        public bool IsDedicationTypeRequired
        {
            get
            {
                return GetValue<bool>();
            }
            set
            {
                SetValue(value);
                if (value)
                {
                    SetFocus(nameof(ChuckDedicationType));
                }
                RaisePropertiesChanged(nameof(IsDedicationTypeReadOnly));
            }
        }

        public bool IsDedicationTypeReadOnly
        {
            get { return IsDedicationTypeRequired; }
        }
        #endregion
    }
}
