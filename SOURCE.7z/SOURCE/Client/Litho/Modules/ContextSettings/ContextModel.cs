﻿using System.ComponentModel;
using AMAT.R2R.Shared.Litho.DTO;

namespace AMAT.R2R.Client.Litho.Modules.ContextSettings
{
    public class ContextModel : Context, INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;

        public void NotifyChanges()
        {
            //PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(LstSpecs)));
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(LstOVLValues)));
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(DCDValues)));
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(CDControlFlag)));
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(OVLControlFlag)));
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(ModelName)));
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(LastModifyTime)));
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(LastModifyUser)));
        }
    }
}
