﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Data;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using AMAT.R2R.Client.Common.Enums;
using AMAT.R2R.Client.Common.Helpers;
using AMAT.R2R.Client.Litho.Helpers;
using AMAT.R2R.Client.Litho.Messages;
using AMAT.R2R.Client.Litho.Modules.SpecialJobSettings;
using AMAT.R2R.Shared.Base.DTO;
using AMAT.R2R.Shared.Litho.DTO;
using DevExpress.Data.Filtering.Helpers;
using DevExpress.Export.Xl;
using DevExpress.Mvvm;
using DevExpress.Mvvm.DataAnnotations;
using DevExpress.Mvvm.Native;
using DevExpress.Spreadsheet;
using DevExpress.Spreadsheet.Export;
using DevExpress.Xpf.Core;
using DevExpress.Xpf.Data;

namespace AMAT.R2R.Client.Litho.Modules.ContextSettings
{

    public class ContextListViewModel : LithoViewModelBase
    {
        public const string Auth_Context = "Context";
        public const string Auth_Context_Add = "Context:Add";
        public const string Auth_Context_Copy = "Context:Copy";
        public const string Auth_Context_Edit = "Context:Edit";
        public const string Auth_Context_BatchUpdate = "Context:BatchUpdate";
        public const string Auth_Context_Delete = "Context:Delete";
        public const string Auth_Context_CreateSpecialJob = "SpecialJob:Create";
        public const string Auth_Context_SpecSetting = "Context:SpecSetting";
        public const string Auth_Context_BatchSpecSetting = "Context:BatchSpecSetting";

        public ContextListViewModel()
        {
            Caption = "Context Settings";
            Icon = "SvgImages/Business Objects/BO_KPI_Scorecard.svg";
            PropertyChanged += OnPropertyChanged;
            Messenger.Default.Register<ContextChangedMessage>(this, OnContextChanged);

            NoChuckFlag = true;
            HaveChuckFlag = !NoChuckFlag;

            IsFilter = false;
            InitializePagedSource();
        }

        #region Filtering & Paging

        private void InitializePagedSource()
        {
            #region Paged Source
            var pagedSource = new PagedAsyncSource()
            {
                ElementType = typeof(ContextModel),
                KeyProperty = nameof(ContextModel.OVLContextKey),
                PageSize = 100,
                PageNavigationMode = PageNavigationMode.ArbitraryWithTotalPageCount
            };

#if DEBUG
            pagedSource.PageSize = 10;
#endif

            pagedSource.FetchPage += (o, e) =>
            {
                e.Result = FetchPageRowsAsync(e);
            };

            pagedSource.GetTotalSummaries += (o, e) =>
            {
                e.Result = GetSummariesAsync(e);
            };

            pagedSource.GetUniqueValues += (o, e) =>
            {
                e.Result = GetValueListAsync(e);
            };

            pagedSource.PropertyChanged += (o, e) =>
            {
                if (e.PropertyName == nameof(PagedAsyncSource.AreRowsFetching))
                {
                    IsLoading = PagedSource.AreRowsFetching;

                    // restore selection.
                    if (!IsLoading)
                    {
                        if (_lastSelectedItem != null)
                        {
                            foreach (var item in PagedSource)
                            {
                                var context = item as ContextModel;
                                if (context.OVLContextKey == _lastSelectedItem.OVLContextKey)
                                {
                                    SelectedContext = context;
                                    break;
                                }
                            }
                        }
                    }
                }
            };

            PagedSource = pagedSource;
            #endregion
        }

        FetchPageAsyncEventArgs eArgs;
        ContextModel _lastSelectedItem = null;
        private async Task<FetchRowsResult> FetchPageRowsAsync(FetchPageAsyncEventArgs e)
        {
            try
            {
                IsFilter = !e.Filter.ReferenceEqualsNull();

                eArgs = e;
                if (SelectedContext != null)
                {
                    _lastSelectedItem = SelectedContext;
                }

                var items = await ContextService.GetContextListAsync(false, e.Filter.MakeFilters(), e.MakeSorters(), e.Skip, e.Take);

                return new FetchRowsResult(items.ToArray(), hasMoreRows: items.Count == e.Take);
            }
            catch (Exception ex)
            {
                Logger.Error(ex);
                throw;
            }
        }

        private async Task<object[]> GetSummariesAsync(GetSummariesAsyncEventArgs e)
        {
            try
            {
                var summary = await ContextService.GetContextCount(e.Filter.MakeFilters());
                return e.Summaries.Select(x =>
                {
                    return x.SummaryType == SummaryType.Count ? (object)summary : throw new InvalidOperationException();
                }).ToArray();
            }
            catch (Exception ex)
            {
                Logger.Error(ex);
                throw;
            }
        }

        private async Task<object[]> GetValueListAsync(GetUniqueValuesAsyncEventArgs e)
        {
            try
            {
                if (e.PropertyName == nameof(Context.Enabled) || e.PropertyName == nameof(Context.IsCDSpecConfig) || e.PropertyName == nameof(Context.IsOVLSpecConfig))
                {
                    var values = new object[] { true, false };
                    return await Task.Factory.StartNew(() => values);
                }
                else
                {
                    return await ContextService.GetContextValueListAsync(e.PropertyName, e.Filter.MakeFilters());
                }
            }
            catch (Exception ex)
            {
                Logger.Error(ex);
                throw;
            }
        }

        #endregion


        protected override void OnViewReadyAsync()
        {
            //Refresh();
        }
        public override void OnRemoving(CancelEventArgs e)
        {
            base.OnRemoving(e);

            PagedSource?.Dispose();
            Messenger.Default.Unregister<ContextChangedMessage>(this, OnContextChanged);
        }
        private async void OnPropertyChanged(object sender, System.ComponentModel.PropertyChangedEventArgs e)
        {
            if (e.PropertyName == nameof(SelectedContext))
            {
                if (SelectedContext != null)
                {
                    await GetContextDetailsAsync();

                    if (SelectedContext != null)
                    {
                        NoChuckFlag = SelectedContext.ChuckControl == 0;
                    }
                    else
                    {

                    }

                    HaveChuckFlag = !NoChuckFlag;
                }
                else
                {
                    ClearContextDetails();
                }
            }
        }
        private void OnContextChanged(ContextChangedMessage msg)
        {
            Refresh();
        }

        private async Task UpdateSingleContext(ContextModel context)
        {

            var lastModifiedTime = context.LastModifyTime;
            var newContext = await ContextService.GetContextAsync(context.OVLContextKey);

            context.LastModifyUser = newContext.LastModifyUser;
            context.LastModifyTime = newContext.LastModifyTime;

            context.NotifyChanges();

            if (SelectedContext != null && context.OVLContextKey == SelectedContext.OVLContextKey && lastModifiedTime != newContext.LastModifyTime)
            {
                await GetContextDetailsAsync();
            }
        }


        private async Task GetContextDetailsAsync()
        {
            if (SelectedContext != null)
            {
                #region 
                Fab = SelectedContext.Fab;
                Product = SelectedContext.Product;
                Layer = SelectedContext.Layer;
                Tool = SelectedContext.Tool;
                Reticle = SelectedContext.Reticle;
                Recipe = SelectedContext.Recipe;
                PreTool = SelectedContext.PreTool;
                PreReticle = SelectedContext.PreReticle;
                CDAssignPilot = SelectedContext.CDAssignPilot;
                CDGOFThreshold = SelectedContext.CDGOFThreshold;
                CDMinPointLimit = SelectedContext.CDMinPointLimit;
                CDControlFlag = SelectedContext.CDControlFlag;
                CDFBAllowCount = SelectedContext.CDFBAllowLotCnt;
                CDFBLotCount = SelectedContext.CDFBLotCounter;
                CDFBLotList = SelectedContext.CDFBLotList;
                CDFBActiveDays = SelectedContext.CDFBEffectiveDays;
                DCDValuesEntity = SelectedContext.DCDValues;
                if (DCDValuesEntity != null)
                {
                    DoseFixedValue = DCDValuesEntity.DoseFixedValue;
                    FocusFixedValue = DCDValuesEntity.FocusFixedValue;
                    DoseSensitivity = DCDValuesEntity.DoseSensitivity;
                    Target = DCDValuesEntity.Target;
                    ReworkBias = DCDValuesEntity.ReworkBias;
                }

                OVLAssignPilot = SelectedContext.OVLAssignPilot;
                OVLControlFlag = SelectedContext.OVLControlFlag;
                OVLFBAllowCount = SelectedContext.OVLFBAllowLotCnt;
                OVLFBLotCount = SelectedContext.OVLFBLotCounter;
                OVLFBLotList = SelectedContext.OVLFBLotList;
                OVLFBActiveDays = SelectedContext.OVLFBEffectiveDays;
                ModelName = SelectedContext.ModelName;
                TwoDMetrologyFlag = SelectedContext.TwoDMetrologyEnabled == 1;
                ChuckControl = SelectedContext.ChuckControl == 1;
                ChuckDedicationType = SelectedContext.ChuckDedicationType;
                if (ChuckDedicationType == 1)
                {
                    StrChuckDedicationType = "No Chuck Dedication";
                }
                else if (ChuckDedicationType == 2)
                {
                    StrChuckDedicationType = "First Chuck";
                }
                else if (ChuckDedicationType == 3)
                {
                    StrChuckDedicationType = "Chuck Dedication with Wafer List";
                }
                else
                {
                    StrChuckDedicationType = "No Chuck Dedication";
                }

                OVLGOFThreshold = SelectedContext.OVLGOFThreshold;

                LstOVLValues = new List<OVLValues>(SelectedContext.LstOVLValues);
                #endregion

                //var contextList = await ContextService.GetContextListAsync(new QueryFilter("fab", ClientInfo.LoginFab));
                //ContextList = new ObservableCollection<ContextModel>(contextList);

                var contextSpecList = await ContextService.GetContextSpecListAsync(SelectedContext.OVLContextKey);
                ContextSpecList = new ObservableCollection<Specs>(contextSpecList);
                CDContextSpecList = new ObservableCollection<Specs>(ContextSpecList.Where(p => p.ModelName == "DCD").ToList());
                OVLContextSpecList = new ObservableCollection<Specs>(ContextSpecList.Where(p => p.ModelName != "DCD").ToList());

                try
                {
                    IsHistoryLoading = true;
                    HistoryList?.Clear();
                    if (SelectedContext != null)
                    {
                        HistoryList = new ObservableCollection<TransactionHistory>(await GlobalService.GetHistoryAsync(ClientInfo.LoginArea, "Context", SelectedContext.OVLContextKey, null));
                    }
                }
                finally
                {
                    IsHistoryLoading = false;
                }
            }
            else
            {
                HistoryList?.Clear();
            }
        }

        #region Check
        bool CheckOVLContext(DataTable dtOVLContext, ref string msg)
        {
            bool flag = false;

            if (dtOVLContext == null)
            {
                msg = "None OVLContext found";
                return true;
            }
            else
            {
                string strMsg = "";
                if (dtOVLContext.Rows.Count < 1)
                {
                    msg = "OVLContext not data";
                    return true;
                }
                if (DataTableHelp.CheckDataTable(dtOVLContext, 14, new string[] { "Product", "Layer", "Tool", "Reticle", "Recipe", "PreTool", "PreReticle", "FBEffectiveDays", "FBAllowCount", "GofThreshold", "OVLModel", "ChuckControl", "DedicationType", "TwoDMetrologyFlag" }, ref strMsg))
                {
                    msg = "OVLContext " + strMsg;
                    return true;
                }

                if (DataTableHelp.IsContainsEmptyData(dtOVLContext, new string[] { "Product", "Layer", "Tool", "Reticle", "Recipe", "PreTool", "PreReticle" }))
                {
                    msg = "OVLContext Empty Product/Layer/Tool/Reticle/Recipe/PreTool/PreReticle found";
                    return true;
                }
            }
            return flag;
        }
        bool CheckOVLValues(DataTable dtOVLValues, ref string msg)
        {
            bool flag = false;

            if (dtOVLValues == null)
            {
                msg = "None CDContext found";
                return true;
            }
            else
            {
                string strMsg = "";
                if (dtOVLValues.Rows.Count < 1)
                {
                    msg = "OVLValues not data";
                    return true;
                }
                if (DataTableHelp.CheckDataTable(dtOVLValues, 21, new string[] { "Product", "Layer", "Tool", "Reticle", "PreTool", "PreReticle", "Recipe", "ParameterName", "FixedValue_NA", "FixedValue_C1", "FixedValue_C2", "Offset_NA", "Offset_C1", "Offset_C2", "Min", "Max", "Delta", "Deadband", "FBMin", "FBMax", "Lambda" }, ref strMsg))
                {
                    msg = "OVLValues " + strMsg;
                    return true;
                }

                if (DataTableHelp.IsContainsEmptyData(dtOVLValues, new string[] { "Product", "Layer", "Tool", "Reticle", "Recipe", "PreTool", "PreReticle" }))
                {
                    msg = "OVLValues Empty Product/Layer/Tool/Reticle/Recipe/PreTool/PreReticle found";
                    return true;
                }
            }
            return flag;
        }
        #endregion

        #region Commands
        [Command]
        public async void ImportContext()
        {
            OpenFileDialogService.Filter = "Excel files(*.xlsx)|*.xlsx|Excel 97-2003 Workbook files(*.xls)|*.xls|All Files(*.*)| *.*";
            OpenFileDialogService.FilterIndex = 1;
            if (OpenFileDialogService.ShowDialog())
            {
                string fileName = OpenFileDialogService.GetFullFileName();
                if (!File.Exists(fileName))
                {
                    MessageBoxService.ShowMessage("File not found");
                    return;
                }
                else
                {
                    DataTable dtProcess = null;
                    DataTable dtCDContext = null;
                    DataTable dtCDValues = null;
                    DataTable dtOVLContext = null;
                    DataTable dtOVLValues = null;

                    Workbook workbook = new Workbook();

                    DXSplashScreen.Show<ImportSplashScreenView>();

                    // Load a workbook from the file.
                    bool flagXlsx = workbook.LoadDocument(fileName, DocumentFormat.Xlsx);
                    if (!flagXlsx)
                    {
                        workbook.LoadDocument(fileName, DocumentFormat.Xls);
                    }

                    if (workbook.Worksheets.Count > 0)
                    {
                        string msg = "";
                        foreach (var s in workbook.Worksheets)
                        {
                            if (s.Name.Equals("Process"))
                            {
                                dtProcess = WorkSheetToDataTable(s);
                                if (dtProcess.Columns.Contains("FeedbackStage(CD)"))
                                {
                                    dtProcess.Columns["FeedbackStage(CD)"].ColumnName = "CDFBStage";
                                }
                                if (dtProcess.Columns.Contains("FeedbackStage(OVL)"))
                                {
                                    dtProcess.Columns["FeedbackStage(OVL)"].ColumnName = "OVLFBStage";
                                }
                            }
                            else if (s.Name.Equals("CD Context"))
                            {
                                dtCDContext = WorkSheetToDataTable(s);
                            }
                            else if (s.Name.Equals("CD Values"))
                            {
                                dtCDValues = WorkSheetToDataTable(s);
                            }
                            else if (s.Name.Equals("OVL Context"))
                            {
                                dtOVLContext = WorkSheetToDataTable(s);
                                if (dtOVLContext.Columns.Contains("2DMetrologyFlag"))
                                {
                                    dtOVLContext.Columns["2DMetrologyFlag"].ColumnName = "TwoDMetrologyFlag";
                                }
                                if (CheckOVLContext(dtOVLContext, ref msg))
                                {
                                    DXSplashScreen.Close();
                                    MessageBoxService.ShowMessage(msg);
                                    return;
                                }
                            }
                            else if (s.Name.Equals("OVL Values"))
                            {
                                dtOVLValues = WorkSheetToDataTable(s);
                                if (CheckOVLValues(dtOVLValues, ref msg))
                                {
                                    DXSplashScreen.Close();
                                    MessageBoxService.ShowMessage(msg);
                                    return;
                                }
                            }
                            else
                            {
                                DXSplashScreen.Close();
                                MessageBoxService.ShowMessage(@"Please check the import file!");
                                return;
                            }

                        }
                    }
                    else
                    {
                        DXSplashScreen.Close();
                        MessageBoxService.ShowMessage(@"Please check the import file!");
                        return;
                    }

                    //去掉重复行
                    DataView dvProcess = new DataView(dtProcess);    
                    dtProcess = dvProcess.ToTable(true);
                    DataView dvCdContext = new DataView(dtCDContext);    
                    dtCDContext = dvCdContext.ToTable(true);
                    DataView dvCdValues = new DataView(dtCDValues);    
                    dtCDValues = dvCdValues.ToTable(true);
                    DataView dvOvlContext = new DataView(dtOVLContext);    
                    dtOVLContext = dvOvlContext.ToTable(true);
                    DataView dvOvlValues = new DataView(dtOVLValues);    
                    dtOVLValues = dvOvlValues.ToTable(true);

                    var processList = DataTableToEntityHelp.DatatableToEntity<XMLProcess>(dtProcess);
                    var cdContextList = DataTableToEntityHelp.DatatableToEntity<XMLCDContext>(dtCDContext);
                    var cdValuesList = DataTableToEntityHelp.DatatableToEntity<XMLCDValues>(dtCDValues);
                    var ovlContextList = DataTableToEntityHelp.DatatableToEntity<XMLOVLContext>(dtOVLContext);
                    var ovlValuesList = DataTableToEntityHelp.DatatableToEntity<XMLOVLValues>(dtOVLValues);
                    if (processList == null)
                    {
                        processList = new List<XMLProcess>();
                    }
                    if (cdContextList == null)
                    {
                        cdContextList = new List<XMLCDContext>();
                    }
                    if (cdValuesList == null)
                    {
                        cdValuesList = new List<XMLCDValues>();
                    }
                    if (ovlContextList == null)
                    {
                        ovlContextList = new List<XMLOVLContext>();
                    }
                    if (ovlValuesList == null)
                    {
                        ovlValuesList = new List<XMLOVLValues>();
                    }
                    XMLStructure importEntity = new XMLStructure()
                    {
                        LstProcess = new List<XMLProcess>(processList),
                        LstCDContext = new List<XMLCDContext>(cdContextList),
                        LstOVLContext = new List<XMLOVLContext>(ovlContextList),
                        LstCDValues = new List<XMLCDValues>(cdValuesList),
                        LstOVLValues = new List<XMLOVLValues>(ovlValuesList),
                    };

                    var importResult = await ContextService.CreateImportVerifyAsync(importEntity, "Import Verify");
                    List<ImportVerifyEntity> importVerifyEntityList = new List<ImportVerifyEntity>();

                    if (importResult.LstOVLContext.Count < 1)
                    {
                        DXSplashScreen.Close();
                        MessageBoxService.ShowMessage(@"Empty OVLContext");
                        return;
                    }
                    if (importResult.LstOVLValues.Count < 1)
                    {
                        DXSplashScreen.Close();
                        MessageBoxService.ShowMessage(@"Empty OVLValues");
                        return;
                    }

                    foreach (var c in importResult.LstOVLContext)
                    {
                        if (string.IsNullOrEmpty(c.Product) || string.IsNullOrEmpty(c.Tool) || string.IsNullOrEmpty(c.Reticle) || string.IsNullOrEmpty(c.Recipe) || string.IsNullOrEmpty(c.PreTool) || string.IsNullOrEmpty(c.PreReticle))
                        {
                            MessageBoxService.ShowMessage(@"Please check key Product/Layer/Tool/Reticle/Recipe/PreTool/PreReticle");
                            continue;
                        }

                        ImportVerifyEntity importVerifyEntity = new ImportVerifyEntity();

                        importVerifyEntity.Product = c.Product;
                        importVerifyEntity.Layer = c.Layer;
                        importVerifyEntity.Tool = c.Tool;
                        importVerifyEntity.Reticle = c.Reticle;
                        importVerifyEntity.Recipe = c.Recipe;
                        importVerifyEntity.PreTool = c.PreTool;
                        importVerifyEntity.PreReticle = c.PreReticle;
                        importVerifyEntity.Process = c.VerifyResult.Process;
                        importVerifyEntity.CD = c.VerifyResult.CD;
                        importVerifyEntity.OVL = c.VerifyResult.OVL;

                        importVerifyEntity.ProcessComment = c.VerifyResult.ProcessComment;
                        importVerifyEntity.CDComment = c.VerifyResult.CDComment;
                        importVerifyEntity.OVLComment = c.VerifyResult.OVLComment;
                        importVerifyEntity.Comment = c.VerifyResult.Comment;

                        importVerifyEntity.UpdateExistFlag = false;
                        if (importVerifyEntity.Process == "Exception" || importVerifyEntity.CD == "Exception" || importVerifyEntity.OVL == "Exception")
                        {
                            importVerifyEntity.CanSelectedFlag = false;
                        }
                        else if (importVerifyEntity.Process == "New" || importVerifyEntity.CD == "New" || importVerifyEntity.OVL == "New")
                        {
                            importVerifyEntity.CanSelectedFlag = true;
                        }
                        else if (importVerifyEntity.Process == "Exist" || importVerifyEntity.CD == "Exist" || importVerifyEntity.OVL == "Exist")
                        {
                            importVerifyEntity.CanSelectedFlag = false;
                        }

                        importVerifyEntityList.Add(importVerifyEntity);
                    }

                    DXSplashScreen.Close();

                    if (importVerifyEntityList.Count > 0)
                    {
                        ShowPopup("ImportVerify", new ImportVerifyViewModel(importResult, importVerifyEntityList));
                    }
                    else
                    {
                        MessageBoxService.ShowMessage(@"Import Verify is null");
                    }
                }
            }
        }
        public bool CanImportContext()
        {
            return true;
        }

        private DataTable WorkSheetToDataTable(Worksheet workSheet)
        {
            DataTable dt = null;

            CellRange range = workSheet.GetUsedRange();

            dt = workSheet.CreateDataTable(range, true, true);

            // Change the data type of the "As Of" column to text. 
            //dataTable.Columns["As Of"].DataType = System.Type.GetType("System.String");

            DataTableExporter exporter = workSheet.CreateDataTableExporter(range, dt, false);

            // Handle value conversion errors.
            exporter.CellValueConversionError += Exporter_CellValueConversionError;

            // Perform the export.
            exporter.Export();

            dt.Rows.RemoveAt(0);
            return dt;
        }
        void Exporter_CellValueConversionError(object sender, CellValueConversionErrorEventArgs e)
        {
            MessageBoxService.ShowMessage("Error in cell " + e.Cell.GetReferenceA1());
            e.DataTableValue = null;
            e.Action = DataTableExporterAction.Continue;
        }

        [Command]
        public async void ExportContext()
        {
            if (PagedSource.Count < 1)
            {
                return;
            }

            string strFileName = GetSaveFilePath();
            if (string.IsNullOrEmpty(strFileName))
            {
                return;
            }
            else
            {
                DXSplashScreen.Show<SplashScreenView>();

                var itemsFilter = await ContextService.GetContextListAsync(true, eArgs.Filter.MakeFilters(), eArgs.MakeSorters(), eArgs.Skip, (int?)PagedSource.TotalItemCount);
                ContextListFilter = new List<ContextModel>(itemsFilter);

                FileStream stream = new FileStream(strFileName, FileMode.Create, FileAccess.ReadWrite);
                IXlExporter exporter = XlExport.CreateExporter(XlDocumentFormat.Xlsx);

                // Create a new document.
                using (IXlDocument document = exporter.CreateDocument(stream))
                {

                    // Specify the document culture.
                    document.Options.Culture = CultureInfo.CurrentCulture;

                    // Create a new worksheet under the specified name. 
                    using (IXlSheet sheet = document.CreateSheet())
                    {
                        sheet.Name = "Process";
                        List<string> columnNames = new List<string>() { "Product", "Layer", "Enabled", "CDFeature", "PreLayerX", "PreLayerY", "DedicationLayer", "PreLayersForOVLContext", "AlignLayer", "NPWFlag", "UseToolStatus", "FeedbackStage(CD)", "FeedbackStage(OVL)" };

                        IXlTable table;
                        using (IXlRow row = sheet.CreateRow())
                        {
                            // Start generating the table with a header row displayed.
                            table = row.BeginTable(columnNames, true);
                        }
                        // Generate table rows and populate them with data.
                        List<string> strProcessKey = new List<string>();
                        foreach (var entity in ContextListFilter)
                        {
                            if (entity.Process != null)
                            {
                                if (strProcessKey.Contains(entity.Process.Product + ":" + entity.Process.Layer))
                                {
                                    continue;
                                }
                                strProcessKey.Add(entity.Process.Product + ":" + entity.Process.Layer);

                                var process = entity.Process;
                                string strPreLayers = process.PreLayers1 + "," + process.PreLayers2 + "," + process.PreLayers3 + "," + process.PreLayers4 + "," + process.PreLayers5; ;
                                Regex reg = new Regex("[,]+");
                                strPreLayers = reg.Replace(strPreLayers, ",");
                                strPreLayers = strPreLayers.TrimEnd(',');

                                using (IXlRow row = sheet.CreateRow())
                                    row.BulkCells(new object[] { process.Product, process.Layer, process.Enabled, process.CDFeature, process.PreLayerX, process.PreLayerY,
                                                                 process.DedicationLayer,strPreLayers, process.AlignLayer, process.NPWFlag, process.UseToolStatus,
                                                                 process.CDFBStage, process.OVLFBStage}, null);

                            }
                        }
                    }
                    using (IXlSheet sheet = document.CreateSheet())
                    {
                        sheet.Name = "CD Context";
                        List<string> columnNames = new List<string>() { "Product", "Layer", "Tool", "Reticle", "Recipe", "FBEffectiveDays", "FBAllowCount", "GofThreshold", "Target", "DoseSensitivity", "ReworkBias" };

                        IXlTable table;
                        using (IXlRow row = sheet.CreateRow())
                        {
                            // Start generating the table with a header row displayed.
                            table = row.BeginTable(columnNames, true);
                        }

                        foreach (var entity in ContextListFilter)
                        {
                            using (IXlRow row = sheet.CreateRow())
                                row.BulkCells(new object[] { entity.Product, entity.Layer, entity.Tool, entity.Reticle, entity.Recipe,
                                                             entity.CDFBEffectiveDays, entity.CDFBAllowLotCnt, entity.CDGOFThreshold,
                                                             entity.Target, entity.DoseSensitivity, entity.ReworkBias}, null);
                        }
                    }
                    using (IXlSheet sheet = document.CreateSheet())
                    {
                        sheet.Name = "CD Values";

                        List<string> columnNames = new List<string>() { "Product", "Layer", "Tool", "Reticle", "Recipe", "ParameterName", "FixedValue", "Min", "Max", "Delta", "Deadband", "FBMin", "FBMax", "Lambda", "MinPointForAvg" };

                        IXlTable table;
                        using (IXlRow row = sheet.CreateRow())
                        {
                            // Start generating the table with a header row displayed.
                            table = row.BeginTable(columnNames, true);
                        }

                        foreach (var entity in ContextListFilter)
                        {
                            List<Specs> contextSpecList = new List<Specs>(entity.LstSpecs);
                            foreach (var cdValue in contextSpecList)
                            {
                                if ("DCD" == cdValue.ModelName)
                                {
                                    using (IXlRow row = sheet.CreateRow())
                                        row.BulkCells(new object[] { entity.Product, entity.Layer, entity.Tool, entity.Reticle, entity.Recipe,
                                                                     cdValue.Varname, cdValue.FixValueNA, cdValue.Min, cdValue.Max, cdValue.MaxDelta,
                                                                     cdValue.Deadband, cdValue.OutputMin, cdValue.OutputMax, cdValue.Lambda,
                                                                     cdValue.MinPointsForAvg}, null);
                                }
                            }
                        }
                    }
                    using (IXlSheet sheet = document.CreateSheet())
                    {
                        sheet.Name = "OVL Context";
                        List<string> columnNames = new List<string>() { "Product", "Layer", "Tool", "Reticle", "Recipe", "PreTool", "PreReticle", "FBEffectiveDays", "FBAllowCount", "GofThreshold", "OVLModel", "ChuckControl", "DedicationType", "2DMetrologyFlag" };

                        IXlTable table;
                        using (IXlRow row = sheet.CreateRow())
                        {
                            // Start generating the table with a header row displayed.
                            table = row.BeginTable(columnNames, true);
                        }

                        foreach (var entity in ContextListFilter)
                        {
                            using (IXlRow row = sheet.CreateRow())
                                row.BulkCells(new object[] { entity.Product, entity.Layer, entity.Tool, entity.Reticle, entity.Recipe, entity.PreTool,entity.PreReticle,
                                                             entity.OVLFBEffectiveDays, entity.OVLFBAllowLotCnt, entity.OVLGOFThreshold,entity.ModelName,
                                                             entity.ChuckControl == 1, entity.ChuckDedicationType, entity.TwoDMetrologyEnabled == 1}, null);
                        }
                    }
                    using (IXlSheet sheet = document.CreateSheet())
                    {
                        sheet.Name = "OVL Values";
                        List<string> columnNames = new List<string>() { "Product", "Layer", "Tool", "Reticle", "PreTool", "PreReticle", "Recipe", "ParameterName", "FixedValue_NA", "FixedValue_C1", "FixedValue_C2", "Offset_NA", "Offset_C1", "Offset_C2", "Min", "Max", "Delta", "Deadband", "FBMin", "FBMax", "Lambda" };

                        IXlTable table;
                        using (IXlRow row = sheet.CreateRow())
                        {
                            // Start generating the table with a header row displayed.
                            table = row.BeginTable(columnNames, true);
                        }

                        foreach (var entity in ContextListFilter)
                        {
                            List<Specs> contextSpecList = new List<Specs>(entity.LstSpecs);
                            foreach (var ovlValue in contextSpecList)
                            {
                                if ("DCD" != ovlValue.ModelName)
                                    using (IXlRow row = sheet.CreateRow())
                                        row.BulkCells(new object[] { entity.Product, entity.Layer, entity.Tool, entity.Reticle, entity.PreTool,entity.PreReticle,entity.Recipe,
                                                                     ovlValue.Varname, ovlValue.FixValueNA, ovlValue.FixValueC1, ovlValue.FixValueC2, ovlValue.OffsetValueNA,
                                                                     ovlValue.OffsetValueC1, ovlValue.OffsetValueC2, ovlValue.Min,ovlValue.Max,ovlValue.MaxDelta,
                                                                     ovlValue.Deadband, ovlValue.OutputMin, ovlValue.OutputMax, ovlValue.Lambda}, null);
                            }
                        }
                    }
                }

                stream.Close();

                DXSplashScreen.Close();

                MessageBoxService.ShowMessage($"Export To" + "\r\n" + strFileName + "\r\n" + "Succeed!", "Success");
            }
        }
        public bool CanExportContext()
        {
            return true && PagedSource.Count > 0 && IsFilter;
        }

        private string GetSaveFilePath()
        {
            string fileName = "";
            SaveFileDialogService.DefaultFileName = "LithoExport.xlsx";
            //SaveFileDialogService.DefaultExt = "xlsx";
            SaveFileDialogService.Filter = "Excel files(*.xlsx)|*.xlsx|All Files(*.*)|*.*|Excel 97-2003 Workbook files(*.xls)|*.xls";
            SaveFileDialogService.FilterIndex = 1;
            if (SaveFileDialogService.ShowDialog())
            {
                fileName = SaveFileDialogService.GetFullFileName();
            }
            return fileName;
        }

        [Command]
        public void Refresh()
        {
            InitializePagedSource();
            PagedSource.UpdateSummaries();
            PagedSource.RefreshRows();
        }
        public bool CanRefresh()
        {
            return !IsLoading;
        }

        [Command]
        public void Add()
        {
            ShowEditContext(null, FunctionMode.Add);
        }

        public bool CanAdd()
        {
            return AuthorityManager.HasAuthority(Auth_Context_Add);
        }

        [Command]
        public void Copy()
        {
            ShowEditContext(SelectedContext, FunctionMode.Copy);
        }

        public bool CanCopy()
        {
            return SelectedContext != null && SelectedContextList.Count == 1 && !IsLoading && AuthorityManager.HasAuthority(Auth_Context_Copy);
        }

        [Command]
        public void Modify()
        {
            ShowEditContext(SelectedContext, FunctionMode.Modify);
        }

        public bool CanModify()
        {
            return SelectedContext != null && SelectedContextList.Count == 1 && !IsLoading && AuthorityManager.HasAuthority(Auth_Context_Edit);
        }

        private void ShowEditContext(Context originalContext, FunctionMode mode)
        {
            if (ShowPopup("EditContext", new EditContextViewModel(originalContext, mode)).IsOK)
            {
                Refresh();
            }
        }

        [Command]
        public async void Delete()
        {
            if (IsConfirmed(out var comment))
            {
                var toDeleteContext = SelectedContext;
                await ContextService.DeleteContextAsync(SelectedContext.OVLContextKey, comment);
                Refresh();
                Messenger.Default.Send(new ContextChangedMessage() { ChangeType = ObjectChangeType.Deleted, ContextKey = SelectedContext.OVLContextKey });
                MessageBoxService.ShowMessage($"Context {toDeleteContext.OVLContextKey} is deleted.", "Success", MessageButton.OK, MessageIcon.Information);
            }
        }

        public bool CanDelete()
        {
            return SelectedContext != null && SelectedContextList.Count == 1 && !IsLoading && AuthorityManager.HasAuthority(Auth_Context_Delete);
        }

        private void ClearContextDetails()
        {
            _lastSelectedItem = null;
            HistoryList?.Clear();
        }

        [Command]
        public void BatchEdit()
        {
            ShowBatchEditContext(SelectedContextList.ToList(), FunctionMode.Modify);
        }

        public bool CanBatchEdit()
        {
            return SelectedContext != null && SelectedContextList.Count > 1 && !IsLoading && AuthorityManager.HasAuthority(Auth_Context_BatchUpdate);
        }

        private void ShowBatchEditContext(List<Context> originalContextList, FunctionMode mode)
        {
            if (ShowPopup("BatchEditContext", new BatchEditContextViemModel(originalContextList)).IsOK)
            {
                Refresh();
            }
        }

        [Command]
        public void EditSpecSetting()
        {
            if (ContextSpecList == null)
            {
                var contextSpecList = ContextService.GetContextSpecList(SelectedContext.OVLContextKey);
                ContextSpecList = new ObservableCollection<Specs>(contextSpecList);
            }
            if (ShowPopup("EditSpecSetting", new EditSpecSettingViewModel(SelectedContext, ContextSpecList.ToList())).IsOK)
            {
                Refresh();
            }
        }

        public bool CanEditSpecSetting()
        {
            return SelectedContext != null && SelectedContextList.Count == 1 && !IsLoading && AuthorityManager.HasAuthority(Auth_Context_SpecSetting);
        }

        [Command]
        public void BatchEditSpec()
        {
            ShowBatchEditSpec(SelectedContextList.ToList());
        }

        public bool CanBatchEditSpec()
        {
            return SelectedContext != null && SelectedContextList.Count > 1 && !IsLoading && AuthorityManager.HasAuthority(Auth_Context_BatchSpecSetting);
        }

        private void ShowBatchEditSpec(List<Context> originalContextList)
        {
            if (ShowPopup("BatchEditSpec", new BatchEditSpecViewModel(originalContextList)).IsOK)
            {
                Refresh();
            }
        }

        [Command]
        public async void CreateSpecialJob()
        {
            List<string> OVLModelNameList = new List<string>();
            OVLModelNameList = await ContextService.GetOVLModelNameListAsync(SelectedContext.Tool);
            ShowPopup("EditSpecialJob", new EditSpecialJobViewModel(SelectedContext, new SpecialJob(), OVLModelNameList, FunctionMode.Add));
        }

        public bool CanCreateSpecialJob()
        {
            return SelectedContext != null && SelectedContextList.Count == 1 && !IsLoading && AuthorityManager.HasAuthority(Auth_Context_CreateSpecialJob);
        }

        public async Task UpdateBeforeAction()
        {
            ShowWait();
            await UpdateSingleContext(SelectedContext);
            //await Task.WhenAll(SelectedContextList.Select(context => UpdateSingleContext(context)));
            HideWait();
        }

        #endregion

        #region Properties
        public PagedAsyncSource PagedSource
        {
            get { return GetValue<PagedAsyncSource>(); }
            set { SetValue(value); }
        }
        public List<ContextModel> ContextListFilter
        {
            get { return GetValue<List<ContextModel>>(); }
            set { SetValue(value); }
        }

        bool IsFilter;
        public bool NoChuckFlag
        {
            get { return GetValue<bool>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(NoChuckFlag));
            }
        }

        public bool HaveChuckFlag
        {
            get { return GetValue<bool>(); }
            set
            {
                SetValue(value);

                ClearError(nameof(HaveChuckFlag));
            }
        }

        public bool IsContextSelected
        {
            get { return GetValue<bool>(); }
            set { SetValue(value); }
        }

        public ObservableCollection<ContextModel> ContextList
        {
            get { return GetValue<ObservableCollection<ContextModel>>(); }
            set { SetValue(value); }
        }

        public ObservableCollection<Context> SelectedContextList { get; } = new ObservableCollection<Context>();

        public ContextModel SelectedContext
        {
            get { return GetValue<ContextModel>(); }
            set { SetValue(value); }
        }

        public string Fab
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(Fab));
            }
        }

        public string Tool
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(Tool));
            }
        }

        public string Product
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(Product));
            }
        }

        public string Layer
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(Layer));
            }
        }

        public string Recipe
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(Recipe));
            }
        }

        public string Reticle
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(Reticle));
            }
        }
        public string PreTool
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(PreTool));
            }
        }

        public string PreReticle
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(PreReticle));
            }
        }

        public string CDControlFlag
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(CDControlFlag));
            }
        }

        public int CDFBAllowCount
        {
            get { return GetValue<int>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(CDFBAllowCount));
            }
        }

        public int CDFBLotCount
        {
            get { return GetValue<int>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(CDFBLotCount));
            }
        }

        public string CDFBLotList
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(CDFBLotList));
            }
        }

        public string CDAssignPilot
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(CDAssignPilot));
            }
        }

        public double CDGOFThreshold
        {
            get { return GetValue<double>(); }
            set
            {
                SetValue(value);

                ClearError(nameof(CDGOFThreshold));
            }
        }

        public double CDMinPointLimit
        {
            get { return GetValue<double>(); }
            set
            {
                SetValue(value);

                ClearError(nameof(CDMinPointLimit));
            }
        }

        public int CDFBActiveDays
        {
            get { return GetValue<int>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(CDFBActiveDays));
            }
        }

        public DCDValues DCDValuesEntity
        {
            get { return GetValue<DCDValues>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(DCDValuesEntity));
            }
        }
        public double? DoseFixedValue
        {
            get { return GetValue<double?>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(DoseFixedValue));
            }
        }

        public double? FocusFixedValue
        {
            get { return GetValue<double?>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(FocusFixedValue));
            }
        }

        public double Target
        {
            get { return GetValue<double>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(Target));
            }
        }

        public double? DoseSensitivity
        {
            get { return GetValue<double?>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(DoseSensitivity));
            }
        }

        public double ReworkBias
        {
            get { return GetValue<double>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(ReworkBias));
            }
        }

        public string OVLControlFlag
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(OVLControlFlag));
            }
        }

        public int OVLFBAllowCount
        {
            get { return GetValue<int>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(OVLFBAllowCount));
            }
        }

        public int OVLFBLotCount
        {
            get { return GetValue<int>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(OVLFBLotCount));
            }
        }

        public string OVLFBLotList
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(OVLFBLotList));
            }
        }

        public string OVLAssignPilot
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(OVLAssignPilot));
            }
        }

        public double OVLGOFThreshold
        {
            get { return GetValue<double>(); }
            set
            {
                SetValue(value);

                ClearError(nameof(OVLGOFThreshold));
            }
        }

        public int OVLFBActiveDays
        {
            get { return GetValue<int>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(OVLFBActiveDays));
            }
        }

        public List<OVLValues> LstOVLValues
        {
            get { return GetValue<List<OVLValues>>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(LstOVLValues));
            }
        }

        public List<Specs> LstSpecs
        {
            get { return GetValue<List<Specs>>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(LstSpecs));
            }
        }

        public string ModelName
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(ModelName));
            }
        }
        public bool TwoDMetrologyFlag
        {
            get { return GetValue<bool>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(TwoDMetrologyFlag));
            }
        }

        public bool ChuckControl
        {
            get { return GetValue<bool>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(ChuckControl));
            }
        }
        public int ChuckDedicationType
        {
            get { return GetValue<int>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(ChuckDedicationType));
            }
        }

        public string StrChuckDedicationType
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(StrChuckDedicationType));
            }
        }

        public ObservableCollection<Specs> CDContextSpecList
        {
            get { return GetValue<ObservableCollection<Specs>>(); }
            set { SetValue(value); }
        }
        public ObservableCollection<Specs> OVLContextSpecList
        {
            get { return GetValue<ObservableCollection<Specs>>(); }
            set { SetValue(value); }
        }
        public ObservableCollection<Specs> ContextSpecList
        {
            get { return GetValue<ObservableCollection<Specs>>(); }
            set { SetValue(value); }
        }
        #endregion
    }
}
