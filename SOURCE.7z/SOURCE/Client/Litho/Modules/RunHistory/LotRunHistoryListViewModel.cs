﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Dynamic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Data;
using AMAT.R2R.Client.Common.Helpers;
using AMAT.R2R.Client.Common.Services;
using AMAT.R2R.Shared.Litho.DTO;

namespace AMAT.R2R.Client.Litho.Modules.RunHistory
{
    public class LotRunHistoryListViewModel : LithoViewModelBase
    {
        public const string Auth_LotRunHistoryList = "Context";

        public LotRunHistoryListViewModel()
        {
            Caption = "Lot History - Tool View";
            Icon = "SvgImages/Business Objects/BO_Audit_ChangeHistory.svg";
            PropertyChanged += OnPropertyChanged;
            ViewType = ViewType.ByTool;
            IsVisibleBasicTool = true;
            IsVisibleBasicRecipe = false;
            IsVisibleInfoRecipe = true;
            IsVisibleBasicRecipe = false;
            IsTimeRangeMode = true;
        }

        #region Events

        protected async override void OnViewReadyAsync()
        {
            await ResetFilterValueListAsync();
        }

        public override void OnRemoving(CancelEventArgs e)
        {
            base.OnRemoving(e);
        }

        private void OnPropertyChanged(object sender, System.ComponentModel.PropertyChangedEventArgs e)
        {
            if (e.PropertyName == nameof(ViewType))
            {

            }
        }

        #endregion

        #region Commands

        internal async Task ResetFilterValueListAsync()
        {
            ShowWait();
            MasterList = new List<ExpandoObject>();
            ToolList = (await LotRunHistoryService.GetLotRunHistoryValueListAsync(nameof(LotRunHistory.Tool), null)).Select(t => t?.ToString()).ToList();
            ProductList = (await LotRunHistoryService.GetLotRunHistoryValueListAsync(nameof(LotRunHistory.Product), null)).Select(t => t?.ToString()).ToList();
            LayerList = (await LotRunHistoryService.GetLotRunHistoryValueListAsync(nameof(LotRunHistory.Layer), null)).Select(t => t?.ToString()).ToList();
            ReticleList = (await LotRunHistoryService.GetLotRunHistoryValueListAsync(nameof(LotRunHistory.Reticle), null)).Select(t => t?.ToString()).ToList();
            RecipeList = (await LotRunHistoryService.GetLotRunHistoryValueListAsync(nameof(LotRunHistory.Recipe), null)).Select(t => t?.ToString()).ToList();
            OvlModelList = (await LotRunHistoryService.GetLotRunHistoryValueListAsync(nameof(LotRunHistory.OvlModel), null)).Select(t => t?.ToString()).ToList();
            HideWait();
        }

        internal async Task RefreshAsync(List<QueryFilter> filters = null, List<QuerySorter> sorters = null, int? skip = null, int? take = null)
        {
            ShowWait();
            try
            {
                MasterList = new List<ExpandoObject>();
                var list = await LotRunHistoryService.GetLotRunHistoryListAsync(filters, sorters, skip, take);

                if (list.Count > 0)
                {
                    var processParameterNameListList = list.Select(r => r.ProcessVaues.Select(p => p.Name).ToList());
                    var processParameterNameList = processParameterNameListList.FirstOrDefault(l => l.Count == processParameterNameListList.Max(ll => ll.Count));

                    var estimateParameterNameListList = list.Select(r => r.EstimateValues.Select(p => p.Name).ToList());
                    var estimateParameterNameList = estimateParameterNameListList.FirstOrDefault(l => l.Count == estimateParameterNameListList.Max(ll => ll.Count));

                    var metrologyParameterNameListList = list.Select(r => r.MetrologyValues.Select(p => p.Name).ToList());
                    var metrologyParameterNameList = metrologyParameterNameListList.FirstOrDefault(l => l.Count == metrologyParameterNameListList.Max(ll => ll.Count));


                    switch (ViewType)
                    {
                        case ViewType.ByTool:
                            MasterList = list.GroupBy(h => h.Tool).Select(g => CreateMasterRow(g, processParameterNameList, estimateParameterNameList, metrologyParameterNameList)).ToList();
                            break;
                        case ViewType.ByRecipe:
                            MasterList = list.GroupBy(h => h.Recipe).Select(g => CreateMasterRow(g, processParameterNameList, estimateParameterNameList, metrologyParameterNameList)).ToList();
                            break;
                        default:
                            break;
                    }
                }
                else
                {
                    MasterList = new List<ExpandoObject>();
                }
            }
            finally
            {
                HideWait();
            }
        }

        private ExpandoObject CreateMasterRow(IGrouping<string, LotRunHistory> group, List<string> processParameterNameList, List<string> estimateParameterNameList, List<string> metrologyParameterNameList)
        {
            IDictionary<string, object> masterRow = new ExpandoObject();

            var lastProcessedRun = group.FirstOrDefault(l => l.ProcessStamp == group.Max(h => h.ProcessStamp));

            if (lastProcessedRun != null)
            {
                // fill detail info.
                masterRow = FillDynamicObjectByRunHistory(lastProcessedRun, masterRow, processParameterNameList, estimateParameterNameList, metrologyParameterNameList);

                // fill master info.

                // basic
                masterRow[nameof(LotRunHistory.Tool)] = lastProcessedRun.Tool;
                masterRow["ProcessedLot"] = group.Count();
                masterRow["ProcessedWafer"] = group.Aggregate(0, (cnt, history) => cnt + history.WaferQty);

                // last process info
                masterRow["Date"] = lastProcessedRun.ProcessStamp;

                masterRow["Mode"] = "";
            }

            List<ExpandoObject> detailList = new List<ExpandoObject>();

            foreach (var item in group)
            {
                detailList.Add(CreateDetailRow(item, processParameterNameList, estimateParameterNameList, metrologyParameterNameList));
            }

            masterRow["DetailList"] = detailList;
            masterRow["SelectedDetail"] = detailList.FirstOrDefault();

            return masterRow as ExpandoObject;
        }

        private ExpandoObject CreateDetailRow(LotRunHistory runHistory, List<string> processParameterNameList, List<string> estimateParameterNameList, List<string> metrologyParameterNameList)
        {
            IDictionary<string, object> detailRow = new ExpandoObject();
            return FillDynamicObjectByRunHistory(runHistory, detailRow, processParameterNameList, estimateParameterNameList, metrologyParameterNameList);
        }

        private ExpandoObject FillDynamicObjectByRunHistory(LotRunHistory item, IDictionary<string, object> dynamicObject, List<string> processParameterNameList, List<string> estimateParameterNameList, List<string> metrologyParameterNameList)
        {
            dynamicObject[nameof(LotRunHistory.LotId)] = item.LotId;
            dynamicObject[nameof(LotRunHistory.WaferId)] = item.WaferId;
            dynamicObject[nameof(LotRunHistory.Tool)] = item.Tool;
            dynamicObject[nameof(LotRunHistory.Product)] = item.Product;
            dynamicObject[nameof(LotRunHistory.Layer)] = item.Layer;
            dynamicObject[nameof(LotRunHistory.Recipe)] = item.Recipe;
            dynamicObject[nameof(LotRunHistory.Reticle)] = item.Reticle;
            dynamicObject[nameof(LotRunHistory.PreTool)] = item.PreTool;
            dynamicObject[nameof(LotRunHistory.PreReticle)] = item.PreReticle;
            dynamicObject[nameof(LotRunHistory.WaferQty)] = item.WaferQty;
            dynamicObject[nameof(LotRunHistory.ProcessStamp)] = item.ProcessStamp;
            dynamicObject[nameof(LotRunHistory.EstiTimeStamp)] = item.EstiTimeStamp;
            dynamicObject[nameof(LotRunHistory.MotherLot)] = item.MotherLot;
            dynamicObject[nameof(LotRunHistory.ReworkCnt)] = int.Parse(item.ReworkCnt);
            dynamicObject[nameof(LotRunHistory.OvlModel)] = item.OvlModel;
            dynamicObject[nameof(LotRunHistory.SplitId)] = item.SplitId;
            dynamicObject[nameof(LotRunHistory.SpecifyLot)] = item.SpecifyLot;
            dynamicObject[nameof(LotRunHistory.PilotFlagOvl)] = item.PilotFlagOvl;
            dynamicObject[nameof(LotRunHistory.PilotFlagCd)] = item.PilotFlagCd;
            dynamicObject[nameof(LotRunHistory.IsActiveOvl)] = item.IsActiveOvl;
            dynamicObject[nameof(LotRunHistory.IsActiveCd)] = item.IsActiveCd;
            dynamicObject[nameof(LotRunHistory.RunCardId)] = item.RunCardId;
            dynamicObject[nameof(LotRunHistory.Feedback)] = item.Feedback;
            dynamicObject[nameof(LotRunHistory.Remark)] = item.Remark;

            if (item.ProcessVaues != null)
            {
                // set Process Values.
                for (var i = 0; i < processParameterNameList.Count; i++)
                {
                    var name = processParameterNameList[i];
                    var parameter = item.ProcessVaues.FirstOrDefault(p => p.Name == name);
                    dynamicObject[$"P_{i}_{name}"] = parameter == null ? null : parameter.IsNumeric ? NullableDataConverter.Convert<decimal>(parameter.Value) : (object)parameter.Value;
                }
            }

            if (item.EstimateValues != null)
            {
                // set Estimate Values.
                for (var i = 0; i < estimateParameterNameList.Count; i++)
                {
                    var name = processParameterNameList[i];
                    var parameter = item.EstimateValues.FirstOrDefault(p => p.Name == name);
                    dynamicObject[$"E_{i}_{name}"] = parameter == null ? null : parameter.IsNumeric ? NullableDataConverter.Convert<decimal>(parameter.Value) : (object)parameter.Value;
                }
            }

            if (item.MetrologyValues != null)
            {
                // set Metrology Values.
                for (var i = 0; i < metrologyParameterNameList.Count; i++)
                {
                    var name = processParameterNameList[i];
                    var parameter = item.MetrologyValues.FirstOrDefault(p => p.Name == name);
                    dynamicObject[$"M_{i}_{name}"] = parameter == null ? null : parameter.IsNumeric ? NullableDataConverter.Convert<decimal>(parameter.Value) : (object)parameter.Value;
                }
            }

            return dynamicObject as ExpandoObject;
        }

        public bool CanRefresh()
        {
            return !IsLoading;
        }


        #endregion

        #region Properties

        public bool IsVisibleBasicTool
        {
            get { return GetValue<bool>(); }
            set { SetValue(value); }
        }

        public bool IsVisibleBasicRecipe
        {
            get { return GetValue<bool>(); }
            set { SetValue(value); }
        }

        public bool IsVisibleInfoTool
        {
            get { return GetValue<bool>(); }
            set { SetValue(value); }
        }

        public bool IsVisibleInfoRecipe
        {
            get { return GetValue<bool>(); }
            set { SetValue(value); }
        }

        public bool IsTimeRangeMode
        {
            get { return GetValue<bool>(); }
            set { SetValue(value); }
        }
        public bool IsLastNDayMode
        {
            get { return GetValue<bool>(); }
            set { SetValue(value); }
        }
        public bool IsLastNRunMode
        {
            get { return GetValue<bool>(); }
            set { SetValue(value); }
        }

        public List<ExpandoObject> MasterList
        {
            get { return GetValue<List<ExpandoObject>>(); }
            set { SetValue(value); }
        }

        public ExpandoObject SelectedMaster
        {
            get { return GetValue<ExpandoObject>(); }
            set { SetValue(value); }
        }

        public List<string> ToolList
        {
            get { return GetValue<List<string>>(); }
            set { SetValue(value); }
        }

        public List<string> ProductList
        {
            get { return GetValue<List<string>>(); }
            set { SetValue(value); }
        }
        public List<string> LayerList
        {
            get { return GetValue<List<string>>(); }
            set { SetValue(value); }
        }

        public List<string> ReticleList
        {
            get { return GetValue<List<string>>(); }
            set { SetValue(value); }
        }

        public List<string> RecipeList
        {
            get { return GetValue<List<string>>(); }
            set { SetValue(value); }
        }

        public List<string> OvlModelList
        {
            get { return GetValue<List<string>>(); }
            set { SetValue(value); }
        }


        public ViewType ViewType
        {
            get { return GetValue<ViewType>(); }
            set { SetValue(value); }
        }

        #endregion
    }

    public class ViewTypeToBooleanConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            ViewType itemType = (ViewType)parameter;
            ViewType newValue = (ViewType)value;
            return itemType == newValue;
        }
        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            if ((bool)value)
                return (ViewType)parameter;
            return Binding.DoNothing;
        }
    }

    public enum ViewType
    {
        ByTool,
        ByRecipe,
    }
}
