﻿using System;
using System.Collections.Generic;
using System.Dynamic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using AMAT.R2R.Client.Common.Extensions;
using AMAT.R2R.Client.Common.Services;
using AMAT.R2R.Shared.Litho.DTO;
using DevExpress.Mvvm;
using DevExpress.Xpf.Bars;
using DevExpress.Xpf.Grid;
using DevExpress.Xpf.Utils;

namespace AMAT.R2R.Client.Litho.Modules.RunHistory
{
    /// <summary>
    /// Interaction logic for LotRunHistoryList.xaml
    /// </summary>
    public partial class LotRunHistoryList : UserControl
    {
        public LotRunHistoryList()
        {
            InitializeComponent();
            CopyCellInfo = new DelegateCommand<object>(OnCopyCellInfo);
            //CopyRowInfo = new DelegateCommand<object>(OnCopyRowInfo);
            Loaded += LotRunHistoryList_Loaded;
            Unloaded += LotRunHistoryList_Unloaded;
            masterGrid.MasterRowExpanding += MasterGrid_MasterRowExpanding;
            masterGrid.MasterRowExpanded += MasterGrid_MasterRowExpanded;

            SetRangeFilterDefaultValue();
        }

        private void LotRunHistoryList_Unloaded(object sender, RoutedEventArgs e)
        {
            var viewModel = DataContext as LotRunHistoryListViewModel;
            if (viewModel != null)
            {
                viewModel.PropertyChanged -= ViewModel_PropertyChanged;
            }
        }

        private void LotRunHistoryList_Loaded(object sender, RoutedEventArgs e)
        {
            var viewModel = DataContext as LotRunHistoryListViewModel;
            if (viewModel != null)
            {
                viewModel.PropertyChanged += ViewModel_PropertyChanged;
            }
        }

        /// <summary>
        /// double click to expand master row.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void MasterView_RowDoubleClick(object sender, RowDoubleClickEventArgs e)
        {
            var rowHandle = e.HitInfo.RowHandle;
            if (!masterGrid.IsMasterRowExpanded(rowHandle))
            {
                masterGrid.ExpandMasterRow(rowHandle);
            }
            else
            {
                masterGrid.CollapseMasterRow(rowHandle);
            }
        }

        private void MasterGrid_MasterRowExpanded(object sender, RowEventArgs e)
        {
            if (DataContext is LotRunHistoryListViewModel viewModel)
            {
                viewModel.HideWait();
            }
        }

        private void MasterGrid_MasterRowExpanding(object sender, RowAllowEventArgs e)
        {
            if (DataContext is LotRunHistoryListViewModel viewModel)
            {
                viewModel.ShowWait();
            }
        }

        // https://supportcenter.devexpress.com/ticket/details/t522280/selection-of-row-overrides-the-back-colors-of-cells-in-gridcontrol

        private void MasterView_CustomCellAppearance(object sender, DevExpress.Xpf.Grid.CustomCellAppearanceEventArgs e)
        {
            e.Result = e.ConditionalValue;
            e.Handled = true;
        }

        public static readonly DependencyProperty CellMenuInfoProperty = DependencyPropertyManager.Register("CellMenuInfo", typeof(GridCellMenuInfo), typeof(LotRunHistoryList), new FrameworkPropertyMetadata(null));

        public ICommand CopyCellInfo { get; private set; }
        //public ICommand CopyRowInfo { get; private set; }

        public GridCellMenuInfo CellMenuInfo
        {
            get { return (GridCellMenuInfo)GetValue(CellMenuInfoProperty); }
            set { SetValue(CellMenuInfoProperty, value); }
        }


        private void TableView_ShowGridMenu(object sender, DevExpress.Xpf.Grid.GridMenuEventArgs e)
        {
            CellMenuInfo = e.MenuType == GridMenuType.RowCell ? (GridCellMenuInfo)e.MenuInfo : null;
        }

        void OnCopyCellInfo(object parameter)
        {
            if (parameter is GridCellMenuInfo menuInfo && menuInfo.Row != null)
            {
                string text = GetCellText(menuInfo.Row.RowHandle.Value, menuInfo.Column);
                SetClibboardText(text);
            }
        }

        //void OnCopyRowInfo(object parameter)
        //{
        //    if (parameter is int)
        //    {
        //        masterGrid.ClipboardCopyMode = ClipboardCopyMode.ExcludeHeader;
        //        masterGrid.CopyRowsToClipboard(new int[] { Convert.ToInt32(parameter) });
        //        masterGrid.ClipboardCopyMode = ClipboardCopyMode.IncludeHeader;
        //    }
        //}

        void SetClibboardText(string text)
        {
            try
            {
                Clipboard.SetText(text);
            }
            catch { }
        }

        string GetCellText(int rowHandle, ColumnBase column)
        {
            return Convert.ToString((column.View as TableView).Grid.GetCellValue(rowHandle, (GridColumn)column));
        }

        private void Export_ItemClick(object sender, DevExpress.Xpf.Bars.ItemClickEventArgs e)
        {
            if(e.Item.Hint?.ToString() == "RibbonExport")
            {
                Common.Helpers.WYSIWYGExportHelper.DoExport(masterGrid.View, DevExpress.XtraPrinting.ExportFormat.Xlsx);
            }
            else
            {
                Common.Helpers.WYSIWYGExportHelper.DoExport(CellMenuInfo.View, DevExpress.XtraPrinting.ExportFormat.Xlsx);
            }
        }

        private void DetailGrid_ItemsSourceChanged(object sender, ItemsSourceChangedEventArgs e)
        {
            var detailGrid = sender as GridControl;

            var processValueBand = detailGrid.Bands.First(b => b.Name == "processValueBand");
            var estimateValueBand = detailGrid.Bands.First(b => b.Name == "estimateValueBand");
            var metrologyValueBand = detailGrid.Bands.First(b => b.Name == "metrologyValueBand");

            if (processValueBand != null)
            {
                processValueBand.Columns.Clear();
            }
            else
            {
            }

            if (estimateValueBand != null)
            {
                estimateValueBand.Columns.Clear();
            }
            else
            {
            }

            if (metrologyValueBand != null)
            {
                metrologyValueBand.Columns.Clear();
            }
            else
            {
            }

            if (e.NewItemsSource is List<ExpandoObject> detailList && detailList.Count > 0)
            {
                var firstObject = detailList.First();
                foreach (var propertyName in firstObject.Select(o => o.Key))
                {
                    if (processValueBand != null && propertyName.StartsWith("P_"))
                    {
                        var splits = propertyName.SplitToList("_");
                        var displayIndex = int.Parse(splits[1]);
                        var realName = string.Join("_", splits.Skip(2));
                        processValueBand.Columns.Add(new GridColumn
                        {
                            Binding = new Binding(propertyName) { Mode = BindingMode.OneWay },
                            Header = realName,
                            VisibleIndex = displayIndex
                        });
                    }
                    else if (estimateValueBand != null && propertyName.StartsWith("E_"))
                    {
                        var splits = propertyName.SplitToList("_");
                        var displayIndex = int.Parse(splits[1]);
                        var realName = string.Join("_", splits.Skip(2));
                        estimateValueBand.Columns.Add(new GridColumn
                        {
                            Binding = new Binding(propertyName) { Mode = BindingMode.OneWay },
                            Header = realName,
                            VisibleIndex = displayIndex
                        });
                    }
                    else if (metrologyValueBand != null && propertyName.StartsWith("M_"))
                    {
                        var splits = propertyName.SplitToList("_");
                        var displayIndex = int.Parse(splits[1]);
                        var realName = string.Join("_", splits.Skip(2));
                        metrologyValueBand.Columns.Add(new GridColumn
                        {
                            Binding = new Binding(propertyName) { Mode = BindingMode.OneWay },
                            Header = realName,
                            VisibleIndex = displayIndex
                        });
                    }
                    else { }
                }
            }
        }

        private void MasterGrid_ItemsSourceChanged(object sender, ItemsSourceChangedEventArgs e)
        {
            var masterGrid = sender as GridControl;

            lastProcessValueBand.Columns.Clear();
            lastEstimateValueBand.Columns.Clear();


            if (e.NewItemsSource is List<ExpandoObject> masterList && masterList.Count > 0)
            {
                var firstObject = masterList.First();
                foreach (var propertyName in firstObject.Select(o => o.Key))
                {
                    if (lastProcessValueBand != null && propertyName.StartsWith("P_"))
                    {
                        var splits = propertyName.SplitToList("_");
                        var displayIndex = int.Parse(splits[1]);
                        var realName = string.Join("_", splits.Skip(2));
                        lastProcessValueBand.Columns.Add(new GridColumn
                        {
                            Binding = new Binding(propertyName) { Mode = BindingMode.OneWay },
                            Header = realName,
                            VisibleIndex = displayIndex
                        });
                    }
                    else if (lastEstimateValueBand != null && propertyName.StartsWith("E_"))
                    {
                        var splits = propertyName.SplitToList("_");
                        var displayIndex = int.Parse(splits[1]);
                        var realName = string.Join("_", splits.Skip(2));
                        lastEstimateValueBand.Columns.Add(new GridColumn
                        {
                            Binding = new Binding(propertyName) { Mode = BindingMode.OneWay },
                            Header = realName,
                            VisibleIndex = displayIndex
                        });
                    }
                    else { }
                }
            }

        }

        private async void BtnRefresh_Click(object sender, RoutedEventArgs e)
        {
            await Refresh();
        }

        private async Task Refresh()
        {
            var viewModel = DataContext as LotRunHistoryListViewModel;
            if (viewModel == null) return;

            var filters = new List<QueryFilter>();
            var sorters = new List<QuerySorter>();
            sorters.Add(new QuerySorter(nameof(LotRunHistory.ProcessStamp), System.ComponentModel.ListSortDirection.Descending));
            int? skip = null;
            int? take = null;
            if (lbeTool.SelectedItems != null && lbeTool.SelectedItems.Count > 0)
            {
                if (lbeTool.SelectedItems.Count > 1)
                {
                    filters.Add(new QueryFilter(nameof(LotRunHistory.Tool), lbeTool.SelectedItems.Select(o => o as string).ToArray(), QueryOperator.In));
                }
                else
                {
                    filters.Add(new QueryFilter(nameof(LotRunHistory.Tool), lbeTool.SelectedItems.First() as string, QueryOperator.Equals));
                }
            }

            if (lbeProduct.SelectedItems != null && lbeProduct.SelectedItems.Count > 0)
            {
                if (lbeProduct.SelectedItems.Count > 1)
                {
                    filters.Add(new QueryFilter(nameof(LotRunHistory.Product), lbeProduct.SelectedItems.Select(o => o as string).ToArray(), QueryOperator.In));
                }
                else
                {
                    filters.Add(new QueryFilter(nameof(LotRunHistory.Product), lbeProduct.SelectedItems.First() as string, QueryOperator.Equals));
                }
            }

            if (lbeLayer.SelectedItems != null && lbeLayer.SelectedItems.Count > 0)
            {
                if (lbeLayer.SelectedItems.Count > 1)
                {
                    filters.Add(new QueryFilter(nameof(LotRunHistory.Layer), lbeLayer.SelectedItems.Select(o => o as string).ToArray(), QueryOperator.In));
                }
                else
                {
                    filters.Add(new QueryFilter(nameof(LotRunHistory.Layer), lbeLayer.SelectedItems.First() as string, QueryOperator.Equals));
                }
            }

            if (lbeReticle.SelectedItems != null && lbeReticle.SelectedItems.Count > 0)
            {
                if (lbeReticle.SelectedItems.Count > 1)
                {
                    filters.Add(new QueryFilter(nameof(LotRunHistory.Reticle), lbeReticle.SelectedItems.Select(o => o as string).ToArray(), QueryOperator.In));
                }
                else
                {
                    filters.Add(new QueryFilter(nameof(LotRunHistory.Reticle), lbeReticle.SelectedItems.First() as string, QueryOperator.Equals));
                }
            }

            if (lbeRecipe.SelectedItems != null && lbeRecipe.SelectedItems.Count > 0)
            {
                if (lbeRecipe.SelectedItems.Count > 1)
                {
                    filters.Add(new QueryFilter(nameof(LotRunHistory.Recipe), lbeRecipe.SelectedItems.Select(o => o as string).ToArray(), QueryOperator.In));
                }
                else
                {
                    filters.Add(new QueryFilter(nameof(LotRunHistory.Recipe), lbeRecipe.SelectedItems.First() as string, QueryOperator.Equals));
                }
            }

            if (lbeOvlModel.SelectedItems != null && lbeOvlModel.SelectedItems.Count > 0)
            {
                if (lbeOvlModel.SelectedItems.Count > 1)
                {
                    filters.Add(new QueryFilter(nameof(LotRunHistory.OvlModel), lbeOvlModel.SelectedItems.Select(o => o as string).ToArray(), QueryOperator.In));
                }
                else
                {
                    filters.Add(new QueryFilter(nameof(LotRunHistory.OvlModel), lbeOvlModel.SelectedItems.First() as string, QueryOperator.Equals));
                }
            }

            if (!string.IsNullOrEmpty(teRootLot.Text))
            {
                filters.Add(new QueryFilter(nameof(LotRunHistory.LotId), teRootLot.Text, QueryOperator.Contains));
            }

            if (viewModel.IsTimeRangeMode)
            {
                if (deFromDate.EditValue != null && DateTime.TryParse(deFromDate.EditValue.ToString(), out var fromDate))
                {
                    filters.Add(new QueryFilter(nameof(LotRunHistory.ProcessStamp), deFromDate.DateTime, QueryOperator.GreaterThanOrEqualsTo));
                }
                else
                {
                    viewModel.MessageBoxService.ShowMessage("From Date must be provided!", "Invalid Filter!", MessageButton.OK, MessageIcon.Stop);
                    return;
                }

                if (deToDate.EditValue != null && DateTime.TryParse(deToDate.EditValue.ToString(), out var toDate))
                {
                    if (fromDate < toDate)
                    {
                        filters.Add(new QueryFilter(nameof(LotRunHistory.ProcessStamp), deToDate.DateTime, QueryOperator.LessThanOrEqualsTo));
                    }
                    else
                    {
                        viewModel.MessageBoxService.ShowMessage("To Date must be greater than From Date!", "Invalid Filter!", MessageButton.OK, MessageIcon.Stop);
                        return;
                    }
                }
                else
                {
                    viewModel.MessageBoxService.ShowMessage("To Date must be provided!", "Invalid Filter!", MessageButton.OK, MessageIcon.Stop);
                    return;
                }
            }
            else if (viewModel.IsLastNDayMode)
            {
                if (cbeLastNDay.EditValue != null && int.TryParse(cbeLastNDay.EditValue.ToString(), out var lastNDay))
                {
                    filters.Add(new QueryFilter(nameof(LotRunHistory.ProcessStamp), DateTime.Now.AddDays(0 - lastNDay), QueryOperator.GreaterThanOrEqualsTo));
                    filters.Add(new QueryFilter(nameof(LotRunHistory.ProcessStamp), DateTime.Now, QueryOperator.LessThanOrEqualsTo));
                }
                else
                {
                    viewModel.MessageBoxService.ShowMessage("Please input Last N Day!", "Invalid Filter!", MessageButton.OK, MessageIcon.Stop);
                    return;
                }
            }
            else if (viewModel.IsLastNRunMode)
            {
                if (cbeLastNRun.EditValue != null && int.TryParse(cbeLastNRun.EditValue.ToString(), out var lastNRun))
                {
                    skip = 0;
                    take = lastNRun;
                }
                else
                {
                    viewModel.MessageBoxService.ShowMessage("Please input Last N Run!", "Invalid Filter!", MessageButton.OK, MessageIcon.Stop);
                    return;
                }
            }

            await viewModel.RefreshAsync(filters, sorters, skip, take);
        }

        private void SetRangeFilterDefaultValue()
        {
            deFromDate.DateTime = DateTime.Now.AddDays(-7);
            deToDate.DateTime = DateTime.Now;
            cbeLastNDay.EditValue = 7;
            cbeLastNRun.EditValue = 200;
        }

        private async void BtnReset_Click(object sender, RoutedEventArgs e)
        {
            lbeTool.EditValue = null;
            lbeProduct.EditValue = null;
            lbeLayer.EditValue = null;
            lbeReticle.EditValue = null;
            lbeRecipe.EditValue = null;
            lbeOvlModel.EditValue = null;
            teRootLot.EditValue = null;

            SetRangeFilterDefaultValue();

            if (DataContext is LotRunHistoryListViewModel viewModel)
            {
                await viewModel.ResetFilterValueListAsync();
            }
        }

        private async void ViewModel_PropertyChanged(object sender, System.ComponentModel.PropertyChangedEventArgs e)
        {
            if (DataContext is LotRunHistoryListViewModel viewModel)
            {
                if (e.PropertyName == nameof(LotRunHistoryListViewModel.ViewType))
                {
                    if (viewModel.ViewType == ViewType.ByTool)
                    {
                        viewModel.IsVisibleBasicTool = true;
                        viewModel.IsVisibleBasicRecipe = false;
                        viewModel.IsVisibleInfoTool = false;
                        viewModel.IsVisibleInfoRecipe = true;
                    }
                    else
                    {
                        viewModel.IsVisibleBasicTool = false;
                        viewModel.IsVisibleBasicRecipe = true;
                        viewModel.IsVisibleInfoTool = true;
                        viewModel.IsVisibleInfoRecipe = false;
                    }
                    await Refresh();
                }
            }
        }

        private void GridControl_CustomColumnDisplayText(object sender, CustomColumnDisplayTextEventArgs e)
        {
            if (DataContext is ExpandoObject row && e.Value is bool b)
            {
                e.DisplayText = b.ToString();
            }
        }
    }
}
