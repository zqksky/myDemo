﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AMAT.R2R.Client.Common.Services;
using AMAT.R2R.Client.Common.ViewModels;
using AMAT.R2R.Client.Litho.Services;

namespace AMAT.R2R.Client.Litho.Modules
{
    public abstract class LithoViewModelBase : SuperViewModel
    {
        protected IProcessService ProcessService { get { return GetService<IProcessService>(); } }
        protected IGlobalService GlobalService { get { return ServiceContainer.GetService<IGlobalService>(); } }
        protected IContextService ContextService { get { return GetService<IContextService>(); } }
        protected ISpecialJobService SpecialJobService { get { return GetService<ISpecialJobService>(); } }
        protected IMaterialService MaterialService { get { return GetService<IMaterialService>(); } }
        protected ILithoGlobalService LithoGlobalService { get { return GetService<ILithoGlobalService>(); } }
        protected IProcessRecordService ProcessRecordService { get { return GetService<IProcessRecordService>(); } }
        protected ILotRunHistoryService LotRunHistoryService { get { return GetService<ILotRunHistoryService>(); } }
        
    }
}
