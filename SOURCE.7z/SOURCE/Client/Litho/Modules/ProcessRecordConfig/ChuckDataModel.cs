﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AMAT.R2R.Shared.Litho.DTO;

namespace AMAT.R2R.Client.Litho.Modules.ProcessRecordConfig
{
    public class ChuckDataModel : OVLChuckDedicate, INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;

        public void NotifyChanges()
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(ChuckId)));
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(WaferId)));
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Layer)));
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(LastModifyUser)));
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(LastModifyTime)));
        }
    }
}
