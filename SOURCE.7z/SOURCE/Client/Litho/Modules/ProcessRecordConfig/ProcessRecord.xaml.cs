﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using DevExpress.Mvvm;
using DevExpress.Xpf.Bars;
using DevExpress.Xpf.Grid;
using DevExpress.Xpf.Utils;

namespace AMAT.R2R.Client.Litho.Modules.ProcessRecordConfig
{
    /// <summary>
    /// Interaction logic for ProcessRecord.xaml
    /// </summary>
    public partial class ProcessRecord : UserControl
    {
        public ProcessRecord()
        {
            InitializeComponent();
            CopyCellInfo = new DelegateCommand<object>(OnCopyCellInfo);
            CopyRowInfo = new DelegateCommand<object>(OnCopyRowInfo);

            CopyChuckDataCellInfo = new DelegateCommand<object>(OnCopyChuckDataCellInfo);
            CopyChuckDataRowInfo = new DelegateCommand<object>(OnCopyChuckDataRowInfo);
        }

        // https://supportcenter.devexpress.com/ticket/details/t522280/selection-of-row-overrides-the-back-colors-of-cells-in-gridcontrol

        private void View_CustomCellAppearance(object sender, DevExpress.Xpf.Grid.CustomCellAppearanceEventArgs e)
        {
            e.Result = e.ConditionalValue;
            e.Handled = true;
        }


        public static readonly DependencyProperty CellMenuInfoProperty = DependencyPropertyManager.Register("CellMenuInfo", typeof(GridCellMenuInfo), typeof(ProcessRecord), new FrameworkPropertyMetadata(null));

        public ICommand DeleteRow { get; private set; }
        public ICommand CopyCellInfo { get; private set; }
        public ICommand CopyRowInfo { get; private set; }

        public ICommand CopyChuckDataCellInfo { get; private set; }
        public ICommand CopyChuckDataRowInfo { get; private set; }

        public GridCellMenuInfo CellMenuInfo
        {
            get { return (GridCellMenuInfo)GetValue(CellMenuInfoProperty); }
            set { SetValue(CellMenuInfoProperty, value); }
        }


        private void TableView_ShowGridMenu(object sender, DevExpress.Xpf.Grid.GridMenuEventArgs e)
        {
            CellMenuInfo = e.MenuType == GridMenuType.RowCell ? (GridCellMenuInfo)e.MenuInfo : null;
        }

        void OnCopyCellInfo(object parameter)
        {
            if (parameter is GridCellMenuInfo menuInfo && menuInfo.Row != null)
            {
                string text = GetCellText(menuInfo.Row.RowHandle.Value, menuInfo.Column);
                SetClibboardText(text);
            }
        }

        void OnCopyRowInfo(object parameter)
        {
            if (parameter is int)
            {
                gridPreData.ClipboardCopyMode = ClipboardCopyMode.ExcludeHeader;
                gridPreData.CopyRowsToClipboard(new int[] { Convert.ToInt32(parameter) });
                gridPreData.ClipboardCopyMode = ClipboardCopyMode.IncludeHeader;
            }
        }

        void SetClibboardText(string text)
        {
            try
            {
                Clipboard.SetText(text);
            }
            catch { }
        }

        string GetCellText(int rowHandle, ColumnBase column)
        {
            return Convert.ToString(gridPreData.GetCellValue(rowHandle, (GridColumn)column));
        }

        void OnCopyChuckDataCellInfo(object parameter)
        {
            if (parameter is GridCellMenuInfo menuInfo && menuInfo.Row != null)
            {
                string text = GetChuckDataCellText(menuInfo.Row.RowHandle.Value, menuInfo.Column);
                SetClibboardText(text);
            }
        }

        void OnCopyChuckDataRowInfo(object parameter)
        {
            if (parameter is int)
            {
                gridChuckData.ClipboardCopyMode = ClipboardCopyMode.ExcludeHeader;
                gridChuckData.CopyRowsToClipboard(new int[] { Convert.ToInt32(parameter) });
                gridChuckData.ClipboardCopyMode = ClipboardCopyMode.IncludeHeader;
            }
        }

        string GetChuckDataCellText(int rowHandle, ColumnBase column)
        {
            return Convert.ToString(gridChuckData.GetCellValue(rowHandle, (GridColumn)column));
        }

        private void ExportPreRecord_ItemClick(object sender, DevExpress.Xpf.Bars.ItemClickEventArgs e)
        {
            var button = sender as BarButtonItem;
            var format = button.Content.ToString().Substring(10);

            switch (format)
            {
                case "XLSX":
                    Common.Helpers.WYSIWYGExportHelper.DoExport(viewPreData, DevExpress.XtraPrinting.ExportFormat.Xlsx);
                    break;
                case "CSV":
                    Common.Helpers.WYSIWYGExportHelper.DoExport(viewPreData, DevExpress.XtraPrinting.ExportFormat.Csv);
                    break;
                default:
                    Common.Helpers.WYSIWYGExportHelper.DoExport(viewPreData, DevExpress.XtraPrinting.ExportFormat.Txt);
                    break;
            }
        }

        private void ExportChuckData_ItemClick(object sender, DevExpress.Xpf.Bars.ItemClickEventArgs e)
        {
            var button = sender as BarButtonItem;
            var format = button.Content.ToString().Substring(10);

            switch (format)
            {
                case "XLSX":
                    Common.Helpers.WYSIWYGExportHelper.DoExport(viewChuckData, DevExpress.XtraPrinting.ExportFormat.Xlsx);
                    break;
                case "CSV":
                    Common.Helpers.WYSIWYGExportHelper.DoExport(viewChuckData, DevExpress.XtraPrinting.ExportFormat.Csv);
                    break;
                default:
                    Common.Helpers.WYSIWYGExportHelper.DoExport(viewChuckData, DevExpress.XtraPrinting.ExportFormat.Txt);
                    break;
            }
        }
    }
}
