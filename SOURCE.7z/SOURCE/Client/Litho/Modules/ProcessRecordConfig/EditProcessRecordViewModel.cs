﻿using System;
using System.Collections.ObjectModel;
using AMAT.R2R.Client.Common.Enums;
using AMAT.R2R.Client.Common.Helpers;
using AMAT.R2R.Client.Litho.Messages;
using AMAT.R2R.Shared.Litho.DTO;
using DevExpress.Mvvm;
using DevExpress.Mvvm.DataAnnotations;

namespace AMAT.R2R.Client.Litho.Modules.ProcessRecordConfig
{
    class EditProcessRecordViewModel : LithoViewModelBase
    {
        private const string NA = "NA";
        public EditProcessRecordViewModel(OVLReferenceData preData, FunctionMode mode)
        {
            OriginalPreData = preData;
            SizeToContent = System.Windows.SizeToContent.WidthAndHeight;

            if (preData != null)
            {
                Lot = preData.Lot;
                Product = preData.Product;
                Layer = preData.Layer;
                Tool = preData.Tool;
                Reticle = preData.Reticle;
            }
            else
            {
                Fab = ClientInfo.LoginFab;

            }
            ProductList = new ObservableCollection<string>(LithoGlobalService.GetProductIdList());
            ToolList = new ObservableCollection<string>(LithoGlobalService.GetToolIdList());
            if (!string.IsNullOrEmpty(Product))
            {
                LayerList = new ObservableCollection<string>(LithoGlobalService.GetLayerIdList(Product));
            }

            Mode = mode;

            switch (mode)
            {
                case FunctionMode.None:
                    break;
                case FunctionMode.Add:
                    Caption = "Create Process Record";
                    break;
                case FunctionMode.Copy:
                    Caption = "Copy Process Record";
                    break;
                case FunctionMode.Modify:
                    Caption = "Edit Process Record";
                    break;
                case FunctionMode.Delete:
                    break;
                case FunctionMode.View:
                    break;
                default:
                    break;
            }
            IsDirty = false;

            PropertyChanged += OnPropertyChanged;
        }

        private void OnPropertyChanged(object sender, System.ComponentModel.PropertyChangedEventArgs e)
        {
            if (e.PropertyName == nameof(Lot))
            {
                IsDirty = true;
            }
        }

        protected override void OnViewReadyAsync()
        {
            if (Mode == FunctionMode.Add)
            {
                SetFocus(nameof(Lot));
            }
        }

        [Command]
        public void ProductSelectedIndexChanged()
        {
            if (!string.IsNullOrEmpty(Product))
            {
                Layer = "";
                LayerList = new ObservableCollection<string>();
                LayerList = new ObservableCollection<string>(LithoGlobalService.GetLayerIdList(Product));
            }
        }
        public bool CanProductSelectedIndex()
        {
            return true;
        }

        [Command]
        public async void Save()
        {
            ValidateAndSetErrorFocus(nameof(Lot), nameof(Product), nameof(Layer), nameof(Tool), nameof(Reticle));

            if (HasErrors)
            {
                return;
            }

            if (IsConfirmed(out string comment))
            {
                var newPreData = new OVLReferenceData
                {
                    Lot = Lot,
                    Product = Product,
                    Layer = Layer,
                    Tool = Tool,
                    Reticle = Reticle,
                    LastModifyTime = DateTime.Now,
                    LastModifyUser = ClientInfo.UserName
                };

                if (Mode == FunctionMode.Modify)
                {
                }
                else
                {
                    //ShowWait();
                    await ProcessRecordService.CreateProcessRecordAsync(newPreData, comment);

                    IsDirty = false;
                    //HideWait();
                    //if (newPreData != null)
                    //{ 
                    //}
                    string key = newPreData.Lot + ":" + newPreData.Product + ":" + newPreData.Layer;
                    Messenger.Default.Send(new ProcessRecordChangedMessage() { ChangeType = ObjectChangeType.Created, ProcessRecordKey = key });
                    MessageBoxService.ShowMessage($"PreData {key} is created!", "Success", MessageButton.OK, MessageIcon.Information);

                }

                IsOK = true;
                CloseWindow();
            }
        }

        public bool CanSave()
        {
            switch (Mode)
            {
                case FunctionMode.Add:
                    return true;
                case FunctionMode.Modify:
                    return IsDirty;
                default:
                    return true;
            }
        }

        protected override string GetError(string columnName)
        {
            switch (columnName)
            {
                case nameof(Lot):
                    return DataValidator.ValidString(Lot);
                case nameof(Product):
                    return DataValidator.ValidString(Product);
                case nameof(Layer):
                    return DataValidator.ValidString(Layer);
                case nameof(Tool):
                    return DataValidator.ValidString(Tool);
                case nameof(Reticle):
                    return DataValidator.ValidString(Reticle);

                default:
                    return null;
            }
        }


        #region Properties
        public OVLReferenceData OriginalPreData { get; private set; }
        public string Fab
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(Fab));
            }
        }
        public string Lot
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(Lot));
            }
        }

        public string Product
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(Product));
            }
        }

        public string Layer
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(Layer));
            }
        }

        public string Tool
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(Tool));
            }
        }

        public string Reticle
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(Reticle));
            }
        }

        public string LastModifyUser
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(LastModifyUser));
            }
        }

        public DateTime LastModifyTime
        {
            get { return GetValue<DateTime>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(LastModifyTime));
            }
        }

        public ObservableCollection<string> ProductList
        {
            get { return GetValue<ObservableCollection<string>>(); }
            set { SetValue(value); }
        }
        public ObservableCollection<string> LayerList
        {
            get { return GetValue<ObservableCollection<string>>(); }
            set { SetValue(value); }
        }
        public ObservableCollection<string> ToolList
        {
            get { return GetValue<ObservableCollection<string>>(); }
            set { SetValue(value); }
        }
        #endregion
    }
}
