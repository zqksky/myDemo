﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AMAT.R2R.Shared.Litho.DTO;

namespace AMAT.R2R.Client.Litho.Modules.ProcessRecordConfig
{
    public class PreRecordDataModel : OVLReferenceData, INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;

        public void NotifyChanges()
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Lot)));
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Product)));
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Layer)));
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Tool)));
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Reticle)));
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(LastModifyUser)));
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(LastModifyTime)));
        }
    }
}
