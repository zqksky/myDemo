﻿using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading.Tasks;
using AMAT.R2R.Client.Common.Enums;
using AMAT.R2R.Client.Common.Helpers;
using AMAT.R2R.Client.Litho.Messages;
using AMAT.R2R.Shared.Litho.DTO;
using DevExpress.Mvvm;
using DevExpress.Mvvm.DataAnnotations;

namespace AMAT.R2R.Client.Litho.Modules.ProcessRecordConfig
{
    public class ProcessRecordViewModel : LithoViewModelBase
    {
        public const string Auth_ProcessRecord = "ProcessRecord";
        public const string Auth_PreData = "ProcessRecord:PreData";
        public const string Auth_PreData_Add = "ProcessRecord:PreData:Add";
        public const string Auth_PreData_Copy = "ProcessRecord:PreData:Copy";
        public const string Auth_PreData_Edit = "ProcessRecord:PreData:Edit";
        public const string Auth_PreData_Delete = "ProcessRecord:PreData:Delete";

        public const string Auth_ChuckData = "ProcessRecord:ChuckData";
        public const string Auth_ChuckData_Add = "ProcessRecord:ChuckData:Add";
        public const string Auth_ChuckData_Copy = "ProcessRecord:ChuckData:Copy";
        public const string Auth_ChuckData_Edit = "ProcessRecord:ChuckData:Edit";
        public const string Auth_ChuckData_Delete = "ProcessRecord:ChuckData:Delete";

        public ProcessRecordViewModel()
        {
            Caption = "Process Record";
            Icon = "SvgImages/XAF/ActionGroup_EasyTestRecorder.svg";

            Messenger.Default.Register<ChuckDataChangedMessage>(this, OnChuckDataChanged);
            Messenger.Default.Register<ProcessRecordChangedMessage>(this, OnProcessRecordChanged);

            PropertyChanged += OnPropertyChanged;
        }
        protected override void OnViewReadyAsync()
        {
            Refresh();
        }
        private void OnPropertyChanged(object sender, System.ComponentModel.PropertyChangedEventArgs e)
        {
            if (e.PropertyName == nameof(SelectedPreData))
            {
                RefreshChuckData();
            }
        }

        private async void OnProcessRecordChanged(ProcessRecordChangedMessage msg)
        {
            var processRecordData = PreDataList.FirstOrDefault(p => p.Lot + ":" + p.Product + ":" + p.Layer == msg.ProcessRecordKey);
            switch (msg.ChangeType)
            {
                case ObjectChangeType.Created:
                    Refresh();
                    break;
                case ObjectChangeType.Deleted:
                    PreDataList.Remove(processRecordData);
                    break;
                case ObjectChangeType.Updated:
                    await UpdateSingleProcessRecord(processRecordData);
                    break;
                default:
                    break;

            }
        }

        private async Task UpdateSingleProcessRecord(PreRecordDataModel processRecordData)
        {
            string key = processRecordData.Lot + ":" + processRecordData.Product + ":" + processRecordData.Layer;
            var newProcessRecordData = await ProcessRecordService.GetProcessRecordAsync(key);

            processRecordData.LastModifyUser = newProcessRecordData.LastModifyUser;
            processRecordData.LastModifyTime = newProcessRecordData.LastModifyTime;
            processRecordData.Lot = newProcessRecordData.Lot;
            processRecordData.Product = newProcessRecordData.Product;
            processRecordData.Layer = newProcessRecordData.Layer;
            processRecordData.Tool = newProcessRecordData.Tool;
            processRecordData.Reticle = newProcessRecordData.Reticle;

            processRecordData.NotifyChanges();
        }

        private async void OnChuckDataChanged(ChuckDataChangedMessage msg)
        {
            //var chuckData = ChuckDataList.FirstOrDefault(p => p.Layer + ":" + Regex.Match(p.WaferId, @"[^#]+").Value  == msg.ChuckDataKey);
            var chuckData = ChuckDataList.FirstOrDefault(p => p.Layer + ":" + p.WaferId == msg.ChuckDataKey);
            switch (msg.ChangeType)
            {
                case ObjectChangeType.Created:
                    Refresh();
                    break;
                case ObjectChangeType.Deleted:
                    ChuckDataList.Remove(chuckData);
                    break;
                case ObjectChangeType.Updated:
                    await UpdateSingleChuckData(chuckData);
                    break;
                default:
                    break;

            }
        }

        private async Task UpdateSingleChuckData(ChuckDataModel ChuckData)
        {
            //string strLot = Regex.Match(ChuckData.WaferId, @"[^#]+").Value;
            //string key = ChuckData.Layer + ":" + strLot;
            string key = ChuckData.Layer + ":" + ChuckData.WaferId;

            var newChuckData = await ProcessRecordService.GetChuckDataAsync(key);

            ChuckData.LastModifyUser = newChuckData.LastModifyUser;
            ChuckData.LastModifyTime = newChuckData.LastModifyTime;
            ChuckData.Layer = newChuckData.Layer;
            ChuckData.WaferId = newChuckData.WaferId;
            ChuckData.ChuckId = newChuckData.ChuckId;

            ChuckData.NotifyChanges();
        }

        #region Commands
        [Command]
        public void Refresh()
        {
            try
            {
                IsLoading = true;
                RefreshProcessData();
                RefreshChuckData();
            }
            finally
            {
                IsLoading = false;
            }
        }
        public bool CanRefresh()
        {
            return !IsLoading;
        }
        public async void RefreshProcessData()
        {
            try
            {
                var preSelectedPreData = SelectedPreData;
                var processDataList = await ProcessRecordService.GetProcessRecordListAsync();
                PreDataList = new ObservableCollection<PreRecordDataModel>(processDataList);

                if (preSelectedPreData != null)
                {
                    string key = preSelectedPreData.Lot + ":" + preSelectedPreData.Product + ":" + preSelectedPreData.Layer;
                    SelectedPreData = processDataList.FirstOrDefault(p => p.Lot + ":" + p.Product + ":" + p.Layer == key);
                }
            }
            finally
            {

            }
        }
        public async void RefreshChuckData()
        {
            try
            {
                if (SelectedPreData != null)
                {
                    SelectedChuckData = null;
                    ChuckDataList = new ObservableCollection<ChuckDataModel>();
                    var chuckDataList = await ProcessRecordService.GetChuckDataListAsync(SelectedPreData.Layer, SelectedPreData.Lot);
                    ChuckDataList = new ObservableCollection<ChuckDataModel>(chuckDataList);
                }
                else
                {
                    ChuckDataList = new ObservableCollection<ChuckDataModel>();
                }
            }
            finally
            {

            }
        }

        #region PreData
        [Command]
        public void AddPreData()
        {
            ShowEditPreData(null, FunctionMode.Add);
        }

        public bool CanAddPreData()
        {
            //return true;
            return AuthorityManager.HasAuthority(Auth_PreData_Add);
        }

        [Command]
        public void CopyPreData()
        {
            ShowEditPreData(SelectedPreData, FunctionMode.Copy);
        }

        public bool CanCopyPreData()
        {
            return SelectedPreData != null && SelectedPreDataList.Count == 1 && !IsLoading && AuthorityManager.HasAuthority(Auth_PreData_Copy);
        }

        private void ShowEditPreData(OVLReferenceData originalPreData, FunctionMode mode)
        {
            if (ShowPopup("EditProcessRecord", new EditProcessRecordViewModel(originalPreData, mode)).IsOK)
            {
                RefreshProcessData();
            }
        }

        [Command]
        public async void DeletePreData()
        {
            if (IsConfirmed(out var comment))
            {
                var toDeletePreData = SelectedPreData;
                if (SelectedPreData == null)
                {
                    return;
                }
                string key = SelectedPreData.Lot + ":" + SelectedPreData.Product + ":" + SelectedPreData.Layer;
                await ProcessRecordService.DeleteProcessRecordAsync(key, comment);
                Refresh();
                Messenger.Default.Send(new ProcessRecordChangedMessage() { ChangeType = ObjectChangeType.Deleted, ProcessRecordKey = key });
                MessageBoxService.ShowMessage($"ProcessRecord {key} is deleted.", "Success", MessageButton.OK, MessageIcon.Information);
            }
        }

        public bool CanDeletePreData()
        {
            return SelectedPreData != null && SelectedPreDataList.Count == 1 && !IsLoading && AuthorityManager.HasAuthority(Auth_PreData_Delete);
        }
        #endregion

        #region ChuckData
        [Command]
        public void AddChuckData()
        {
            ShowEditChuckData(SelectedPreData.Lot, SelectedPreData.Layer, null, FunctionMode.Add);
            //ShowEditChuckData(SelectedPreData.Lot, SelectedPreData.Layer, ChuckDataList.ToList(), FunctionMode.Add);
        }

        public bool CanAddChuckData()
        {
            return SelectedPreData != null && SelectedPreDataList.Count == 1 && !IsLoading && AuthorityManager.HasAuthority(Auth_ChuckData_Add);
        }
        private void ShowEditChuckData(string strLot, string strLayer, List<ChuckDataModel> chuckDataList, FunctionMode mode)
        {
            if (ShowPopup("EditChuckData", new EditChuckDataViewModel(strLot, strLayer, chuckDataList, mode)).IsOK)
            {
                RefreshChuckData();
            }
        }

        //[Command]
        //public void CopyChuckData()
        //{
        //    ShowEditChuckData(SelectedPreData.Lot, SelectedPreData.Layer, ChuckDataList.ToList(), FunctionMode.Copy);
        //}

        //public bool CanCopyChuckData()
        //{
        //    return SelectedPreData != null && !IsLoading;// && AuthorityManager.HasAuthority(Auth_ChuckData_Copy);
        //}

        [Command]
        public async void DeleteChuckData()
        {
            if (IsConfirmed(out var comment))
            {
                //string key = SelectedPreData.Layer + ":" + SelectedPreData.Lot;
                string key = SelectedChuckData.Layer + ":" + SelectedChuckData.WaferId;
                await ProcessRecordService.DeleteChuckDataAsync(key, comment);
                RefreshChuckData();
                Messenger.Default.Send(new ChuckDataChangedMessage() { ChangeType = ObjectChangeType.Deleted, ChuckDataKey = key });
                MessageBoxService.ShowMessage($"ChuckData {key} is deleted.", "Success", MessageButton.OK, MessageIcon.Information);
            }
        }

        public bool CanDeleteChuckData()
        {
            //return SelectedChuckDataList.Count > 0 && !IsLoading;// && AuthorityManager.HasAuthority(Auth_ChuckData_Delete);
            return SelectedChuckData != null && SelectedChuckDataList.Count == 1 && !IsLoading && AuthorityManager.HasAuthority(Auth_ChuckData_Delete);
        }
        #endregion

        #endregion

        #region Properties
        public ObservableCollection<PreRecordDataModel> PreDataList
        {
            get { return GetValue<ObservableCollection<PreRecordDataModel>>(); }
            set { SetValue(value); }
        }

        public ObservableCollection<OVLReferenceData> SelectedPreDataList { get; } = new ObservableCollection<OVLReferenceData>();

        public OVLReferenceData SelectedPreData
        {
            get { return GetValue<OVLReferenceData>(); }
            set { SetValue(value); }
        }

        public ObservableCollection<ChuckDataModel> ChuckDataList
        {
            get { return GetValue<ObservableCollection<ChuckDataModel>>(); }
            set { SetValue(value); }
        }

        public ObservableCollection<OVLChuckDedicate> SelectedChuckDataList { get; } = new ObservableCollection<OVLChuckDedicate>();

        public OVLChuckDedicate SelectedChuckData
        {
            get { return GetValue<OVLChuckDedicate>(); }
            set { SetValue(value); }
        }
        #endregion
    }
}
