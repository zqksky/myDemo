﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using AMAT.R2R.Client.Common.Enums;
using AMAT.R2R.Client.Common.Helpers;
using AMAT.R2R.Client.Litho.Messages;
using AMAT.R2R.Shared.Litho.DTO;
using DevExpress.Mvvm;
using DevExpress.Mvvm.DataAnnotations;

namespace AMAT.R2R.Client.Litho.Modules.ProcessRecordConfig
{
    class EditChuckDataViewModel : LithoViewModelBase
    {
        private const string NA = "NA";
        public EditChuckDataViewModel(string strLot, string strLayer, List<ChuckDataModel> chuckDataList, FunctionMode mode)
        {
            OriginalChuckDataList = chuckDataList;
            SizeToContent = System.Windows.SizeToContent.WidthAndHeight;

            Lot = strLot;
            Layer = strLayer;
            InitWafer();

            Mode = mode;

            switch (mode)
            {
                case FunctionMode.None:
                    break;
                case FunctionMode.Add:
                    Caption = "Create Chuck Data";
                    break;
                case FunctionMode.Copy:
                    Caption = "Copy Chuck Data";
                    break;
                case FunctionMode.Modify:
                    Caption = "Edit Chuck Data";
                    break;
                case FunctionMode.Delete:
                    break;
                case FunctionMode.View:
                    break;
                default:
                    break;
            }
            IsDirty = false;

            ChuckIdList = new ObservableCollection<string>() { "NA", "C1", "C2" };
            PropertyChanged += OnPropertyChanged;
        }

        private void OnPropertyChanged(object sender, System.ComponentModel.PropertyChangedEventArgs e)
        {
            if (e.PropertyName == nameof(WaferId))
            {
                IsDirty = true;
            }
        }

        protected override void OnViewReadyAsync()
        {
            if (Mode == FunctionMode.Add)
            {
                SetFocus(nameof(WaferId));
            }
        }
        void InitWafer()
        {
            Wafer01 = "NA";
            Wafer02 = "NA";
            Wafer03 = "NA";
            Wafer04 = "NA";
            Wafer05 = "NA";
            Wafer06 = "NA";
            Wafer07 = "NA";
            Wafer08 = "NA";
            Wafer09 = "NA";
            Wafer10 = "NA";

            Wafer11 = "NA";
            Wafer12 = "NA";
            Wafer13 = "NA";
            Wafer14 = "NA";
            Wafer15 = "NA";
            Wafer16 = "NA";
            Wafer17 = "NA";
            Wafer18 = "NA";
            Wafer19 = "NA";
            Wafer20 = "NA";

            Wafer21 = "NA";
            Wafer22 = "NA";
            Wafer23 = "NA";
            Wafer24 = "NA";
            Wafer25 = "NA";

            SetOriginalChuckData();
        }
        void SetOriginalChuckData()
        {
            if (OriginalChuckDataList != null && OriginalChuckDataList.Count > 0)
            {
                foreach (var c in OriginalChuckDataList)
                {
                    //string str = c.WaferId;
                    //var strGroup = Regex.Matches(str, @"[^#]+");
                    //if (strGroup.Count > 1)
                    //{
                    //    str = strGroup[1].Value;
                    //}

                    if (c.WaferId.Contains("#"))
                    {
                        string str = c.WaferId;
                        str = str.Substring(str.IndexOf('#') + 1);
                        switch (str)
                        {
                            case "01":
                                Wafer01 = c.ChuckId;
                                break;
                            case "02":
                                Wafer02 = c.ChuckId;
                                break;
                            case "03":
                                Wafer03 = c.ChuckId;
                                break;
                            case "04":
                                Wafer04 = c.ChuckId;
                                break;
                            case "05":
                                Wafer05 = c.ChuckId;
                                break;
                            case "06":
                                Wafer06 = c.ChuckId;
                                break;
                            case "07":
                                Wafer07 = c.ChuckId;
                                break;
                            case "08":
                                Wafer08 = c.ChuckId;
                                break;
                            case "09":
                                Wafer09 = c.ChuckId;
                                break;
                            case "10":
                                Wafer10 = c.ChuckId;
                                break;
                            case "11":
                                Wafer11 = c.ChuckId;
                                break;
                            case "12":
                                Wafer12 = c.ChuckId;
                                break;
                            case "13":
                                Wafer13 = c.ChuckId;
                                break;
                            case "14":
                                Wafer14 = c.ChuckId;
                                break;
                            case "15":
                                Wafer15 = c.ChuckId;
                                break;
                            case "16":
                                Wafer16 = c.ChuckId;
                                break;
                            case "17":
                                Wafer17 = c.ChuckId;
                                break;
                            case "18":
                                Wafer18 = c.ChuckId;
                                break;
                            case "19":
                                Wafer19 = c.ChuckId;
                                break;
                            case "20":
                                Wafer20 = c.ChuckId;
                                break;
                            case "21":
                                Wafer21 = c.ChuckId;
                                break;
                            case "22":
                                Wafer22 = c.ChuckId;
                                break;
                            case "23":
                                Wafer23 = c.ChuckId;
                                break;
                            case "24":
                                Wafer24 = c.ChuckId;
                                break;
                            case "25":
                                Wafer25 = c.ChuckId;
                                break;
                            default:
                                break;
                        }
                    }
                }
            }
        }

        [Command]
        public void DefaultSetting()
        {
            Wafer01 = "C1";
            Wafer02 = "C2";
            Wafer03 = "C1";
            Wafer04 = "C2";
            Wafer05 = "C1";

            Wafer06 = "C2";
            Wafer07 = "C1";
            Wafer08 = "C2";
            Wafer09 = "C1";
            Wafer10 = "C2";

            Wafer11 = "C1";
            Wafer12 = "C2";
            Wafer13 = "C1";
            Wafer14 = "C2";
            Wafer15 = "C1";

            Wafer16 = "C2";
            Wafer17 = "C1";
            Wafer18 = "C2";
            Wafer19 = "C1";
            Wafer20 = "C2";

            Wafer21 = "C1";
            Wafer22 = "C2";
            Wafer23 = "C1";
            Wafer24 = "C2";
            Wafer25 = "C1";
        }

        public bool CanDefaultSetting()
        {
            return true;
        }

        OVLChuckDedicate SetChuckData(string strWaferId, string strChuckId)
        {
            OVLChuckDedicate chuckData = new OVLChuckDedicate();
            chuckData.WaferId = Lot + strWaferId;
            chuckData.ChuckId = strChuckId;
            chuckData.Layer = Layer;
            chuckData.LastModifyUser = ClientInfo.UserName;
            chuckData.LastModifyTime = DateTime.Now;
            return chuckData;
        }

        [Command]
        public async void Save()
        {
            ValidateAndSetErrorFocus(nameof(Lot), nameof(Layer));

            if (HasErrors)
            {
                return;
            }

            if (IsConfirmed(out string comment))
            {
                List<OVLChuckDedicate> newChuckDataList = new List<OVLChuckDedicate>();

                OVLChuckDedicate newChuckData = new OVLChuckDedicate();
                newChuckData = SetChuckData("#01", Wafer01);
                newChuckDataList.Add(newChuckData);

                newChuckData = SetChuckData("#02", Wafer02);
                newChuckDataList.Add(newChuckData);

                newChuckData = SetChuckData("#03", Wafer03);
                newChuckDataList.Add(newChuckData);

                newChuckData = SetChuckData("#04", Wafer04);
                newChuckDataList.Add(newChuckData);

                newChuckData = SetChuckData("#05", Wafer05);
                newChuckDataList.Add(newChuckData);

                newChuckData = SetChuckData("#06", Wafer06);
                newChuckDataList.Add(newChuckData);

                newChuckData = SetChuckData("#07", Wafer07);
                newChuckDataList.Add(newChuckData);

                newChuckData = SetChuckData("#08", Wafer08);
                newChuckDataList.Add(newChuckData);

                newChuckData = SetChuckData("#09", Wafer09);
                newChuckDataList.Add(newChuckData);

                newChuckData = SetChuckData("#10", Wafer10);
                newChuckDataList.Add(newChuckData);

                newChuckData = SetChuckData("#11", Wafer11);
                newChuckDataList.Add(newChuckData);

                newChuckData = SetChuckData("#12", Wafer12);
                newChuckDataList.Add(newChuckData);

                newChuckData = SetChuckData("#13", Wafer13);
                newChuckDataList.Add(newChuckData);

                newChuckData = SetChuckData("#14", Wafer14);
                newChuckDataList.Add(newChuckData);

                newChuckData = SetChuckData("#15", Wafer15);
                newChuckDataList.Add(newChuckData);

                newChuckData = SetChuckData("#16", Wafer16);
                newChuckDataList.Add(newChuckData);

                newChuckData = SetChuckData("#17", Wafer17);
                newChuckDataList.Add(newChuckData);

                newChuckData = SetChuckData("#18", Wafer18);
                newChuckDataList.Add(newChuckData);

                newChuckData = SetChuckData("#19", Wafer19);
                newChuckDataList.Add(newChuckData);

                newChuckData = SetChuckData("#20", Wafer20);
                newChuckDataList.Add(newChuckData);

                newChuckData = SetChuckData("#21", Wafer21);
                newChuckDataList.Add(newChuckData);

                newChuckData = SetChuckData("#22", Wafer22);
                newChuckDataList.Add(newChuckData);

                newChuckData = SetChuckData("#23", Wafer23);
                newChuckDataList.Add(newChuckData);

                newChuckData = SetChuckData("#24", Wafer24);
                newChuckDataList.Add(newChuckData);

                newChuckData = SetChuckData("#25", Wafer25);
                newChuckDataList.Add(newChuckData);

                //newChuckDataList = newChuckDataList.FindAll(p => p.ChuckId != "NA");

                if (Mode == FunctionMode.Modify)
                {

                }
                else
                {
                    //ShowWait();
                    await ProcessRecordService.CreateChuckDataAsync(newChuckDataList, comment);

                    IsDirty = false;
                    //HideWait();
                    string key = Layer + ":" + Lot;
                    Messenger.Default.Send(new ChuckDataChangedMessage() { ChangeType = ObjectChangeType.Created, ChuckDataKey = key });
                    MessageBoxService.ShowMessage($"ChuckData {key} is created!", "Success", MessageButton.OK, MessageIcon.Information);

                }

                IsOK = true;
                CloseWindow();
            }
        }

        public bool CanSave()
        {
            switch (Mode)
            {
                case FunctionMode.Add:
                    return true;
                case FunctionMode.Modify:
                    return IsDirty;
                default:
                    return true;
            }
        }

        protected override string GetError(string columnName)
        {
            switch (columnName)
            {
                case nameof(Lot):
                    return DataValidator.ValidString(Lot);
                case nameof(WaferId):
                    return DataValidator.ValidString(WaferId);
                case nameof(ChuckId):
                    return DataValidator.ValidString(ChuckId);
                case nameof(Layer):
                    return DataValidator.ValidString(Layer);
                case nameof(Wafer01):
                    return DataValidator.ValidString(Wafer01);
                case nameof(Wafer02):
                    return DataValidator.ValidString(Wafer02);

                default:
                    return null;
            }
        }


        #region Properties
        public List<ChuckDataModel> OriginalChuckDataList { get; private set; }
        public string Lot
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(Lot));
            }
        }

        public string WaferId
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(WaferId));
            }
        }

        public string ChuckId
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(ChuckId));
            }
        }

        public string Layer
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(Layer));
            }
        }

        public string LastModifyUser
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(LastModifyUser));
            }
        }

        public DateTime LastModifyTime
        {
            get { return GetValue<DateTime>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(LastModifyTime));
            }
        }

        public string Wafer01
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(Wafer01));
            }
        }
        public string Wafer02
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(Wafer02));
            }
        }
        public string Wafer03
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(Wafer03));
            }
        }
        public string Wafer04
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(Wafer04));
            }
        }
        public string Wafer05
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(Wafer05));
            }
        }
        public string Wafer06
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(Wafer06));
            }
        }
        public string Wafer07
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(Wafer07));
            }
        }
        public string Wafer08
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(Wafer08));
            }
        }
        public string Wafer09
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(Wafer09));
            }
        }
        public string Wafer10
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(Wafer10));
            }
        }
        public string Wafer11
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(Wafer11));
            }
        }
        public string Wafer12
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(Wafer12));
            }
        }
        public string Wafer13
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(Wafer13));
            }
        }
        public string Wafer14
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(Wafer14));
            }
        }
        public string Wafer15
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(Wafer15));
            }
        }
        public string Wafer16
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(Wafer16));
            }
        }
        public string Wafer17
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(Wafer17));
            }
        }
        public string Wafer18
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(Wafer18));
            }
        }
        public string Wafer19
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(Wafer19));
            }
        }
        public string Wafer20
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(Wafer20));
            }
        }
        public string Wafer21
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(Wafer21));
            }
        }
        public string Wafer22
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(Wafer22));
            }
        }
        public string Wafer23
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(Wafer23));
            }
        }
        public string Wafer24
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(Wafer24));
            }
        }
        public string Wafer25
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(Wafer25));
            }
        }
        public ObservableCollection<string> ChuckIdList
        {
            get { return GetValue<ObservableCollection<string>>(); }
            set { SetValue(value); }
        }
        #endregion
    }
}
