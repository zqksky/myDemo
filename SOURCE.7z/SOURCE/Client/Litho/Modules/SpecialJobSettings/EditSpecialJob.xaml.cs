﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using DevExpress.Xpf.Bars;

namespace AMAT.R2R.Client.Litho.Modules.SpecialJobSettings
{
    /// <summary>
    /// Interaction logic for EditSpecialJob.xaml
    /// </summary>
    public partial class EditSpecialJob : UserControl
    {
        public EditSpecialJob()
        {
            InitializeComponent();
        }
        private void toolTextEdit_Validate(object sender, DevExpress.Xpf.Editors.ValidationEventArgs e)
        {
            // e.Value - the processed input value
            if (e.Value == null) return;
            if (e.Value.ToString().Length == 6) return;
            // Set the e.IsValid property to 'false' if the input value is invalid
            e.IsValid = false;
            // Specifies the error icon type
            e.ErrorType = DevExpress.XtraEditors.DXErrorProvider.ErrorType.Default;
            // Specifies the error text
            e.ErrorContent = "Must contain six symbols. Please correct.";
        }
        private void ExportSpecCD_ItemClick(object sender, DevExpress.Xpf.Bars.ItemClickEventArgs e)
        {
            var button = sender as BarButtonItem;
            var format = button.Content.ToString().Substring(10);

            switch (format)
            {
                case "XLSX":
                    Common.Helpers.WYSIWYGExportHelper.DoExport(viewSpecCD, DevExpress.XtraPrinting.ExportFormat.Xlsx);
                    break;
                case "CSV":
                    Common.Helpers.WYSIWYGExportHelper.DoExport(viewSpecCD, DevExpress.XtraPrinting.ExportFormat.Csv);
                    break;
                default:
                    Common.Helpers.WYSIWYGExportHelper.DoExport(viewSpecCD, DevExpress.XtraPrinting.ExportFormat.Txt);
                    break;
            }
        }

        private void ExportSpecOVL_ItemClick(object sender, DevExpress.Xpf.Bars.ItemClickEventArgs e)
        {
            var button = sender as BarButtonItem;
            var format = button.Content.ToString().Substring(10);

            switch (format)
            {
                case "XLSX":
                    Common.Helpers.WYSIWYGExportHelper.DoExport(viewSpecOVL, DevExpress.XtraPrinting.ExportFormat.Xlsx);
                    break;
                case "CSV":
                    Common.Helpers.WYSIWYGExportHelper.DoExport(viewSpecOVL, DevExpress.XtraPrinting.ExportFormat.Csv);
                    break;
                default:
                    Common.Helpers.WYSIWYGExportHelper.DoExport(viewSpecOVL, DevExpress.XtraPrinting.ExportFormat.Txt);
                    break;
            }
        }
    }
}
