﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Threading.Tasks;
using AMAT.R2R.Client.Common.Enums;
using AMAT.R2R.Client.Common.Helpers;
using AMAT.R2R.Client.Litho.Messages;
using AMAT.R2R.Shared.Base.DTO;
using AMAT.R2R.Shared.Litho.DTO;
using DevExpress.Mvvm;
using DevExpress.Mvvm.DataAnnotations;
using DevExpress.Xpf.Data;

namespace AMAT.R2R.Client.Litho.Modules.SpecialJobSettings
{
    public class SpecialJobListViewModel : LithoViewModelBase
    {
        //public const string Auth_SpecialJob = "SpecialJob";
        public const string Auth_SpecialJob = "SpecialJob";
        public const string Auth_SpecialJob_Copy = "SpecialJob:Copy";
        public const string Auth_SpecialJob_Edit = "SpecialJob:Edit";
        public const string Auth_SpecialJob_Delete = "SpecialJob:Delete";
        public SpecialJobListViewModel()
        {
            Caption = "Special Job Settings";
            Icon = "SvgImages/Snap/SnapHeader.svg";
            PropertyChanged += OnPropertyChanged;
            Messenger.Default.Register<SpecialJobChangedMessage>(this, OnSpecialJobChanged);

            InitializePagedSource();
        }

        #region Filtering & Paging

        private void InitializePagedSource()
        {
            #region Paged Source
            var pagedSource = new PagedAsyncSource()
            {
                ElementType = typeof(SpecialJobModel),
                //KeyProperty = nameof(SpecialJob.ContextKey),
                PageSize = 100,
                PageNavigationMode = PageNavigationMode.ArbitraryWithTotalPageCount
            };

#if DEBUG
            pagedSource.PageSize = 10;
#endif

            pagedSource.FetchPage += (o, e) =>
            {
                e.Result = FetchPageRowsAsync(e);
            };

            pagedSource.GetTotalSummaries += (o, e) =>
            {
                e.Result = GetSummariesAsync(e);
            };

            pagedSource.GetUniqueValues += (o, e) =>
            {
                e.Result = GetValueListAsync(e);
            };

            pagedSource.PropertyChanged += (o, e) =>
            {
                if (e.PropertyName == nameof(PagedAsyncSource.AreRowsFetching))
                {
                    IsLoading = PagedSource.AreRowsFetching;
                    // restore selection.
                    if (!IsLoading)
                    {
                        if (_lastSelectedItem != null)
                        {
                            foreach (var item in PagedSource)
                            {
                                var job = item as SpecialJobModel;
                                if (job.JobId == _lastSelectedItem.JobId)
                                {
                                    SelectedSpecialJob = job;
                                    break;
                                }
                            }
                        }
                    }
                }
            };

            PagedSource = pagedSource;
            #endregion
        }

        SpecialJobModel _lastSelectedItem = null;
        private async Task<FetchRowsResult> FetchPageRowsAsync(FetchPageAsyncEventArgs e)
        {
            try
            {
                if (SelectedSpecialJob != null)
                {
                    _lastSelectedItem = SelectedSpecialJob;
                }

                var items = await SpecialJobService.GetSpecialJobListAsync(e.Filter.MakeFilters(), e.MakeSorters(), e.Skip, e.Take);
                return new FetchRowsResult(items.ToArray(), hasMoreRows: items.Count == e.Take);
            }
            catch (Exception ex)
            {
                Logger.Error(ex);
                throw;
            }
        }

        private async Task<object[]> GetSummariesAsync(GetSummariesAsyncEventArgs e)
        {
            try
            {
                var summary = await SpecialJobService.GetSpecialJobCount(e.Filter.MakeFilters());
                return e.Summaries.Select(x =>
                {
                    return x.SummaryType == SummaryType.Count ? (object)summary : throw new InvalidOperationException();
                }).ToArray();
            }
            catch (Exception ex)
            {
                Logger.Error(ex);
                throw;
            }
        }

        private async Task<object[]> GetValueListAsync(GetUniqueValuesAsyncEventArgs e)
        {
            try
            {
                if (e.PropertyName == nameof(SpecialJob.IsValid) || e.PropertyName == nameof(SpecialJob.JobCompleted))
                {
                    var values = new object[] { true, false };
                    return await Task.Factory.StartNew(() => values);
                }
                else
                {
                    return await SpecialJobService.GetSpecialJobValueListAsync(e.PropertyName, e.Filter.MakeFilters());
                }
            }
            catch (Exception ex)
            {
                Logger.Error(ex);
                throw;
            }
        }

        #endregion

        #region Events

        protected override void OnViewReadyAsync()
        {
            //Refresh();
        }

        public override void OnRemoving(CancelEventArgs e)
        {
            base.OnRemoving(e);

            PagedSource?.Dispose();
            Messenger.Default.Unregister<SpecialJobChangedMessage>(this, OnSpecialJobChanged);
        }

        private async void OnPropertyChanged(object sender, System.ComponentModel.PropertyChangedEventArgs e)
        {
            if (e.PropertyName == nameof(SelectedSpecialJob))
            {
                if (SelectedSpecialJob != null)
                {
                    HaveChuckFlag = SelectedSpecialJob.C2C == 1;
                    NoChuckFlag = !HaveChuckFlag;

                    await GetSpecialJobDetailsAsync();

                    if (SelectedSpecialJob == null || SelectedSpecialJob.SpecialJobParameters.Count < 1)
                    {
                        return;
                    }
                    JobParameterList = new ObservableCollection<SpecialJobInputSetting>(SelectedSpecialJob.SpecialJobParameters.Select(p =>
                    new SpecialJobInputSetting()
                    {
                        ParameterName = p.ParameterName,
                        InputValueNA = p.InputValueNA,
                        InputValueC1 = p.InputValueC1,
                        InputValueC2 = p.InputValueC2,
                        Min = p.Min,
                        Max = p.Max,
                        Unit = p.Unit,
                        ParameterType = p.ParameterType,
                        ChuckFlag = NoChuckFlag,
                    }));

                    CDJobParameterList = new ObservableCollection<SpecialJobInputSetting>(JobParameterList.Where(p => p.ParameterType == "DCD" || p.ParameterType == "FEM").ToList());
                    OVLJobParameterList = new ObservableCollection<SpecialJobInputSetting>(JobParameterList.Where(p => p.ParameterType == SelectedSpecialJob.OVLModelName).ToList());

                }
                else
                {
                    ClearSpecialJobDetails();
                }
            }
        }

        private void OnSpecialJobChanged(SpecialJobChangedMessage msg)
        {
            Refresh();
        }

        private async Task UpdateSingleSpecialJob(SpecialJobModel specialJob)
        {
            DateTime lastModifiedTime = specialJob.LastModifyDate;

            var newSpecialJob = await SpecialJobService.GetSpecialJobAsync(specialJob.JobId);
            specialJob.LotId = newSpecialJob.LotId;
            specialJob.RunCardId = newSpecialJob.RunCardId;
            specialJob.SplitId = newSpecialJob.SplitId;
            specialJob.CreateTime = newSpecialJob.CreateTime;
            specialJob.JobCompleted = newSpecialJob.JobCompleted;
            specialJob.ControlModelName = newSpecialJob.ControlModelName;
            specialJob.OVLModelName = newSpecialJob.OVLModelName;
            specialJob.C2C = newSpecialJob.C2C;
            specialJob.FEM = newSpecialJob.FEM;
            specialJob.LisOptiSubRecipeName = newSpecialJob.LisOptiSubRecipeName;
            specialJob.UsedTime = newSpecialJob.UsedTime;
            specialJob.NotifyChanges();

            if (SelectedSpecialJob != null && specialJob.JobId == SelectedSpecialJob.JobId && newSpecialJob.LastModifyDate != lastModifiedTime)
            {
                await GetSpecialJobDetailsAsync();

                if (SelectedSpecialJob == null || SelectedSpecialJob.SpecialJobParameters.Count < 1)
                {
                    return;
                }

                JobParameterList = new ObservableCollection<SpecialJobInputSetting>(SelectedSpecialJob.SpecialJobParameters.Select(p =>
                new SpecialJobInputSetting()
                {
                    ParameterName = p.ParameterName,
                    InputValueNA = p.InputValueNA,
                    InputValueC1 = p.InputValueC1,
                    InputValueC2 = p.InputValueC2,
                    Min = p.Min,
                    Max = p.Max,
                    Unit = p.Unit,
                    ParameterType = p.ParameterType,
                    ChuckFlag = NoChuckFlag,
                }));

                CDJobParameterList = new ObservableCollection<SpecialJobInputSetting>(JobParameterList.Where(p => p.ParameterType == "DCD" || p.ParameterType == "FEM").ToList());
                OVLJobParameterList = new ObservableCollection<SpecialJobInputSetting>(JobParameterList.Where(p => p.ParameterType == SelectedSpecialJob.OVLModelName).ToList());

            }
        }
        #endregion

        #region Commands

        [Command]
        public void Refresh()
        {
            PagedSource.UpdateSummaries();
            PagedSource.RefreshRows();
        }
        public bool CanRefresh()
        {
            return !IsLoading;
        }

        private async Task GetSpecialJobDetailsAsync()
        {
            if (SelectedSpecialJob != null)
            {
                var targetJob = SelectedSpecialJob;
                var refreshedJob = await SpecialJobService.GetSpecialJobAsync(targetJob.JobId);
                targetJob.LastModifiedBy = refreshedJob.LastModifiedBy;
                targetJob.LastModifyDate = refreshedJob.LastModifyDate;
                targetJob.UsedTime = refreshedJob.UsedTime;
                targetJob.UserId = refreshedJob.UserId;
                targetJob.IsValid = refreshedJob.IsValid;
                targetJob.JobCompleted = refreshedJob.JobCompleted;
                targetJob.SpecialJobParameters = refreshedJob.SpecialJobParameters;
                targetJob.RunCardId = refreshedJob.RunCardId;
                targetJob.SplitId = refreshedJob.SplitId;
                targetJob.LotId = refreshedJob.LotId;
                targetJob.JobId = refreshedJob.JobId;
                targetJob.FabId = refreshedJob.FabId;
                targetJob.Product = refreshedJob.Product;
                targetJob.Layer = refreshedJob.Layer;
                targetJob.Tool = refreshedJob.Tool;
                targetJob.Reticle = refreshedJob.Reticle;
                targetJob.Recipe = refreshedJob.Recipe;
                targetJob.ControlModelName = refreshedJob.ControlModelName;
                targetJob.OVLModelName = refreshedJob.OVLModelName;
                targetJob.C2C = refreshedJob.C2C;
                targetJob.FEM = refreshedJob.FEM;
                targetJob.LisOptiSubRecipeName = refreshedJob.LisOptiSubRecipeName;
                //targetJob.UserId = refreshedJob.UserId; //ClientInfo.UserName, 
                //targetJob.UsedTime = refreshedJob.UsedTime;
                //targetJob.CreateTime = DateTime.Now;
                targetJob.NotifyChanges();

                if (SelectedSpecialJob.SpecialJobParameters.Count < 1)
                {
                    return;
                }

                JobParameterList = new ObservableCollection<SpecialJobInputSetting>(SelectedSpecialJob.SpecialJobParameters.Select(p =>
                new SpecialJobInputSetting()
                {
                    ParameterName = p.ParameterName,
                    InputValueNA = p.InputValueNA,
                    InputValueC1 = p.InputValueC1,
                    InputValueC2 = p.InputValueC2,
                    Min = p.Min,
                    Max = p.Max,
                    Unit = p.Unit,
                    ParameterType = p.ParameterType,
                    ChuckFlag = NoChuckFlag,
                }));

                CDJobParameterList = new ObservableCollection<SpecialJobInputSetting>(JobParameterList.Where(p => p.ParameterType == "DCD" || p.ParameterType == "FEM").ToList());
                OVLJobParameterList = new ObservableCollection<SpecialJobInputSetting>(JobParameterList.Where(p => p.ParameterType  == SelectedSpecialJob.OVLModelName).ToList());

                try
                {
                    IsHistoryLoading = true;
                    if (SelectedSpecialJob != null)
                    {
                        HistoryList = new ObservableCollection<TransactionHistory>(await GlobalService.GetHistoryAsync(ClientInfo.LoginArea, "SpecialJob", targetJob.JobKey, null));
                    }
                }
                finally
                {
                    IsHistoryLoading = false;
                }
            }
            else
            {
                HistoryList?.Clear();
            }
        }

        [Command]
        public async void CopySpecialJob()
        {
            await RefreshBeforeAction(SelectedSpecialJob);
            List<string> OVLModelNameList = new List<string>();
            OVLModelNameList = await ContextService.GetOVLModelNameListAsync(SelectedSpecialJob.Tool);
            ShowPopup("EditSpecialJob", new EditSpecialJobViewModel(null, SelectedSpecialJob, OVLModelNameList, FunctionMode.Copy));
            //Refresh();
        }

        public bool CanCopySpecialJob()
        {
            return SelectedSpecialJob != null && SelectedSpecialJobList.Count == 1 && !IsLoading && AuthorityManager.HasAuthority(Auth_SpecialJob_Copy);
        }

        [Command]
        public async void EditSpecialJob()
        {
            await RefreshBeforeAction(SelectedSpecialJob);
            List<string> OVLModelNameList = new List<string>();
            OVLModelNameList = await ContextService.GetOVLModelNameListAsync(SelectedSpecialJob.Tool);
            ShowPopup("EditSpecialJob", new EditSpecialJobViewModel(null, SelectedSpecialJob, OVLModelNameList, FunctionMode.Modify));
            //Refresh();
        }

        public bool CanEditSpecialJob()
        {
            return SelectedSpecialJob != null && SelectedSpecialJobList.Count == 1 && !IsLoading && SelectedSpecialJob.IsValid && !SelectedSpecialJob.JobCompleted && AuthorityManager.HasAuthority(Auth_SpecialJob_Edit);
        }

        [Command]
        public async void DeleteSpecialJob()
        {
            await RefreshBeforeAction(SelectedSpecialJob);
            if (IsConfirmed(out var comment, $"Delete Special Job"))
            {
                var toDeleteSpecialJob = SelectedSpecialJob;
                await SpecialJobService.DeleteSpecialJobAsync(SelectedSpecialJob.JobId, comment);
                Messenger.Default.Send(new SpecialJobChangedMessage() { ChangeType = ObjectChangeType.Deleted, SpecialJobId = toDeleteSpecialJob.JobId });
                MessageBoxService.ShowMessage($"SpecialJob {toDeleteSpecialJob.JobId} is deleted.", "Success", MessageButton.OK, MessageIcon.Information);
            }
            //Refresh();
        }

        public bool CanDeleteSpecialJob()
        {
            return SelectedSpecialJob != null && SelectedSpecialJobList.Count == 1 && !IsLoading && SelectedSpecialJob.IsValid && !SelectedSpecialJob.JobCompleted && AuthorityManager.HasAuthority(Auth_SpecialJob_Delete);
        }
        public async Task RefreshBeforeAction(SpecialJobModel job)
        {
            ShowWait();
            await UpdateSingleSpecialJob(job);
            HideWait();
        }
        private void ClearSpecialJobDetails()
        {
            HistoryList = new ObservableCollection<TransactionHistory>();
        }

        #endregion

        #region Properties
        public PagedAsyncSource PagedSource
        {
            get { return GetValue<PagedAsyncSource>(); }
            set { SetValue(value); }
        }
        public bool NoChuckFlag
        {
            get { return GetValue<bool>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(NoChuckFlag));
            }
        }

        public bool HaveChuckFlag
        {
            get { return GetValue<bool>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(HaveChuckFlag));
            }
        }

        public ObservableCollection<SpecialJobModel> SpecialJobList
        {
            get { return GetValue<ObservableCollection<SpecialJobModel>>(); }
            set { SetValue(value); }
        }


        public SpecialJobModel SelectedSpecialJob
        {
            get { return GetValue<SpecialJobModel>(); }
            set { SetValue(value); }
        }

        public ObservableCollection<SpecialJobInputSetting> JobParameterList
        {
            get { return GetValue<ObservableCollection<SpecialJobInputSetting>>(); }
            set { SetValue(value); }
        }

        public ObservableCollection<SpecialJobInputSetting> CDJobParameterList
        {
            get { return GetValue<ObservableCollection<SpecialJobInputSetting>>(); }
            set { SetValue(value); }
        }
        public ObservableCollection<SpecialJobInputSetting> OVLJobParameterList
        {
            get { return GetValue<ObservableCollection<SpecialJobInputSetting>>(); }
            set { SetValue(value); }
        }
        public ObservableCollection<SpecialJobModel> SelectedSpecialJobList { get; } = new ObservableCollection<SpecialJobModel>();

        #endregion
    }
}
