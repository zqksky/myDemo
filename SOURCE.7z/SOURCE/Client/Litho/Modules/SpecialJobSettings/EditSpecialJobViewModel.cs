﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using AMAT.R2R.Client.Common.Enums;
using AMAT.R2R.Client.Common.Helpers;
using AMAT.R2R.Client.Litho.Messages;
using AMAT.R2R.Shared.Litho.DTO;
using DevExpress.Mvvm;
using DevExpress.Mvvm.DataAnnotations;
using Newtonsoft.Json;

namespace AMAT.R2R.Client.Litho.Modules.SpecialJobSettings
{
    public class EditSpecialJobViewModel : LithoViewModelBase
    {
        private const string NA = "NA";

        public EditSpecialJobViewModel(Context context, SpecialJob sourceSpecialJob, List<string> ovlModelNameList, FunctionMode mode)
        {
            CurrentContext = context;
            if (context != null && !string.IsNullOrEmpty(context.OVLContextKey))
            {
                ContextKey = context.OVLContextKey;
            }

            SizeToContent = System.Windows.SizeToContent.Manual;
            SourceSpecialJob = sourceSpecialJob;

            // TODO: read from config for Primary Keys.
            IsFabPrimaryKey = true;
            IsToolPrimaryKey = true;
            IsProductPrimaryKey = true;
            IsLayerPrimaryKey = true;
            IsReticlePrimaryKey = true;
            IsRecipePrimaryKey = true;
            IsOVLModelNameKey = true;

            IsOVLModelNameRequired = IsOVLModelNameKey;
            IsFabRequired = IsFabPrimaryKey;
            IsToolRequired = IsToolPrimaryKey;
            IsProductRequired = IsProductPrimaryKey;
            IsLayerRequired = IsLayerPrimaryKey;
            IsReticleRequired = IsReticlePrimaryKey;
            IsRecipeRequired = IsRecipePrimaryKey;


            if (SourceSpecialJob != null)
            {
                JobId = SourceSpecialJob.JobId;
                Fab = SourceSpecialJob.FabId;
                Product = SourceSpecialJob.Product;
                Layer = SourceSpecialJob.Layer;
                Tool = SourceSpecialJob.Tool;
                Reticle = SourceSpecialJob.Reticle;
                Recipe = SourceSpecialJob.Recipe;
                SpecialJobParameters = SourceSpecialJob.SpecialJobParameters;
                OVLModelName = SourceSpecialJob.OVLModelName;
                C2C = SourceSpecialJob.C2C == 1;
                FEM = SourceSpecialJob.FEM == 1;
                LotId = SourceSpecialJob.LotId;
                RuncardId = SourceSpecialJob.RunCardId;
                SplitId = SourceSpecialJob.SplitId;
                UserId = SourceSpecialJob.UserId;
                UsedTime = SourceSpecialJob.UsedTime;
                CreateTime = SourceSpecialJob.CreateTime;

            }
            else
            {
                Fab = ClientInfo.LoginFab;
            }

            Mode = mode;
            if (Mode == FunctionMode.Add)
            {
                if (ovlModelNameList != null)
                {
                    OVLModelNameList = new ObservableCollection<string>(ovlModelNameList);
                }
            }

            switch (mode)
            {
                case FunctionMode.None:
                    break;
                case FunctionMode.Add:
                    Caption = "Create Special Job";
                    break;
                case FunctionMode.Copy:
                    Caption = "Copy Special Job";
                    break;
                case FunctionMode.Modify:
                    Caption = "Edit Special Job";
                    break;
                case FunctionMode.Delete:
                    break;
                case FunctionMode.View:
                    break;
                default:
                    break;
            }
            NoChuckFlag = !C2C;
        }

        protected override void OnViewReadyAsync()
        {
            Refresh();
        }

        private async void Refresh()
        {
            ShowWait();

            // refresh context.
            if (ContextKey != null)
            {
                CurrentContext = await ContextService.GetContextAsync(ContextKey);
            }


            if (Mode != FunctionMode.Add)
            {
                // refresh source job.
                //SourceSpecialJob = await SpecialJobService.GetSpecialJobAsync(SourceSpecialJob.JobId);

                // clone source job.
                NewSpecialJob = JsonConvert.DeserializeObject<SpecialJob>(JsonConvert.SerializeObject(SourceSpecialJob));
            }
            else
            {
                if (OVLModelNameList != null && OVLModelNameList.Count > 0)
                {
                    OVLModelName = OVLModelNameList[0];
                }
                else
                {
                    OVLModelName = " ";
                }
                if (!string.IsNullOrEmpty(ContextKey))
                {
                    SpecialJobParameters = await SpecialJobService.GetSpecialJobParameterAsync(OVLModelName, C2C ? 1 : 0, FEM ? 1 : 0, ContextKey);
                }
                NewSpecialJob = new SpecialJob
                {
                    FabId = CurrentContext.Fab,
                    Tool = CurrentContext.Tool,
                    Product = CurrentContext.Product,
                    Layer = CurrentContext.Layer,
                    Reticle = CurrentContext.Reticle,
                    Recipe = CurrentContext.Recipe,


                    // create default parameters
                    SpecialJobParameters = SpecialJobParameters,
                    LotId = string.Empty,
                    RunCardId = NA,
                    SplitId = NA,

                    IsValid = false,
                    ControlModelName = ControlModelName,
                    LisOptiSubRecipeName = LisOptiSubRecipeName,
                    CreateTime = DateTime.Now,
                    UsedTime = DateTime.Now,
                    UserId = ClientInfo.UserName,
                };
            }

            Fab = NewSpecialJob.FabId;
            Product = NewSpecialJob.Product;
            Layer = NewSpecialJob.Layer;
            Tool = NewSpecialJob.Tool;
            Reticle = NewSpecialJob.Reticle;
            Recipe = NewSpecialJob.Recipe;
            SpecialJobParameters = SourceSpecialJob.SpecialJobParameters;
            OVLModelName = NewSpecialJob.OVLModelName;
            C2C = NewSpecialJob.C2C == 1;
            FEM = NewSpecialJob.FEM == 1;


            JobParameterList = new ObservableCollection<SpecialJobInputSetting>(NewSpecialJob.SpecialJobParameters.Select(p =>
            new SpecialJobInputSetting()
            {
                ParameterName = p.ParameterName,
                InputValueNA = p.InputValueNA,
                InputValueC1 = p.InputValueC1,
                InputValueC2 = p.InputValueC2,
                Min = p.Min,
                Max = p.Max,
                Unit = p.Unit,
                ParameterType = p.ParameterType,
                ChuckFlag=NoChuckFlag,
            }));

            CDJobParameterList = new ObservableCollection<SpecialJobInputSetting>(JobParameterList.Where(p => p.ParameterType == "DCD" || p.ParameterType == "FEM").ToList());
            OVLJobParameterList = new ObservableCollection<SpecialJobInputSetting>(JobParameterList.Where(p => p.ParameterType == OVLModelName).ToList());

            foreach (var param in JobParameterList)
            {
                param.PropertyChanged += Param_PropertyChanged;
            }
            foreach (var param in CDJobParameterList)
            {
                param.PropertyChanged += Param_PropertyChanged;
            }
            foreach (var param in OVLJobParameterList)
            {
                param.PropertyChanged += Param_PropertyChanged;
            }
            IsLot = NewSpecialJob.LotId != NA;
            LotId = NewSpecialJob.LotId;
            RunCardId = NewSpecialJob.RunCardId;
            SplitId = NewSpecialJob.SplitId;

            HideWait();

            IsDirty = false;
        }

        private void Param_PropertyChanged(object sender, System.ComponentModel.PropertyChangedEventArgs e)
        {
            if (e.PropertyName == nameof(SpecialJobInputSetting.InputValueNA))
            {
                IsDirty = true;
                ClearError($"{nameof(JobParameterList)}.{e.PropertyName}");
            }
            if (e.PropertyName == nameof(SpecialJobInputSetting.InputValueC1))
            {
                IsDirty = true;
                ClearError($"{nameof(JobParameterList)}.{e.PropertyName}");
            }
            if (e.PropertyName == nameof(SpecialJobInputSetting.InputValueC2))
            {
                IsDirty = true;
                ClearError($"{nameof(JobParameterList)}.{e.PropertyName}");
            }
        }

        [Command]
        public async void Save()
        {
            try
            {
                if (!IsDirty)
                {
                    MessageBoxService.ShowMessage($"No change!", "Message", MessageButton.OK, MessageIcon.Information);
                    return;
                }

                if (IsLot)
                {
                    ValidateAndSetErrorFocus(nameof(LotId));
                }
                else
                {
                    ValidateAndSetErrorFocus(nameof(RunCardId), nameof(SplitId));
                }

                if (HasErrors) return;

                foreach (var item in JobParameterList)
                {
                    if (item.Error != null)
                    {
                        SetError($"{nameof(JobParameterList)}.{item.Error}", item[item.Error]);
                        SetFocus(nameof(JobParameterList));
                        return;
                    }
                }

                if (IsConfirmed(out var comment))
                {
                    NewSpecialJob.LotId = LotId;
                    NewSpecialJob.RunCardId = RunCardId;
                    NewSpecialJob.SplitId = SplitId;
                    NewSpecialJob.JobCompleted = false;
                    //NewSpecialJob.JobId = JobId;
                    NewSpecialJob.FabId = Fab;
                    NewSpecialJob.Product = Product;
                    NewSpecialJob.Layer = Layer;
                    NewSpecialJob.Tool = Tool;
                    NewSpecialJob.Reticle = Reticle;
                    NewSpecialJob.Recipe = Recipe;
                    NewSpecialJob.IsValid = true;
                    NewSpecialJob.ControlModelName = "NA";
                    NewSpecialJob.OVLModelName = OVLModelName;
                    NewSpecialJob.C2C = C2C ? 1 : 0;
                    NewSpecialJob.FEM = FEM ? 1 : 0;
                    //NewSpecialJob.LisOptiSubRecipeName = LisOptiSubRecipeName;            
                    NewSpecialJob.UserId = ClientInfo.UserName;
                    NewSpecialJob.UsedTime = DateTime.Now;
                    NewSpecialJob.CreateTime = DateTime.Now;

                    NewSpecialJob.ControlModelName = ContextService.GetControlModelName(OVLModelName);

                    foreach (SpecialJobInputSetting ovlParam in OVLJobParameterList)
                    {
                        SpecialJobParameter sjp = NewSpecialJob.SpecialJobParameters.First(p => p.ParameterName == ovlParam.ParameterName);
                        if (sjp != null)
                        {
                            sjp.InputValueNA = ovlParam.InputValueNA;
                            sjp.InputValueC1 = ovlParam.InputValueC1;
                            sjp.InputValueC2 = ovlParam.InputValueC2;
                        }
                    }

                    foreach (SpecialJobInputSetting cdParam in CDJobParameterList)
                    {
                        SpecialJobParameter sjp = NewSpecialJob.SpecialJobParameters.First(p => p.ParameterName == cdParam.ParameterName);
                        if (sjp != null)
                        {
                            sjp.InputValueNA = cdParam.InputValueNA;
                            sjp.InputValueC1 = cdParam.InputValueC1;
                            sjp.InputValueC2 = cdParam.InputValueC2;
                        }
                    }



                    ShowWait();
                    if (Mode == FunctionMode.Add || Mode == FunctionMode.Copy)
                    {
                        NewSpecialJob.JobId = string.Empty;
                        var createdJob = await SpecialJobService.CreateSpecialJobAsync(NewSpecialJob, comment);
                        IsDirty = false;
                        HideWait();
                        Messenger.Default.Send(new SpecialJobChangedMessage() { ChangeType = ObjectChangeType.Created, SpecialJobId = createdJob.JobId });
                        MessageBoxService.ShowMessage($"Special Job is created!", "Success", MessageButton.OK, MessageIcon.Information);
                    }
                    else
                    {
                        await SpecialJobService.UpdateSpecialJobAsync(NewSpecialJob.JobId, NewSpecialJob, comment);
                        IsDirty = false;
                        HideWait();
                        Messenger.Default.Send(new SpecialJobChangedMessage() { ChangeType = ObjectChangeType.Updated, SpecialJobId = NewSpecialJob.JobId });
                        MessageBoxService.ShowMessage($"Special Job is updated!", "Success", MessageButton.OK, MessageIcon.Information);
                    }
                    CloseWindow();
                }
            }
            catch (Exception ex)
            {
                ErrorHandler.HandleError(ex);
            }
        }

        public bool CanSave()
        {
            return true;
            //return IsDirty;
        }

        [Command]
        public void SelectedIndexChanged()
        {
            NoChuckFlag = !C2C;
            if (Mode == FunctionMode.Modify)
            {
                return;
            }
            if (OVLModelNameList != null && OVLModelNameList.Count > 0)
            {
                if (string.IsNullOrEmpty(OVLModelName))
                {
                    OVLModelName = OVLModelNameList[0];
                }
            }
            else
            {
                if (string.IsNullOrEmpty(OVLModelName))
                {
                    OVLModelName = " ";
                }

            }
            if (NewSpecialJob != null && ContextKey != null)
            {
                NewSpecialJob.SpecialJobParameters = new List<SpecialJobParameter>();
                NewSpecialJob.SpecialJobParameters = SpecialJobService.GetSpecialJobParameter(OVLModelName, C2C ? 1 : 0, FEM ? 1 : 0, ContextKey);
                JobParameterList = new ObservableCollection<SpecialJobInputSetting>(NewSpecialJob.SpecialJobParameters.Select(p =>
                new SpecialJobInputSetting()
                {
                    ParameterName = p.ParameterName,
                    InputValueNA = p.InputValueNA,
                    InputValueC1 = p.InputValueC1,
                    InputValueC2 = p.InputValueC2,
                    Min = p.Min,
                    Max = p.Max,
                    Unit = p.Unit,
                    ParameterType = p.ParameterType,
                    ChuckFlag = NoChuckFlag,
                }));

                CDJobParameterList = new ObservableCollection<SpecialJobInputSetting>(JobParameterList.Where(p => p.ParameterType == "DCD" || p.ParameterType == "FEM").ToList());
                OVLJobParameterList = new ObservableCollection<SpecialJobInputSetting>(JobParameterList.Where(p => p.ParameterType == OVLModelName).ToList());

                //foreach (var param in JobParameterList)
                //{
                //    param.PropertyChanged += Param_PropertyChanged;
                //}
            }
        }
        public bool CanSelectedIndex()
        {
            return true;
        }

        public void SetRunCardIdNA() => RunCardId = NA;
        public void SetSplitIdNA() => SplitId = NA;

        #region Properties

        public string ContextKey { get; set; }

        public Context CurrentContext
        {
            get { return GetValue<Context>(); }
            set { SetValue(value); }
        }

        public SpecialJob SourceSpecialJob
        {
            get { return GetValue<SpecialJob>(); }
            set { SetValue(value); }
        }

        public SpecialJob NewSpecialJob
        {
            get { return GetValue<SpecialJob>(); }
            set { SetValue(value); }
        }
        public ObservableCollection<SpecialJobInputSetting> JobParameterList
        {
            get { return GetValue<ObservableCollection<SpecialJobInputSetting>>(); }
            set { SetValue(value); }
        }

        public ObservableCollection<SpecialJobInputSetting> CDJobParameterList
        {
            get { return GetValue<ObservableCollection<SpecialJobInputSetting>>(); }
            set { SetValue(value); }
        }
        public ObservableCollection<SpecialJobInputSetting> OVLJobParameterList
        {
            get { return GetValue<ObservableCollection<SpecialJobInputSetting>>(); }
            set { SetValue(value); }
        }

        public string LotId
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(LotId));
            }
        }

        public string RunCardId
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(RunCardId));
            }
        }

        public string SplitId
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(SplitId));
            }
        }

        public string JobKey
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(JobKey));
            }
        }

        public string JobId
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(JobId));
            }
        }
        public string RuncardId
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(RuncardId));
            }
        }

        public string LisOptiSubRecipeName
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(LisOptiSubRecipeName));
            }
        }

        public DateTime? UsedTime
        {
            get { return GetValue<DateTime>(); }
            set { SetValue(value); }
        }

        public List<SpecialJobParameter> SpecialJobParameters
        {
            get { return GetValue<List<SpecialJobParameter>>(); }
            set { SetValue(value); }
        }
        public bool IsValid
        {
            get { return GetValue<bool>(); }
            set { SetValue(value); }
        }

        public string UserId
        {
            get { return GetValue<string>(); }
            set { SetValue(value); }
        }

        public DateTime? CreateTime
        {
            get { return GetValue<DateTime>(); }
            set { SetValue(value); }
        }

        public string Fab
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(Fab));
            }
        }

        public string Tool
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(Tool));
            }
        }

        public string Product
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(Product));
            }
        }

        public string Layer
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(Layer));
            }
        }

        public string Reticle
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(Reticle));
            }
        }

        public string Recipe
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(Recipe));
            }
        }
        public string CDContextKey
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(CDContextKey));
            }
        }
        public string ControlModelName
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(ControlModelName));
            }
        }

        public string OVLModelName
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(OVLModelName));
            }
        }

        public bool JobCompleted
        {
            get { return GetValue<bool>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(JobCompleted));
            }
        }
        public bool NoChuckFlag
        {
            get { return GetValue<bool>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(NoChuckFlag));
            }
        }

        public bool C2C
        {
            get { return GetValue<bool>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(C2C));
            }
        }

        public bool FEM
        {
            get { return GetValue<bool>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(FEM));
            }
        }

        public bool SpecialLot
        {
            get { return GetValue<bool>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(SpecialLot));
            }
        }

        public bool IsOVLModelNameKey { get { return GetValue<bool>(); } set { SetValue(value); } }
        public bool IsOVLModelNameRequired
        {
            get
            {
                return GetValue<bool>();
            }
            set
            {
                SetValue(value);
                SetFocus(nameof(OVLModelName));
            }
        }

        public bool IsFabPrimaryKey { get { return GetValue<bool>(); } set { SetValue(value); } }
        public bool IsFabRequired
        {
            get
            {
                return GetValue<bool>();
            }
            set
            {
                SetValue(value);
                SetFocus(nameof(Fab));
            }
        }

        public bool IsToolPrimaryKey { get { return GetValue<bool>(); } set { SetValue(value); } }
        public bool IsToolRequired
        {
            get
            {
                return GetValue<bool>();
            }
            set
            {
                SetValue(value);
                SetFocus(nameof(Tool));
            }
        }

        public bool IsProductPrimaryKey { get { return GetValue<bool>(); } set { SetValue(value); } }
        public bool IsProductRequired
        {
            get
            {
                return GetValue<bool>();
            }
            set
            {
                SetValue(value);
                if (value)
                {
                    SetFocus(nameof(Product));
                }
            }
        }
        public bool IsLayerPrimaryKey { get { return GetValue<bool>(); } set { SetValue(value); } }
        public bool IsLayerRequired
        {
            get
            {
                return GetValue<bool>();
            }
            set
            {
                SetValue(value);
                if (value)
                {
                    SetFocus(nameof(Layer));
                }
            }
        }
        public bool IsRecipePrimaryKey { get { return GetValue<bool>(); } set { SetValue(value); } }
        public bool IsRecipeRequired
        {
            get
            {
                return GetValue<bool>();
            }
            set
            {
                SetValue(value);
                if (value)
                {
                    SetFocus(nameof(Recipe));
                }
            }
        }
        public bool IsReticlePrimaryKey { get { return GetValue<bool>(); } set { SetValue(value); } }
        public bool IsReticleRequired
        {
            get
            {
                return GetValue<bool>();
            }
            set
            {
                SetValue(value);
                if (value)
                {
                    SetFocus(nameof(Reticle));
                }
            }
        }

        public bool IsSpecialLotKey { get { return GetValue<bool>(); } set { SetValue(value); } }
        public bool IsSpecialLotRequired
        {
            get
            {
                return GetValue<bool>();
            }
            set
            {
                SetValue(value);
                SetFocus(nameof(SpecialLot));
            }
        }
        public bool IsC2CKey { get { return GetValue<bool>(); } set { SetValue(value); } }
        public bool IsC2CRequired
        {
            get
            {
                return GetValue<bool>();
            }
            set
            {
                SetValue(value);
                SetFocus(nameof(C2C));
            }
        }
        public bool IsFEMKey { get { return GetValue<bool>(); } set { SetValue(value); } }
        public bool IsFEMRequired
        {
            get
            {
                return GetValue<bool>();
            }
            set
            {
                SetValue(value);
                SetFocus(nameof(FEM));
            }
        }

        public ObservableCollection<string> OVLModelNameList
        {
            get { return GetValue<ObservableCollection<string>>(); }
            set { SetValue(value); }
        }

        public bool IsLot
        {
            get { return GetValue<bool>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(IsLot));
                if (value)
                {
                    if (LotId == NA)
                    {
                        LotId = string.Empty;
                    }
                    RunCardId = NA;
                    SplitId = NA;
                }
                else
                {
                    if (RunCardId == NA)
                    {
                        RunCardId = string.Empty;
                    }
                    if (SplitId == NA)
                    {
                        SplitId = string.Empty;
                    }
                    LotId = NA;
                }
            }
        }
        #endregion

        protected override string GetError(string columnName)
        {
            switch (columnName)
            {
                case nameof(Fab):
                    return DataValidator.ValidString(Fab);
                case nameof(Product):
                    return DataValidator.ValidString(Product);
                case nameof(Layer):
                    return DataValidator.ValidString(Layer);
                case nameof(Tool):
                    return DataValidator.ValidString(Tool);
                case nameof(Reticle):
                    return DataValidator.ValidString(Reticle);
                case nameof(Recipe):
                    return DataValidator.ValidString(Recipe);
                case nameof(OVLModelName):
                    return DataValidator.ValidString(OVLModelName);
                case nameof(LotId):
                    return DataValidator.ValidString(LotId);
                case nameof(RuncardId):
                    return DataValidator.ValidString(RuncardId);
                case nameof(SplitId):
                    return DataValidator.ValidString(SplitId);
                default:
                    return null;
            }
        }
    }

    public class SpecialJobInputSetting : BindableBase, IDataErrorInfo
    {
        public string ParameterName { get; set; }
        public string Unit { get; set; }

        public double? InputValueNA
        {
            get { return GetValue<double?>(); }
            set { SetValue(value); }
        }
        public double? InputValueC1
        {
            get { return GetValue<double?>(); }
            set { SetValue(value); }
        }
        public double? InputValueC2
        {
            get { return GetValue<double?>(); }
            set { SetValue(value); }
        }
        public double? Min { get; set; }
        public double? Max { get; set; }
        public string ParameterType { get; set; }

        public bool ChuckFlag { get; set; }
        public string Error
        {
            get
            {
                if (ParameterType == "DCD" || ParameterType == "FEM")
                {
                    return !string.IsNullOrEmpty(this[nameof(InputValueNA)]) ? $"InputValue" : null;
                }
                else
                {
                    if (ChuckFlag)
                    {
                        return !string.IsNullOrEmpty(this[nameof(InputValueNA)]) ? $"InputValue" : null;
                    }
                    else
                    {
                        if (!string.IsNullOrEmpty(this[nameof(InputValueC1)]))
                        {
                            return $"{nameof(InputValueC1)}";
                        }
                        else if (!string.IsNullOrEmpty(this[nameof(InputValueC2)]))
                        {
                            return $"{nameof(InputValueC2)}";
                        }
                        else
                        {
                            return null;
                        }
                    }
                }

            }
        }

        public string this[string propertyName]
        {
            get
            {
                switch (propertyName)
                {
                    case nameof(InputValueNA):
                        return DataValidator.NotNull(InputValueNA);
                    case nameof(InputValueC1):
                        return DataValidator.NotNull(InputValueC1);
                    case nameof(InputValueC2):
                        return DataValidator.NotNull(InputValueC2);
                    default:
                        return null;
                }
            }
        }
    }
}
