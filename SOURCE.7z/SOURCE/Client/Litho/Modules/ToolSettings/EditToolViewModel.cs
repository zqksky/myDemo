﻿using AMAT.R2R.Client.Common.Enums;
using AMAT.R2R.Client.Common.Helpers;
using AMAT.R2R.Client.Litho.Messages;
using AMAT.R2R.Shared.Litho.DTO;
using DevExpress.Mvvm;
using DevExpress.Mvvm.DataAnnotations;

namespace AMAT.R2R.Client.Litho.Modules.ToolSettings
{
    public class EditToolViewModel : LithoViewModelBase
    {
        private const string NA = "NA";
        public EditToolViewModel(Tool tool, FunctionMode mode)
        {
            OriginalTool = tool;
            SizeToContent = System.Windows.SizeToContent.WidthAndHeight;

            if (tool != null)
            {
                Fab = tool.Fab;
                Area = tool.Area;
                NameSpace = tool.NameSpace;
                ToolId = tool.ToolId;
                ToolVendor = tool.ToolVendor;
                ToolModel = tool.ToolModel;
                ProcessModel = tool.ProcessModel;
                ProcessType = tool.ProcessType;
            }
            else
            {
                Fab = ClientInfo.LoginFab;

            }
            Mode = mode;

            switch (mode)
            {
                case FunctionMode.None:
                    break;
                case FunctionMode.Add:
                    Caption = "Create Tool";
                    break;
                case FunctionMode.Copy:
                    Caption = "Copy Tool";
                    break;
                case FunctionMode.Modify:
                    Caption = "Edit Tool";
                    break;
                case FunctionMode.Delete:
                    break;
                case FunctionMode.View:
                    break;
                default:
                    break;
            }
            IsDirty = false;

            PropertyChanged += OnPropertyChanged;
        }

        private void OnPropertyChanged(object sender, System.ComponentModel.PropertyChangedEventArgs e)
        {
            if (e.PropertyName == nameof(ToolId))
            {
                IsDirty = true;
            }
        }

        protected override void OnViewReadyAsync()
        {
            if (Mode == FunctionMode.Add)
            {
                SetFocus(nameof(ToolId));
            }
        }


        [Command]
        public async void Save()
        {
            ValidateAndSetErrorFocus(nameof(ToolId), nameof(ToolModel), nameof(ToolVendor), nameof(ProcessType), nameof(ProcessModel));

            if (HasErrors)
            {
                return;
            }

            // 
            if (IsConfirmed(out string comment))
            {
                var newTool = new Tool
                {
                    Fab = Fab,
                    ToolId = ToolId,
                    ToolModel = ToolModel,
                    ProcessType = ProcessType,
                    ToolVendor = ToolVendor,
                    ProcessModel = ProcessModel,
                };

                if (Mode == FunctionMode.Modify)
                {
                    //newTool.ToolId = newTool.ToolId.Replace("#","%23");
                    //ShowWait();
                    await LithoGlobalService.ModifyToolAsync(newTool.ToolId, newTool, comment);
                    IsDirty = false;
                    //HideWait();
                    Messenger.Default.Send(new ToolChangedMessage() { ChangeType = ObjectChangeType.Updated, ToolId = OriginalTool.ToolId });
                    MessageBoxService.ShowMessage($"Tool {newTool.ToolId} is updated!", "Success", MessageButton.OK, MessageIcon.Information);

                }
                else
                {
                    //ShowWait();
                    await LithoGlobalService.CreateToolAsync(newTool, comment);

                    IsDirty = false;
                    //HideWait();
                    Messenger.Default.Send(new ToolChangedMessage() { ChangeType = ObjectChangeType.Created, ToolId = newTool.ToolId });
                    MessageBoxService.ShowMessage($"Tool {newTool.ToolId} is created!", "Success", MessageButton.OK, MessageIcon.Information);

                }

                IsOK = true;
                CloseWindow();
            }
        }

        public bool CanSave()
        {
            switch (Mode)
            {
                case FunctionMode.Add:
                    return true;
                case FunctionMode.Modify:
                    return IsDirty;
                default:
                    return true;
            }
        }

        protected override string GetError(string columnName)
        {
            switch (columnName)
            {
                case nameof(ToolId):
                    return DataValidator.ValidString(ToolId);
                case nameof(ToolVendor):
                    return DataValidator.ValidString(ToolVendor);
                case nameof(ToolModel):
                    return DataValidator.ValidString(ToolModel);
                case nameof(ProcessType):
                    return DataValidator.ValidString(ProcessType);
                case nameof(ProcessModel):
                    return DataValidator.ValidString(ProcessModel);

                default:
                    return null;
            }
        }


        #region Properties
        public Tool OriginalTool { get; private set; }

        public string Fab
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(Fab));
            }
        }
        public string Area
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(Area));
            }
        }

        public string NameSpace
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(NameSpace));
            }
        }
        public string ToolId
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(ToolId));
            }
        }

        public string ToolVendor
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(ToolVendor));
            }
        }

        public string ToolModel
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(ToolModel));
            }
        }
        public string ProcessType
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(ProcessType));
            }
        }

        public string ProcessModel
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(ProcessModel));
            }
        }
        #endregion
    }
}
