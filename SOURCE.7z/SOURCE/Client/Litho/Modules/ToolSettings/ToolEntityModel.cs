﻿using System.ComponentModel;
using AMAT.R2R.Shared.Litho.DTO;

namespace AMAT.R2R.Client.Litho.Modules.ToolSettings
{
    public class ToolEntityModel : Tool, INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;

        public void NotifyChanges()
        {

            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(ToolId)));
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(ToolVendor)));
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(ToolModel)));
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(ProcessType)));
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(ProcessModel)));
        }
    }
}
