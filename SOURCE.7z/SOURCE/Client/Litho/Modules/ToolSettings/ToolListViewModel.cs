﻿using System;
using System.Collections.ObjectModel;
using System.Data;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using AMAT.R2R.Client.Common.Enums;
using AMAT.R2R.Client.Common.Helpers;
using AMAT.R2R.Client.Litho.Helpers;
using AMAT.R2R.Client.Litho.Messages;
using AMAT.R2R.Shared.Base.DTO;
using DevExpress.Mvvm;
using DevExpress.Mvvm.DataAnnotations;
using DevExpress.Spreadsheet;
using DevExpress.Xpf.Data;
using DevExpress.XtraPrinting;

namespace AMAT.R2R.Client.Litho.Modules.ToolSettings
{
    public class ToolListViewModel : LithoViewModelBase
    {
        public const string Auth_Global = "GlobalSettings";
        public const string Auth_Tool = "GlobalSettings:Tool";
        public const string Auth_Tool_Add = "GlobalSettings:Tool:Add";
        public const string Auth_Tool_Copy = "GlobalSettings:Tool:Copy";
        public const string Auth_Tool_Edit = "GlobalSettings:Tool:Edit";
        public const string Auth_Tool_Delete = "GlobalSettings:Tool:Delete";

        public ToolListViewModel()
        {
            Caption = "Tool Settings";
            //Icon = "SvgImages/Outlook Inspired/ProductSpecificationsSummary.svg";
            Icon = "SvgImages/Business Objects/BO_Category.svg";
            PropertyChanged += OnPropertyChanged;
            Messenger.Default.Register<ToolChangedMessage>(this, OnToolChanged);

            //InitializePagedSource();
        }

        #region Filtering & Paging

        private void InitializePagedSource()
        {
            #region Paged Source
            var pagedSource = new PagedAsyncSource()
            {
                ElementType = typeof(ToolEntityModel),
                KeyProperty = nameof(Tool.ToolId),
                PageSize = 100,
                PageNavigationMode = PageNavigationMode.ArbitraryWithTotalPageCount
            };

#if DEBUG
            pagedSource.PageSize = 10;
#endif

            pagedSource.FetchPage += (o, e) =>
            {
                e.Result = FetchPageRowsAsync(e);
            };

            pagedSource.GetTotalSummaries += (o, e) =>
            {
                e.Result = GetSummariesAsync(e);
            };

            pagedSource.GetUniqueValues += (o, e) =>
            {
                e.Result = GetValueListAsync(e);
            };

            pagedSource.PropertyChanged += (o, e) =>
            {
                if (e.PropertyName == nameof(PagedAsyncSource.AreRowsFetching))
                {
                    IsLoading = PagedSource.AreRowsFetching;
                }
            };

            PagedSource = pagedSource;
            #endregion
        }

        private async Task<FetchRowsResult> FetchPageRowsAsync(FetchPageAsyncEventArgs e)
        {
            try
            {
                var items = await LithoGlobalService.GetToolListAsync(e.Filter.MakeFilters(), e.MakeSorters(), e.Skip, e.Take);
                return new FetchRowsResult(items.ToArray(), hasMoreRows: items.Count == e.Take);
            }
            catch (Exception ex)
            {
                Logger.Error(ex);
                throw;
            }
        }

        private async Task<object[]> GetSummariesAsync(GetSummariesAsyncEventArgs e)
        {
            try
            {
                var summary = await LithoGlobalService.GetToolCount(e.Filter.MakeFilters());
                return e.Summaries.Select(x =>
                {
                    return x.SummaryType == SummaryType.Count ? (object)summary : throw new InvalidOperationException();
                }).ToArray();
            }
            catch (Exception ex)
            {
                Logger.Error(ex);
                throw;
            }
        }

        private async Task<object[]> GetValueListAsync(GetUniqueValuesAsyncEventArgs e)
        {
            try
            {
                return await LithoGlobalService.GetToolValueListAsync(e.PropertyName, e.Filter.MakeFilters());
            }
            catch (Exception ex)
            {
                Logger.Error(ex);
                throw;
            }
        }

        #endregion

        protected override void OnViewReadyAsync()
        {
            Refresh();
        }

        //public override void OnClosing(CancelEventArgs e)
        //{
        //    base.OnClosing(e);

        //    PagedSource?.Dispose();
        //    Messenger.Default.Unregister<ToolChangedMessage>(this, OnToolChanged);
        //}

        private async void OnPropertyChanged(object sender, System.ComponentModel.PropertyChangedEventArgs e)
        {
            if (e.PropertyName == nameof(SelectedTool))
            {
                if (SelectedTool != null)
                {
                    await GetToolDetailsAsync();
                }
                else
                {
                    ClearToolDetails();
                }
            }
        }
        private async void OnToolChanged(ToolChangedMessage msg)
        {
            //Refresh();

            var toolEntity = ToolEntityList.FirstOrDefault(p => p.ToolId == msg.ToolId);
            switch (msg.ChangeType)
            {
                case ObjectChangeType.Created:
                    Refresh();
                    break;
                case ObjectChangeType.Deleted:
                    ToolEntityList.Remove(toolEntity);
                    break;
                case ObjectChangeType.Updated:
                    await UpdateSingleTool(toolEntity);
                    break;
                default:
                    break;

            }
        }

        private async Task UpdateSingleTool(ToolEntityModel toolEntity)
        {
            var newToolEntity = await LithoGlobalService.GetToolAsync(toolEntity.ToolId);

            //toolEntity.LastModifyUser = newToolEntity.LastModifyUser;
            //toolEntity.LastModifyTime = newToolEntity.LastModifyTime;
            toolEntity.Fab = newToolEntity.Fab;
            toolEntity.Area = newToolEntity.Area;
            toolEntity.ToolId = newToolEntity.ToolId;
            toolEntity.ToolVendor = newToolEntity.ToolVendor;
            toolEntity.ToolModel = newToolEntity.ToolModel;
            toolEntity.Area = newToolEntity.Area;
            toolEntity.NameSpace = newToolEntity.NameSpace;
            toolEntity.ProcessModel = newToolEntity.ProcessModel;
            toolEntity.ProcessType = newToolEntity.ProcessType;

            toolEntity.NotifyChanges();

            if (SelectedTool != null && toolEntity.ToolId == SelectedTool.ToolId)
            {
                await GetToolDetailsAsync();
            }
        }


        private async Task GetToolDetailsAsync()
        {
            if (SelectedTool != null)
            {
                #region 
                Fab = SelectedTool.Fab;
                Area = SelectedTool.Area;
                NameSpace = SelectedTool.NameSpace;
                ToolId = SelectedTool.ToolId;
                ToolModel = SelectedTool.ToolModel;
                ProcessModel = SelectedTool.ProcessModel;
                ProcessType = SelectedTool.ProcessType;
                ToolVendor = SelectedTool.ToolVendor;
                #endregion

                try
                {
                    IsHistoryLoading = true;
                    HistoryList = new ObservableCollection<TransactionHistory>(await GlobalService.GetHistoryAsync(ClientInfo.LoginArea, "Tool", SelectedTool.ToolId, null));
                }
                finally
                {
                    IsHistoryLoading = false;
                }
            }
            else
            {
                HistoryList?.Clear();
            }
        }

        #region Commands
        [Command]
        public async void Refresh()
        {
            try
            {
                //IsLoading = true;
                //PagedSource.UpdateSummaries();
                //PagedSource.RefreshRows();

                IsLoading = true;
                ClearToolDetails();

                var preSelectedTool = SelectedTool;
                var toolEntityList = await LithoGlobalService.GetToolListAsync();
                //var toolEntityList = await LithoGlobalService.GetToolListAsync(new QueryParameter("fab", ClientInfo.LoginFab));
                ToolEntityList = new ObservableCollection<ToolEntityModel>(toolEntityList);

                if (preSelectedTool != null)
                {
                    SelectedTool = ToolEntityList.FirstOrDefault(p => p.ToolId == preSelectedTool.ToolId);
                }

            }
            finally
            {
                IsLoading = false;
            }
        }
        public bool CanRefresh()
        {
            return !IsLoading;
        }

        [Command]
        public void Import()
        {
            OpenFile();
        }

        public bool CanImport()
        {
            return true;
            //return AuthorityManager.HasAuthority(Auth_Tool_Add);
        }
        private void OpenFile()
        {
            OpenFileDialogService.Filter = "Excel文件(*.xlsx)|*.xlsx|All Files(*.*)| *.* ";
            OpenFileDialogService.FilterIndex = 1;
            if (OpenFileDialogService.ShowDialog())
            {
                //IFileInfo file = OpenFileDialogService.Files.First();
                string fileName = OpenFileDialogService.GetFullFileName();
                //var fullFileName = string.Format("{0}\\{1}", Directory.GetCurrentDirectory(), fileName);
                if (!File.Exists(fileName))
                {
                    //XtraMessageBox.Show("File not found");
                    //return null;
                }

                DataTable dtImport = new DataTable();
                using (System.Data.OleDb.OleDbConnection myConnection = new System.Data.OleDb.OleDbConnection(
                            "Provider=Microsoft.ACE.OLEDB.12.0; " +
                             "data source='" + fileName + "';" +
                                "Extended Properties=\"Excel 12.0;HDR=YES;IMEX=1\" "))
                {
                    using (System.Data.OleDb.OleDbDataAdapter myImportCommand = new System.Data.OleDb.OleDbDataAdapter("select * from [Sheet$]", myConnection))
                        myImportCommand.Fill(dtImport);
                }
                var list = DataTableToEntityHelp.DatatableToEntity<ToolEntityModel>(dtImport);
                ToolEntityList = new ObservableCollection<ToolEntityModel>(list);
                foreach (var entity in list)
                {
                    if (string.IsNullOrEmpty(entity.Fab))
                    {
                        ToolEntityList.Remove(entity);
                    }                       
                }
                ToolEntityList = new ObservableCollection<ToolEntityModel>(ToolEntityList);
            }
            else
            {
            }
            
        }

        [Command]
        public void Export(object obj)
        {
            DevExpress.Export.ExportSettings.DefaultExportType = DevExpress.Export.ExportType.Default;
            XlsxExportOptionsEx op = new XlsxExportOptionsEx();
            var view = obj as DevExpress.Xpf.Grid.TableView;

            string strFileName = SaveFile();
            if (string.IsNullOrEmpty(strFileName))
            {
                return;
            }
            view.ExportToXlsx(strFileName,new XlsxExportOptions(TextExportMode.Text,true));
            //Process.Start(strFileName);
        }
        public bool CanExport(object obj)
        {
            return true;
            //return AuthorityManager.HasAuthority(Auth_Tool_Add);
        }

        private string SaveFile()
        {
            string fileName = "";
            //SaveFileDialogService.DefaultFileName = "newExport.xlsx";
            //SaveFileDialogService.DefaultExt = "xlsx";
            SaveFileDialogService.Filter = "Excel文件(*.xlsx)|*.xlsx|All Files(*.*)| *.* ";
            SaveFileDialogService.FilterIndex = 1;
            if (SaveFileDialogService.ShowDialog())
            {
                fileName = SaveFileDialogService.GetFullFileName();
            }
            return fileName;
        }


        [Command]
        public void Add()
        {
            ShowEditTool(null, FunctionMode.Add);
        }

        public bool CanAdd()
        {
            //return true;
            return AuthorityManager.HasAuthority(Auth_Tool_Add);
        }

        [Command]
        public void Copy()
        {
            ShowEditTool(SelectedTool, FunctionMode.Copy);
        }

        public bool CanCopy()
        {
            return SelectedTool != null && SelectedToolList.Count == 1 && !IsLoading;// && AuthorityManager.HasAuthority(Auth_Tool_Copy);
        }

        [Command]
        public void Modify()
        {
            ShowEditTool(SelectedTool, FunctionMode.Modify);
        }

        public bool CanModify()
        {
            return SelectedTool != null && SelectedToolList.Count == 1 && !IsLoading && AuthorityManager.HasAuthority(Auth_Tool_Edit);
        }

        private void ShowEditTool(Shared.Litho.DTO.Tool originalTool, FunctionMode mode)
        {
            if (ShowPopup("EditTool", new EditToolViewModel(originalTool, mode)).IsOK)
            {
                Refresh();
            }
        }

        [Command]
        public async void Delete()
        {
            if (IsConfirmed(out var comment))
            {
                var toDeleteTool = SelectedTool;
                await LithoGlobalService.DeleteToolAsync(SelectedTool.ToolId, comment);
                Refresh();
                Messenger.Default.Send(new ToolChangedMessage() { ChangeType = ObjectChangeType.Deleted, ToolId = SelectedTool.ToolId });
                MessageBoxService.ShowMessage($"Tool {toDeleteTool.ToolId} is deleted.", "Success", MessageButton.OK, MessageIcon.Information);
            }
        }

        public bool CanDelete()
        {
            return SelectedTool != null && SelectedToolList.Count == 1 && !IsLoading && AuthorityManager.HasAuthority(Auth_Tool_Delete);
        }

        public async Task RefreshToolBeforeAction(ToolEntityModel tool)
        {
            await UpdateSingleTool(tool);
        }

        private void ClearToolDetails()
        {
            HistoryList = new ObservableCollection<TransactionHistory>();
        }
        #endregion

        #region Properties
        public PagedAsyncSource PagedSource
        {
            get { return GetValue<PagedAsyncSource>(); }
            set { SetValue(value); }
        }

        public ObservableCollection<ToolEntityModel> ToolEntityList
        {
            get { return GetValue<ObservableCollection<ToolEntityModel>>(); }
            set { SetValue(value); }
        }

        public ObservableCollection<Shared.Litho.DTO.Tool> SelectedToolList { get; } = new ObservableCollection<Shared.Litho.DTO.Tool>();

        public ToolEntityModel SelectedTool
        {
            get { return GetValue<ToolEntityModel>(); }
            set { SetValue(value); }
        }

        public string Fab
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(Fab));
            }
        }

        public string Area
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(Area));
            }
        }

        public string NameSpace
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(NameSpace));
            }
        }

        public string ToolId
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(ToolId));
            }
        }

        public string ToolVendor
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(ToolVendor));
            }
        }

        public string ToolModel
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(ToolModel));
            }
        }
        public string ProcessType
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(ProcessType));
            }
        }

        public string ProcessModel
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(ProcessModel));
            }
        }
        #endregion
    }
}
