﻿using System;
using System.Collections.ObjectModel;
using AMAT.R2R.Client.Common.Enums;
using AMAT.R2R.Client.Common.Helpers;
using AMAT.R2R.Client.Litho.Messages;
using AMAT.R2R.Shared.Litho.DTO;
using DevExpress.Mvvm;
using DevExpress.Mvvm.DataAnnotations;

namespace AMAT.R2R.Client.Litho.Modules.ProcessSettings
{
    public class EditProcessViewModel : LithoViewModelBase
    {
        private const string NA = "NA";
        public EditProcessViewModel(Process process, FunctionMode mode)
        {
            OriginalProcess = process;
            Icon = "SvgImages/Business Objects/BO_KPI_Definition.svg";
            Mode = mode;
            SizeToContent = System.Windows.SizeToContent.WidthAndHeight;

            // TODO: read from config for Primary Keys.
            IsFabPrimaryKey = true;
            IsProductPrimaryKey = true;
            IsLayerPrimaryKey = true;

            IsEnabledPrimaryKey = true;
            IsCDFeaturePrimaryKey = true;
            IsPreLayerXPrimaryKey = true;
            IsPreLayerYPrimaryKey = true;
            IsPrioroty1PrimaryKey = true;

            IsFabRequired = IsFabPrimaryKey;
            IsProductRequired = IsProductPrimaryKey;
            IsLayerRequired = IsLayerPrimaryKey;
            IsEnabledRequired = IsEnabledPrimaryKey;
            IsCDFeatureRequired = IsCDFeaturePrimaryKey;
            IsPreLayerXRequired = IsPreLayerXPrimaryKey;
            IsPreLayerYRequired = IsPreLayerYPrimaryKey;
            //IsPrioroty1Required = IsPrioroty1PrimaryKey;

            Mode = mode;
            if (Mode != FunctionMode.Modify)
            {
                ProductList = new ObservableCollection<string>(LithoGlobalService.GetProductIdList());
                //ProductList = new ObservableCollection<string>(productList);
            }
            if (process != null)
            {
                ProcessKey = process.ProcessKey;
                Fab = process.Fab;
                Product = process.Product;
                Layer = process.Layer;
                Prioroty1 = process.PreLayers1;
                Prioroty2 = process.PreLayers2;
                Prioroty3 = process.PreLayers3;
                Prioroty4 = process.PreLayers4;
                Prioroty5 = process.PreLayers5;
                PreLayerX = process.PreLayerX;
                PreLayerY = process.PreLayerY;
                Enabled = process.Enabled;
                IsFirstLayer = process.IsFirstLayer;
                CDFeature = process.CDFeature;
                NPWFlag = process.NPWFlag;
                DedicationLayer = process.DedicationLayer;
                CDFBStage = process.CDFBStage;
                OVLFBStage = process.OVLFBStage;

                AlignLayer = process.AlignLayer;
                UseToolStatus = process.UseToolStatus;
                Comment = process.Comment;
                LastModifyUser = process.LastModifyBy;
                LastModifyTime = process.LastModifyDate;

            }
            else
            {
                Fab = ClientInfo.LoginFab;
                Enabled = false;
                //CDFeature = "";
            }

            IsDirty = false;

            switch (mode)
            {
                case FunctionMode.None:
                    break;
                case FunctionMode.Add:
                    Caption = "Create Process";
                    break;
                case FunctionMode.Copy:
                    Caption = "Copy Process";
                    break;
                case FunctionMode.Modify:
                    Caption = "Edit Process";
                    break;
                case FunctionMode.Delete:
                    break;
                case FunctionMode.View:
                    break;
                default:
                    break;
            }

            PropertyChanged += OnPropertyChanged;

        }

        private void OnPropertyChanged(object sender, System.ComponentModel.PropertyChangedEventArgs e)
        {
            //if (e.PropertyName == nameof())
            //{

            //}
        }

        protected override void OnViewReadyAsync()
        {
            if (Mode == FunctionMode.Add)
            {
                SetFocus(nameof(Product));
            }
        }

        //[Command]
        //public void CreateContextByProcess()
        //{
        //    if (string.IsNullOrEmpty(Fab) || string.IsNullOrEmpty(Product) || string.IsNullOrEmpty(Layer))
        //    {
        //        return;
        //    }
        //    if (ShowPopup("CreateContextByProcess", new CreateContextByProcessViewModel(Fab,Product,Layer)).IsOK)
        //    {
                
        //    }
        //}
        //public bool CanCreateContextByProcess()
        //{
        //    return !string.IsNullOrEmpty(Fab) && !string.IsNullOrEmpty(Product) && !string.IsNullOrEmpty(Layer);
        //}

        [Command]
        public async void Save()
        {
            ValidateAndSetErrorFocus(nameof(Fab), nameof(Product), nameof(Layer), nameof(PreLayerX), nameof(PreLayerY), nameof(CDFeature));

            if (HasErrors)
            {
                return;
            }

            if (IsConfirmed(out string comment))
            {
                var newProcess = new Process
                {
                    //ProcessKey= string.Format("{0}:{1}:{2}", Fab, Product, Layer),
                    Fab = Fab,
                    Product = Product,
                    Layer = Layer,
                    PreLayerX = PreLayerX,
                    PreLayerY = PreLayerY,
                    PreLayers1 = Prioroty1,
                    PreLayers2 = Prioroty2,
                    PreLayers3 = Prioroty3,
                    PreLayers4 = Prioroty4,
                    PreLayers5 = Prioroty5,
                    Enabled = Enabled,
                    //IsFirstLayer = IsFirstLayer, //future
                    CDFeature = CDFeature,
                    NPWFlag = NPWFlag,
                    DedicationLayer = DedicationLayer,
                    CDFBStage = CDFBStage,
                    OVLFBStage = OVLFBStage,
                    AlignLayer = AlignLayer,
                    UseToolStatus = UseToolStatus,
                    Comment = comment,
                    LastModifyBy = ClientInfo.UserName,   //LastModifyUser,
                    LastModifyDate = DateTime.Now   //LastModifyTime
                };

                if (Mode == FunctionMode.Modify)
                {
                    ShowWait();
                    await ProcessService.ModifyProcessAsync(newProcess.ProcessKey, newProcess, comment);
                    IsDirty = false;
                    HideWait();
                    Messenger.Default.Send(new ProcessChangedMessage() { ChangeType = ObjectChangeType.Updated, ProcessKey = OriginalProcess.ProcessKey });
                    MessageBoxService.ShowMessage($"Process {newProcess.ProcessKey} is updated!", "Success", MessageButton.OK, MessageIcon.Information);
                }
                else
                {
                    ShowWait();
                    await ProcessService.CreateProcessAsync(newProcess, comment);
                    IsDirty = false;
                    HideWait();
                    Messenger.Default.Send(new ProcessChangedMessage() { ChangeType = ObjectChangeType.Created, ProcessKey = newProcess.ProcessKey });
                    MessageBoxService.ShowMessage($"Process {newProcess.ProcessKey} is created!", "Success", MessageButton.OK, MessageIcon.Information);

                }

                IsOK = true;
                CloseWindow();
            }
        }

        public bool CanSave()
        {
            switch (Mode)
            {
                case FunctionMode.Add:
                    return true;
                case FunctionMode.Modify:
                    return IsDirty;
                default:
                    return true;
            }
        }

        protected override string GetError(string columnName)
        {
            switch (columnName)
            {
                case nameof(Fab):
                    return DataValidator.ValidString(Fab);
                case nameof(Product):
                    return DataValidator.ValidString(Product);
                case nameof(Layer):
                    return DataValidator.ValidString(Layer);
                case nameof(PreLayerX):
                    return DataValidator.ValidString(PreLayerX);
                case nameof(PreLayerY):
                    return DataValidator.ValidString(PreLayerY);
                case nameof(Prioroty1):
                    return DataValidator.ValidString(Prioroty1);
                case nameof(CDFeature):
                    return DataValidator.ValidString(CDFeature);
                default:
                    return null;
            }
        }

        #region Properties
        public Process OriginalProcess { get; private set; }

        public string ProcessKey
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(ProcessKey));
            }
        }
        public string Fab
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(Fab));
            }
        }

        public string Product
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(Product));
            }
        }
        public ObservableCollection<string> ProductList
        {
            get { return GetValue<ObservableCollection<string>>(); }
            set { SetValue(value); }
        }

        public string Layer
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(Layer));
            }
        }

        public string PreLayerX
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(PreLayerX));
            }
        }

        public string PreLayerY
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(PreLayerY));
            }
        }
        public string Prioroty1
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(Prioroty1));
            }
        }
        public string Prioroty2
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(Prioroty2));
            }
        }
        public string Prioroty3
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(Prioroty3));
            }
        }
        public string Prioroty4
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(Prioroty4));
            }
        }
        public string Prioroty5
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(Prioroty5));
            }
        }

        public bool IsFirstLayer
        {
            get { return GetValue<bool>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(IsFirstLayer));
            }
        }

        public bool Enabled
        {
            get { return GetValue<bool>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(Enabled));
            }
        }

        public string CDFeature
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(CDFeature));
            }
        }

        public bool NPWFlag
        {
            get { return GetValue<bool>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(NPWFlag));
            }
        }

        public string DedicationLayer
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(DedicationLayer));
            }
        }

        public string CDFBStage
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(CDFBStage));
            }
        }

        public string OVLFBStage
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(OVLFBStage));
            }
        }

        public string LISFBStage
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(LISFBStage));
            }
        }
        public string AlignLayer
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(AlignLayer));
            }
        }


        public bool EnableControl
        {
            get { return GetValue<bool>(); }
            set
            {
                SetValue(value);
                //IsDirty = true;
                ClearError(nameof(EnableControl));
            }
        }
        public bool UseToolStatus
        {
            get { return GetValue<bool>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(UseToolStatus));
            }
        }

        public string Comment
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(Comment));
            }
        }

        public DateTime LastModifyTime
        {
            get { return GetValue<DateTime>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(LastModifyTime));
            }
        }

        public string LastModifyUser
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(LastModifyUser));
            }
        }

        public bool IsFabPrimaryKey { get { return GetValue<bool>(); } set { SetValue(value); } }
        public bool IsFabRequired
        {
            get
            {
                return GetValue<bool>();
            }
            set
            {
                SetValue(value);
                SetFocus(nameof(Fab));
            }
        }
        public bool IsProductPrimaryKey { get { return GetValue<bool>(); } set { SetValue(value); } }
        public bool IsProductRequired
        {
            get
            {
                return GetValue<bool>();
            }
            set
            {
                SetValue(value);
                if (value)
                {
                    SetFocus(nameof(Product));
                }
            }
        }
        public bool IsLayerPrimaryKey { get { return GetValue<bool>(); } set { SetValue(value); } }
        public bool IsLayerRequired
        {
            get
            {
                return GetValue<bool>();
            }
            set
            {
                SetValue(value);
                if (value)
                {
                    SetFocus(nameof(Layer));
                }
            }
        }
        public bool IsEnabledPrimaryKey { get { return GetValue<bool>(); } set { SetValue(value); } }
        public bool IsEnabledRequired
        {
            get
            {
                return GetValue<bool>();
            }
            set
            {
                SetValue(value);
                if (value)
                {
                    SetFocus(nameof(Enabled));
                }
            }
        }
        public bool IsEnabledReadOnly
        {
            get { return IsEnabledRequired; }
        }

        public bool IsPreLayerXPrimaryKey { get { return GetValue<bool>(); } set { SetValue(value); } }
        public bool IsPreLayerXRequired
        {
            get
            {
                return GetValue<bool>();
            }
            set
            {
                SetValue(value);
                if (value)
                {
                    SetFocus(nameof(PreLayerX));
                }
                RaisePropertiesChanged(nameof(IsPreLayerXReadOnly));
            }
        }

        public bool IsPreLayerXReadOnly
        {
            get { return IsPreLayerXRequired; }
        }

        public bool IsPreLayerYPrimaryKey { get { return GetValue<bool>(); } set { SetValue(value); } }
        public bool IsPreLayerYRequired
        {
            get
            {
                return GetValue<bool>();
            }
            set
            {
                SetValue(value);
                if (value)
                {
                    SetFocus(nameof(PreLayerY));
                }
                RaisePropertiesChanged(nameof(IsPreLayerYReadOnly));
            }
        }
        public bool IsPreLayerYReadOnly
        {
            get { return IsPreLayerYRequired; }
        }
        public bool IsPrioroty1PrimaryKey { get { return GetValue<bool>(); } set { SetValue(value); } }
        public bool IsPrioroty1Required
        {
            get
            {
                return GetValue<bool>();
            }
            set
            {
                SetValue(value);
                if (value)
                {
                    SetFocus(nameof(Prioroty1));
                }
                RaisePropertiesChanged(nameof(IsPrioroty1ReadOnly));
            }
        }
        public bool IsPrioroty1ReadOnly
        {
            get { return IsPrioroty1Required; }
        }
        public bool IsCDFeaturePrimaryKey { get { return GetValue<bool>(); } set { SetValue(value); } }
        public bool IsCDFeatureRequired
        {
            get
            {
                return GetValue<bool>();
            }
            set
            {
                SetValue(value);
                if (value)
                {
                    SetFocus(nameof(CDFeature));
                }
                RaisePropertiesChanged(nameof(IsCDFeatureReadOnly));
            }
        }
        public bool IsCDFeatureReadOnly
        {
            get { return IsCDFeatureRequired; }
        }

        #endregion
    }
}
