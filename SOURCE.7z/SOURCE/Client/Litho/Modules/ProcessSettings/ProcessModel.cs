﻿using System.ComponentModel;
using AMAT.R2R.Shared.Litho.DTO;

namespace AMAT.R2R.Client.Litho.Modules.ProcessSettings
{
    public class ProcessModel : Process, INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;

        public void NotifyChanges()
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(LastModifyBy)));
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(LastModifyDate)));
        }
    }
}
