﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Data;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using AMAT.R2R.Client.Common.Enums;
using AMAT.R2R.Client.Common.Helpers;
using AMAT.R2R.Client.Litho.Helpers;
using AMAT.R2R.Client.Litho.Messages;
using AMAT.R2R.Shared.Base.DTO;
using AMAT.R2R.Shared.Litho.DTO;
using DevExpress.Mvvm;
using DevExpress.Mvvm.DataAnnotations;
using DevExpress.Mvvm.Native;
using DevExpress.Spreadsheet;
using DevExpress.Spreadsheet.Export;
using DevExpress.Xpf.Data;

namespace AMAT.R2R.Client.Litho.Modules.ProcessSettings
{
    public class ProcessListViewModel : LithoViewModelBase
    {
        public const string Auth_Process = "Process";
        public const string Auth_Process_Add = "Process:Add";
        public const string Auth_Process_Copy = "Process:Copy";
        public const string Auth_Process_Edit = "Process:Edit";
        public const string Auth_Process_Delete = "Process:Delete";
        public const string Auth_Process_BatchEdit = "Process:BatchEdit";

        public ProcessListViewModel()
        {
            Caption = "Process Settings";
            PropertyChanged += OnPropertyChanged;
            Icon = "SvgImages/Business Objects/BO_KPI_Definition.svg";
            Messenger.Default.Register<ProcessChangedMessage>(this, OnProcessChanged);

            InitializePagedSource();
        }

        #region Filtering & Paging

        private void InitializePagedSource()
        {
            #region Paged Source
            var pagedSource = new PagedAsyncSource()
            {
                ElementType = typeof(ProcessModel),
                KeyProperty = nameof(Process.ProcessKey),
                PageSize = 100,
                PageNavigationMode = PageNavigationMode.ArbitraryWithTotalPageCount
            };

#if DEBUG
            pagedSource.PageSize = 10;
#endif

            pagedSource.FetchPage += (o, e) =>
            {
                e.Result = FetchPageRowsAsync(e);
            };

            pagedSource.GetTotalSummaries += (o, e) =>
            {
                e.Result = GetSummariesAsync(e);
            };

            pagedSource.GetUniqueValues += (o, e) =>
            {
                e.Result = GetValueListAsync(e);
            };

            pagedSource.PropertyChanged += (o, e) =>
            {
                if (e.PropertyName == nameof(PagedAsyncSource.AreRowsFetching))
                {
                    IsLoading = PagedSource.AreRowsFetching;
                    // restore selection.
                    if (!IsLoading)
                    {
                        if (_lastSelectedItem != null)
                        {
                            foreach (var item in PagedSource)
                            {
                                var process = item as ProcessModel;
                                if (process.ProcessKey == _lastSelectedItem.ProcessKey)
                                {
                                    SelectedProcess = process;
                                    break;
                                }
                            }
                        }
                    }
                }
            };

            PagedSource = pagedSource;
            #endregion
        }

        ProcessModel _lastSelectedItem = null;

        private async Task<FetchRowsResult> FetchPageRowsAsync(FetchPageAsyncEventArgs e)
        {
            try
            {
                if (SelectedProcess != null)
                {
                    _lastSelectedItem = SelectedProcess;
                }
                var items = await ProcessService.GetProcessListAsync(e.Filter.MakeFilters(), e.MakeSorters(), e.Skip, e.Take);
                return new FetchRowsResult(items.ToArray(), hasMoreRows: items.Count == e.Take);
            }
            catch (Exception ex)
            {
                Logger.Error(ex);
                throw;
            }
        }

        private async Task<object[]> GetSummariesAsync(GetSummariesAsyncEventArgs e)
        {
            try
            {
                var summary = await ProcessService.GetProcessCount(e.Filter.MakeFilters());
                return e.Summaries.Select(x =>
                {
                    return x.SummaryType == SummaryType.Count ? (object)summary : throw new InvalidOperationException();
                }).ToArray();
            }
            catch (Exception ex)
            {
                Logger.Error(ex);
                throw;
            }
        }

        private async Task<object[]> GetValueListAsync(GetUniqueValuesAsyncEventArgs e)
        {
            try
            {
                if (e.PropertyName == nameof(Process.Enabled) || e.PropertyName == nameof(Process.NPWFlag) || e.PropertyName == nameof(Process.UseToolStatus))
                {
                    var values = new object[] { true, false };
                    return await Task.Factory.StartNew(() => values);
                }
                else
                {
                    return await ProcessService.GetProcessValueListAsync(e.PropertyName, e.Filter.MakeFilters());
                }
            }
            catch (Exception ex)
            {
                Logger.Error(ex);
                throw;
            }
        }

        #endregion

        protected override void OnViewReadyAsync()
        {
            //Refresh();
        }

        public override void OnRemoving(CancelEventArgs e)
        {
            base.OnRemoving(e);

            PagedSource?.Dispose();
            Messenger.Default.Unregister<ProcessChangedMessage>(this, OnProcessChanged);
        }

        private async void OnPropertyChanged(object sender, System.ComponentModel.PropertyChangedEventArgs e)
        {
            if (e.PropertyName == nameof(SelectedProcess))
            {
                if (SelectedProcess != null)
                {
                    await GetProcessDetailsAsync();
                }
                else
                {
                    ClearProcessDetails();
                }
            }
        }
        private void OnProcessChanged(ProcessChangedMessage msg)
        {
            Refresh();
        }

        private async Task RefreshSingleProcess(ProcessModel process)
        {

            var lastModifiedTime = process.LastModifyDate;
            var newProcess = await ProcessService.GetProcessAsync(process.ProcessKey);

            process.LastModifyBy = newProcess.LastModifyBy;
            process.LastModifyDate = newProcess.LastModifyDate;

            process.NotifyChanges();

            if (SelectedProcess != null && process.ProcessKey == SelectedProcess.ProcessKey && lastModifiedTime != newProcess.LastModifyDate)
            {
                await GetProcessDetailsAsync();
            }
        }

        #region Commands
        [Command]
        public void ImportProcess()
        {
            OpenFileDialogService.Filter = "Excel 97-2003 Workbook files(*.xls)|*.xls|Excel files(*.xlsx)|*.xlsx|All Files(*.*)| *.*";
            OpenFileDialogService.FilterIndex = 1;
            if (OpenFileDialogService.ShowDialog())
            {
                //IFileInfo file = OpenFileDialogService.Files.First();
                string fileName = OpenFileDialogService.GetFullFileName();
                //var fullFileName = string.Format("{0}\\{1}", Directory.GetCurrentDirectory(), fileName);
                if (!File.Exists(fileName))
                {
                    //XtraMessageBox.Show("File not found");
                    //return null;
                }
                else
                {
                    DataTable dtLayerList = null;
                    DataTable dtCDContext = null;
                    DataTable dtCDParameter = null;
                    DataTable dtOVLContext = null;
                    DataTable dtOVLSetting = null;
                    DataTable dtOVLFixed = null;

                    Workbook workbook = new Workbook();

                    // Load a workbook from the file.
                    bool flagXlsx = workbook.LoadDocument(fileName, DocumentFormat.Xlsx);
                    if (!flagXlsx)
                    {
                        workbook.LoadDocument(fileName, DocumentFormat.Xls);
                    }
                    if (workbook.Worksheets.Count > 0)
                    {
                        foreach (var s in workbook.Worksheets)
                        {
                            if (s.Name.Equals("LayerList"))
                            {
                                dtLayerList = WorkSheetToDataTable(s);
                            }
                            else if (s.Name.Equals("CDContext"))
                            {
                                dtCDContext = WorkSheetToDataTable(s);
                            }
                            else if (s.Name.Equals("CDParameter"))
                            {
                                dtCDParameter = WorkSheetToDataTable(s);
                            }
                            else if (s.Name.Equals("OVLContext"))
                            {
                                dtOVLContext = WorkSheetToDataTable(s);
                            }
                            else if (s.Name.Equals("OVLSetting"))
                            {
                                dtOVLSetting = WorkSheetToDataTable(s);
                            }
                            else if (s.Name.Equals("OVLFixed"))
                            {
                                dtOVLFixed = WorkSheetToDataTable(s);
                            }
                            else
                            {
                                return;
                            }

                        }
                    }
                    else
                    {
                        return;
                    }
                    var list = DataTableToEntityHelp.DatatableToEntity<object>(dtLayerList);
                }
            }
        }
        private DataTable WorkSheetToDataTable(Worksheet workSheet)
        {
            DataTable dt = null;

            CellRange range = workSheet.GetUsedRange();

            dt = workSheet.CreateDataTable(range, true, false);

            // Change the data type of the "As Of" column to text. 
            //dataTable.Columns["As Of"].DataType = System.Type.GetType("System.String");

            DataTableExporter exporter = workSheet.CreateDataTableExporter(range, dt, false);

            // Handle value conversion errors.
            exporter.CellValueConversionError += exporter_CellValueConversionError;

            // Perform the export.
            exporter.Export();

            return dt;
        }
        public bool CanImportProcess()
        {
            return true;
        }
        void exporter_CellValueConversionError(object sender, CellValueConversionErrorEventArgs e)
        {
            MessageBoxService.ShowMessage("Error in cell " + e.Cell.GetReferenceA1());
            e.DataTableValue = null;
            e.Action = DataTableExporterAction.Continue;
        }
        private async Task GetProcessDetailsAsync()
        {
            if (SelectedProcess != null)
            {
                #region   
                CDFeature = SelectedProcess.CDFeature;
                PreLayerX = SelectedProcess.PreLayerX;
                PreLayerY = SelectedProcess.PreLayerY;
                Prioroty1 = SelectedProcess.PreLayers1;
                Prioroty2 = SelectedProcess.PreLayers2;
                Prioroty3 = SelectedProcess.PreLayers3;
                Prioroty4 = SelectedProcess.PreLayers4;
                Prioroty5 = SelectedProcess.PreLayers5;
                NPWFlag = SelectedProcess.NPWFlag;
                DedicationLayer = SelectedProcess.DedicationLayer;
                Enabled = SelectedProcess.Enabled;
                CDFBStage = SelectedProcess.CDFBStage;
                OVLFBStage = SelectedProcess.OVLFBStage;
                AlignLayer = SelectedProcess.AlignLayer;
                UseToolStatus = SelectedProcess.UseToolStatus;
                #endregion


                try
                {
                    IsHistoryLoading = true;
                    if (SelectedProcess != null)
                    {
                        HistoryList = new ObservableCollection<TransactionHistory>(await GlobalService.GetHistoryAsync(ClientInfo.LoginArea, "Process", SelectedProcess.ProcessKey, null));
                    }
                }
                finally
                {
                    IsHistoryLoading = false;
                }
            }
            else
            {
                HistoryList?.Clear();
            }
        }
        [Command]
        public void CreateContextByProcess()
        {
            if (SelectedProcess==null)
            {
                return;
            }
            if (ShowPopup("CreateContextByProcess", new CreateContextByProcessViewModel(SelectedProcess.Fab, SelectedProcess.Product, SelectedProcess.Layer)).IsOK)
            {

            }
        }
        public bool CanCreateContextByProcess()
        {
            return SelectedProcess != null && SelectedProcessList.Count == 1 && !IsLoading;// && AuthorityManager.HasAuthority(Auth_Process_Copy);
        }


        [Command]
        public void Add()
        {
            ShowEditProcess(null, FunctionMode.Add);
        }
        public bool CanAdd()
        {
            return AuthorityManager.HasAuthority(Auth_Process_Add);
        }

        [Command]
        public async void Copy()
        {
            await UpdateBeforeAction();
            ShowEditProcess(SelectedProcess, FunctionMode.Copy);
        }

        public bool CanCopy()
        {
            return SelectedProcess != null && SelectedProcessList.Count == 1 && !IsLoading && AuthorityManager.HasAuthority(Auth_Process_Copy);
        }

        [Command]
        public async void Modify()
        {
            await UpdateBeforeAction();
            ShowEditProcess(SelectedProcess, FunctionMode.Modify);
        }

        public bool CanModify()
        {
            return SelectedProcess != null && SelectedProcessList.Count == 1 && !IsLoading && AuthorityManager.HasAuthority(Auth_Process_Edit);
        }

        private void ShowEditProcess(Process originalProcess, FunctionMode mode)
        {
            if (ShowPopup("EditProcess", new EditProcessViewModel(originalProcess, mode)).IsOK)
            {
                Refresh();
            }
        }

        [Command]
        public async void Delete()
        {
            await UpdateBeforeAction();

            if (IsConfirmed(out var comment))
            {
                var key = SelectedProcess.ProcessKey;
                //ProcessService.DeleteProcess(key, comment);
                await ProcessService.DeleteProcessAsync(SelectedProcess.ProcessKey, comment);
                Refresh();
                Messenger.Default.Send(new ProcessChangedMessage() { ChangeType = ObjectChangeType.Deleted, ProcessKey = SelectedProcess.ProcessKey });
                MessageBoxService.ShowMessage($"Process {key} is deleted.", "Success", MessageButton.OK, MessageIcon.Information);
            }
        }

        public bool CanDelete()
        {
            return SelectedProcess != null && SelectedProcessList.Count == 1 && !IsLoading && AuthorityManager.HasAuthority(Auth_Process_Delete);
        }

        [Command]
        public void BatchEditProcess()
        {
            ShowBatchEditProcess(SelectedProcessList.ToList(), FunctionMode.Add);
        }

        public bool CanBatchEditProcess()
        {
            return SelectedProcess != null && SelectedProcessList.Count > 1 && !IsLoading && AuthorityManager.HasAuthority(Auth_Process_BatchEdit);
        }

        private void ShowBatchEditProcess(List<Process> selectedProcessList, FunctionMode mode)
        {
            if (ShowPopup("BatchEditProcess", new BatchEditProcessViewModel(selectedProcessList)).IsOK)
            {
                Refresh();
            }
        }

        [Command]
        public async void HistoryProcess()
        {
            //ShowEditProcess(SelectedProcess, FunctionMode.Add);
            await GetProcessDetailsAsync();
        }

        [Command]
        public void Refresh()
        {
            PagedSource.UpdateSummaries();
            PagedSource.RefreshRows();
        }

        public bool CanRefresh()
        {
            return !IsLoading;
        }

        private void ClearProcessDetails()
        {
            HistoryList = new ObservableCollection<TransactionHistory>();
        }
        protected async Task UpdateBeforeAction()
        {
            ShowWait();
            await RefreshSingleProcess(SelectedProcess);
            HideWait();
        }
        #endregion

        #region Properties
        public PagedAsyncSource PagedSource
        {
            get { return GetValue<PagedAsyncSource>(); }
            set { SetValue(value); }
        }

        public ObservableCollection<ProcessModel> ProcessList
        {
            get { return GetValue<ObservableCollection<ProcessModel>>(); }
            set { SetValue(value); }
        }

        public ObservableCollection<Process> SelectedProcessList { get; } = new ObservableCollection<Process>();

        public ProcessModel SelectedProcess
        {
            get { return GetValue<ProcessModel>(); }
            set { SetValue(value); }
        }

        public bool IsProcessSelected
        {
            get { return GetValue<bool>(); }
            set { SetValue(value); }
        }

        public bool IsEnableRequired
        {
            get { return GetValue<bool>(); }
            set { SetValue(value); }
        }

        public bool IsUseToolStatusRequired
        {
            get { return GetValue<bool>(); }
            set { SetValue(value); }
        }

        public bool IsNpwFlagRequired
        {
            get { return GetValue<bool>(); }
            set { SetValue(value); }
        }

        public string PreLayerX
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(PreLayerX));
            }
        }

        public string PreLayerY
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(PreLayerY));
            }
        }

        public string Prioroty1
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(Prioroty1));
            }
        }
        public string Prioroty2
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(Prioroty2));
            }
        }
        public string Prioroty3
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(Prioroty3));
            }
        }
        public string Prioroty4
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(Prioroty4));
            }
        }
        public string Prioroty5
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(Prioroty5));
            }
        }

        public bool Enabled
        {
            get { return GetValue<bool>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(Enabled));
            }
        }
        public string CDFeature
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(CDFeature));
            }
        }

        public string DoseSlope
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(DoseSlope));
            }
        }

        public bool NPWFlag
        {
            get { return GetValue<bool>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(NPWFlag));
            }
        }

        public string DedicationLayer
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(DedicationLayer));
            }
        }

        public string CDFBStage
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(CDFBStage));
            }
        }

        public string OVLFBStage
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(OVLFBStage));
            }
        }

        public string AlignLayer
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(AlignLayer));
            }
        }

        public bool UseToolStatus
        {
            get { return GetValue<bool>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(UseToolStatus));
            }
        }
        #endregion

    }
}
