﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AMAT.R2R.Client.Common.Enums;
using AMAT.R2R.Client.Common.Helpers;
using AMAT.R2R.Client.Litho.Messages;
using AMAT.R2R.Shared.Litho.DTO;
using DevExpress.Mvvm;
using DevExpress.Mvvm.DataAnnotations;
using Newtonsoft.Json;

namespace AMAT.R2R.Client.Litho.Modules.ProcessSettings
{
    class BatchEditProcessViewModel : LithoViewModelBase
    {
        private const string NA = "NA";
        public BatchEditProcessViewModel(List<Process> processList)
        {
            Caption = "Batch Edit Process";
            ProcessList = new ObservableCollection<Process>(processList);
            SizeToContent = System.Windows.SizeToContent.WidthAndHeight;

            // TODO: read from config for Primary Keys.

            IsEnabledPrimaryKey = true;
            IsCDFeaturePrimaryKey = true;
            IsPreLayerXPrimaryKey = true;
            IsPreLayerYPrimaryKey = true;
            IsPrioroty1PrimaryKey = true;

            IsEnabledRequired = IsEnabledPrimaryKey;
            IsCDFeatureRequired = IsCDFeaturePrimaryKey;
            IsPreLayerXRequired = IsPreLayerXPrimaryKey;
            IsPreLayerYRequired = IsPreLayerYPrimaryKey;
            //IsPrioroty1Required = IsPrioroty1PrimaryKey;


            if (ProcessList != null && ProcessList.Count > 0)
            {
                Process process = ProcessList[0];

                Prioroty1 = process.PreLayers1;
                Prioroty2 = process.PreLayers2;
                Prioroty3 = process.PreLayers3;
                Prioroty4 = process.PreLayers4;
                Prioroty5 = process.PreLayers5;
                PreLayerX = process.PreLayerX;
                PreLayerY = process.PreLayerY;
                Enabled = process.Enabled;
                IsFirstLayer = process.IsFirstLayer;
                CDFeature = process.CDFeature;
                NPWFlag = process.NPWFlag;
                DedicationLayer = process.DedicationLayer;
                CDFBStage = process.CDFBStage;
                OVLFBStage = process.OVLFBStage;

                AlignLayer = process.AlignLayer;
                UseToolStatus = process.UseToolStatus;
            }

            IsDirty = false;
            PropertyChanged += OnPropertyChanged;
        }
        private async void OnPropertyChanged(object sender, System.ComponentModel.PropertyChangedEventArgs e)
        {
            if (e.PropertyName == nameof(SelectedProcess))
            {
                if (SelectedProcess != null)
                {
                    await GetProcessDetailsAsync();
                }
            }
        }

        protected override void OnViewReadyAsync()
        {

        }

        private async Task GetProcessDetailsAsync()
        {
            if (SelectedProcess != null)
            {
                #region   
                CDFeature = SelectedProcess.CDFeature;
                PreLayerX = SelectedProcess.PreLayerX;
                PreLayerY = SelectedProcess.PreLayerY;
                Prioroty1 = SelectedProcess.PreLayers1;
                Prioroty2 = SelectedProcess.PreLayers2;
                Prioroty3 = SelectedProcess.PreLayers3;
                Prioroty4 = SelectedProcess.PreLayers4;
                Prioroty5 = SelectedProcess.PreLayers5;
                NPWFlag = SelectedProcess.NPWFlag;
                DedicationLayer = SelectedProcess.DedicationLayer;
                Enabled = SelectedProcess.Enabled;
                CDFBStage = SelectedProcess.CDFBStage;
                OVLFBStage = SelectedProcess.OVLFBStage;
                AlignLayer = SelectedProcess.AlignLayer;
                UseToolStatus = SelectedProcess.UseToolStatus;
                #endregion
            }
        }

        [Command]
        public async void Save()
        {
            ValidateAndSetErrorFocus(nameof(PreLayerX), nameof(PreLayerY),  nameof(CDFeature));

            if (HasErrors)
            {
                return;
            }

            List<Process> failedProcessList = new List<Process>();
            StringBuilder sb = new StringBuilder();
            // 
            if (IsConfirmed(out string comment))
            {
                ShowWait();

                foreach (var process in ProcessList)
                {
                    try
                    {
                        // clone process.
                        var newProcess = JsonConvert.DeserializeObject<Process>(JsonConvert.SerializeObject(process));

                        newProcess.PreLayerX = PreLayerX;
                        newProcess.PreLayerY = PreLayerY;
                        newProcess.PreLayers1 = Prioroty1;
                        newProcess.PreLayers2 = Prioroty2;
                        newProcess.PreLayers3 = Prioroty3;
                        newProcess.PreLayers4 = Prioroty4;
                        newProcess.PreLayers5 = Prioroty5;
                        newProcess.Enabled = Enabled;
                        //IsFirstLayer = IsFirstLayer.ToLower().Equals("true"), //future
                        newProcess.CDFeature = CDFeature;
                        newProcess.NPWFlag = NPWFlag;
                        newProcess.DedicationLayer = DedicationLayer;
                        newProcess.CDFBStage = CDFBStage;
                        newProcess.OVLFBStage = OVLFBStage;
                        newProcess.AlignLayer = AlignLayer;
                        newProcess.UseToolStatus = UseToolStatus;
                        newProcess.Comment = comment;
                        newProcess.LastModifyBy = ClientInfo.UserName;   //LastModifyUser,
                        newProcess.LastModifyDate = DateTime.Now;  //LastModifyTime

                        await ProcessService.ModifyProcessAsync(newProcess.ProcessKey, newProcess, comment);
                    }
                    catch (Exception ex)
                    {
                        failedProcessList.Add(process);
                        sb.AppendLine(LocalizationService.LocalizeException(ex));
                    }
                }

                HideWait();

                var successCount = ProcessList.Count - failedProcessList.Count;

                if (successCount > 0)
                {
                    var successProcessList = ProcessList.Except(failedProcessList);
                    foreach (var process in successProcessList)
                    {
                        Messenger.Default.Send(new ProcessChangedMessage() { ChangeType = ObjectChangeType.Updated, ProcessKey = process.ProcessKey });
                    }
                }

                // show error if any
                if (failedProcessList.Count <= 0)
                {
                    MessageBoxService.ShowMessage($"{ProcessList.Count} Process's  Updated successfully.", "Success", MessageButton.OK, MessageIcon.Information);
                }
                else
                {
                    MessageBoxService.ShowMessage(sb.ToString(), $"Success Count: {successCount} Failed Count: { failedProcessList.Count} ", MessageButton.OK, MessageIcon.Error);
                }

                IsOK = true;
                CloseWindow();
            }
        }

        public bool CanSave()
        {
            switch (Mode)
            {
                case FunctionMode.Add:
                    return true;
                case FunctionMode.Modify:
                    return IsDirty;
                default:
                    return true;
            }
        }

        protected override string GetError(string columnName)
        {
            switch (columnName)
            {
                case nameof(Fab):
                    return DataValidator.ValidString(Fab);
                case nameof(Product):
                    return DataValidator.ValidString(Product);
                case nameof(Layer):
                    return DataValidator.ValidString(Layer);
                case nameof(PreLayerX):
                    return DataValidator.ValidString(PreLayerX);
                case nameof(PreLayerY):
                    return DataValidator.ValidString(PreLayerY);
                case nameof(Prioroty1):
                    return DataValidator.ValidString(Prioroty1);
                case nameof(CDFeature):
                    return DataValidator.ValidString(CDFeature);
                //case nameof(DedicationLayer):
                //    return DataValidator.ValidString(DedicationLayer);
                //case nameof(CDFBStage):
                //    return DataValidator.ValidString(CDFBStage);
                //case nameof(OVLFBStage):
                //    return DataValidator.ValidString(OVLFBStage);
                //case nameof(LISFBStage):
                //    return DataValidator.ValidString(LISFBStage);
                //case nameof(AlignLayer):
                //    return DataValidator.ValidString(AlignLayer);

                default:
                    return null;
            }
        }

        #region Properties
        public ObservableCollection<Process> ProcessList
        {
            get { return GetValue<ObservableCollection<Process>>(); }
            set { SetValue(value); }
        }
        public ProcessModel SelectedProcess
        {
            get { return GetValue<ProcessModel>(); }
            set { SetValue(value); }
        }

        public string ProcessKey
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(ProcessKey));
            }
        }
        public string Fab
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(Fab));
            }
        }

        public string Product
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(Product));
            }
        }
        public ObservableCollection<string> ProductList
        {
            get { return GetValue<ObservableCollection<string>>(); }
            set { SetValue(value); }
        }

        public string Layer
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(Layer));
            }
        }

        public string PreLayerX
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(PreLayerX));
            }
        }

        public string PreLayerY
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(PreLayerY));
            }
        }
        public string Prioroty1
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(Prioroty1));
            }
        }
        public string Prioroty2
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(Prioroty2));
            }
        }
        public string Prioroty3
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(Prioroty3));
            }
        }
        public string Prioroty4
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(Prioroty4));
            }
        }
        public string Prioroty5
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(Prioroty5));
            }
        }

        public bool IsFirstLayer
        {
            get { return GetValue<bool>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(IsFirstLayer));
            }
        }

        public bool Enabled
        {
            get { return GetValue<bool>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(Enabled));
            }
        }

        public string CDFeature
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(CDFeature));
            }
        }
        public bool EnableControl
        {
            get { return GetValue<bool>(); }
            set
            {
                SetValue(value);
                //IsDirty = true;
                ClearError(nameof(EnableControl));
            }
        }
        public bool NPWFlag
        {
            get { return GetValue<bool>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(NPWFlag));
            }
        }

        public string DedicationLayer
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(DedicationLayer));
            }
        }

        public string CDFBStage
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(CDFBStage));
            }
        }

        public string OVLFBStage
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(OVLFBStage));
            }
        }

        public string LISFBStage
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(LISFBStage));
            }
        }
        public string AlignLayer
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(AlignLayer));
            }
        }

        public bool UseToolStatus
        {
            get { return GetValue<bool>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(UseToolStatus));
            }
        }

        public string Comment
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(Comment));
            }
        }

        public DateTime LastModifyTime
        {
            get { return GetValue<DateTime>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(LastModifyTime));
            }
        }

        public string LastModifyUser
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(LastModifyUser));
            }
        }

        public bool IsEnabledPrimaryKey { get { return GetValue<bool>(); } set { SetValue(value); } }
        public bool IsEnabledRequired
        {
            get
            {
                return GetValue<bool>();
            }
            set
            {
                SetValue(value);
                if (value)
                {
                    SetFocus(nameof(Enabled));
                }
            }
        }
        public bool IsEnabledReadOnly
        {
            get { return IsEnabledRequired; }
        }

        public bool IsPreLayerXPrimaryKey { get { return GetValue<bool>(); } set { SetValue(value); } }
        public bool IsPreLayerXRequired
        {
            get
            {
                return GetValue<bool>();
            }
            set
            {
                SetValue(value);
                if (value)
                {
                    SetFocus(nameof(PreLayerX));
                }
                RaisePropertiesChanged(nameof(IsPreLayerXReadOnly));
            }
        }

        public bool IsPreLayerXReadOnly
        {
            get { return IsPreLayerXRequired; }
        }

        public bool IsPreLayerYPrimaryKey { get { return GetValue<bool>(); } set { SetValue(value); } }
        public bool IsPreLayerYRequired
        {
            get
            {
                return GetValue<bool>();
            }
            set
            {
                SetValue(value);
                if (value)
                {
                    SetFocus(nameof(PreLayerY));
                }
                RaisePropertiesChanged(nameof(IsPreLayerYReadOnly));
            }
        }
        public bool IsPreLayerYReadOnly
        {
            get { return IsPreLayerYRequired; }
        }
        public bool IsPrioroty1PrimaryKey { get { return GetValue<bool>(); } set { SetValue(value); } }
        public bool IsPrioroty1Required
        {
            get
            {
                return GetValue<bool>();
            }
            set
            {
                SetValue(value);
                if (value)
                {
                    SetFocus(nameof(Prioroty1));
                }
                RaisePropertiesChanged(nameof(IsPrioroty1ReadOnly));
            }
        }
        public bool IsPrioroty1ReadOnly
        {
            get { return IsPrioroty1Required; }
        }
        public bool IsCDFeaturePrimaryKey { get { return GetValue<bool>(); } set { SetValue(value); } }
        public bool IsCDFeatureRequired
        {
            get
            {
                return GetValue<bool>();
            }
            set
            {
                SetValue(value);
                if (value)
                {
                    SetFocus(nameof(CDFeature));
                }
                RaisePropertiesChanged(nameof(IsCDFeatureReadOnly));
            }
        }
        public bool IsCDFeatureReadOnly
        {
            get { return IsCDFeatureRequired; }
        }

        #endregion

    }
}
