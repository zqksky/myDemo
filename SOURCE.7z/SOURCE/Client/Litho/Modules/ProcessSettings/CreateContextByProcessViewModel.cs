﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Threading.Tasks;
using AMAT.R2R.Client.Common.Enums;
using AMAT.R2R.Client.Common.Helpers;
using AMAT.R2R.Client.Common.Services;
using AMAT.R2R.Client.Litho.Messages;
using AMAT.R2R.Client.Litho.Modules.ContextSettings;
using AMAT.R2R.Shared.Litho.DTO;
using DevExpress.Mvvm;
using DevExpress.Mvvm.DataAnnotations;

namespace AMAT.R2R.Client.Litho.Modules.ProcessSettings
{
    public class CreateContextByProcessViewModel : LithoViewModelBase
    {
        public CreateContextByProcessViewModel(string fab, string product, string layer)
        {
            Caption = "Create Context By process";
            SizeToContent = System.Windows.SizeToContent.Manual;

            PropertyChanged += OnPropertyChanged;

            Fab = fab;
            Product = product;
            Layer = layer;

            ToolList = new ObservableCollection<string>(LithoGlobalService.GetToolIdList());
            CDControlFlagList = new ObservableCollection<string>(ContextService.GetControlFlagList());
            OVLControlFlagList = new ObservableCollection<string>(ContextService.GetControlFlagList());
            ModelNameList = new ObservableCollection<string>();
            if (!string.IsNullOrEmpty(Tool))
            {
                ModelNameList = new ObservableCollection<string>(ContextService.GetOVLModelNameList(Tool));
            }

            CDReadOnlyFlag = true;
            OVLReadOnlyFlag = true;
        }
        protected override void OnViewReadyAsync()
        {
            Refresh();
        }
        private async void OnPropertyChanged(object sender, System.ComponentModel.PropertyChangedEventArgs e)
        {
            if (e.PropertyName == nameof(SelectedContext))
            {
                if (SelectedContext != null)
                {
                    //await GetContextDetailsAsync(); 
                }
                else
                {
                }
            }
        }
        private async Task GetContextDetailsAsync()
        {
            if (SelectedContext != null)
            {
                #region 
                Fab = SelectedContext.Fab;
                Product = SelectedContext.Product;
                Layer = SelectedContext.Layer;
                Tool = SelectedContext.Tool;
                Reticle = SelectedContext.Reticle;
                Recipe = SelectedContext.Recipe;
                PreTool = SelectedContext.PreTool;
                PreReticle = SelectedContext.PreReticle;
                CDAssignPilot = SelectedContext.CDAssignPilot;
                CDGOFThreshold = SelectedContext.CDGOFThreshold;
                CDMinPointLimit = SelectedContext.CDMinPointLimit;
                CDControlFlag = SelectedContext.CDControlFlag;
                CDFBAllowCount = SelectedContext.CDFBAllowLotCnt;
                CDFBLotCount = SelectedContext.CDFBLotCounter;
                CDFBLotList = SelectedContext.CDFBLotList;
                CDFBEffectiveDays = SelectedContext.CDFBEffectiveDays;
                DCDValuesEntity = SelectedContext.DCDValues;
                if (DCDValuesEntity != null)
                {
                    DoseFixedValue = DCDValuesEntity.DoseFixedValue;
                    FocusFixedValue = DCDValuesEntity.FocusFixedValue;
                    DoseSensitivity = DCDValuesEntity.DoseSensitivity;
                    Target = DCDValuesEntity.Target;
                    ReworkBias = DCDValuesEntity.ReworkBias;
                }

                OVLAssignPilot = SelectedContext.OVLAssignPilot;
                OVLControlFlag = SelectedContext.OVLControlFlag;
                OVLFBAllowCount = SelectedContext.OVLFBAllowLotCnt;
                OVLFBLotCount = SelectedContext.OVLFBLotCounter;
                OVLFBLotList = SelectedContext.OVLFBLotList;
                OVLFBEffectiveDays = SelectedContext.OVLFBEffectiveDays;
                ModelName = SelectedContext.ModelName;
                TwoDMetrologyFlag = SelectedContext.TwoDMetrologyEnabled == 1;
                ChuckControl = SelectedContext.ChuckControl == 1;
                ChuckDedicationType = SelectedContext.ChuckDedicationType;
                if (ChuckDedicationType == 1)
                {
                    StrChuckDedicationType = "No Chuck Dedication";
                }
                else if (ChuckDedicationType == 2)
                {
                    StrChuckDedicationType = "First Chuck";
                }
                else if (ChuckDedicationType == 3)
                {
                    StrChuckDedicationType = "Chuck Dedication with Wafer List";
                }
                else
                {
                    StrChuckDedicationType = "No Chuck Dedication";
                }

                OVLGOFThreshold = SelectedContext.OVLGOFThreshold;

                LstOVLValues = new List<OVLValues>(SelectedContext.LstOVLValues);
                #endregion

                try
                {

                }
                finally
                {
                    IsHistoryLoading = false;
                }
            }
            else
            {
            }
        }
        private void ClearContextInfo()
        {
            int? iNull = null;

            CDAssignPilot = "";
            CDControlFlag = "";
            CDFBAllowCount = null;
            CDFBEffectiveDays = null;
            //CDFBLotCount = 0;
            //CDFBLotList = "";
            DCDValuesEntity = new DCDValues();
            SpecsEntity = new Specs();

            DoseFixedValue = double.NaN;
            FocusFixedValue = double.NaN;
            DoseSensitivity = double.NaN;
            Target = double.NaN;
            ReworkBias = double.NaN;
            CDGOFThreshold = double.NaN;

            OVLAssignPilot = "";
            OVLControlFlag = "";
            OVLFBAllowCount = null;
            OVLFBEffectiveDays = null;
            //OVLFBLotCount = 0;
            //OVLFBLotList = "";
            TwoDMetrologyFlag = false;
            ChuckControl = false;
            ChuckDedicationType = 0;
            if (ChuckDedicationType == 1)
            {
                StrChuckDedicationType = "No Chuck Dedication";
            }
            else if (ChuckDedicationType == 2)
            {
                StrChuckDedicationType = "First Chuck";
            }
            else if (ChuckDedicationType == 3)
            {
                StrChuckDedicationType = "Chuck Dedication with Wafer List";
            }
            else
            {
                StrChuckDedicationType = "No Chuck Dedication";
            }

            ModelName = "";
            OVLGOFThreshold = double.NaN;
        }
        #region Commands
        [Command]
        public void OnRowDoubleClick()
        {
            if (SelectedContext == null)
            {
                return;
            }
            else
            {
                GetContextDetailsAsync();
            }
            IsDirty = true;
        }
        public bool CanOnRowDoubleClick()
        {
            return true;
        }

        [Command]
        public async void Refresh()
        {
            try
            {
                IsLoading = true;
                var contextList = await ContextService.GetContextListAsync(new QueryFilter[] { new QueryFilter("fab", Fab), new QueryFilter("product", Product), new QueryFilter("layer", Layer) });
                ContextList = new ObservableCollection<ContextModel>(contextList);
            }
            finally
            {
                IsLoading = false;
            }
        }
        public bool CanRefresh()
        {
            return !IsLoading;
        }

        [Command]
        public void ToolSelectedIndexChanged()
        {
            if (!string.IsNullOrEmpty(Tool))
            {
                ModelNameList = new ObservableCollection<string>(ContextService.GetOVLModelNameList(Tool));
                KeyEditValueChanged();
            }

        }
        public bool CanToolSelectedIndex()
        {
            return true;
        }

        [Command]
        public async void KeyEditValueChanged()
        {
            if (string.IsNullOrEmpty(Fab) || string.IsNullOrEmpty(Tool) || string.IsNullOrEmpty(Product) || string.IsNullOrEmpty(Layer) ||
                string.IsNullOrEmpty(Reticle) || string.IsNullOrEmpty(Recipe) || string.IsNullOrEmpty(PreTool) || string.IsNullOrEmpty(PreReticle))
            {
                return;
            }
            else
            {
                //ClearContextInfo();

                DCDControlSetting cdContextInfo = await ContextService.GetDCDContextInfoAsync(Fab, Tool, Product, Layer, Reticle, Recipe);
                if (cdContextInfo != null)
                {
                    CDAssignPilot = cdContextInfo.AssignPilot;
                    CDControlFlag = cdContextInfo.ControlFlag;
                    CDFBAllowCount = int.Parse(cdContextInfo.FBAllowCount.ToString());
                    CDFBEffectiveDays = int.Parse(cdContextInfo.FBEffectiveDays.ToString());
                    CDFBLotCount = cdContextInfo.FBLotCounter;
                    CDFBLotList = cdContextInfo.FBLotList;
                    DCDValuesEntity = cdContextInfo.DCDValues;
                    DoseFixedValue = DCDValuesEntity.DoseFixedValue;
                    FocusFixedValue = DCDValuesEntity.FocusFixedValue;
                    DoseSensitivity = DCDValuesEntity.DoseSensitivity;
                    Target = DCDValuesEntity.Target;
                    ReworkBias = DCDValuesEntity.ReworkBias;
                    CDGOFThreshold = cdContextInfo.GOFThreshold;
                    //CDMinPointLimit = cdContextInfo.MinPointLimit;
                    DCDValuesEntity = cdContextInfo.DCDValues;
                    SpecsEntity = cdContextInfo.Specs;

                    CDReadOnlyFlag = true;
                }
                else
                {
                    CDReadOnlyFlag = false;
                }
                var ovlContextInfo = await ContextService.GetOVLContextInfoAsync(Fab, Tool, Product, Layer, Reticle, Recipe, PreTool, PreReticle);
                if (ovlContextInfo != null)
                {
                    OVLAssignPilot = ovlContextInfo.AssignPilot;
                    OVLControlFlag = ovlContextInfo.ControlFlag;
                    OVLFBAllowCount = int.Parse(ovlContextInfo.FBAllowCount.ToString());
                    OVLFBEffectiveDays = int.Parse(ovlContextInfo.FBEffectiveDays.ToString());
                    OVLFBLotCount = ovlContextInfo.FBLotCounter;
                    OVLFBLotList = ovlContextInfo.FBLotList;
                    TwoDMetrologyFlag = ovlContextInfo.TwoDMetrologyFlag == 1;
                    ChuckControl = ovlContextInfo.ChuckControlEnabled == 1;
                    ChuckDedicationType = ovlContextInfo.ChuckDedicationType;
                    if (ChuckDedicationType == 1)
                    {
                        StrChuckDedicationType = "No Chuck Dedication";
                    }
                    else if (ChuckDedicationType == 2)
                    {
                        StrChuckDedicationType = "First Chuck";
                    }
                    else if (ChuckDedicationType == 3)
                    {
                        StrChuckDedicationType = "Chuck Dedication with Wafer List";
                    }
                    else
                    {
                        StrChuckDedicationType = "No Chuck Dedication";
                    }

                    ModelName = ovlContextInfo.ModelName;
                    OVLGOFThreshold = ovlContextInfo.GOFThreshold;
                    LstOVLValues = new List<OVLValues>(ovlContextInfo.LstOVLValues);
                    //LstSpecs = new List<Specs>(ovlContextInfo.LstOVLSpecs);

                    OVLReadOnlyFlag = true;
                }
                else
                {
                    OVLReadOnlyFlag = false;
                    ChuckDedicationTypeList = new ObservableCollection<string>() { "No Chuck Dedication", "First Chuck", "Chuck Dedication with Wafer List" };
                    //ChuckDedicationType = 1;
                    StrChuckDedicationType = "No Chuck Dedication";
                }
            }
        }
        public bool CanKeyEditValueChanged()
        {
            return true;
        }

        [Command]
        public async void Save()
        {
            ValidateAndSetErrorFocus(nameof(Fab), nameof(Tool), nameof(Product), nameof(Layer), nameof(Reticle), nameof(Recipe), nameof(PreTool), nameof(PreReticle),
                nameof(CDControlFlag), nameof(CDFBEffectiveDays), nameof(CDFBAllowCount), nameof(DoseSensitivity), nameof(Target), nameof(CDGOFThreshold), nameof(CDMinPointLimit),
                nameof(OVLControlFlag), nameof(OVLFBEffectiveDays), nameof(OVLFBAllowCount), nameof(ModelName), nameof(StrChuckDedicationType), nameof(OVLGOFThreshold));

            if (HasErrors)
            {
                return;
            }

            if (IsConfirmed(out string comment))
            {
                DCDValuesEntity = new DCDValues();

                DCDValuesEntity.DoseFixedValue = DoseFixedValue;
                DCDValuesEntity.FocusFixedValue = FocusFixedValue;
                DCDValuesEntity.Target = Target.Value;
                DCDValuesEntity.DoseSensitivity = DoseSensitivity;
                DCDValuesEntity.ReworkBias = ReworkBias.Value;
                DCDValuesEntity.Comment = comment;
                DCDValuesEntity.LastModifyUser = ClientInfo.UserName; //LastModifyUser;
                DCDValuesEntity.LastModifyTime = DateTime.Now; //LastModifyTime;
                if (string.IsNullOrEmpty(StrChuckDedicationType))
                {
                    ChuckDedicationType = 1;
                }
                else if (StrChuckDedicationType.Equals("No Chuck Dedication"))
                {
                    ChuckDedicationType = 1;
                }
                else if (StrChuckDedicationType.Equals("First Chuck"))
                {
                    ChuckDedicationType = 2;
                }
                else if (StrChuckDedicationType.Equals("Chuck Dedication with Wafer List"))
                {
                    ChuckDedicationType = 3;
                }

                var newContext = new Context
                {
                    Fab = Fab,
                    Tool = Tool,
                    Product = Product,
                    Layer = Layer,
                    Reticle = Reticle,
                    Recipe = Recipe,
                    PreTool = PreTool,
                    PreReticle = PreReticle,
                    CDAssignPilot = CDAssignPilot,
                    CDControlFlag = CDControlFlag,
                    CDFBAllowLotCnt = CDFBAllowCount.Value,
                    CDFBLotCounter = CDFBLotCount,
                    CDFBLotList = CDFBLotList,
                    CDFBEffectiveDays = CDFBEffectiveDays.Value,
                    DCDValues = DCDValuesEntity,
                    CDContextKey = string.Format("{0}:{1}:{2}:{3}:{4}:{5}", Fab, Tool, Product, Layer, Reticle, Recipe),
                    OVLContextKey = string.Format("{0}:{1}:{2}:{3}:{4}:{5}:{6}:{7}", Fab, Tool, Product, Layer, Reticle, Recipe, PreTool, PreReticle),

                    CDGOFThreshold = CDGOFThreshold.Value,
                    CDMinPointLimit = CDMinPointLimit.Value,

                    OVLAssignPilot = OVLAssignPilot,
                    OVLControlFlag = OVLControlFlag,
                    OVLFBAllowLotCnt = OVLFBAllowCount.Value,
                    OVLFBLotCounter = OVLFBLotCount,
                    OVLFBLotList = OVLFBLotList,
                    OVLFBEffectiveDays = OVLFBEffectiveDays.Value,
                    ModelName = ModelName,
                    TwoDMetrologyEnabled = TwoDMetrologyFlag ? 1 : 0,
                    ChuckControl = ChuckControl ? 1 : 0,
                    ChuckDedicationType = ChuckDedicationType,
                    OVLGOFThreshold = OVLGOFThreshold.Value,
                    LstOVLValues = LstOVLValues,
                    //LstSpecs = LstSpecs,

                    Comment = comment,
                    LastModifyUser = ClientInfo.UserName,   //LastModifyUser,
                    LastModifyTime = DateTime.Now   // LastModifyTime
                };

                DCDValuesEntity.ContextKey = string.Format("{0}:{1}:{2}:{3}:{4}:{5}", Fab, Tool, Product, Layer, Reticle, Recipe);

                //ShowWait();
                if (string.IsNullOrEmpty(CopySpecContextKey))
                {
                    await ContextService.CreateContextAsync(newContext, comment);
                }
                else
                {
                    await ContextService.CreateContextAndSpecAsync(newContext, CopySpecContextKey, comment);
                }

                IsDirty = false;
                //HideWait();
                Messenger.Default.Send(new ContextChangedMessage() { ChangeType = ObjectChangeType.Created, ContextKey = newContext.OVLContextKey });
                MessageBoxService.ShowMessage($"Context {newContext.OVLContextKey} is created!", "Success", MessageButton.OK, MessageIcon.Information);


                IsOK = true;
                //CloseWindow();
                Refresh();
            }
        }

        public bool CanSave()
        {
            return !CDReadOnlyFlag || !OVLReadOnlyFlag;
        }

        protected override string GetError(string columnName)
        {
            switch (columnName)
            {
                case nameof(Fab):
                    return DataValidator.ValidString(Fab);
                case nameof(Tool):
                    return DataValidator.ValidString(Tool);
                case nameof(Product):
                    return DataValidator.ValidString(Product);
                case nameof(Layer):
                    return DataValidator.ValidString(Layer);
                case nameof(Reticle):
                    return DataValidator.ValidString(Reticle);
                case nameof(Recipe):
                    return DataValidator.ValidString(Recipe);
                case nameof(PreTool):
                    return DataValidator.ValidString(PreTool);
                case nameof(PreReticle):
                    return DataValidator.ValidString(PreReticle);
                case nameof(CDAssignPilot):
                    return DataValidator.ValidString(CDAssignPilot);
                case nameof(CDControlFlag):
                    return DataValidator.ValidString(CDControlFlag);
                case nameof(CDFBAllowCount):
                    return DataValidator.ValidateInOrder(
                        () => DataValidator.NotNull(CDFBAllowCount),
                        () => DataValidator.LargerThanOrEqualTo(CDFBAllowCount, 1));
                case nameof(DoseSensitivity):
                    return DataValidator.ValidString(DoseSensitivity.ToString());
                case nameof(CDFBEffectiveDays):
                    return DataValidator.ValidateInOrder(
                        () => DataValidator.NotNull(CDFBEffectiveDays),
                        () => DataValidator.LargerThanOrEqualTo(CDFBEffectiveDays, 1));
                case nameof(Target):
                    return DataValidator.ValidString(Target.ToString());
                case nameof(CDGOFThreshold):
                    return DataValidator.ValidateInOrder(
                        () => DataValidator.NotNull(CDGOFThreshold),
                        () => DataValidator.InRange((decimal)CDGOFThreshold, 0, 100));
                case nameof(CDMinPointLimit):
                    return DataValidator.ValidateInOrder(
                        () => DataValidator.NotNull(CDMinPointLimit),
                        () => DataValidator.LargerThanOrEqualTo((decimal)CDMinPointLimit, 1));

                case nameof(ModelName):
                    return DataValidator.ValidString(ModelName);
                case nameof(OVLAssignPilot):
                    return DataValidator.ValidString(OVLAssignPilot);
                case nameof(OVLControlFlag):
                    return DataValidator.ValidString(OVLControlFlag);
                case nameof(OVLFBAllowCount):
                    return DataValidator.ValidateInOrder(
                        () => DataValidator.NotNull(OVLFBAllowCount),
                        () => DataValidator.LargerThanOrEqualTo(OVLFBAllowCount, 1));
                case nameof(OVLFBEffectiveDays):
                    return DataValidator.ValidateInOrder(
                        () => DataValidator.NotNull(OVLFBEffectiveDays),
                        () => DataValidator.LargerThanOrEqualTo(decimal.Parse(OVLFBEffectiveDays.ToString()), 1));
                case nameof(OVLGOFThreshold):
                    return DataValidator.ValidateInOrder(
                        () => DataValidator.NotNull(OVLGOFThreshold),
                        () => DataValidator.InRange((decimal)OVLGOFThreshold, 0, 100));

                case nameof(ChuckDedicationType):
                    return DataValidator.ValidString(StrChuckDedicationType);
                default:
                    return null;
            }
        }
        #endregion

        #region Properties
        public bool CDReadOnlyFlag
        {
            get { return GetValue<bool>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(CDReadOnlyFlag));
            }
        }
        public bool OVLReadOnlyFlag
        {
            get { return GetValue<bool>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(OVLReadOnlyFlag));
            }
        }

        public Context OriginalContext { get; private set; }
        public string CopySpecContextKey { get; private set; }

        public ObservableCollection<Context> SelectedContextList { get; } = new ObservableCollection<Context>();

        public ObservableCollection<ContextModel> ContextList
        {
            get { return GetValue<ObservableCollection<ContextModel>>(); }
            set { SetValue(value); }
        }

        public ContextModel SelectedContext
        {
            get { return GetValue<ContextModel>(); }
            set { SetValue(value); }
        }

        public string Fab
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(Fab));
            }
        }

        public string Tool
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(Tool));
            }
        }

        public string Product
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(Product));
            }
        }
        public ObservableCollection<string> ProductList
        {
            get { return GetValue<ObservableCollection<string>>(); }
            set { SetValue(value); }
        }
        public ObservableCollection<string> LayerList
        {
            get { return GetValue<ObservableCollection<string>>(); }
            set { SetValue(value); }
        }
        public ObservableCollection<string> ToolList
        {
            get { return GetValue<ObservableCollection<string>>(); }
            set { SetValue(value); }
        }

        public ObservableCollection<string> OVLControlFlagList
        {
            get { return GetValue<ObservableCollection<string>>(); }
            set { SetValue(value); }
        }

        public ObservableCollection<string> CDControlFlagList
        {
            get { return GetValue<ObservableCollection<string>>(); }
            set { SetValue(value); }
        }

        public ObservableCollection<string> ModelNameList
        {
            get { return GetValue<ObservableCollection<string>>(); }
            set { SetValue(value); }
        }

        public ObservableCollection<string> ChuckDedicationTypeList
        {
            get { return GetValue<ObservableCollection<string>>(); }
            set { SetValue(value); }
        }

        public string Layer
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(Layer));
            }
        }

        public string Recipe
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(Recipe));
            }
        }

        public string Reticle
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(Reticle));
            }
        }
        public string PreTool
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(PreTool));
            }
        }

        public string PreReticle
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(PreReticle));
            }
        }

        public string CDControlFlag
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(CDControlFlag));
            }
        }

        public int? CDFBAllowCount
        {
            get { return GetValue<int?>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(CDFBAllowCount));
            }
        }

        public int CDFBLotCount
        {
            get { return GetValue<int>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(CDFBLotCount));
            }
        }

        public string CDFBLotList
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(CDFBLotList));
            }
        }

        public string CDAssignPilot
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(CDAssignPilot));
            }
        }

        public double? CDGOFThreshold
        {
            get { return GetValue<double?>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(CDGOFThreshold));
            }
        }

        public double? CDMinPointLimit
        {
            get { return GetValue<double?>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(CDMinPointLimit));
            }
        }

        public int? CDFBEffectiveDays
        {
            get { return GetValue<int?>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(CDFBEffectiveDays));
            }
        }

        public DCDValues DCDValuesEntity
        {
            get { return GetValue<DCDValues>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(DCDValuesEntity));
            }
        }

        public Specs SpecsEntity
        {
            get { return GetValue<Specs>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(Specs));
            }
        }

        public double? DoseFixedValue
        {
            get { return GetValue<double?>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(DoseFixedValue));
            }
        }

        public double? FocusFixedValue
        {
            get { return GetValue<double?>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(FocusFixedValue));
            }
        }

        public double? Target
        {
            get { return GetValue<double?>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(Target));
            }
        }

        public double? DoseSensitivity
        {
            get { return GetValue<double?>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(DoseSensitivity));
            }
        }

        public double? ReworkBias
        {
            get { return GetValue<double?>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(ReworkBias));
            }
        }

        public string ModelName
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(ModelName));
            }
        }
        public bool TwoDMetrologyFlag
        {
            get { return GetValue<bool>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(TwoDMetrologyFlag));
            }
        }
        public string OVLControlFlag
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(OVLControlFlag));
            }
        }

        public int? OVLFBAllowCount
        {
            get { return GetValue<int?>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(OVLFBAllowCount));
            }
        }

        public int OVLFBLotCount
        {
            get { return GetValue<int>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(OVLFBLotCount));
            }
        }

        public string OVLFBLotList
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(OVLFBLotList));
            }
        }

        public string OVLAssignPilot
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(OVLAssignPilot));
            }
        }

        public double? OVLGOFThreshold
        {
            get { return GetValue<double?>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(OVLGOFThreshold));
            }
        }

        public string OVLMode
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(OVLMode));
            }
        }
        public int? OVLFBEffectiveDays
        {
            get { return GetValue<int?>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(OVLFBEffectiveDays));
            }
        }

        public int ChuckDedicationType
        {
            get { return GetValue<int>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(ChuckDedicationType));
            }
        }

        public string StrChuckDedicationType
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(StrChuckDedicationType));
            }
        }

        public bool ChuckControl
        {
            get { return GetValue<bool>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(ChuckControl));
            }
        }

        public List<OVLValues> LstOVLValues
        {
            get { return GetValue<List<OVLValues>>(); }
            set
            {
                SetValue(value);
                //IsDirty = true;
                ClearError(nameof(LstOVLValues));
            }
        }

        public List<Specs> LstSpecs
        {
            get { return GetValue<List<Specs>>(); }
            set
            {
                SetValue(value);
                //IsDirty = true;
                ClearError(nameof(LstSpecs));
            }
        }

        public DateTime LastModifyTime
        {
            get { return GetValue<DateTime>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(LastModifyTime));
            }
        }

        public string LastModifyUser
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(LastModifyUser));
            }
        }
        #endregion
    }
}
