﻿using AMAT.R2R.Client.Common.Enums;
using AMAT.R2R.Client.Common.Helpers;
using AMAT.R2R.Client.Litho.Messages;
using AMAT.R2R.Shared.Litho.DTO;
using DevExpress.Mvvm;
using DevExpress.Mvvm.DataAnnotations;

namespace AMAT.R2R.Client.Litho.Modules.ProductSettings
{
    class EditProductViewModel : LithoViewModelBase
    {
        private const string NA = "NA";
        public EditProductViewModel(Product product, FunctionMode mode)
        {
            OriginalProduct = product;
            SizeToContent = System.Windows.SizeToContent.WidthAndHeight;

            if (product != null)
            {
                Fab = product.Fab;           
                NameSpace = product.NameSpace;
                ProductId = product.ProductId;
                ProductType = product.ProductType;;
            }
            else
            {
                Fab = ClientInfo.LoginFab;

            }
            Mode = mode;

            switch (mode)
            {
                case FunctionMode.None:
                    break;
                case FunctionMode.Add:
                    Caption = "Create Product";
                    break;
                case FunctionMode.Copy:
                    Caption = "Copy Product";
                    break;
                case FunctionMode.Modify:
                    Caption = "Edit Product";
                    break;
                case FunctionMode.Delete:
                    break;
                case FunctionMode.View:
                    break;
                default:
                    break;
            }
            IsDirty = false;

            PropertyChanged += OnPropertyChanged;
        }

        private void OnPropertyChanged(object sender, System.ComponentModel.PropertyChangedEventArgs e)
        {
            if (e.PropertyName == nameof(ProductId))
            {
                IsDirty = true;
            }
        }

        protected override void OnViewReadyAsync()
        {
            if (Mode == FunctionMode.Add)
            {
                SetFocus(nameof(ProductId));
            }
        }


        [Command]
        public async void Save()
        {
            ValidateAndSetErrorFocus(nameof(ProductId),  nameof(ProductType));

            if (HasErrors)
            {
                return;
            }

            // 
            if (IsConfirmed(out string comment))
            {
                var newProduct = new Product
                {
                    Fab = Fab,
                    NameSpace =NameSpace,
                    ProductId = ProductId,
                    ProductType = ProductType,
                };

                if (Mode == FunctionMode.Modify)
                {
                    //ShowWait();
                    await LithoGlobalService.ModifyProductAsync(newProduct.ProductId, newProduct, comment);
                    IsDirty = false;
                    //HideWait();
                    Messenger.Default.Send(new ProductChangedMessage() { ChangeType = ObjectChangeType.Updated, ProductId = OriginalProduct.ProductId });
                    MessageBoxService.ShowMessage($"Product {newProduct.ProductId} is updated!", "Success", MessageButton.OK, MessageIcon.Information);

                }
                else
                {
                    //ShowWait();
                    await LithoGlobalService.CreateProductAsync(newProduct, comment);

                    IsDirty = false;
                    //HideWait();
                    Messenger.Default.Send(new ProductChangedMessage() { ChangeType = ObjectChangeType.Created, ProductId = newProduct.ProductId });
                    MessageBoxService.ShowMessage($"Product {newProduct.ProductId} is created!", "Success", MessageButton.OK, MessageIcon.Information);

                }

                IsOK = true;
                CloseWindow();
            }
        }

        public bool CanSave()
        {
            switch (Mode)
            {
                case FunctionMode.Add:
                    return true;
                case FunctionMode.Modify:
                    return IsDirty;
                default:
                    return true;
            }
        }

        protected override string GetError(string columnName)
        {
            switch (columnName)
            {
                case nameof(ProductId):
                    return DataValidator.ValidString(ProductId);
                case nameof(ProductType):
                    return DataValidator.ValidString(ProductType);


                default:
                    return null;
            }
        }


        #region Properties
        public Product OriginalProduct { get; private set; }

        public string Fab
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(Fab));
            }
        }

        public string NameSpace
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(NameSpace));
            }
        }
        public string ProductId
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(ProductId));
            }
        }

        public string ProductType
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(ProductType));
            }
        }
        #endregion
    }
}
