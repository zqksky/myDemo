﻿using System;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading.Tasks;
using AMAT.R2R.Client.Common.Enums;
using AMAT.R2R.Client.Common.Helpers;
using AMAT.R2R.Client.Litho.Messages;
using AMAT.R2R.Shared.Base.DTO;
using DevExpress.Mvvm;
using DevExpress.Mvvm.DataAnnotations;
using DevExpress.Xpf.Data;

namespace AMAT.R2R.Client.Litho.Modules.ProductSettings
{
    class ProductListViewModel : LithoViewModelBase
    {
        public const string Auth_Global= "GlobalSettings";
        public const string Auth_Product = "GlobalSettings:Product";
        public const string Auth_Product_Add = "GlobalSettings:Product:Add";
        public const string Auth_Product_Copy = "GlobalSettings:Product:Copy";
        public const string Auth_Product_Edit = "GlobalSettings:Product:Edit";
        public const string Auth_Product_Delete = "GlobalSettings:Product:Delete";

        public ProductListViewModel()
        {
            Caption = "Product Settings";
            Icon = "SvgImages/Outlook Inspired/Products.svg";
            PropertyChanged += OnPropertyChanged;
            Messenger.Default.Register<ProductChangedMessage>(this, OnProductChanged);

            //InitializePagedSource();
        }

        #region Filtering & Paging

        private void InitializePagedSource()
        {
            #region Paged Source
            var pagedSource = new PagedAsyncSource()
            {
                ElementType = typeof(ProductEntityModel),
                KeyProperty = nameof(Product.ProductId),
                PageSize = 100,
                PageNavigationMode = PageNavigationMode.ArbitraryWithTotalPageCount
            };

#if DEBUG
            pagedSource.PageSize = 10;
#endif

            pagedSource.FetchPage += (o, e) =>
            {
                e.Result = FetchPageRowsAsync(e);
            };

            pagedSource.GetTotalSummaries += (o, e) =>
            {
                e.Result = GetSummariesAsync(e);
            };

            pagedSource.GetUniqueValues += (o, e) =>
            {
                e.Result = GetValueListAsync(e);
            };

            pagedSource.PropertyChanged += (o, e) =>
            {
                if (e.PropertyName == nameof(PagedAsyncSource.AreRowsFetching))
                {
                    IsLoading = PagedSource.AreRowsFetching;
                }
            };

            PagedSource = pagedSource;
            #endregion
        }

        private async Task<FetchRowsResult> FetchPageRowsAsync(FetchPageAsyncEventArgs e)
        {
            try
            {
                var items = await LithoGlobalService.GetProductListAsync(e.Filter.MakeFilters(), e.MakeSorters(), e.Skip, e.Take);
                return new FetchRowsResult(items.ToArray(), hasMoreRows: items.Count == e.Take);
            }
            catch (Exception ex)
            {
                Logger.Error(ex);
                throw;
            }
        }

        private async Task<object[]> GetSummariesAsync(GetSummariesAsyncEventArgs e)
        {
            try
            {
                var summary = await LithoGlobalService.GetProductCount(e.Filter.MakeFilters());
                return e.Summaries.Select(x =>
                {
                    return x.SummaryType == SummaryType.Count ? (object)summary : throw new InvalidOperationException();
                }).ToArray();
            }
            catch (Exception ex)
            {
                Logger.Error(ex);
                throw;
            }
        }

        private async Task<object[]> GetValueListAsync(GetUniqueValuesAsyncEventArgs e)
        {
            try
            {
                return await LithoGlobalService.GetProductValueListAsync(e.PropertyName, e.Filter.MakeFilters());
            }
            catch (Exception ex)
            {
                Logger.Error(ex);
                throw;
            }
        }

        #endregion

        protected override void OnViewReadyAsync()
        {
            Refresh();
        }

        //public override void OnClosing(CancelEventArgs e)
        //{
        //    base.OnClosing(e);

        //    PagedSource?.Dispose();
        //    Messenger.Default.Unregister<ProductChangedMessage>(this, OnProductChanged);
        //}

        private async void OnPropertyChanged(object sender, System.ComponentModel.PropertyChangedEventArgs e)
        {
            if (e.PropertyName == nameof(SelectedProduct))
            {
                if (SelectedProduct != null)
                {
                    await GetProductDetailsAsync();
                }
                else
                {
                    ClearProductDetails();
                }
            }
        }
        private async void OnProductChanged(ProductChangedMessage msg)
        {
            //Refresh();

            var ProductEntity = ProductEntityList.FirstOrDefault(p => p.ProductId == msg.ProductId);
            switch (msg.ChangeType)
            {
                case ObjectChangeType.Created:
                    Refresh();
                    break;
                case ObjectChangeType.Deleted:
                    ProductEntityList.Remove(ProductEntity);
                    break;
                case ObjectChangeType.Updated:
                    await UpdateSingleProduct(ProductEntity);
                    break;
                default:
                    break;

            }
        }

        private async Task UpdateSingleProduct(ProductEntityModel ProductEntity)
        {
            var newProductEntity = await LithoGlobalService.GetProductAsync(ProductEntity.ProductId);

            //ProductEntity.LastModifyUser = newProductEntity.LastModifyUser;
            //ProductEntity.LastModifyTime = newProductEntity.LastModifyTime;
            ProductEntity.ProductId = newProductEntity.ProductId;
            ProductEntity.ProductType = newProductEntity.ProductId;
            ProductEntity.Fab = newProductEntity.Fab;

            ProductEntity.NotifyChanges();

            if (SelectedProduct != null && ProductEntity.ProductId == SelectedProduct.ProductId)
            {
                await GetProductDetailsAsync();
            }
        }


        private async Task GetProductDetailsAsync()
        {
            if (SelectedProduct != null)
            {
                #region 
                Fab = SelectedProduct.Fab;
                NameSpace = SelectedProduct.NameSpace;
                ProductId = SelectedProduct.ProductId;
                ProductType = SelectedProduct.ProductType;
                #endregion

                try
                {
                    IsHistoryLoading = true;
                    if (SelectedProduct != null)
                    {
                        HistoryList = new ObservableCollection<TransactionHistory>(await GlobalService.GetHistoryAsync(ClientInfo.LoginArea, "Product", SelectedProduct.ProductId, null));

                    }
                }
                finally
                {
                    IsHistoryLoading = false;
                }
            }
            else
            {
                HistoryList?.Clear();
            }
        }

        #region Commands
        [Command]
        public async void Refresh()
        {
            try
            {
                //IsLoading = true;
                //PagedSource.UpdateSummaries();
                //PagedSource.RefreshRows();

                IsLoading = true;
                ClearProductDetails();

                var preSelectedProduct = SelectedProduct;
                var productEntityList = await LithoGlobalService.GetProductListAsync();
                //var productEntityList = await LithoGlobalService.GetProductListAsync(new QueryParameter("fab", ClientInfo.LoginFab));
                ProductEntityList = new ObservableCollection<ProductEntityModel>(productEntityList);

                if (preSelectedProduct != null)
                {
                    SelectedProduct = productEntityList.FirstOrDefault(p => p.ProductId == preSelectedProduct.ProductId);
                }

            }
            finally
            {
                IsLoading = false;
            }
        }
        public bool CanRefresh()
        {
            return !IsLoading;
        }

        [Command]
        public void Add()
        {
            ShowEditProduct(null, FunctionMode.Add);
        }

        public bool CanAdd()
        {
            //return true;
            return AuthorityManager.HasAuthority(Auth_Product_Add);
        }

        [Command]
        public void Copy()
        {
            ShowEditProduct(SelectedProduct, FunctionMode.Copy);
        }

        public bool CanCopy()
        {
            return SelectedProduct != null && SelectedProductList.Count == 1 && !IsLoading;// && AuthorityManager.HasAuthority(Auth_Product_Copy);
        }

        [Command]
        public void Modify()
        {
            ShowEditProduct(SelectedProduct, FunctionMode.Modify);
        }

        public bool CanModify()
        {
            return SelectedProduct != null && SelectedProductList.Count == 1 && !IsLoading && AuthorityManager.HasAuthority(Auth_Product_Edit);
        }

        private void ShowEditProduct(Shared.Litho.DTO.Product originalProduct, FunctionMode mode)
        {
            if (ShowPopup("EditProduct", new EditProductViewModel(originalProduct, mode)).IsOK)
            {
                Refresh();
            }
        }

        [Command]
        public async void Delete()
        {
            if (IsConfirmed(out var comment))
            {
                var toDeleteProduct = SelectedProduct;
                await LithoGlobalService.DeleteProductAsync(SelectedProduct.ProductId, comment);
                Refresh();
                Messenger.Default.Send(new ProductChangedMessage() { ChangeType = ObjectChangeType.Deleted, ProductId = SelectedProduct.ProductId });
                MessageBoxService.ShowMessage($"Product {toDeleteProduct.ProductId} is deleted.", "Success", MessageButton.OK, MessageIcon.Information);
            }
        }

        public bool CanDelete()
        {
            return SelectedProduct != null && SelectedProductList.Count == 1 && !IsLoading && AuthorityManager.HasAuthority(Auth_Product_Delete);
        }

        public async Task RefreshProductBeforeAction(ProductEntityModel product)
        {
            await UpdateSingleProduct(product);
        }

        private void ClearProductDetails()
        {
            HistoryList = new ObservableCollection<TransactionHistory>();
        }

        #endregion

        #region Properties
        public PagedAsyncSource PagedSource
        {
            get { return GetValue<PagedAsyncSource>(); }
            set { SetValue(value); }
        }

        public bool IsProductSelected
        {
            get { return GetValue<bool>(); }
            set { SetValue(value); }
        }

        public ObservableCollection<ProductEntityModel> ProductEntityList
        {
            get { return GetValue<ObservableCollection<ProductEntityModel>>(); }
            set { SetValue(value); }
        }

        public ObservableCollection<Shared.Litho.DTO.Product> SelectedProductList { get; } = new ObservableCollection<Shared.Litho.DTO.Product>();

        public ProductEntityModel SelectedProduct
        {
            get { return GetValue<ProductEntityModel>(); }
            set { SetValue(value); }
        }

        public string Fab
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(Fab));
            }
        }

        public string Area
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(Area));
            }
        }

        public string NameSpace
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(NameSpace));
            }
        }

        public string ProductId
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(ProductId));
            }
        }

        public string ProductType
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(ProductType));
            }
        }

        #endregion
    }
}
