﻿using System.ComponentModel;
using AMAT.R2R.Shared.Litho.DTO;

namespace AMAT.R2R.Client.Litho.Modules.ProductSettings
{
    public class ProductEntityModel : Product, INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;

        public void NotifyChanges()
        {

            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(ProductId)));
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(ProductType)));
        }
    }
}
