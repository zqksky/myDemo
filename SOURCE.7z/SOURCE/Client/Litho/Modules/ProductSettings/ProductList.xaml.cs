﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using DevExpress.Mvvm;
using DevExpress.Xpf.Bars;
using DevExpress.Xpf.Grid;
using DevExpress.Xpf.Utils;

namespace AMAT.R2R.Client.Litho.Modules.ProductSettings
{
    /// <summary>
    /// Interaction logic for ProductList.xaml
    /// </summary>
    public partial class ProductList : UserControl
    {
        public ProductList()
        {
            InitializeComponent();
            CopyCellInfo = new DelegateCommand<object>(OnCopyCellInfo);
            CopyRowInfo = new DelegateCommand<object>(OnCopyRowInfo);
        }

        // https://supportcenter.devexpress.com/ticket/details/t522280/selection-of-row-overrides-the-back-colors-of-cells-in-gridcontrol

        private void View_CustomCellAppearance(object sender, DevExpress.Xpf.Grid.CustomCellAppearanceEventArgs e)
        {
            e.Result = e.ConditionalValue;
            e.Handled = true;
        }


        public static readonly DependencyProperty CellMenuInfoProperty = DependencyPropertyManager.Register("CellMenuInfo", typeof(GridCellMenuInfo), typeof(ProductList), new FrameworkPropertyMetadata(null));

        public ICommand DeleteRow { get; private set; }
        public ICommand CopyCellInfo { get; private set; }
        public ICommand CopyRowInfo { get; private set; }

        public GridCellMenuInfo CellMenuInfo
        {
            get { return (GridCellMenuInfo)GetValue(CellMenuInfoProperty); }
            set { SetValue(CellMenuInfoProperty, value); }
        }


        private void TableView_ShowGridMenu(object sender, DevExpress.Xpf.Grid.GridMenuEventArgs e)
        {
            CellMenuInfo = e.MenuType == GridMenuType.RowCell ? (GridCellMenuInfo)e.MenuInfo : null;
        }

        void OnCopyCellInfo(object parameter)
        {
            if (parameter is GridCellMenuInfo menuInfo && menuInfo.Row != null)
            {
                string text = GetCellText(menuInfo.Row.RowHandle.Value, menuInfo.Column);
                SetClibboardText(text);
            }
        }

        void OnCopyRowInfo(object parameter)
        {
            if (parameter is int)
            {
                grid.ClipboardCopyMode = ClipboardCopyMode.ExcludeHeader;
                grid.CopyRowsToClipboard(new int[] { Convert.ToInt32(parameter) });
                grid.ClipboardCopyMode = ClipboardCopyMode.IncludeHeader;
            }
        }

        void SetClibboardText(string text)
        {
            try
            {
                Clipboard.SetText(text);
            }
            catch { }
        }

        string GetCellText(int rowHandle, ColumnBase column)
        {
            return Convert.ToString(grid.GetCellValue(rowHandle, (GridColumn)column));
        }

        private void Export_ItemClick(object sender, DevExpress.Xpf.Bars.ItemClickEventArgs e)
        {
            var button = sender as BarButtonItem;
            var format = button.Content.ToString().Substring(10);

            switch (format)
            {
                case "XLSX":
                    Common.Helpers.WYSIWYGExportHelper.DoExport(view, DevExpress.XtraPrinting.ExportFormat.Xlsx);
                    break;
                case "CSV":
                    Common.Helpers.WYSIWYGExportHelper.DoExport(view, DevExpress.XtraPrinting.ExportFormat.Csv);
                    break;
                default:
                    Common.Helpers.WYSIWYGExportHelper.DoExport(view, DevExpress.XtraPrinting.ExportFormat.Txt);
                    break;
            }
        }
    }
}
