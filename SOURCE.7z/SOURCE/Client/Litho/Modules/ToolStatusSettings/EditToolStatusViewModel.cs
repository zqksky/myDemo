﻿using System.Collections.Generic;
using System.Collections.ObjectModel;
using AMAT.R2R.Client.Common.Enums;
using AMAT.R2R.Client.Litho.Messages;
using AMAT.R2R.Shared.Litho.DTO;
using DevExpress.Mvvm;
using DevExpress.Mvvm.DataAnnotations;

namespace AMAT.R2R.Client.Litho.Modules.ToolStatusSettings
{
    public class EditToolStatusViewModel : LithoViewModelBase
    {
        private const string NA = "NA";
        public EditToolStatusViewModel(List<ToolStatusEntity> toolStatusValuesList, FunctionMode mode)
        {
            OriginalToolStatusValuesList = new List<ToolStatusEntity>(toolStatusValuesList);
            EditToolStatusValuesList = new ObservableCollection<ToolStatusEntity>(toolStatusValuesList);
            SizeToContent = System.Windows.SizeToContent.WidthAndHeight;

            Mode = mode;

            switch (mode)
            {
                case FunctionMode.None:
                    break;
                case FunctionMode.Modify:
                    Caption = "Edit ToolStatus";
                    break;
                case FunctionMode.View:
                    break;
                default:
                    break;
            }
            IsDirty = false;

            //PropertyChanged += OnPropertyChanged;
            //Messenger.Default.Register<ToolStatusChangedMessage>(this, OnToolStatusChanged);
        }

        private void OnPropertyChanged(object sender, System.ComponentModel.PropertyChangedEventArgs e)
        {
            if (e.PropertyName == nameof(ToolStatusEntity.ToolId))
            {
                IsDirty = true;
            }
            if (e.PropertyName == nameof(ToolStatusEntity.VarName))
            {
                IsDirty = true;
            }
            if (e.PropertyName == nameof(ToolStatusEntity.ToolStatus))
            {
                IsDirty = true;
            }
        }
        //private void OnToolStatusChanged(ToolStatusChangedMessage msg)
        //{
        //    foreach (var param in EditToolStatusValuesList)
        //    {
        //        param.PropertyChanged += OnPropertyChanged;
        //    }
        //}

        protected override void OnViewReadyAsync()
        {
            if (Mode == FunctionMode.Modify)
            {
                SetFocus(nameof(ToolStatusEntity.ToolStatus));

                foreach (var param in EditToolStatusValuesList)
                {
                    param.PropertyChanged += OnPropertyChanged;
                }

            }
        }


        [Command]
        public async void Save()
        {
            if (HasErrors)
            {
                return;
            }

            if (IsConfirmed(out string comment))
            {
                if (Mode == FunctionMode.Modify)
                {
                    CurrentRecToolStatusValues = new RecToolStatusValues();
                    List<string> parameterList = new List<string>();
                    List<string> valueList = new List<string>();
                    foreach (var entity in EditToolStatusValuesList)
                    {
                        CurrentRecToolStatusValues.ToolId = entity.ToolId;
                        parameterList.Add(entity.VarName);
                        valueList.Add(entity.ToolStatus);
                    }
                    CurrentRecToolStatusValues.Parameters = parameterList.ToArray();
                    CurrentRecToolStatusValues.Values = valueList.ToArray();

                    //ShowWait();
                    await LithoGlobalService.ModifyToolStatusAsync(CurrentRecToolStatusValues.ToolId, CurrentRecToolStatusValues, comment);
                    IsDirty = false;
                    //HideWait();
                    Messenger.Default.Send(new ToolChangedMessage() { ChangeType = ObjectChangeType.Updated, ToolId = CurrentRecToolStatusValues.ToolId });
                    MessageBoxService.ShowMessage($"Tool {CurrentRecToolStatusValues.ToolId} is updated!", "Success", MessageButton.OK, MessageIcon.Information);

                }

                IsOK = true;
                CloseWindow();
            }
        }

        public bool CanSave()
        {
            switch (Mode)
            {
                case FunctionMode.Add:
                    return true;
                case FunctionMode.Modify:
                    return IsDirty;
                default:
                    return true;
            }
        }

        protected override string GetError(string columnName)
        {
            switch (columnName)
            {
                default:
                    return null;
            }
        }

        #region Properties
        RecToolStatusValues CurrentRecToolStatusValues;

        public List<ToolStatusEntity> OriginalToolStatusValuesList
        {
            get { return GetValue<List<ToolStatusEntity>>(); }
            set { SetValue(value); }
        }

        public ObservableCollection<ToolStatusEntity> EditToolStatusValuesList
        {
            get { return GetValue<ObservableCollection<ToolStatusEntity>>(); }
            set { SetValue(value); }
        }
        #endregion
    }
}
