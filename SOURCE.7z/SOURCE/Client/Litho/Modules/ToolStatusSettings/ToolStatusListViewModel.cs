﻿using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading.Tasks;
using AMAT.R2R.Client.Common.Enums;
using AMAT.R2R.Client.Common.Helpers;
using AMAT.R2R.Client.Litho.Messages;
using AMAT.R2R.Client.Litho.Modules.ToolSettings;
using AMAT.R2R.Shared.Base.DTO;
using AMAT.R2R.Shared.Litho.DTO;
using DevExpress.Mvvm;
using DevExpress.Mvvm.DataAnnotations;

namespace AMAT.R2R.Client.Litho.Modules.ToolStatusSettings
{
    public class ToolStatusListViewModel : LithoViewModelBase
    {
        public const string Auth_Global = "GlobalSettings";
        public const string Auth_ToolStatus = "GlobalSettings:ToolStatus";
        public const string Auth_ToolStatus_Edit = "GlobalSettings:ToolStatus:Edit";

        public ToolStatusListViewModel()
        {
            Caption = "ToolStatus Settings";
            Icon = "SvgImages/Business Objects/BO_StateMachine.svg";
            PropertyChanged += OnPropertyChanged;
            Messenger.Default.Register<ToolChangedMessage>(this, OnToolChanged);
        }

        protected override void OnViewReadyAsync()
        {
            Refresh();
        }

        private async void OnPropertyChanged(object sender, System.ComponentModel.PropertyChangedEventArgs e)
        {
            if (e.PropertyName == nameof(SelectedTool))
            {
                if (SelectedTool != null)
                {
                    ToolStatusValuesList = new ObservableCollection<ToolStatusEntity>();
                    await GetToolStatusDetailsAsync();
                }
                else
                {
                    ClearToolDetails();
                }
            }
        }
        private async void OnToolChanged(ToolChangedMessage msg)
        {
            switch (msg.ChangeType)
            {
                case ObjectChangeType.Updated:
                    //await UpdateSingleTool(msg.ToolId);
                    await GetToolStatusDetailsAsync();
                    break;
                default:
                    break;

            }
        }

        private async Task UpdateSingleTool(string toolId)
        {
            if (SelectedTool != null && toolId == SelectedTool.ToolId)
            {
                ToolStatusValuesList = new ObservableCollection<ToolStatusEntity>();
                await GetToolStatusDetailsAsync();
            }
        }


        private async Task GetToolStatusDetailsAsync()
        {
            if (SelectedTool != null)
            {
                try
                {
                    GetToolStatusValuesList();

                    IsHistoryLoading = true;
                    HistoryList = new ObservableCollection<TransactionHistory>(await GlobalService.GetHistoryAsync(ClientInfo.LoginArea, "ToolStatus", SelectedTool.ToolId, null));
                }
                finally
                {
                    IsHistoryLoading = false;
                }
            }
            else
            {
                HistoryList?.Clear();
            }
        }

        #region Commands
        [Command]
        public async void Refresh()
        {
            try
            {
                IsLoading = true;
                ClearToolDetails();

                var preSelectedTool = SelectedTool;
                var toolEntityList = await LithoGlobalService.GetToolListAsync();
                //var toolEntityList = await LithoGlobalService.GetToolListAsync(new QueryParameter("fab", ClientInfo.LoginFab));
                ToolEntityList = new ObservableCollection<ToolEntityModel>(toolEntityList);

                if (preSelectedTool != null)
                {
                    SelectedTool = ToolEntityList.FirstOrDefault(p => p.ToolId == preSelectedTool.ToolId);
                }

            }
            finally
            {
                IsLoading = false;
            }
        }
        public bool CanRefresh()
        {
            return !IsLoading;
        }

        [Command]
        public void Modify()
        {
            GetToolStatusValuesList();

            ShowEditTool(ToolStatusValuesList.ToList(), FunctionMode.Modify);
        }

        public bool CanModify()
        {            
            return SelectedTool != null && SelectedToolList.Count == 1 && !IsLoading;// && AuthorityManager.HasAuthority(Auth_ToolStatus_Edit);
        }

        private void ShowEditTool(List<ToolStatusEntity> currentToolStatusValuesList, FunctionMode mode)
        {
            if (ShowPopup("EditToolStatus", new EditToolStatusViewModel(currentToolStatusValuesList, mode)).IsOK)
            {
                Refresh();
            }
        }

        private void ClearToolDetails()
        {
            HistoryList = new ObservableCollection<TransactionHistory>();
        }

        private async void GetToolStatusValuesList()
        {
            if (SelectedTool != null)
            {
                try
                {
                    RecToolStatusValues toolStatusValues = await LithoGlobalService.GetToolStatusAsync(SelectedTool.ToolId);
                    ToolStatusValuesList = new ObservableCollection<ToolStatusEntity>();
                    if (toolStatusValues != null)
                    {
                        for (int i = 0; i < toolStatusValues.Parameters.Length; i++)
                        {
                            ToolStatusEntity toolStatus = new ToolStatusEntity();
                            toolStatus.ToolId = SelectedTool.ToolId;
                            toolStatus.VarName = toolStatusValues.Parameters[i];
                            toolStatus.ToolStatus = toolStatusValues.Values[i];
                            ToolStatusValuesList.Add(toolStatus);
                        }
                    }
                }
                finally
                { 
                }
            }
        }

        #endregion

        #region Properties
        public ObservableCollection<ToolEntityModel> ToolEntityList
        {
            get { return GetValue<ObservableCollection<ToolEntityModel>>(); }
            set { SetValue(value); }
        }

        public ObservableCollection<Shared.Litho.DTO.Tool> SelectedToolList { get; } = new ObservableCollection<Shared.Litho.DTO.Tool>();

        public ToolEntityModel SelectedTool
        {
            get { return GetValue<ToolEntityModel>(); }
            set { SetValue(value); }
        }

        public ObservableCollection<ToolStatusEntity> ToolStatusValuesList
        {
            get { return GetValue<ObservableCollection<ToolStatusEntity>>(); }
            set { SetValue(value); }
        }
        #endregion
    }
    public class ToolStatusEntity : BindableBase
    {
        public string ToolId { get; set; }
        public string VarName { get; set; }
        public string ToolStatus
        {
            get { return GetValue<string>(); }
            set { SetValue(value); }
        }

    }
}
