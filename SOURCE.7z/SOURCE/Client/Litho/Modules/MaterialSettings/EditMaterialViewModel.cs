﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using AMAT.R2R.Client.Common.Enums;
using AMAT.R2R.Client.Common.Helpers;
using AMAT.R2R.Client.Litho.Enums;
using AMAT.R2R.Client.Litho.Messages;
using AMAT.R2R.Shared.Litho.DTO;
using DevExpress.Mvvm;
using DevExpress.Mvvm.DataAnnotations;
using Newtonsoft.Json;

namespace AMAT.R2R.Client.Litho.Modules.MaterialSettings
{
    public class EditMaterialViewModel : LithoViewModelBase
    {
        public const string Auth_MaterialView_ResetCD = "MaterialView:ResetCD";
        public const string Auth_MaterialView_ResetOVL = "MaterialView:ResetOVL";

        private const string NA = "NA";
        public EditMaterialViewModel(Material sourceMaterial, FunctionMode mode)
        {
            SizeToContent = System.Windows.SizeToContent.Manual;

            SourceMaterial = sourceMaterial;
            Mode = mode;

            switch (mode)
            {
                case FunctionMode.None:
                    break;
                case FunctionMode.Add:
                    Caption = "Create Material";
                    break;
                case FunctionMode.Copy:
                    Caption = "Copy Material";
                    break;
                case FunctionMode.Modify:
                    Caption = "Edit Material";
                    break;
                case FunctionMode.Delete:
                    break;
                case FunctionMode.View:
                    break;
                default:
                    break;
            }

            if (SourceMaterial != null)
            {
                Fab = SourceMaterial.Fab;
                Product = SourceMaterial.Product;
                Layer = SourceMaterial.Layer;
                Tool = SourceMaterial.Tool;
                Reticle = SourceMaterial.Reticle;
                Recipe = SourceMaterial.Recipe;
                PreTool = SourceMaterial.PreTool;
                PreReticle = SourceMaterial.PreReticle;
                LstMaterialValue = SourceMaterial.LstMaterialValue;
                OVLControlFlag = SourceMaterial.OVLControlFlag;
                OVLIntercept = SourceMaterial.OVLIntercept;
                OVLRecommendValue = SourceMaterial.OVLRecommendValue;
                CDControlFlag = SourceMaterial.CDControlFlag;
                CDIntercept = SourceMaterial.CDIntercept;
                CDRecommendValue = SourceMaterial.CDRecommendValue;
                CDAssignPilot = SourceMaterial.CDAssignPilot;
                OVLAssignPilot = SourceMaterial.OVLAssignPilot;



            }
            CDControlFlagList = new ObservableCollection<string>(ContextService.GetControlFlagList());
            OVLControlFlagList = new ObservableCollection<string>(ContextService.GetControlFlagList());

            HaveChuckFlag = SourceMaterial.ChuckControl == 1;
            NoChuckFlag = !HaveChuckFlag;

        }

        protected override void OnViewReadyAsync()
        {
            Refresh();
        }

        private void Refresh()
        {
            ShowWait();

            if (Mode != FunctionMode.Add)
            {
                // clone source Material.
                NewMaterial = JsonConvert.DeserializeObject<Material>(JsonConvert.SerializeObject(SourceMaterial));
            }

            MaterialParameterList = new ObservableCollection<MaterialInputSetting>(NewMaterial.LstMaterialValue.Select(p =>
            new MaterialInputSetting()
            {
                VarName = p.Varname,
                RecommendValueNA = p.RecommendValueNA,
                FixedValueNA = p.FixedValueNA,
                OffsetValueNA = p.OffsetValueNA,
                RecommendValueC1 = p.RecommendValueC1,
                FixedValueC1 = p.FixedValueC1,
                OffsetValueC1 = p.OffsetValueC1,
                RecommendValueC2 = p.RecommendValueC2,
                FixedValueC2 = p.FixedValueC2,
                OffsetValueC2 = p.OffsetValueC2,
                Min = p.Min,
                Max = p.Max,
                MaxDelta = p.MaxDelta,
                Deadband = p.Deadband,
                Lambda = p.Lambda,
                ParameterType=p.ParameterType,
                ChuckFlag= NewMaterial.ChuckControl==0,
            }));

            CDMaterialParameterList = new ObservableCollection<MaterialInputSetting>(MaterialParameterList.Where(p => p.ParameterType == "DCD" || p.ParameterType == "FEM").ToList());
            OVLMaterialParameterList = new ObservableCollection<MaterialInputSetting>(MaterialParameterList.Where(p => p.ParameterType == SourceMaterial.OVLModel).ToList());

            foreach (var param in MaterialParameterList)
            {
                param.PropertyChanged += Param_PropertyChanged;
            }

            foreach (var param in CDMaterialParameterList)
            {
                param.PropertyChanged += Param_PropertyChanged;
            }
            foreach (var param in OVLMaterialParameterList)
            {
                param.PropertyChanged += Param_PropertyChanged;
            }
            HideWait();

            IsDirty = false;
        }

        private void Param_PropertyChanged(object sender, System.ComponentModel.PropertyChangedEventArgs e)
        {
            if (e.PropertyName == nameof(MaterialInputSetting.RecommendValueNA))
            {
                IsDirty = true;

                ClearError($"{nameof(MaterialParameterList)}.{e.PropertyName}");
            }
            if (e.PropertyName == nameof(MaterialInputSetting.FixedValueNA))
            {
                IsDirty = true;

                ClearError($"{nameof(MaterialParameterList)}.{e.PropertyName}");
            }
            if (e.PropertyName == nameof(MaterialInputSetting.OffsetValueNA))
            {
                IsDirty = true;

                ClearError($"{nameof(MaterialParameterList)}.{e.PropertyName}");
            }
            if (e.PropertyName == nameof(MaterialInputSetting.RecommendValueC1))
            {
                IsDirty = true;

                ClearError($"{nameof(MaterialParameterList)}.{e.PropertyName}");
            }
            if (e.PropertyName == nameof(MaterialInputSetting.FixedValueC1))
            {
                IsDirty = true;

                ClearError($"{nameof(MaterialParameterList)}.{e.PropertyName}");
            }
            if (e.PropertyName == nameof(MaterialInputSetting.OffsetValueC1))
            {
                IsDirty = true;

                ClearError($"{nameof(MaterialParameterList)}.{e.PropertyName}");
            }
            if (e.PropertyName == nameof(MaterialInputSetting.RecommendValueC2))
            {
                IsDirty = true;

                ClearError($"{nameof(MaterialParameterList)}.{e.PropertyName}");
            }
            if (e.PropertyName == nameof(MaterialInputSetting.FixedValueC2))
            {
                IsDirty = true;

                ClearError($"{nameof(MaterialParameterList)}.{e.PropertyName}");
            }
            if (e.PropertyName == nameof(MaterialInputSetting.OffsetValueC2))
            {
                IsDirty = true;

                ClearError($"{nameof(MaterialParameterList)}.{e.PropertyName}");
            }
        }

        [Command]
        public void ResetCD()
        {
            //await RefreshBeforeAction(SelectedMaterial);
            if (SourceMaterial == null || string.IsNullOrEmpty(SourceMaterial.ContextKey))
            {
                return;
            }
            string strKey = string.Format("{0}:{1}:{2}:{3}:{4}:{5}", SourceMaterial.Fab, SourceMaterial.Tool, SourceMaterial.Product, SourceMaterial.Layer, SourceMaterial.Reticle, SourceMaterial.Recipe);
            ShowPopup("Reset", new ResetViewModel(strKey, SourceMaterial, ResetType.CD));
        }
        public bool CanResetCD()
        {
            return SourceMaterial != null && AuthorityManager.HasAuthority(Auth_MaterialView_ResetCD);
        }

        [Command]
        public void ResetOVL()
        {
            //await RefreshBeforeAction(SelectedMaterial);
            if (SourceMaterial == null || string.IsNullOrEmpty(SourceMaterial.ContextKey))
            {
                return;
            }
            string strKey = string.Format("{0}:{1}:{2}:{3}:{4}:{5}:{6}:{7}", SourceMaterial.Fab, SourceMaterial.Tool, SourceMaterial.Product, SourceMaterial.Layer, SourceMaterial.Reticle, SourceMaterial.Recipe, SourceMaterial.PreTool, SourceMaterial.PreReticle);
            ShowPopup("Reset", new ResetViewModel(strKey, SourceMaterial, ResetType.OVL));
        }
        public bool CanResetOVL()
        {
            return SourceMaterial != null && AuthorityManager.HasAuthority(Auth_MaterialView_ResetOVL);
        }

        [Command]
        public async void SaveControl()
        {
            try
            {
                if (!IsDirty)
                {
                    MessageBoxService.ShowMessage($"No change!", "Message", MessageButton.OK, MessageIcon.Information);
                    return;
                }

                if (HasErrors) return;

                if (IsConfirmed(out var comment))
                {
                    NewMaterial.CDControlFlag = CDControlFlag;
                    NewMaterial.OVLControlFlag = OVLControlFlag;
                    NewMaterial.CDAssignPilot = CDAssignPilot;
                    NewMaterial.OVLAssignPilot = OVLAssignPilot;

                    ShowWait();
                    if (Mode == FunctionMode.Add || Mode == FunctionMode.Copy)
                    {
                    }
                    else
                    {
                        await MaterialService.UpdateControlFlagAsync(NewMaterial.ContextKey, NewMaterial, comment);
                        IsDirty = false;
                        HideWait();
                        Messenger.Default.Send(new MaterialChangedMessage() { ChangeType = ObjectChangeType.Updated, MaterialKey = NewMaterial.ContextKey });
                        MessageBoxService.ShowMessage($"ControlFlag is updated!", "Success", MessageButton.OK, MessageIcon.Information);
                    }
                    CloseWindow();
                }
            }
            catch (Exception ex)
            {
                ErrorHandler.HandleError(ex);
            }
        }

        public bool CanSaveControl()
        {
            return true;
            //return IsDirty;
        }

        [Command]
        public async void SaveRecommendValue()
        {
            try
            {
                if (!IsDirty)
                {
                    MessageBoxService.ShowMessage($"No change!", "Message", MessageButton.OK, MessageIcon.Information);
                    return;
                }

                if (HasErrors) return;

                foreach (var item in MaterialParameterList)
                {
                    if (item.Error != null)
                    {
                        SetError($"{nameof(MaterialParameterList)}.{item.Error}", item[item.Error]);
                        SetFocus(nameof(MaterialParameterList));
                        return;
                    }
                }

                if (IsConfirmed(out var comment))
                {
                    foreach (var cdParam in CDMaterialParameterList)
                    {
                        MaterialValue material = NewMaterial.LstMaterialValue.First(p => p.Varname == cdParam.VarName);
                        if (material != null)
                        {
                            material.RecommendValueNA = cdParam.RecommendValueNA;
                            material.FixedValueNA = cdParam.FixedValueNA;
                            material.OffsetValueNA = cdParam.OffsetValueNA;
                            material.RecommendValueC1 = cdParam.RecommendValueC1;
                            material.FixedValueC1 = cdParam.FixedValueC1;
                            material.OffsetValueC1 = cdParam.OffsetValueC1;
                            material.RecommendValueC2 = cdParam.RecommendValueC2;
                            material.FixedValueC2 = cdParam.FixedValueC2;
                            material.OffsetValueC2 = cdParam.OffsetValueC2;
                        }     
                    }

                    foreach (var ovlParam in OVLMaterialParameterList)
                    {
                        MaterialValue material = NewMaterial.LstMaterialValue.First(p => p.Varname == ovlParam.VarName);
                        if (material != null)
                        {
                            material.RecommendValueNA = ovlParam.RecommendValueNA;
                            material.FixedValueNA = ovlParam.FixedValueNA;
                            material.OffsetValueNA = ovlParam.OffsetValueNA;
                            material.RecommendValueC1 = ovlParam.RecommendValueC1;
                            material.FixedValueC1 = ovlParam.FixedValueC1;
                            material.OffsetValueC1 = ovlParam.OffsetValueC1;
                            material.RecommendValueC2 = ovlParam.RecommendValueC2;
                            material.FixedValueC2 = ovlParam.FixedValueC2;
                            material.OffsetValueC2 = ovlParam.OffsetValueC2;
                        }
                    }

                    ShowWait();
                    if (Mode == FunctionMode.Add || Mode == FunctionMode.Copy)
                    {
                    }
                    else
                    {
                        await MaterialService.ModifyMaterialAsync(NewMaterial.ContextKey, NewMaterial, comment);
                        IsDirty = false;
                        HideWait();
                        Messenger.Default.Send(new MaterialChangedMessage() { ChangeType = ObjectChangeType.Updated, MaterialKey = NewMaterial.ContextKey });
                        MessageBoxService.ShowMessage($"Material is updated!", "Success", MessageButton.OK, MessageIcon.Information);
                    }
                    CloseWindow();
                }
            }
            catch (Exception ex)
            {
                ErrorHandler.HandleError(ex);
            }
        }

        public bool CanSaveRecommendValue()
        {
            return true;
            //return IsDirty;
        }

        protected override string GetError(string columnName)
        {
            switch (columnName)
            {
                case nameof(Chuck):
                    return DataValidator.NotNull(Chuck);
                case nameof(CDControlFlag):
                    return DataValidator.NotNull(CDControlFlag);
                case nameof(CDIntercept):
                    return DataValidator.NotNull(CDIntercept);
                case nameof(CDRecommendValue):
                    return DataValidator.NotNull(CDRecommendValue);
                case nameof(OVLControlFlag):
                    return DataValidator.NotNull(OVLControlFlag);
                case nameof(OVLIntercept):
                    return DataValidator.NotNull(OVLIntercept);
                case nameof(OVLRecommendValue):
                    return DataValidator.NotNull(OVLRecommendValue);
                default:
                    return null;
            }
        }

        #region Properties
        public Material SourceMaterial
        {
            get { return GetValue<Material>(); }
            set { SetValue(value); }
        }

        public MaterialInputSetting SelectedMaterialParameter
        {
            get { return GetValue<MaterialInputSetting>(); }
            set { SetValue(value); }
        }

        public Material NewMaterial
        {
            get { return GetValue<Material>(); }
            set { SetValue(value); }
        }

        public ObservableCollection<MaterialInputSetting> MaterialParameterList
        {
            get { return GetValue<ObservableCollection<MaterialInputSetting>>(); }
            set { SetValue(value); }
        }
        public ObservableCollection<MaterialInputSetting> CDMaterialParameterList
        {
            get { return GetValue<ObservableCollection<MaterialInputSetting>>(); }
            set { SetValue(value); }
        }

        public ObservableCollection<MaterialInputSetting> OVLMaterialParameterList
        {
            get { return GetValue<ObservableCollection<MaterialInputSetting>>(); }
            set { SetValue(value); }
        }
        
        public bool NoChuckFlag
        {
            get { return GetValue<bool>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(NoChuckFlag));
            }
        }

        public bool HaveChuckFlag
        {
            get { return GetValue<bool>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(HaveChuckFlag));
            }
        }

        public string Fab
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(Fab));
            }
        }

        public string Tool
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(Tool));
            }
        }

        public string Product
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(Product));
            }
        }

        public string Layer
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(Layer));
            }
        }

        public string Reticle
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(Reticle));
            }
        }

        public string Recipe
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(Recipe));
            }
        }

        public string PreTool
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(PreTool));
            }
        }

        public string PreReticle
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(PreReticle));
            }
        }

        public string Chuck
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(Chuck));
            }
        }


        public string CDControlFlag
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(CDControlFlag));
            }
        }
        public ObservableCollection<string> CDControlFlagList
        {
            get { return GetValue<ObservableCollection<string>>(); }
            set { SetValue(value); }
        }
        public string OVLControlFlag
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(OVLControlFlag));
            }
        }
        public ObservableCollection<string> OVLControlFlagList
        {
            get { return GetValue<ObservableCollection<string>>(); }
            set { SetValue(value); }
        }
        public string CDIntercept
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(CDIntercept));
            }
        }

        public string CDRecommendValue
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(CDRecommendValue));
            }
        }

        public string OVLIntercept
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(OVLIntercept));
            }
        }

        public string OVLRecommendValue
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(OVLRecommendValue));
            }
        }

        public List<MaterialValue> LstMaterialValue
        {
            get { return GetValue<List<MaterialValue>>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(Recipe));
            }
        }
        public string CDAssignPilot
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(CDAssignPilot));
            }
        }
        public string OVLAssignPilot
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(OVLAssignPilot));
            }
        }
        #endregion
    }

    public class MaterialInputSetting : BindableBase, IDataErrorInfo
    {
        public string ParameterType { get; set; }
        public string VarName { get; set; }

        public double? RecommendValueNA
        {
            get { return GetValue<double?>(); }
            set { SetValue(value); }
        }
        public double? FixedValueNA
        {
            get { return GetValue<double?>(); }
            set { SetValue(value); }
        }
        public double? OffsetValueNA
        {
            get { return GetValue<double?>(); }
            set { SetValue(value); }
        }
        public double? RecommendValueC1
        {
            get { return GetValue<double?>(); }
            set { SetValue(value); }
        }
        public double? FixedValueC1
        {
            get { return GetValue<double?>(); }
            set { SetValue(value); }
        }
        public double? OffsetValueC1
        {
            get { return GetValue<double?>(); }
            set { SetValue(value); }
        }
        public double? RecommendValueC2
        {
            get { return GetValue<double?>(); }
            set { SetValue(value); }
        }
        public double? FixedValueC2
        {
            get { return GetValue<double?>(); }
            set { SetValue(value); }
        }
        public double? OffsetValueC2
        {
            get { return GetValue<double?>(); }
            set { SetValue(value); }
        }

        public double? Min { get; set; }
        public double? Max { get; set; }
        public double? MaxDelta { get; set; }
        public double? Deadband { get; set; }
        public double? Lambda { get; set; }
        public bool ChuckFlag { get; set; }
        public string Error
        {
            get
            {
                if (ParameterType  == "DCD" || ParameterType == "FEM")
                {
                    if (!string.IsNullOrEmpty(this[nameof(RecommendValueNA)]))
                    {
                        return $"{nameof(RecommendValueNA)}";
                    }
                    else if (!string.IsNullOrEmpty(this[nameof(FixedValueNA)]))
                    {
                        return $"{nameof(FixedValueNA)}";
                    }
                    else if (!string.IsNullOrEmpty(this[nameof(OffsetValueNA)]))
                    {
                        return $"{nameof(OffsetValueNA)}";
                    }
                    else
                    {
                        return null;
                    }
                }

                else
                {
                    if (ChuckFlag)
                    {
                        if (!string.IsNullOrEmpty(this[nameof(RecommendValueNA)]))
                        {
                            return $"{nameof(RecommendValueNA)}";
                        }
                        else if (!string.IsNullOrEmpty(this[nameof(FixedValueNA)]))
                        {
                            return $"{nameof(FixedValueNA)}";
                        }
                        else if (!string.IsNullOrEmpty(this[nameof(OffsetValueNA)]))
                        {
                            return $"{nameof(OffsetValueNA)}";
                        }
                        else
                        {
                            return null;
                        }
                    }
                    else
                    {
                        if (!string.IsNullOrEmpty(this[nameof(RecommendValueC1)]))
                        {
                            return $"{nameof(RecommendValueC1)}";
                        }
                        else if (!string.IsNullOrEmpty(this[nameof(FixedValueC1)]))
                        {
                            return $"{nameof(FixedValueC1)}";
                        }
                        else if (!string.IsNullOrEmpty(this[nameof(OffsetValueC1)]))
                        {
                            return $"{nameof(OffsetValueC1)}";
                        }
                        else if (!string.IsNullOrEmpty(this[nameof(RecommendValueC2)]))
                        {
                            return $"{nameof(RecommendValueC2)}";
                        }
                        else if (!string.IsNullOrEmpty(this[nameof(FixedValueC2)]))
                        {
                            return $"{nameof(FixedValueC2)}";
                        }
                        else if (!string.IsNullOrEmpty(this[nameof(OffsetValueC2)]))
                        {
                            return $"{nameof(OffsetValueC2)}";
                        }
                        else
                        {
                            return null;
                        }
                    }
                    
                    
                }
                
            }
        }


        public string this[string propertyName]
        {
            get
            {
                switch (propertyName)
                {
                    case nameof(RecommendValueNA):
                        return DataValidator.NotNull(RecommendValueNA);
                    case nameof(FixedValueNA):
                        return DataValidator.NotNull(FixedValueNA);
                    case nameof(OffsetValueNA):
                        return DataValidator.NotNull(OffsetValueNA);
                    case nameof(RecommendValueC1):
                        return DataValidator.NotNull(RecommendValueC1);
                    case nameof(FixedValueC1):
                        return DataValidator.NotNull(FixedValueC1);
                    case nameof(OffsetValueC1):
                        return DataValidator.NotNull(OffsetValueC1);
                    case nameof(RecommendValueC2):
                        return DataValidator.NotNull(RecommendValueC2);
                    case nameof(FixedValueC2):
                        return DataValidator.NotNull(FixedValueC2);
                    case nameof(OffsetValueC2):
                        return DataValidator.NotNull(OffsetValueC2);
                    default:
                        return null;
                }
            }
        }
    }
}
