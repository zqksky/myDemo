﻿using System.Collections.Generic;
using System.Collections.ObjectModel;
using AMAT.R2R.Client.Litho.Helpers;
using AMAT.R2R.Shared.Litho.DTO;

namespace AMAT.R2R.Client.Litho.Modules.MaterialSettings
{
    public class RunNoChuckViewModel : LithoViewModelBase
    {
        public RunNoChuckViewModel(RunHist selectedRunHist)
        {
            Caption = "No Chuck Control";
            SizeToContent = System.Windows.SizeToContent.Manual;
            WindowWidth = 760;
            WindowHeight = 480;
            SelectedRunHistory = selectedRunHist;
        }
        protected override void OnViewReadyAsync()
        {
            Refresh();
        }
        private void Refresh()
        {
            List<string> strListName = new List<string>();
            List<string> strListUsedValue = new List<string>();
            List<string> strListOffsetValue = new List<string>();
            List<string> strListPostMetrology = new List<string>();
            List<string> strListIntercept = new List<string>();
            List<string> strListNextRecommend = new List<string>();


            strListName = CommonHelp.StrCsvToList(SelectedRunHistory.OVLNamesCsv);
            strListUsedValue = CommonHelp.StrCsvToList(SelectedRunHistory.OvlUsedSettings);
            strListOffsetValue = CommonHelp.StrCsvToList(SelectedRunHistory.OvlOffset);
            strListPostMetrology = CommonHelp.StrCsvToList(SelectedRunHistory.OVLPostMetrologyCsv);
            strListIntercept = CommonHelp.StrCsvToList(SelectedRunHistory.OVLInterceptCsv);
            strListNextRecommend = CommonHelp.StrCsvToList(SelectedRunHistory.OVLNewRecSettingsFb);


            NoChuckRunHistoryList = new ObservableCollection<ChuckRunHistoryEntity>();
            for (int i = 0; i < strListName.Count; i++)
            {
                ChuckRunHistoryEntity entity = new ChuckRunHistoryEntity();
                entity.VarName = strListName[i];
                if (strListUsedValue.Count > i)
                {
                    entity.UsedValueNA = strListUsedValue[i];
                   
                }
                else 
                {
                    entity.UsedValueNA = "";
                }
                if (strListOffsetValue.Count > i)
                {
                    entity.OffsetValueNA = strListOffsetValue[i];
                    
                }
                else
                {
                    entity.OffsetValueNA = "";
                }
                if (strListPostMetrology.Count > i)
                {
                    entity.PostMetrologyNA = strListPostMetrology[i];
                    
                }
                else
                {
                    entity.PostMetrologyNA = "";
                }
                if (strListIntercept.Count > i)
                {
                    entity.InterceptNA = strListIntercept[i];
                    
                }
                else
                {
                    entity.InterceptNA = "";
                }
                if (strListNextRecommend.Count > i)
                {
                    entity.NextRecommendNA = strListNextRecommend[i];
                }
                else
                {
                    entity.NextRecommendNA = "";
                }
                
                NoChuckRunHistoryList.Add(entity);
            }
        }

        public RunHist SelectedRunHistory
        {
            get { return GetValue<RunHist>(); }
            set { SetValue(value); }
        }
        public ObservableCollection<ChuckRunHistoryEntity> NoChuckRunHistoryList
        {
            get { return GetValue<ObservableCollection<ChuckRunHistoryEntity>>(); }
            set { SetValue(value); }
        }
    }
}
