﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Threading.Tasks;
using AMAT.R2R.Client.Common.Enums;
using AMAT.R2R.Client.Common.Helpers;
using AMAT.R2R.Client.Litho.Messages;
using AMAT.R2R.Client.Litho.Modules.SpecialJobSettings;
using AMAT.R2R.Shared.Base.DTO;
using AMAT.R2R.Shared.Litho.DTO;
using DevExpress.Mvvm;
using DevExpress.Mvvm.DataAnnotations;
using DevExpress.Xpf.Core;
using DevExpress.Xpf.Data;

namespace AMAT.R2R.Client.Litho.Modules.MaterialSettings
{
    class MaterialListViewModel : LithoViewModelBase
    {
        public const string Auth_MaterialView = "MaterialView";
        public const string Auth_MaterialView_Edit = "MaterialView:Edit";
        public const string Auth_MaterialView_ResetCD = "MaterialView:ResetCD";
        public const string Auth_MaterialView_ResetOVL = "MaterialView:ResetOVL";
        public const string Auth_MaterialView_CreateSpecialJob = "SpecialJob:Create";

        public MaterialListViewModel()
        {
            Caption = "Materialized View Settings";
            Icon = "SvgImages/XAF/ModelEditor_Business_Object_Model.svg";
            PropertyChanged += OnPropertyChanged;
            Messenger.Default.Register<MaterialChangedMessage>(this, OnMaterialChanged);
            InitializePagedSource();
        }

        #region Filtering & Paging

        private void InitializePagedSource()
        {
            #region Paged Source
            var pagedSource = new PagedAsyncSource()
            {
                ElementType = typeof(MaterialModel),
                KeyProperty = nameof(MaterialModel.ContextKey),
                PageSize = 100,
                PageNavigationMode = PageNavigationMode.ArbitraryWithTotalPageCount
            };

#if DEBUG
            pagedSource.PageSize = 10;
#endif

            pagedSource.FetchPage += (o, e) =>
            {
                e.Result = FetchPageRowsAsync(e);
            };

            pagedSource.GetTotalSummaries += (o, e) =>
            {
                e.Result = GetSummariesAsync(e);
            };

            pagedSource.GetUniqueValues += (o, e) =>
            {
                e.Result = GetValueListAsync(e);
            };

            pagedSource.PropertyChanged += (o, e) =>
            {
                if (e.PropertyName == nameof(PagedAsyncSource.AreRowsFetching))
                {
                    IsLoading = PagedSource.AreRowsFetching;

                    // restore selection.
                    if (!IsLoading)
                    {
                        if (_lastSelectedItem != null)
                        {
                            foreach (var item in PagedSource)
                            {
                                var material = item as MaterialModel;
                                if (material.ContextKey == _lastSelectedItem.ContextKey)
                                {
                                    SelectedMaterial = material;
                                    break;
                                }
                            }
                        }
                    }
                }
            };

            PagedSource = pagedSource;
            #endregion
        }

        MaterialModel _lastSelectedItem = null;
        private async Task<FetchRowsResult> FetchPageRowsAsync(FetchPageAsyncEventArgs e)
        {
            try
            {
                if (SelectedMaterial != null)
                {
                    _lastSelectedItem = SelectedMaterial;
                }

                var items = await MaterialService.GetMaterialListAsync(e.Filter.MakeFilters(), e.MakeSorters(), e.Skip, e.Take);
                return new FetchRowsResult(items.ToArray(), hasMoreRows: items.Count == e.Take);
            }
            catch (Exception ex)
            {
                Logger.Error(ex);
                throw;
            }
        }

        private async Task<object[]> GetSummariesAsync(GetSummariesAsyncEventArgs e)
        {
            try
            {
                var summary = await MaterialService.GetMaterialCount(e.Filter.MakeFilters());
                return e.Summaries.Select(x =>
                {
                    return x.SummaryType == SummaryType.Count ? (object)summary : throw new InvalidOperationException();
                }).ToArray();
            }
            catch (Exception ex)
            {
                Logger.Error(ex);
                throw;
            }
        }

        private async Task<object[]> GetValueListAsync(GetUniqueValuesAsyncEventArgs e)
        {
            try
            {
                if (e.PropertyName == nameof(MaterialModel.Enabled) || e.PropertyName == nameof(MaterialModel.IsCDSpecConfig) || e.PropertyName == nameof(MaterialModel.IsOVLSpecConfig))
                {
                    var values = new object[] { true, false };
                    return await Task.Factory.StartNew(() => values);
                }
                else
                {
                    return await MaterialService.GetMaterialValueListAsync(e.PropertyName, e.Filter.MakeFilters());
                }
            }
            catch (Exception ex)
            {
                Logger.Error(ex);
                throw;
            }
        }

        #endregion

        #region Events

        protected override void OnViewReadyAsync()
        {
            //Refresh();
        }

        public override void OnRemoving(CancelEventArgs e)
        {
            base.OnRemoving(e);

            PagedSource?.Dispose();
            Messenger.Default.Unregister<MaterialChangedMessage>(this, OnMaterialChanged);
        }

        private async void OnPropertyChanged(object sender, System.ComponentModel.PropertyChangedEventArgs e)
        {
            if (e.PropertyName == nameof(SelectedMaterial))
            {
                if (SelectedMaterial != null)
                {
                    if (windowChuck != null)
                    {
                        windowChuck.Close();
                    }

                    HaveChuckFlag = SelectedMaterial.ChuckControl == 1;
                    NoChuckFlag = !HaveChuckFlag;

                    await GetMaterialDetailsAsync();
                    SelectedMaterialRunHistory = null;
                }
                else if (e.PropertyName == nameof(SelectedTabPageIndex))
                {
                    await UpdateCurrentTabPageDetail();
                }
                else
                {
                    ClearMaterialDetails();
                }
            }
        }

        private void OnMaterialChanged(MaterialChangedMessage msg)
        {
            Refresh();
        }
        private async Task UpdateCurrentTabPageDetail()
        {
            switch (SelectedTabPageIndex)
            {
                case 0:
                    try
                    {
                        IsInputLoading = true;
                        await GetMaterialDetailsAsync();
                    }
                    finally
                    {
                        IsInputLoading = false;
                    }
                    break;
                case 1:
                    try
                    {
                        IsRunHisLoading = true;
                        MaterialRunHistoryList?.Clear();
                        MaterialRunHistoryList = new ObservableCollection<RunHist>(await MaterialService.GetMaterialRunHistoryListAsync(SelectedMaterial.ContextKey));
                    }
                    finally
                    {
                        IsRunHisLoading = false;
                    }
                    break;
                case 2:
                    try
                    {
                        IsHistoryLoading = true;
                        HistoryList?.Clear();
                        try
                        {
                            IsHistoryLoading = true;
                            HistoryList = new ObservableCollection<TransactionHistory>(await GlobalService.GetHistoryAsync(ClientInfo.LoginArea, "Material", SelectedMaterial.ContextKey, null));
                        }
                        finally
                        {
                            IsHistoryLoading = false;
                        }
                    }
                    finally
                    {
                        IsHistoryLoading = false;
                    }
                    break;
                default:
                    break;
            }
        }

        private async Task UpdateSingleMaterial(MaterialModel material)
        {
            MaterialModel newMaterial = null;
            //DateTime lastModifiedTime = Material.LastModifiedTime;
            newMaterial = await MaterialService.GetMaterialAsync(material.ContextKey);

            //#region test
            //newMaterial = TestData();
            //#endregion

            material.CDControlFlag = newMaterial.CDControlFlag;
            material.CDIntercept = newMaterial.CDIntercept;
            material.CDRecommendValue = newMaterial.CDRecommendValue;
            material.OVLControlFlag = newMaterial.OVLControlFlag;
            material.OVLIntercept = newMaterial.OVLIntercept;
            material.OVLRecommendValue = newMaterial.OVLRecommendValue;
            material.LstMaterialValue = newMaterial.LstMaterialValue;
            material.NotifyChanges();

            if (SelectedMaterial != null && material.ContextKey == SelectedMaterial.ContextKey)// && material.LastModifiedTime != lastModifiedTime)
            {
                await GetMaterialDetailsAsync();
            }

        }
        #endregion

        #region Commands
        [Command]
        public void OnLostFocus()
        {
            //if (windowChuck != null)
            //{
            //    windowChuck.Close();
            //}
        }
        public bool CanOnLostFocus()
        {
            return true;
        }

        [Command]
        public void Refresh()
        {
            PagedSource.UpdateSummaries();
            PagedSource.RefreshRows();
        }
        public bool CanRefresh()
        {
            return !IsLoading;
        }

        [Command]
        public async void CreateSpecialJob()
        {
            await RefreshBeforeAction(SelectedMaterial);
            if (SelectedMaterial == null || string.IsNullOrEmpty(SelectedMaterial.ContextKey))
            {
                return;
            }
            List<string> OVLModelNameList = new List<string>();
            OVLModelNameList = await ContextService.GetOVLModelNameListAsync(SelectedMaterial.Tool);

            string strKey = SelectedMaterial.ContextKey;
           
            var SelectedContext = await ContextService.GetContextAsync(strKey);
            ShowPopup("EditSpecialJob", new EditSpecialJobViewModel(SelectedContext, new SpecialJob(), OVLModelNameList, FunctionMode.Add));
        }

        public bool CanCreateSpecialJob()
        {
            return SelectedMaterial != null && SelectedMaterialList.Count == 1 && !IsLoading && SelectedMaterial.ContextKey != null && AuthorityManager.HasAuthority(Auth_MaterialView_CreateSpecialJob);
        }

        private async Task GetMaterialDetailsAsync()
        {
            if (SelectedMaterial != null)
            {
                var targetMaterial = SelectedMaterial;
                var refreshedMaterial = await MaterialService.GetMaterialAsync(targetMaterial.ContextKey);

                //#region test
                //refreshedMaterial = TestData();
                //#endregion

                //targetJob.LastModifiedBy = refreshedJob.LastModifiedBy;
                //targetJob.LastModifiedTime = refreshedJob.LastModifiedTime;
                targetMaterial.Fab = refreshedMaterial.Fab;
                targetMaterial.Product = refreshedMaterial.Product;
                targetMaterial.Layer = refreshedMaterial.Layer;
                targetMaterial.Tool = refreshedMaterial.Tool;
                targetMaterial.Reticle = refreshedMaterial.Reticle;
                targetMaterial.Recipe = refreshedMaterial.Recipe;
                targetMaterial.PreReticle = refreshedMaterial.PreReticle;
                targetMaterial.PreTool = refreshedMaterial.PreTool;
                targetMaterial.CDControlFlag = refreshedMaterial.CDControlFlag;
                targetMaterial.CDIntercept = refreshedMaterial.CDIntercept;
                targetMaterial.CDRecommendValue = refreshedMaterial.CDRecommendValue;
                targetMaterial.OVLControlFlag = refreshedMaterial.OVLControlFlag;
                targetMaterial.OVLIntercept = refreshedMaterial.OVLIntercept;
                targetMaterial.OVLRecommendValue = refreshedMaterial.OVLRecommendValue;
                targetMaterial.LstMaterialValue = refreshedMaterial.LstMaterialValue;
                targetMaterial.NotifyChanges();

                CDMaterialParameterList = new ObservableCollection<MaterialValue>(SelectedMaterial.LstMaterialValue.Where(p => p.ParameterType == "DCD" || p.ParameterType == "FEM").ToList());
                OVLMaterialParameterList = new ObservableCollection<MaterialValue>(SelectedMaterial.LstMaterialValue.Where(p => p.ParameterType == SelectedMaterial.OVLModel).ToList());

                try
                {
                    IsHistoryLoading = true;
                    if (SelectedMaterial != null)
                    {
                        HistoryList = new ObservableCollection<TransactionHistory>(await GlobalService.GetHistoryAsync(ClientInfo.LoginArea, "Material", targetMaterial.ContextKey, null));
                    }

                    IsRunHisLoading = true;
                    if (SelectedMaterial != null)
                    {
                        MaterialRunHistoryList = new ObservableCollection<RunHist>(await MaterialService.GetMaterialRunHistoryListAsync(SelectedMaterial.ContextKey));
                    }

                    #region test
                    //TestRunChuck();
                    #endregion
                }
                finally
                {
                    IsHistoryLoading = false;
                    IsRunHisLoading = false;
                }
            }
            else
            {
                HistoryList?.Clear();
                MaterialRunHistoryList?.Clear();
            }
        }

        [Command]
        public async void EditMaterial()
        {
            await RefreshBeforeAction(SelectedMaterial);

            ShowPopup("EditMaterial", new EditMaterialViewModel(SelectedMaterial, FunctionMode.Modify));
        }

        public bool CanEditMaterial()
        {
            return SelectedMaterial != null && SelectedMaterialList.Count == 1 && !IsLoading && AuthorityManager.HasAuthority(Auth_MaterialView_Edit);
        }

        [Command]
        public void RunHistoryRowDoubleClick()
        {

            if (SelectedMaterialRunHistory != null)
            {
                if (windowChuck != null)
                {
                    windowChuck.Close();
                }
                windowChuck = new ThemedWindow();//Windows窗体    

                if (SelectedMaterialRunHistory.ChuckControl == 1)
                {
                    //RunChuck view = new RunChuck();
                    //view.DataContext = new RunChuckViewModel(SelectedMaterialRunHistory);
                    //windowChuck.Content = view;
                    //windowChuck.Title = "Chuck Control";
                    //windowChuck.TitleAlignment = WindowTitleAlignment.Center;
                    //windowChuck.WindowStyle = WindowStyle.ToolWindow;
                    //windowChuck.Height = 480;
                    //windowChuck.Width = 760;
                    //windowChuck.WindowKind = WindowKind.Auto;
                    //windowChuck.ResizeMode = ResizeMode.CanMinimize;
                    //windowChuck.WindowStartupLocation = WindowStartupLocation.CenterScreen;
                    //windowChuck.Show();

                    ShowPopup("RunChuck", new RunChuckViewModel(SelectedMaterialRunHistory));
                }
                else
                {
                    //testChuck win = new testChuck(SelectedMaterialRunHistory);
                    //win.Show();

                    //RunNoChuck view = new RunNoChuck();
                    //view.DataContext = new RunNoChuckViewModel(SelectedMaterialRunHistory);
                    //windowChuck.Content = view;
                    //windowChuck.Title = "No Chuck Control";
                    //windowChuck.TitleAlignment = WindowTitleAlignment.Center;
                    //windowChuck.WindowStyle = WindowStyle.ToolWindow;
                    //windowChuck.Height = 480;
                    //windowChuck.Width = 760;
                    ////var extension = new SvgImageSourceExtension() { Uri = new Uri("pack://application:,,,/DevExpress.Images.v20.1;component/SvgImages/Outlook Inspired/ShipmentReceived.svg", UriKind.RelativeOrAbsolute) };
                    ////windowChuck.Icon = (ImageSource)extension.ProvideValue(null);

                    ////windowChuck.Background = new SolidColorBrush(Color.FromRgb(0,0,255));
                    ////window.ResizeMode = ResizeMode.NoResize;
                    //windowChuck.WindowKind = WindowKind.Auto;
                    //windowChuck.ResizeMode = ResizeMode.CanMinimize;
                    //windowChuck.WindowStartupLocation = WindowStartupLocation.CenterScreen;
                    //windowChuck.Show();

                    ShowPopup("RunNoChuck", new RunNoChuckViewModel(SelectedMaterialRunHistory));
                }
            }
        }

        public bool CanRunHistoryRowDoubleClick()
        {
            return SelectedMaterialRunHistory != null && !IsLoading;
        }

        public async Task RefreshBeforeAction(MaterialModel material)
        {
            ShowWait();
            await UpdateSingleMaterial(material);
            HideWait();
        }
        private void ClearMaterialDetails()
        {
            HistoryList = new ObservableCollection<TransactionHistory>();
        }

        #endregion

        #region Properties
        public PagedAsyncSource PagedSource
        {
            get { return GetValue<PagedAsyncSource>(); }
            set { SetValue(value); }
        }

        ThemedWindow windowChuck;
        public bool NoChuckFlag
        {
            get { return GetValue<bool>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(NoChuckFlag));
            }
        }

        public bool HaveChuckFlag
        {
            get { return GetValue<bool>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(HaveChuckFlag));
            }
        }

        public bool IsInputLoading
        {
            get { return GetValue<bool>(); }
            set { SetValue(value); }
        }

        public bool IsRunHisLoading
        {
            get { return GetValue<bool>(); }
            set { SetValue(value); }
        }
        public int SelectedTabPageIndex
        {
            get { return GetValue<int>(); }
            set { SetValue(value); }
        }


        public RunHist SelectedMaterialRunHistory
        {
            get { return GetValue<RunHist>(); }
            set { SetValue(value); }
        }
        public ObservableCollection<RunHist> MaterialRunHistoryList
        {
            get { return GetValue<ObservableCollection<RunHist>>(); }
            set { SetValue(value); }
        }
        public ObservableCollection<MaterialModel> MaterialList
        {
            get { return GetValue<ObservableCollection<MaterialModel>>(); }
            set { SetValue(value); }
        }

        public ObservableCollection<MaterialInputSetting> MaterialParameterList
        {
            get { return GetValue<ObservableCollection<MaterialInputSetting>>(); }
            set { SetValue(value); }
        }

        public ObservableCollection<MaterialValue> CDMaterialParameterList
        {
            get { return GetValue<ObservableCollection<MaterialValue>>(); }
            set { SetValue(value); }
        }

        public ObservableCollection<MaterialValue> OVLMaterialParameterList
        {
            get { return GetValue<ObservableCollection<MaterialValue>>(); }
            set { SetValue(value); }
        }

        //public ObservableCollection<MaterialInputSetting> CDMaterialParameterList
        //{
        //    get { return GetValue<ObservableCollection<MaterialInputSetting>>(); }
        //    set { SetValue(value); }
        //}

        //public ObservableCollection<MaterialInputSetting> OVLMaterialParameterList
        //{
        //    get { return GetValue<ObservableCollection<MaterialInputSetting>>(); }
        //    set { SetValue(value); }
        //}

        public MaterialModel SelectedMaterial
        {
            get { return GetValue<MaterialModel>(); }
            set { SetValue(value); }
        }

        public ObservableCollection<MaterialModel> SelectedMaterialList { get; } = new ObservableCollection<MaterialModel>();

        #endregion

        #region test
        void TestRunChuck()
        {
            MaterialRunHistoryList = new ObservableCollection<RunHist>();
            for (int i = 0; i < 5; i++)
            {
                RunHist runHist = new RunHist() { LotId = i.ToString(), ChuckControl = i, OVLNamesCsv = "Name1,Name2,Name3,Name4,Name5" };
                if (i == 1)
                {
                    runHist = new RunHist() { LotId = i.ToString(), ChuckControl = i, OVLNamesCsv = "Name1,Name2,Name3,Name4,Name5", OvlOffset = "1,1,1,1,1;2,2,2,2,2" };
                }
                MaterialRunHistoryList.Add(runHist);
            }
        }
        MaterialModel TestData()
        {
            MaterialModel material = new MaterialModel();
            material.Fab = "Fab";
            material.Product = "Product";
            material.Layer = "Layer";
            material.Tool = "Tool";
            material.Reticle = "Reticle";
            material.Recipe = "Recipe";
            material.PreTool = "PreTool";
            material.PreReticle = "PreReticle";
            material.CDControlFlag = "CDControlFlag";
            material.CDIntercept = "CDIntercept";
            material.CDRecommendValue = "CDRecommendValue";
            material.OVLControlFlag = "OVLControlFlag";
            material.OVLIntercept = "OVLIntercept";
            material.OVLRecommendValue = "OVLRecommendValue";
            material.LstMaterialValue = new List<MaterialValue>() { new MaterialValue() { Varname = "VarName1", RecommendValueNA = 1, FixedValueNA = 1, OffsetValueNA = 1,Max = 20,Min = 0 }, new MaterialValue() { Varname = "VarName2", RecommendValueNA = 1, FixedValueNA = 1, OffsetValueNA = 1, Max = 20, Min = 0 }, new MaterialValue() { Varname = "VarName3", RecommendValueNA = 1, FixedValueNA = 1, OffsetValueNA = 1, Max = 20, Min = 0 }
                };
            return material;
        }

        List<MaterialModel> TestDataList()
        {
            List<MaterialModel> materialList = new List<MaterialModel>();
            for (int i = 0; i < 5; i++)
            {
                MaterialModel material = new MaterialModel();
                material.Fab = "Fab" + i;
                material.Product = "Product" + i;
                material.Layer = "Layer" + i;
                material.Tool = "Tool" + i;
                material.Reticle = "Reticle" + i;
                material.Recipe = "Recipe" + i;
                material.PreTool = "PreTool" + i;
                material.PreReticle = "PreReticle" + i;
                material.CDControlFlag = "CDControlFlag" + i;
                material.CDIntercept = "CDIntercept" + i;
                material.CDRecommendValue = "CDRecommendValue" + i;
                material.OVLControlFlag = "OVLControlFlag" + i;
                material.OVLIntercept = "OVLIntercept" + i;
                material.OVLRecommendValue = "OVLRecommendValue" + i;
                material.LstMaterialValue = new List<MaterialValue>() { new MaterialValue() { Varname = "VarName1", RecommendValueNA = i, FixedValueNA = i, OffsetValueNA = i,Max = 20,Min = 0 }, new MaterialValue() { Varname = "VarName2", RecommendValueNA = i, FixedValueNA = i, OffsetValueNA = i, Max = 20, Min = 0 }, new MaterialValue() { Varname = "VarName3", RecommendValueNA = i, FixedValueNA = i, OffsetValueNA = i, Max = 20, Min = 0 }
                };
                materialList.Add(material);
            }
            return materialList;
        }
        #endregion
    }

    public class ChuckRunHistoryEntity : BindableBase
    {
        public string VarName { get; set; }
        public string UsedValueNA { get; set; }
        public string OffsetValueNA { get; set; }
        public string PostMetrologyNA { get; set; }
        public string InterceptNA { get; set; }
        public string NextRecommendNA { get; set; }
        public string UsedValueC1 { get; set; }
        public string OffsetValueC1 { get; set; }
        public string PostMetrologyC1 { get; set; }
        public string InterceptC1 { get; set; }
        public string NextRecommendC1 { get; set; }
        public string UsedValueC2 { get; set; }
        public string OffsetValueC2 { get; set; }
        public string PostMetrologyC2 { get; set; }
        public string InterceptC2 { get; set; }
        public string NextRecommendC2 { get; set; }
    }
}
