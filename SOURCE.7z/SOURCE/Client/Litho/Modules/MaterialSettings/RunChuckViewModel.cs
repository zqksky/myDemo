﻿using System.Collections.Generic;
using System.Collections.ObjectModel;
using AMAT.R2R.Client.Litho.Helpers;
using AMAT.R2R.Shared.Litho.DTO;

namespace AMAT.R2R.Client.Litho.Modules.MaterialSettings
{
    public class RunChuckViewModel : LithoViewModelBase
    {
        public RunChuckViewModel(RunHist selectedRunHist)
        {
            Caption = "Chuck Control";
            SizeToContent = System.Windows.SizeToContent.Manual;
            WindowWidth = 960;
            WindowHeight = 480;
            SelectedRunHistory = selectedRunHist;
        }
        protected override void OnViewReadyAsync()
        {
            Refresh();
        }
        private void Refresh()
        {
            List<string> strListName = new List<string>();
            List<string> strListUsedValueC1 = new List<string>();
            List<string> strListOffsetValueC1 = new List<string>();
            List<string> strListPostMetrologyC1 = new List<string>();
            List<string> strListInterceptC1 = new List<string>();
            List<string> strListNextRecommendC1 = new List<string>();
            List<string> strListUsedValueC2 = new List<string>();
            List<string> strListOffsetValueC2 = new List<string>();
            List<string> strListPostMetrologyC2 = new List<string>();
            List<string> strListInterceptC2 = new List<string>();
            List<string> strListNextRecommendC2 = new List<string>();

            strListName = CommonHelp.StrCsvToList(SelectedRunHistory.OVLNamesCsv);
            CommonHelp.StrChuckCsvToList(SelectedRunHistory.OvlUsedSettings, ref strListUsedValueC1, ref strListUsedValueC2);
            CommonHelp.StrChuckCsvToList(SelectedRunHistory.OvlOffset, ref strListOffsetValueC1, ref strListOffsetValueC2);
            CommonHelp.StrChuckCsvToList(SelectedRunHistory.OVLPostMetrologyCsv, ref strListPostMetrologyC1, ref strListPostMetrologyC2);
            CommonHelp.StrChuckCsvToList(SelectedRunHistory.OVLInterceptCsv, ref strListInterceptC1, ref strListInterceptC2);
            CommonHelp.StrChuckCsvToList(SelectedRunHistory.OVLNewRecSettingsFb, ref strListNextRecommendC1, ref strListNextRecommendC2);
            ChuckRunHistoryList = new ObservableCollection<ChuckRunHistoryEntity>();
            for(int i=0;i< strListName.Count;i++)
            {
                ChuckRunHistoryEntity entity = new ChuckRunHistoryEntity();
                entity.VarName = strListName[i];
                if (strListOffsetValueC1.Count > i)
                {
                    entity.OffsetValueC1 = strListOffsetValueC1[i];
                    
                }
                else
                {
                    entity.OffsetValueC1 = "";
                }
                if (strListOffsetValueC2.Count > i)
                {
                    entity.OffsetValueC2 = strListOffsetValueC2[i];
                    
                }
                else
                {
                    entity.OffsetValueC2 = "";
                }
                if (strListUsedValueC1.Count > i)
                {
                    entity.UsedValueC1 = strListUsedValueC1[i];
                    
                }
                else
                {
                    entity.UsedValueC1 = "";
                }
                if (strListUsedValueC2.Count > i)
                {
                    entity.UsedValueC2 = strListUsedValueC2[i];
                    
                }
                else
                {
                    entity.UsedValueC2 = "";
                }
                if (strListPostMetrologyC1.Count > i)
                {
                    entity.PostMetrologyC1 = strListPostMetrologyC1[i];
                   
                }
                else
                {
                    entity.PostMetrologyC1 = "";
                }
                if (strListPostMetrologyC2.Count > i)
                {
                    entity.PostMetrologyC2 = strListPostMetrologyC2[i];
                   
                }
                else
                {
                    entity.PostMetrologyC2 = "";
                }
                if (strListInterceptC1.Count > i)
                {
                    entity.InterceptC1 = strListInterceptC1[i];
                    
                }
                else
                {
                    entity.InterceptC1 = "";
                }
                if (strListInterceptC2.Count > i)
                {
                    entity.InterceptC2 = strListInterceptC2[i];
                    
                }
                else
                {
                    entity.InterceptC2 = "";
                }
                if (strListNextRecommendC1.Count > i)
                {
                    entity.NextRecommendC1 = strListNextRecommendC1[i];
                    
                }
                else
                {
                    entity.NextRecommendC1 = "";
                }
                if (strListNextRecommendC2.Count > i)
                {
                    entity.NextRecommendC2 = strListNextRecommendC2[i];
                }
                else
                {
                    entity.NextRecommendC2 = "";
                }
                
                ChuckRunHistoryList.Add(entity);
            }
        }

        public RunHist SelectedRunHistory
        {
            get { return GetValue<RunHist>(); }
            set { SetValue(value); }
        }
        public ObservableCollection<ChuckRunHistoryEntity> ChuckRunHistoryList
        {
            get { return GetValue<ObservableCollection<ChuckRunHistoryEntity>>(); }
            set { SetValue(value); }
        }        
    }
}
