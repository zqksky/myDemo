﻿using AMAT.R2R.Client.Common.Enums;
using AMAT.R2R.Client.Common.Helpers;
using AMAT.R2R.Client.Litho.Enums;
using AMAT.R2R.Client.Litho.Messages;
using AMAT.R2R.Shared.Litho.DTO;
using DevExpress.Mvvm;
using DevExpress.Mvvm.DataAnnotations;

namespace AMAT.R2R.Client.Litho.Modules.MaterialSettings
{
    public class ResetViewModel : LithoViewModelBase
    {
        public ResetViewModel(string strKey, Material material, ResetType resetType)
        {
            CurrentMaterial = material;

            Password = string.Empty;
            SizeToContent = System.Windows.SizeToContent.WidthAndHeight;
            ContextKey = strKey;
            ResetType = resetType;
            switch (resetType)
            {
                case ResetType.None:
                    break;
                case ResetType.CD:
                    Caption = "Reset CD";
                    ResetMsg = "Reset CDContext:  " + strKey + " ?";
                    break;
                case ResetType.OVL:
                    Caption = "Reset OVL";
                    ResetMsg = "Reset OVLContext: " + strKey + " ?";
                    break;
                default:
                    break;
            }
        }
        protected override void OnViewReadyAsync()
        {
        }

        public string Comment
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(Comment));
            }
        }

        public string Password
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(Password));
            }
        }

        protected override string GetError(string fieldName)
        {
            switch (fieldName)
            {
                case nameof(Password):
                    return ClientInfo.CheckLoginPassword(Password) ? null : Properties.Resources.DueDateError;
                case nameof(Comment):
                    return DataValidator.UTF8StringMaxLength(Comment, 1024);
                case nameof(ResetMsg):
                    return DataValidator.ValidString(ResetMsg);
                default:
                    return null;
            }
        }

        [Command]
        public async void Save()
        {
            ValidateAndSetErrorFocus(nameof(Comment), nameof(Password));
            if (!HasErrors)
            {
                string strMsg = "";

                if (ResetType.CD == ResetType)
                {
                    ShowWait();
                    //await MaterialService.ResetCDAsync(ContextKey, Comment);
                    await MaterialService.ResetCDAsync(ContextKey, CurrentMaterial, Comment);
                    //strMsg = await MaterialService.GetResetCDAsync(ContextKey, Comment);
                    HideWait();
                    Messenger.Default.Send(new MaterialChangedMessage() { ChangeType = ObjectChangeType.Updated, MaterialKey = CurrentMaterial.ContextKey });
                    MessageBoxService.ShowMessage($"CD is reset!", "Success", MessageButton.OK, MessageIcon.Information);
                }
                else if (ResetType.OVL == ResetType)
                {
                    ShowWait();
                    await MaterialService.ResetOVLAsync(ContextKey, CurrentMaterial, Comment);
                    //strMsg = await MaterialService.GetResetOVLAsync(ContextKey, Comment);
                    HideWait();
                    Messenger.Default.Send(new MaterialChangedMessage() { ChangeType = ObjectChangeType.Updated, MaterialKey = CurrentMaterial.ContextKey });
                    MessageBoxService.ShowMessage($"OVL is reset!", "Success", MessageButton.OK, MessageIcon.Information);
                }

                IsOK = true;
                CloseWindow();
            }
            else
            {
                if (HasErrorWithProperty(nameof(Password)))
                {
                    MessageBoxService.ShowMessage("Please enter password again!", "Incorrect password!", MessageButton.OK, MessageIcon.Warning);
                }
                return;
            }
        }

        public bool CanSave()
        {
            return !string.IsNullOrEmpty(Comment);
        }

        [Command]
        public void Cancel()
        {
            CloseWindow();
        }
        #region Properties
        public Material CurrentMaterial { get; private set; }

        public ResetType ResetType
        {
            get { return GetValue<ResetType>(); }
            set { SetValue(value); }
        }

        public string ContextKey
        {
            get { return GetValue<string>(); }
            set { SetValue(value); }
        }
        public string ResetMsg
        {
            get { return GetValue<string>(); }
            set { SetValue(value); }
        }
        #endregion
    }
}
