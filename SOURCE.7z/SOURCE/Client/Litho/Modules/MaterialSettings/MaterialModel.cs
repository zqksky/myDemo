﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AMAT.R2R.Shared.Litho.DTO;

namespace AMAT.R2R.Client.Litho.Modules.MaterialSettings
{
    public class MaterialModel : Material, INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;

        public void NotifyChanges()
        {

            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(CDControlFlag)));

            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(OVLControlFlag)));

            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(CDIntercept)));

            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(CDRecommendValue)));

            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(OVLIntercept)));

            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(OVLRecommendValue)));

            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(LstMaterialValue)));
        }
    }
}
