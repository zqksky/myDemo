﻿using System;
using System.Collections.ObjectModel;
using AMAT.R2R.Client.Common.Helpers;
using AMAT.R2R.Client.Common.Messages;
using AMAT.R2R.Client.Common.Models;
using AMAT.R2R.Client.Common.ViewModels;
using AMAT.R2R.Client.Litho.Modules.ContextSettings;
using AMAT.R2R.Client.Litho.Modules.LithoConfig;
using AMAT.R2R.Client.Litho.Modules.MaterialSettings;
using AMAT.R2R.Client.Litho.Modules.ProcessRecordConfig;
using AMAT.R2R.Client.Litho.Modules.ProcessSettings;
using AMAT.R2R.Client.Litho.Modules.ProductSettings;
using AMAT.R2R.Client.Litho.Modules.RunHistory;
using AMAT.R2R.Client.Litho.Modules.SpecialJobSettings;
using AMAT.R2R.Client.Litho.Modules.ToolSettings;
using AMAT.R2R.Client.Litho.Modules.ToolStatusSettings;
using AMAT.R2R.Client.Litho.Services;
using DevExpress.Mvvm;
using DevExpress.Mvvm.DataAnnotations;

namespace AMAT.R2R.Client.Litho
{
    public class MainViewModel : MainViewModelBase
    {
        protected override void RegisterServices()
        {
            DevExpress.Mvvm.ServiceContainer.Default.RegisterService(new ProcessService());
            DevExpress.Mvvm.ServiceContainer.Default.RegisterService(new ContextService());
            DevExpress.Mvvm.ServiceContainer.Default.RegisterService(new SpecialJobService());
            DevExpress.Mvvm.ServiceContainer.Default.RegisterService(new MaterialService());
            DevExpress.Mvvm.ServiceContainer.Default.RegisterService(new LithoGlobalService());
            DevExpress.Mvvm.ServiceContainer.Default.RegisterService(new ProcessRecordService());
            DevExpress.Mvvm.ServiceContainer.Default.RegisterService(new LotRunHistoryService());
        }

        protected override void BuildNavigationMenu()
        {
            NavGroups = new ReadOnlyCollection<NavigationGroupModel>(new NavigationGroupModel[]
            {
                new NavigationGroupModel()
                {
                    Header = "Configuration",
                    SubItems = new ReadOnlyCollection<NavigationModel>(new NavigationModel[]
                    {
                        new NavigationModel()
                        {
                            Header = "Process",
                            FunctionType = "ProcessList",
                            Icon = SetIcon("pack://application:,,,/DevExpress.Images.v20.1;component/SvgImages/Business Objects/BO_KPI_Definition.svg"),
                            IsVisible = AuthorityManager.HasAuthority(ProcessListViewModel.Auth_Process)
                        },
                        new NavigationModel()
                        {
                            Header = "Context",
                            FunctionType = "ContextList",
                            Icon = SetIcon("pack://application:,,,/DevExpress.Images.v20.1;component/SvgImages/Business Objects/BO_KPI_Scorecard.svg"),
                            IsVisible = AuthorityManager.HasAuthority(ContextListViewModel.Auth_Context)
                        },
                    })
                },
                new NavigationGroupModel()
                {
                    Header = "Operation",
                    SubItems = new ReadOnlyCollection<NavigationModel>(new NavigationModel[]
                    {
                        new NavigationModel()
                        {
                            Header = "Special Job",
                            FunctionType = "SpecialJobList",
                            Icon = SetIcon("pack://application:,,,/DevExpress.Images.v20.1;component/SvgImages/Snap/SnapHeader.svg"),
                            IsVisible = AuthorityManager.HasAuthority(SpecialJobListViewModel.Auth_SpecialJob),
                        },
                        new NavigationModel()
                        {
                            Header = "Materialized View",
                            FunctionType = "MaterialList",
                            Icon = SetIcon("pack://application:,,,/DevExpress.Images.v20.1;component/SvgImages/XAF/ModelEditor_Business_Object_Model.svg"),
                            IsVisible = AuthorityManager.HasAuthority(MaterialListViewModel.Auth_MaterialView),
                        },
                        new NavigationModel()
                        {
                            Header = "Process Record",
                            FunctionType = "ProcessRecord",
                            Icon = SetIcon("pack://application:,,,/DevExpress.Images.v20.1;component/SvgImages/XAF/ActionGroup_EasyTestRecorder.svg"),
                            IsVisible = AuthorityManager.HasAuthority(ProcessRecordViewModel.Auth_ProcessRecord),
                            //IsVisible = true,
                        },
                    })
                },
                new NavigationGroupModel()
                {
                    Header = "History",
                    SubItems = new ReadOnlyCollection<NavigationModel>(new NavigationModel[]
                    {
                        new NavigationModel()
                        {
                            Header = "Lot Run History",
                            FunctionType = "LotRunHistoryList",
                            Icon = SetIcon("pack://application:,,,/DevExpress.Images.v20.1;component/SvgImages/Business Objects/BO_Audit_ChangeHistory.svg"),
                            IsVisible = true,
                            //IsVisible = true,
                        },
                    })
                },
                new NavigationGroupModel()
                {
                    Header = "Global",
                    SubItems = new ReadOnlyCollection<NavigationModel>(new NavigationModel[]
                    {
                        new NavigationModel()
                        {
                            Header = "Tool",
                            FunctionType = "ToolList",
                            Icon = SetIcon("pack://application:,,,/DevExpress.Images.v20.1;component/SvgImages/Business Objects/BO_Category.svg"),
                            //Icon = SetIcon("pack://application:,,,/DevExpress.Images.v20.1;component/SvgImages/Outlook Inspired/ProductSpecificationsSummary.svg"),
                            IsVisible = AuthorityManager.HasAuthority(ToolListViewModel.Auth_Global)&&AuthorityManager.HasAuthority(ToolListViewModel.Auth_Tool),
                            //IsVisible = true,
                        },
                         new NavigationModel()
                        {
                            Header = "ToolStatus",
                            FunctionType = "ToolStatusList",
                            Icon = SetIcon("pack://application:,,,/DevExpress.Images.v20.1;component/SvgImages/Business Objects/BO_StateMachine.svg"),
                            //Icon = SetIcon("pack://application:,,,/DevExpress.Images.v20.1;component/SvgImages/Outlook Inspired/ProductSpecificationsSummary.svg"),
                            IsVisible = AuthorityManager.HasAuthority(ToolStatusListViewModel.Auth_Global)&&AuthorityManager.HasAuthority(ToolStatusListViewModel.Auth_ToolStatus),
                            //IsVisible = true,
                        },
                        new NavigationModel()
                        {
                            Header = "Product",
                            FunctionType = "ProductList",
                            Icon = SetIcon("pack://application:,,,/DevExpress.Images.v20.1;component/SvgImages/Outlook Inspired/Products.svg"),
                            IsVisible = AuthorityManager.HasAuthority(ToolListViewModel.Auth_Global)&&AuthorityManager.HasAuthority(ProductListViewModel.Auth_Product),
                            //IsVisible = true,
                        },
                        new NavigationModel()
                        {
                            Header = "Config",
                            FunctionType = "LithoConfigMain",
                            Icon = SetIcon("pack://application:,,,/DevExpress.Images.v20.1;component/SvgImages/Outlook Inspired/ShipmentReceived.svg"),
                            //IsVisible = AuthorityManager.HasAuthority(LithoConfigMainViewModel.Auth_LithoConfig),
                            IsVisible = true,
                        },
                    })
                },
            }
            );
        }

    }
}
