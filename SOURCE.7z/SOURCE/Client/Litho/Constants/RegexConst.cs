﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AMAT.R2R.Client.Litho.Constants
{
    public class RegexConst
    {
        //public const string ToolIdRegex = @"[A-Z0-9#\-_]{1,40}";
        public const string NormalId40 = @"[a-zA-Z0-9#\-_]{1,40}";
        public const string NormalId255 = @"[a-zA-Z0-9#\-_]{1,255}";
        public const string ZoneDefinitionRegex = @"(([1-9]{1}[0-9]*)|(([1-9]{1}[0-9]*)(,|-|(,?([1-9]{1}[0-9]*))|(-?([1-9]{1}[0-9]*)){1})*))"; // ??
        public const string DomainUserRegex = @"[a-zA-Z0-9_]{0,61}\\?[a-zA-Z0-9_]*";

        public const string NormalRegex = @"[A-Za-z0-9#\-_.]+";
        public const string ToolRegex = @"[A-Za-z0-9\-_]{6}";
        public const string ProductRegex = @"[A-Za-z0-9\-_]{5}";
        public const string LayerRegex = @"[A-Za-z0-9\-_]{1,3}";
        public const string ReticleRegex = @"([A-Za-z0-9]{5})-([A-Za-z0-9]{4})-([A-Za-z0-9]{4})";
        public const string RecipeRegex = @"([A-Za-z0-9]+)_([A-Za-z0-9]{1,3})_([A-Za-z0-9]+)";
        public const string PreToolRegex = @"[A-Za-z0-9\-_]{6}|NA";
        public const string PreLayerRegex = @"[A-Za-z0-9\-_]{1,3}|NA";
        public const string PreReticleRegex = @"([A-Za-z0-9]{5})-([A-Za-z0-9]{4})-([A-Za-z0-9]{4})|NA";

        public const string PositiveIntegerRegex = @"([1-9]\d*)";
        public const string Integer0To100Regex = @"([0-9]?\d|100)";

        public const string DoubleFormat = @"#,###,###,##0.0#################";
        public const string NormalDoubleFormat = @"#,###,###,##0.0####";

        public const string BoolRegex = @"^(true|false)$";
        public const string ZeroOrOneRegex = @"^[0-1]$";
        public const string DoubleRegex = @"^[+-]?\d*[.]?\d*$";
        public const string NoSignDoubleRegex = @"^\d*[.]?\d*$";
        public const string IntegerRegex = @"^[+-]?\d*$";
        public const string NoSignIntegerRegex = @"^\d*$";
        public const string DedicationTypeRegex = @"^[1-3]$";

    }
}
