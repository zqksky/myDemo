﻿using AMAT.R2R.Client.Common.Enums;

namespace AMAT.R2R.Client.Litho.Messages
{
    public class ToolStatusChangedMessage
    {
        public ObjectChangeType ChangeType { get; set; }

        public string ToolId { get; set; }
    }
}
