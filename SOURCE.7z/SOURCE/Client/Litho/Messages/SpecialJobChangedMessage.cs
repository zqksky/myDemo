﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AMAT.R2R.Client.Common.Enums;

namespace AMAT.R2R.Client.Litho.Messages
{
    public class SpecialJobChangedMessage
    {
        public ObjectChangeType ChangeType { get; set; }

        public string SpecialJobId { get; set; }
        public string SpecialJobKey { get; set; }
    }
}
