﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AMAT.R2R.Client.Common.Enums;

namespace AMAT.R2R.Client.Litho.Messages
{
    public class ContextChangedMessage
    {
        public ObjectChangeType ChangeType { get; set; }

        public int ContextId { get; set; }
        public string ContextKey { get; set; }
    }
}
