﻿using System.Collections.Generic;
using System.Threading.Tasks;
using AMAT.R2R.Client.Common.Services;
using AMAT.R2R.Client.Litho.Modules.MaterialSettings;
using AMAT.R2R.Shared.Litho.DTO;

namespace AMAT.R2R.Client.Litho.Services
{
    public interface IMaterialService
    {
        #region Filter
        Task<List<MaterialModel>> GetMaterialListAsync(IList<QueryFilter> filters, IList<QuerySorter> sorters, int? skip, int? take);
        Task<int> GetMaterialCount(List<QueryFilter> filters);
        Task<object[]> GetMaterialValueListAsync(string propertyName, List<QueryFilter> list);
        #endregion

        #region CURD
        Task<List<RunHist>> GetMaterialRunHistoryListAsync(string materialKey);

        MaterialModel GetMaterial(string materialKey);
        Task<MaterialModel> GetMaterialAsync(string materialKey);

        List<MaterialModel> GetMaterialList(string fab);
        Task<List<MaterialModel>> GetMaterialListAsync(params QueryFilter[] parameters);

        void ModifyMaterial(string materialKey, Material material, string comment);
        Task ModifyMaterialAsync(string materialKey, Material material, string comment);

        void DeleteMaterial(string materialKey, string comment);
        Task DeleteMaterialAsync(string materialKey, string comment);

        Material CreateMaterial(Material material, string comment);
        Task<Material> CreateMaterialAsync(Material material, string comment);

        string GetResetCD(string contextKey);
        Task<string> GetResetCDAsync(string contextKey);

        string GetResetOVL(string contextKey);
        Task<string> GetResetOVLAsync(string contextKey);

        void ResetCD(string contextKey, Material material, string comment);
        Task ResetCDAsync(string contextKey, Material material, string comment);

        void ResetOVL(string contextKey, Material material, string comment);
        Task ResetOVLAsync(string contextKey, Material material, string comment);

        void UpdateControlFlag(string contextKey, Material material, string comment);
        Task UpdateControlFlagAsync(string contextKey, Material material, string comment);
        #endregion
    }
}
