﻿using System.Collections.Generic;
using System.Threading.Tasks;
using AMAT.R2R.Client.Common.Services;
using AMAT.R2R.Client.Litho.Modules.ContextSettings;
using AMAT.R2R.Shared.Litho.DTO;

namespace AMAT.R2R.Client.Litho.Services
{
    public interface IContextService
    {
        #region Filter
        Task<List<ContextModel>> GetContextListAsync(bool getSpecFlag, IList<QueryFilter> filters, IList<QuerySorter> sorters, int? skip, int? take);
        Task<int> GetContextCount(List<QueryFilter> filters);
        Task<object[]> GetContextValueListAsync(string propertyName, List<QueryFilter> filters);
        #endregion

        #region Import/Export
        Task<XMLStructure> CreateImportVerifyAsync(XMLStructure importEntity, string comment);
        Task<XMLStructure> CreateImportByXmlAsync(XMLStructure importEntity, bool updateExistFlag, string comment);
        Task UpdateImportByXmlAsync(XMLStructure importEntity, bool updateExistFlag, string comment);

        //Task<XMLStructure> GetExportConfig(List<QueryFilter> filters);
        Task<XMLStructure> GetExportConfig(string fab, string tool, string product, string layer);
        #endregion

        #region CURN
        string GetControlModelName(string OVLModelName);
        Task<string> GetControlModelNameAsync(string OVLModelName);

        List<string> GetOVLModelNameList(string tool);
        Task<List<string>> GetOVLModelNameListAsync(string tool);

        List<string> GetControlFlagList();
        Task<List<string>> GetControlFlagListAsync();

        void ModifyContext(string contextKey, Context context, string comment);
        Task ModifyContextAsync(string contextKey, Context context, string comment);

        void DeleteContext(string contextKey, string comment);
        Task DeleteContextAsync(string contextKey, string comment);

        Context CreateContext(Context contextKey, string comment);
        Task<Context> CreateContextAsync(Context newContext, string comment);

        Context CreateContextAndSpec(Context contextKey, string copySpecContextKey, string comment);
        Task<Context> CreateContextAndSpecAsync(Context newContext, string copySpecContextKey, string comment);

        ContextModel GetContextInfo(string fab, string tool, string product, string layer, string reticle, string recipe, string preTool, string preReticle);

        Task<ContextModel> GetContextInfoAsync(string fab, string tool, string product, string layer, string reticle, string recipe, string preTool, string preReticle);
        
        DCDControlSetting GetDCDContextInfo(string fab, string tool, string product, string layer, string reticle, string recipe);
        Task<DCDControlSetting> GetDCDContextInfoAsync(string fab, string tool, string product, string layer, string reticle, string recipe);
        OVLControlSetting GetOVLContextInfo(string fab, string tool, string product, string layer, string reticle, string recipe, string preTool, string preReticle);
        Task<OVLControlSetting> GetOVLContextInfoAsync(string fab, string tool, string product, string layer, string reticle, string recipe, string preTool, string preReticle);

        ContextModel GetContext(string contextKey);
        Task<ContextModel> GetContextAsync(string contextKey);

        IEnumerable<ContextModel> GetContextList(string fab);
        Task<List<ContextModel>> GetContextListAsync(params QueryFilter[] parameters);

        List<Specs> GetContextSpecList(string contextKey);
        Task<List<Specs>> GetContextSpecListAsync(string contextKey);

        void ModifyContextSpec(SpecSetting specSetting, string comment);
        Task ModifyContextSpecAsync(SpecSetting specSetting, string comment);
        #endregion
    }
}
