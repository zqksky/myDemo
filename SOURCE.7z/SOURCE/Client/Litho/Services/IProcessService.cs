﻿using System.Collections.Generic;
using System.Threading.Tasks;
using AMAT.R2R.Client.Common.Services;
using AMAT.R2R.Client.Litho.Modules.ProcessSettings;
using AMAT.R2R.Shared.Litho.DTO;

namespace AMAT.R2R.Client.Litho.Services
{
    public interface IProcessService
    {
        #region Filter
        Task<List<ProcessModel>> GetProcessListAsync(IList<QueryFilter> filters, IList<QuerySorter> sorters, int? skip, int? take);
        Task<int> GetProcessCount(List<QueryFilter> filters);
        Task<object[]> GetProcessValueListAsync(string propertyName, List<QueryFilter> filters);
        #endregion

        #region CURD
        ProcessModel GetProcess(string processKey);
        Task<ProcessModel> GetProcessAsync(string processKey);
        List<ProcessModel> GetProcessList(string fab);
        Task<List<ProcessModel>> GetProcessListAsync(string fab);

        void ModifyProcess(string processKey, Process process, string comment);
        Task ModifyProcessAsync(string processKey, Process process, string comment);

        void DeleteProcess(string processKey, string comment);
        Task DeleteProcessAsync(string processKey, string comment);

        Process CreateProcess(Process process, string comment);
        Task<Process> CreateProcessAsync(Process process, string comment);
        #endregion
    }
}
