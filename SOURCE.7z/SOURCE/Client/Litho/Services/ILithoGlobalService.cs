﻿using System.Collections.Generic;
using System.Threading.Tasks;
using AMAT.R2R.Client.Common.Services;
using AMAT.R2R.Client.Litho.Modules.LithoConfig;
using AMAT.R2R.Client.Litho.Modules.ProductSettings;
using AMAT.R2R.Client.Litho.Modules.ToolSettings;
using AMAT.R2R.Client.Litho.Modules.ToolStatusSettings;
using AMAT.R2R.Shared.Litho.DTO;

namespace AMAT.R2R.Client.Litho.Services
{
    public interface ILithoGlobalService
    {
        #region Tool Filter
        Task<List<ToolEntityModel>> GetToolListAsync(IList<QueryFilter> filters, IList<QuerySorter> sorters, int? skip, int? take);
        Task<int> GetToolCount(List<QueryFilter> filters);
        Task<object[]> GetToolValueListAsync(string propertyName, List<QueryFilter> filters);
        #endregion

        #region Product Filter
        Task<List<ProductEntityModel>> GetProductListAsync(IList<QueryFilter> filters, IList<QuerySorter> sorters, int? skip, int? take);
        Task<int> GetProductCount(List<QueryFilter> filters);
        Task<object[]> GetProductValueListAsync(string propertyName, List<QueryFilter> filters);
        #endregion

        #region LotType/ToolId/ProductId/LayerId List
        List<string> GetLotTypeList();
        Task<List<string>> GetLotTypeListAsync();

        List<string> GetToolIdList();
        Task<List<string>> GetToolIdListAsync();

        List<string> GetProductIdList();
        Task<List<string>> GetProductIdListAsync();

        List<string> GetLayerIdList(string productId);
        Task<List<string>> GetLayerIdListAsync(string productId);

        #endregion

        #region MESNonSkipLotMode
        string GetMESNonSkipLotMode();
        Task<string> GetMESNonSkipLotModeAsync();

        List<string> GetMESNonSkipLotModeList();
        Task<List<string>> GetMESNonSkipLotModeListAsync();
        Task ModifyMESNonSkipLotModeAsync(string strMESNonSkipLotMode, string comment);
        #endregion

        #region Tool
        void ModifyTool(string toolId, Tool tool, string comment);
        Task ModifyToolAsync(string toolId, Tool tool, string comment);

        void DeleteTool(string toolId, string comment);
        Task DeleteToolAsync(string toolId, string comment);

        Tool CreateTool(Tool tool, string comment);
        Task<Tool> CreateToolAsync(Tool newTool, string comment);

        ToolEntityModel GetTool(string toolId);
        Task<ToolEntityModel> GetToolAsync(string toolId);

        IEnumerable<ToolEntityModel> GetToolList(string fab);
        Task<List<ToolEntityModel>> GetToolListAsync();
        Task<List<ToolEntityModel>> GetToolListAsync(params QueryFilter[] parameters);
        #endregion

        #region ToolStatus
        RecToolStatusValues GetToolStatus(string toolId);
        Task<RecToolStatusValues> GetToolStatusAsync(string toolId);

        void ModifyToolStatus(string toolId, RecToolStatusValues toolStatus, string comment);
        Task ModifyToolStatusAsync(string toolId, RecToolStatusValues toolStatus, string comment);
        #endregion

        #region Product
        void ModifyProduct(string ProductId, Product product, string comment);
        Task ModifyProductAsync(string ProductId, Product product, string comment);

        void DeleteProduct(string ProductId, string comment);
        Task DeleteProductAsync(string ProductId, string comment);

        Product CreateProduct(Product product, string comment);
        Task<Product> CreateProductAsync(Product newProduct, string comment);

        ProductEntityModel GetProduct(string ProductId);
        Task<ProductEntityModel> GetProductAsync(string ProductId);

        IEnumerable<ProductEntityModel> GetProductList(string fab);
        Task<List<ProductEntityModel>> GetProductListAsync();
        Task<List<ProductEntityModel>> GetProductListAsync(params QueryFilter[] parameters);
        #endregion

        #region Feedback Exclusion
        void ModifyFBExclusionConfig(string key, FBExclusionConfig fbExclusionConfig, string comment);
        Task ModifyFBExclusionConfigAsync(string key, FBExclusionConfig fbExclusionConfig, string comment);

        void DeleteFBExclusionConfig(string key, string comment);
        Task DeleteFBExclusionConfigAsync(string key, string comment);
        Task DeleteFBExclusionConfigAsync(FBExclusionConfig FBExclusion, string comment);

        FBExclusionConfig CreateFBExclusionConfig(FBExclusionConfig fbExclusionConfig, string comment);
        Task<FBExclusionConfig> CreateFBExclusionConfigAsync(FBExclusionConfig newFBExclusionConfig, string comment);

        FBExclusionConfigModel GetFBExclusionConfig(string key);
        Task<FBExclusionConfigModel> GetFBExclusionConfigAsync(string key);

        IEnumerable<FBExclusionConfigModel> GetFBExclusionConfigList(string fab);
        Task<List<FBExclusionConfigModel>> GetFBExclusionConfigListAsync();
        Task<List<FBExclusionConfigModel>> GetFBExclusionConfigListAsync(params QueryFilter[] parameters);
        #endregion

        #region FEM
        void ModifyFEM(string key, ADVConfig fem, string comment);
        Task ModifyFEMAsync(string key, ADVConfig fem, string comment);

        void DeleteFEM(string key, string comment);
        Task DeleteFEMAsync(string key, string comment);

        ADVConfig CreateFEM(ADVConfig fem, string comment);
        Task<ADVConfig> CreateFEMAsync(ADVConfig newFEM, string comment);

        FEMEntityModel GetFEM(string key);
        Task<FEMEntityModel> GetFEMAsync(string key);

        IEnumerable<FEMEntityModel> GetFEMList(string fab);
        Task<List<FEMEntityModel>> GetFEMListAsync();
        Task<List<FEMEntityModel>> GetFEMListAsync(params QueryFilter[] parameters);
        #endregion
    }
}
