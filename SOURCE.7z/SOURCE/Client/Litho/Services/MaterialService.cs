﻿using System;
using System.Collections.Generic;
using System.Reflection;
using System.Threading.Tasks;
using AMAT.R2R.Client.Common.Helpers;
using AMAT.R2R.Client.Common.Services;
using AMAT.R2R.Client.Litho.Modules.MaterialSettings;
using AMAT.R2R.Shared.Litho.DTO;

namespace AMAT.R2R.Client.Litho.Services
{
    public class MaterialService : IMaterialService
    {
        const string MaterialEndpoint = "material";
        const string ResetCDEndpoint = "resetCD";
        const string ResetOVLEndpoint = "resetOVL";
        const string RunHistoryEndpoint = "run";
        const string ControlEndpoint = "control";

        #region Filter
        public async Task<List<MaterialModel>> GetMaterialListAsync(IList<QueryFilter> filters, IList<QuerySorter> sorters, int? skip, int? take)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid);
            try
            {
                return await Api.Current.GetListAsync<MaterialModel>(MaterialEndpoint, filters, sorters, skip, take);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }
        }
        public async Task<int> GetMaterialCount(List<QueryFilter> filters)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid);
            try
            {
                return await Api.Current.GetTotalCountAsync(MaterialEndpoint, filters);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }
        }
        public async Task<object[]> GetMaterialValueListAsync(string propertyName, List<QueryFilter> filters)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid);
            try
            {
                return await Api.Current.GetValueListAsync(MaterialEndpoint, propertyName, filters);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }
        }
        #endregion

        #region CURD
        public async Task<List<RunHist>> GetMaterialRunHistoryListAsync(string materialKey)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid); try
            {
                return await Api.Current.GetListAsync<RunHist>($"{MaterialEndpoint}/{materialKey}/{RunHistoryEndpoint}");
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }

        }
        public List<MaterialModel> GetMaterialList(string fab)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid); try
            {
                return Api.Current.GetList<MaterialModel>(MaterialEndpoint, new QueryFilter("fab", fab));
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }

        }

        public async Task<List<MaterialModel>> GetMaterialListAsync(params QueryFilter[] parameters)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid); try
            {
                return await Api.Current.GetListAsync<MaterialModel>($"{MaterialEndpoint}", parameters);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }

        }

        public MaterialModel GetMaterial(string materialKey)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid); try
            {
                return Api.Current.GetSingle<MaterialModel>($"{MaterialEndpoint}/{materialKey}");
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }

        }
        public async Task<MaterialModel> GetMaterialAsync(string materialKey)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid); try
            {
                return await Api.Current.GetSingleAsync<MaterialModel>($"{MaterialEndpoint}/{materialKey}");
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }

        }

        public Material CreateMaterial(Material material, string comment)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid); try
            {
                return Api.Current.PostNew(MaterialEndpoint, material, comment);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }

        }
        public async Task<Material> CreateMaterialAsync(Material material, string comment)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid); try
            {
                return await Api.Current.PostNewAsync(MaterialEndpoint, material, comment);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }

        }

        public void DeleteMaterial(string materialKey, string comment)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid); try
            {
                Api.Current.Delete($"{MaterialEndpoint}/{materialKey}", comment);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }

        }
        public async Task DeleteMaterialAsync(string materialKey, string comment)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid); try
            {
                await Api.Current.DeleteAsync($"{MaterialEndpoint}/{materialKey}", comment);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }

        }

        public void ModifyMaterial(string materialKey, Material material, string comment)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid); try
            {
                Api.Current.PutUpdate($"{MaterialEndpoint}/{materialKey}", material, comment);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }

        }
        public async Task ModifyMaterialAsync(string materialKey, Material material, string comment)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid); try
            {
                await Api.Current.PutUpdateAsync($"{MaterialEndpoint}/{materialKey}", material, comment);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }

        }

        public string GetResetCD(string contextKey)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid); try
            {
                return Api.Current.GetSingle<string>($"{MaterialEndpoint}/{ResetCDEndpoint}/{contextKey}");
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }

        }
        public async Task<string> GetResetCDAsync(string contextKey)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid); try
            {
                return await Api.Current.GetSingleAsync<string>($"{MaterialEndpoint}/{ResetCDEndpoint}/{contextKey}");
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }

        }

        public string GetResetOVL(string contextKey)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid); try
            {
                return Api.Current.GetSingle<string>($"{MaterialEndpoint}/{ResetOVLEndpoint}/{contextKey}");
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }

        }
        public async Task<string> GetResetOVLAsync(string contextKey)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid); try
            {
                return await Api.Current.GetSingleAsync<string>($"{ MaterialEndpoint}/{ ResetOVLEndpoint}/{ contextKey}");
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }

        }

        public void ResetCD(string contextKey, Material material, string comment)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid); try
            {
                Api.Current.PutUpdate($"{MaterialEndpoint}/{ResetCDEndpoint}/{contextKey}", material, comment);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }

        }
        public async Task ResetCDAsync(string contextKey, Material material, string comment)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid); try
            {
                await Api.Current.PutUpdateAsync($"{MaterialEndpoint}/{ResetCDEndpoint}/{contextKey}", material, comment);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }

        }

        public void ResetOVL(string contextKey, Material material, string comment)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid); try
            {
                Api.Current.PutUpdate($"{MaterialEndpoint}/{ ResetOVLEndpoint}/{contextKey}", material, comment);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }

        }
        public async Task ResetOVLAsync(string contextKey, Material material, string comment)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid); try
            {
                await Api.Current.PutUpdateAsync($"{MaterialEndpoint}/{ ResetOVLEndpoint}/{contextKey}", material, comment);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }

        }

        public void UpdateControlFlag(string materialKey, Material material, string comment)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid); try
            {
                Api.Current.PutUpdate($"{MaterialEndpoint}/{ ControlEndpoint}/{materialKey}", material, comment);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }

        }
        public async Task UpdateControlFlagAsync(string materialKey, Material material, string comment)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid); try
            {
                await Api.Current.PutUpdateAsync($"{MaterialEndpoint}/{ ControlEndpoint}/{materialKey}", material, comment);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }
        }
        #endregion
    }
}
