﻿using System;
using System.Collections.Generic;
using System.Reflection;
using System.Threading.Tasks;
using AMAT.R2R.Client.Common.Extensions;
using AMAT.R2R.Client.Common.Helpers;
using AMAT.R2R.Client.Common.Services;
using AMAT.R2R.Client.Litho.Modules.LithoConfig;
using AMAT.R2R.Client.Litho.Modules.ProductSettings;
using AMAT.R2R.Client.Litho.Modules.ToolSettings;
using AMAT.R2R.Client.Litho.Modules.ToolStatusSettings;
using AMAT.R2R.Shared.Litho.DTO;

namespace AMAT.R2R.Client.Litho.Services
{
    public class LithoGlobalService : ILithoGlobalService
    {
        const string LithoGlobalEndpoint = "LithoGlobal";
        const string ToolEndpoint = "tool";
        const string ProductEndpoint = "product";
        const string FBExclusionConfigEndpoint = "fbExclusionConfig";
        const string FEMEndpoint = "FEM";
        const string MESNonSkipLotModeEndpoint = "mesNonSkipLotMode";
        const string MESNonSkipLotModeListEndpoint = "mesNonSkipLotModeList";
        const string LotTypeEndpoint = "lotType";
        const string ToolIdEndpoint = "toolId";
        const string ProductIdEndpoint = "productId";
        const string LayerIdEndpoint = "layerId";
        const string ToolFilterEndpoint = "toolFilter";
        const string ProductFilterEndpoint = "productFilter";
        const string ToolStatusEndpoint = "toolStatus";

        #region Tool Filter
        public async Task<List<ToolEntityModel>> GetToolListAsync(IList<QueryFilter> filters, IList<QuerySorter> sorters, int? skip, int? take)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid);
            try
            {
                return await Api.Current.GetListAsync<ToolEntityModel>($"{LithoGlobalEndpoint}/{ToolEndpoint}", filters, sorters, skip, take);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }
        }
        public async Task<int> GetToolCount(List<QueryFilter> filters)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid);
            try
            {
                return await Api.Current.GetTotalCountAsync($"{LithoGlobalEndpoint}/{ToolEndpoint}/{ToolFilterEndpoint}", filters);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }
        }
        public async Task<object[]> GetToolValueListAsync(string propertyName, List<QueryFilter> filters)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid);
            try
            {
                return await Api.Current.GetValueListAsync($"{LithoGlobalEndpoint}/{ToolEndpoint}/{ToolFilterEndpoint}", propertyName, filters);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }
        }
        #endregion

        #region Product Filter
        public async Task<List<ProductEntityModel>> GetProductListAsync(IList<QueryFilter> filters, IList<QuerySorter> sorters, int? skip, int? take)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid);
            try
            {
                return await Api.Current.GetListAsync<ProductEntityModel>($"{LithoGlobalEndpoint}/{ProductEndpoint}", filters, sorters, skip, take);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }
        }
        public async Task<int> GetProductCount(List<QueryFilter> filters)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid);
            try
            {
                return await Api.Current.GetTotalCountAsync($"{LithoGlobalEndpoint}/{ProductEndpoint}/{ProductFilterEndpoint}", filters);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }
        }
        public async Task<object[]> GetProductValueListAsync(string propertyName, List<QueryFilter> filters)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid);
            try
            {
                return await Api.Current.GetValueListAsync($"{LithoGlobalEndpoint}/{ProductFilterEndpoint}/{ProductFilterEndpoint}", propertyName, filters);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }
        }
        #endregion

        #region LotType/ToolId/ProductId/LayerId List
        public List<string> GetLotTypeList()
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid); try
            {
                return Api.Current.GetList<string>($"{LithoGlobalEndpoint}/{LotTypeEndpoint}");
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }

        }
        public async Task<List<string>> GetLotTypeListAsync()
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid); try
            {
                return await Api.Current.GetListAsync<string>($"{LithoGlobalEndpoint}/{LotTypeEndpoint}");
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }

        }

        public List<string> GetToolIdList()
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid); try
            {
                return Api.Current.GetList<string>($"{LithoGlobalEndpoint}/{ToolIdEndpoint}");
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }

        }
        public async Task<List<string>> GetToolIdListAsync()
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid); try
            {
                return await Api.Current.GetListAsync<string>($"{LithoGlobalEndpoint}/{ToolIdEndpoint}");
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }

        }

        public List<string> GetProductIdList()
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid); try
            {
                return Api.Current.GetList<string>($"{LithoGlobalEndpoint}/{ProductIdEndpoint}");
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }

        }
        public async Task<List<string>> GetProductIdListAsync()
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid); try
            {
                return await Api.Current.GetListAsync<string>($"{LithoGlobalEndpoint}/{ProductIdEndpoint}");
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }

        }

        public List<string> GetLayerIdList(string productId)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid); try
            {
                return Api.Current.GetList<string>($"{LithoGlobalEndpoint}/{LayerIdEndpoint}/{productId}");
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }

        }
        public async Task<List<string>> GetLayerIdListAsync(string productId)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid); try
            {
                return await Api.Current.GetListAsync<string>($"{LithoGlobalEndpoint}/{LayerIdEndpoint}/{productId}");
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }

        }
        #endregion

        #region MESNonSkipLotMode
        public string GetMESNonSkipLotMode()
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid); try
            {
                return Api.Current.GetSingle<string>($"{LithoGlobalEndpoint}/{MESNonSkipLotModeEndpoint}");
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }

        }
        public async Task<string> GetMESNonSkipLotModeAsync()
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid); try
            {
                return await Api.Current.GetSingleAsync<string>($"{LithoGlobalEndpoint}/{MESNonSkipLotModeEndpoint}");
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }

        }

        public List<string> GetMESNonSkipLotModeList()
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid); try
            {
                return Api.Current.GetList<string>($"{LithoGlobalEndpoint}/{MESNonSkipLotModeListEndpoint}");
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }

        }
        public async Task<List<string>> GetMESNonSkipLotModeListAsync()
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid); try
            {
                return await Api.Current.GetListAsync<string>($"{LithoGlobalEndpoint}/{MESNonSkipLotModeListEndpoint}");
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }

        }
        public async Task ModifyMESNonSkipLotModeAsync(string strMESNonSkipLotMode, string comment)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid); try
            {
                await Api.Current.PutUpdateAsync($"{LithoGlobalEndpoint}/{MESNonSkipLotModeEndpoint}/{strMESNonSkipLotMode}", strMESNonSkipLotMode, comment);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }

        }
        #endregion

        #region Tool
        public IEnumerable<ToolEntityModel> GetToolList(string fab)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid); try
            {
                return Api.Current.GetList<ToolEntityModel>($"{LithoGlobalEndpoint}/{ToolEndpoint}",
                new QueryFilter("fab", fab));
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }

        }
        public async Task<List<ToolEntityModel>> GetToolListAsync()
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid); try
            {
                return await Api.Current.GetListAsync<ToolEntityModel>($"{LithoGlobalEndpoint}/{ToolEndpoint}");
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }

        }
        public async Task<List<ToolEntityModel>> GetToolListAsync(params QueryFilter[] parameters)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid); try
            {
                return await Api.Current.GetListAsync<ToolEntityModel>($"{LithoGlobalEndpoint}/{ToolEndpoint}", parameters);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }

        }

        public ToolEntityModel GetTool(string ToolKey)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid); try
            {
                return Api.Current.GetSingle<ToolEntityModel>($"{LithoGlobalEndpoint}/{ToolEndpoint}/{ToolKey}");
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }

        }
        public async Task<ToolEntityModel> GetToolAsync(string ToolKey)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid); try
            {
                return await Api.Current.GetSingleAsync<ToolEntityModel>($"{LithoGlobalEndpoint}/{ToolEndpoint}/{ToolKey}");
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }

        }

        public Tool CreateTool(Tool tool, string comment)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid); try
            {
                return Api.Current.PostNew($"{LithoGlobalEndpoint}/{ToolEndpoint}", tool, comment);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }

        }
        public async Task<Tool> CreateToolAsync(Tool newTool, string comment)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid); try
            {
                return await Api.Current.PostNewAsync($"{LithoGlobalEndpoint}/{ToolEndpoint}", newTool, comment);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }

        }


        public void DeleteTool(string ToolKey, string comment)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid); try
            {
                Api.Current.Delete($"{LithoGlobalEndpoint}/{ToolEndpoint}/{ToolKey}", comment);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }

        }
        public async Task DeleteToolAsync(string ToolKey, string comment)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid); try
            {
                await Api.Current.DeleteAsync($"{LithoGlobalEndpoint}/{ToolEndpoint}/{ToolKey.EscapeUrlChar()}", comment);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }

        }

        public void ModifyTool(string ToolKey, Tool tool, string comment)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid); try
            {
                Api.Current.PutUpdate($"{LithoGlobalEndpoint}/{ToolEndpoint}/{ToolKey}", tool, comment);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }

        }
        public async Task ModifyToolAsync(string ToolKey, Tool tool, string comment)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid); try
            {
                await Api.Current.PutUpdateAsync($"{LithoGlobalEndpoint}/{ToolEndpoint}/{ToolKey}", tool, comment);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }

        }
        #endregion

        #region ToolStatus
        public RecToolStatusValues GetToolStatus(string ToolKey)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid); try
            {
                return Api.Current.GetSingle<RecToolStatusValues>($"{LithoGlobalEndpoint}/{ToolStatusEndpoint}/{ToolKey}");
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }

        }
        public async Task<RecToolStatusValues> GetToolStatusAsync(string ToolKey)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid); try
            {
                return await Api.Current.GetSingleAsync<RecToolStatusValues>($"{LithoGlobalEndpoint}/{ToolStatusEndpoint}/{ToolKey}");
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }

        }

        public void ModifyToolStatus(string ToolKey, RecToolStatusValues tool, string comment)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid); try
            {
                Api.Current.PutUpdate($"{LithoGlobalEndpoint}/{ToolStatusEndpoint}/{ToolKey}", tool, comment);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }

        }
        public async Task ModifyToolStatusAsync(string ToolKey, RecToolStatusValues tool, string comment)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid); try
            {
                await Api.Current.PutUpdateAsync($"{LithoGlobalEndpoint}/{ToolStatusEndpoint}/{ToolKey}", tool, comment);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }

        }
        #endregion

        #region Product
        public IEnumerable<ProductEntityModel> GetProductList(string fab)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid); try
            {
                return Api.Current.GetList<ProductEntityModel>($"{LithoGlobalEndpoint}/{ProductEndpoint}",
                new QueryFilter("fab", fab));
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }

        }
        public async Task<List<ProductEntityModel>> GetProductListAsync()
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid); try
            {
                return await Api.Current.GetListAsync<ProductEntityModel>($"{LithoGlobalEndpoint}/{ProductEndpoint}");
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }

        }
        public async Task<List<ProductEntityModel>> GetProductListAsync(params QueryFilter[] parameters)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid); try
            {
                return await Api.Current.GetListAsync<ProductEntityModel>($"{LithoGlobalEndpoint}/{ProductEndpoint}", parameters);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }

        }

        public ProductEntityModel GetProduct(string ProductKey)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid); try
            {
                return Api.Current.GetSingle<ProductEntityModel>($"{LithoGlobalEndpoint}/{ProductEndpoint}/{ProductKey}");
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }

        }
        public async Task<ProductEntityModel> GetProductAsync(string ProductKey)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid); try
            {
                return await Api.Current.GetSingleAsync<ProductEntityModel>($"{LithoGlobalEndpoint}/{ProductEndpoint}/{ProductKey}");
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }

        }

        public Product CreateProduct(Product Product, string comment)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid); try
            {
                return Api.Current.PostNew($"{LithoGlobalEndpoint}/{ProductEndpoint}", Product, comment);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }

        }
        public async Task<Product> CreateProductAsync(Product newProduct, string comment)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid); try
            {
                return await Api.Current.PostNewAsync($"{LithoGlobalEndpoint}/{ProductEndpoint}", newProduct, comment);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }

        }


        public void DeleteProduct(string ProductKey, string comment)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid); try
            {
                Api.Current.Delete($"{LithoGlobalEndpoint}/{ProductEndpoint}/{ProductKey}", comment);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }

        }
        public async Task DeleteProductAsync(string ProductKey, string comment)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid); try
            {
                await Api.Current.DeleteAsync($"{LithoGlobalEndpoint}/{ProductEndpoint}/{ProductKey}", comment);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }

        }

        public void ModifyProduct(string ProductKey, Product Product, string comment)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid); try
            {
                Api.Current.PutUpdate($"{LithoGlobalEndpoint}/{ProductEndpoint}/{ProductKey}", Product, comment);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }

        }
        public async Task ModifyProductAsync(string ProductKey, Product Product, string comment)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid); try
            {
                await Api.Current.PutUpdateAsync($"{LithoGlobalEndpoint}/{ProductEndpoint}/{ProductKey}", Product, comment);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }

        }
        #endregion

        #region Feedback Exclusion

        public IEnumerable<FBExclusionConfigModel> GetFBExclusionConfigList(string fab)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid); try
            {
                return Api.Current.GetList<FBExclusionConfigModel>($"{LithoGlobalEndpoint}/{FBExclusionConfigEndpoint}",
                new QueryFilter("fab", fab));
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }

        }
        public async Task<List<FBExclusionConfigModel>> GetFBExclusionConfigListAsync()
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid); try
            {
                return await Api.Current.GetListAsync<FBExclusionConfigModel>($"{LithoGlobalEndpoint}/{FBExclusionConfigEndpoint}");
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }

        }
        public async Task<List<FBExclusionConfigModel>> GetFBExclusionConfigListAsync(params QueryFilter[] parameters)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid); try
            {
                return await Api.Current.GetListAsync<FBExclusionConfigModel>($"{LithoGlobalEndpoint}/{FBExclusionConfigEndpoint}", parameters);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }

        }

        public FBExclusionConfigModel GetFBExclusionConfig(string key)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid); try
            {
                return Api.Current.GetSingle<FBExclusionConfigModel>($"{LithoGlobalEndpoint}/{FBExclusionConfigEndpoint}/{key}");
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }

        }
        public async Task<FBExclusionConfigModel> GetFBExclusionConfigAsync()
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid); try
            {
                return await Api.Current.GetSingleAsync<FBExclusionConfigModel>($"{LithoGlobalEndpoint}/{FBExclusionConfigEndpoint}");
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }

        }
        public async Task<FBExclusionConfigModel> GetFBExclusionConfigAsync(string key)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid); try
            {
                return await Api.Current.GetSingleAsync<FBExclusionConfigModel>($"{LithoGlobalEndpoint}/{FBExclusionConfigEndpoint}/{key}");
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }

        }

        public FBExclusionConfig CreateFBExclusionConfig(FBExclusionConfig fbExclusionConfig, string comment)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid); try
            {
                return Api.Current.PostNew($"{LithoGlobalEndpoint}/{FBExclusionConfigEndpoint}", fbExclusionConfig, comment);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }

        }
        public async Task<FBExclusionConfig> CreateFBExclusionConfigAsync(FBExclusionConfig newFBExclusionConfig, string comment)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid); try
            {
                return await Api.Current.PostNewAsync($"{LithoGlobalEndpoint}/{FBExclusionConfigEndpoint}", newFBExclusionConfig, comment);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }

        }


        public void DeleteFBExclusionConfig(string key, string comment)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid); try
            {
                Api.Current.Delete($"{LithoGlobalEndpoint}/{FBExclusionConfigEndpoint}/{key}", comment);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }

        }
        public async Task DeleteFBExclusionConfigAsync(string key, string comment)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid); try
            {
                await Api.Current.DeleteAsync($"{LithoGlobalEndpoint}/{FBExclusionConfigEndpoint}/{key}", comment);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }

        }
        public async Task DeleteFBExclusionConfigAsync(FBExclusionConfig FBExclusion, string comment)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid); try
            {
                await Api.Current.DeleteEntityAsync($"{LithoGlobalEndpoint}/{FBExclusionConfigEndpoint}", FBExclusion, comment);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }

        }

        public void ModifyFBExclusionConfig(string key, FBExclusionConfig fbExclusionConfig, string comment)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid); try
            {
                Api.Current.PutUpdate($"{LithoGlobalEndpoint}/{FBExclusionConfigEndpoint}/{key}", fbExclusionConfig, comment);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }

        }
        public async Task ModifyFBExclusionConfigAsync(string key, FBExclusionConfig fbExclusionConfig, string comment)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid); try
            {
                await Api.Current.PutUpdateAsync($"{LithoGlobalEndpoint}/{FBExclusionConfigEndpoint}/{key}", fbExclusionConfig, comment);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }

        }
        #endregion

        #region FEM
        public IEnumerable<FEMEntityModel> GetFEMList(string fab)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid); try
            {
                return Api.Current.GetList<FEMEntityModel>($"{LithoGlobalEndpoint}/{FEMEndpoint}",
                new QueryFilter("fab", fab));
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }

        }
        public async Task<List<FEMEntityModel>> GetFEMListAsync()
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid); try
            {
                return await Api.Current.GetListAsync<FEMEntityModel>($"{LithoGlobalEndpoint}/{FEMEndpoint}");
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }

        }
        public async Task<List<FEMEntityModel>> GetFEMListAsync(params QueryFilter[] parameters)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid); try
            {
                return await Api.Current.GetListAsync<FEMEntityModel>($"{LithoGlobalEndpoint}/{FEMEndpoint}", parameters);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }

        }

        public FEMEntityModel GetFEM(string FEMKey)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid); try
            {
                return Api.Current.GetSingle<FEMEntityModel>($"{LithoGlobalEndpoint}/{FEMEndpoint}/{FEMKey}");
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }

        }
        public async Task<FEMEntityModel> GetFEMAsync(string FEMKey)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid); try
            {
                return await Api.Current.GetSingleAsync<FEMEntityModel>($"{LithoGlobalEndpoint}/{FEMEndpoint}/{FEMKey}");
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }

        }

        public ADVConfig CreateFEM(ADVConfig FEM, string comment)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid); try
            {
                return Api.Current.PostNew($"{LithoGlobalEndpoint}/{FEMEndpoint}", FEM, comment);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }

        }
        public async Task<ADVConfig> CreateFEMAsync(ADVConfig newFEM, string comment)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid); try
            {
                return await Api.Current.PostNewAsync($"{LithoGlobalEndpoint}/{FEMEndpoint}", newFEM, comment);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }

        }


        public void DeleteFEM(string FEMKey, string comment)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid); try
            {
                Api.Current.Delete($"{LithoGlobalEndpoint}/{FEMEndpoint}/{FEMKey}", comment);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }

        }
        public async Task DeleteFEMAsync(string FEMKey, string comment)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid); try
            {
                await Api.Current.DeleteAsync($"{LithoGlobalEndpoint}/{FEMEndpoint}/{FEMKey}", comment);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }

        }

        public void ModifyFEM(string FEMKey, ADVConfig fem, string comment)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid); try
            {
                Api.Current.PutUpdate($"{LithoGlobalEndpoint}/{FEMEndpoint}/{FEMKey}", fem, comment);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }

        }
        public async Task ModifyFEMAsync(string FEMKey, ADVConfig fem, string comment)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid); try
            {
                await Api.Current.PutUpdateAsync($"{LithoGlobalEndpoint}/{FEMEndpoint}/{FEMKey}", fem, comment);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }

        }
        #endregion
    }
}
