﻿using System;
using System.Collections.Generic;
using System.Reflection;
using System.Threading.Tasks;
using AMAT.R2R.Client.Common.Helpers;
using AMAT.R2R.Client.Common.Services;
using AMAT.R2R.Client.Litho.Modules.ContextSettings;
using AMAT.R2R.Shared.Litho.DTO;

namespace AMAT.R2R.Client.Litho.Services
{
    public class ContextService : IContextService
    {
        const string ContextEndpoint = "Context";
        const string SpecEndpoint = "Spec";
        const string OVLModelNameEndpoint = "OVLModelName";
        const string ControlFlagEndpoint = "ControlFlag";
        const string ControlModelNameEndpoint = "ControlModelName";
        const string FabEndpoint = "fab";
        const string ToolEndpoint = "tool";
        const string ProductEndpoint = "product";
        const string LayerEndpoint = "layer";
        const string ReticleEndpoint = "reticle";
        const string RecipeEndpoint = "recipe";
        const string PreToolEndpoint = "preTool";
        const string PreReticleEndpoint = "preReticle";
        const string DCDContextInfoEndpoint = "cdContextInfo";
        const string OVLContextInfoEndpoint = "ovlContextInfo";
        const string ImportConfigInfoEndpoint = "importConfig";
        const string ExportConfigInfoEndpoint = "exportConfig";
        const string UpdateExistEndpoint = "updateExist";
        const string GetSpecEndpoint = "getSpec";

        #region Import/Export
        public async Task<XMLStructure> CreateImportVerifyAsync(XMLStructure importEntity, string comment)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid); try
            {

                return await Api.Current.PostNewAsync($"{ContextEndpoint}/{ImportConfigInfoEndpoint}", importEntity, comment);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }

        }
        public async Task<XMLStructure> CreateImportByXmlAsync(XMLStructure importEntity, bool updateExistFlag, string comment)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid); try
            {

                return await Api.Current.PostNewAsync($"{ContextEndpoint}/{ImportConfigInfoEndpoint}/{updateExistFlag}", importEntity, comment);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }

        }
        public async Task UpdateImportByXmlAsync(XMLStructure importEntity, bool updateExistFlag, string comment)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid); try
            {
                await Api.Current.PutUpdateAsync($"{ContextEndpoint}/{ImportConfigInfoEndpoint}/{updateExistFlag}", importEntity, comment);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }

        }

        public async Task<XMLStructure> GetExportConfig(string fab, string tool, string product, string layer)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid); try
            {
                return await Api.Current.GetSingleAsync<XMLStructure>($"{ContextEndpoint}/{ExportConfigInfoEndpoint}/{FabEndpoint}/{fab}/{ToolEndpoint}/{tool}/{ProductEndpoint}/{product}/{LayerEndpoint}/{layer}");
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }
        }
        #endregion

        #region Filter
        public async Task<List<ContextModel>> GetContextListAsync(bool getSpecFlag,IList<QueryFilter> filters, IList<QuerySorter> sorters, int? skip, int? take)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid);
            try
            {
                return await Api.Current.GetListAsync<ContextModel>($"{ContextEndpoint}/{GetSpecEndpoint}/{getSpecFlag}", filters, sorters, skip, take);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }
        }
        public async Task<int> GetContextCount(List<QueryFilter> filters)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid);
            try
            {
                return await Api.Current.GetTotalCountAsync(ContextEndpoint, filters);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }
        }
        public async Task<object[]> GetContextValueListAsync(string propertyName, List<QueryFilter> filters)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid);
            try
            {
                return await Api.Current.GetValueListAsync(ContextEndpoint, propertyName, filters);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }
        }
        #endregion

        #region CURD
        public string GetControlModelName(string OVLModelName)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid); try
            {
                return Api.Current.GetSingle<string>($"{ContextEndpoint}/{ControlModelNameEndpoint}/{OVLModelName}");
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }

        }
        public async Task<string> GetControlModelNameAsync(string OVLModelName)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid); try
            {
                return await Api.Current.GetSingleAsync<string>($"{ContextEndpoint}/{ControlModelNameEndpoint}/{OVLModelName}");
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }

        }

        public List<string> GetControlFlagList()
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid); try
            {
                return Api.Current.GetList<string>($"{ContextEndpoint}/{ControlFlagEndpoint}");
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }

        }
        public async Task<List<string>> GetControlFlagListAsync()
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid); try
            {
                return await Api.Current.GetListAsync<string>($"{ContextEndpoint}/{ControlFlagEndpoint}");
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }

        }

        public List<string> GetOVLModelNameList(string tool)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid); try
            {
                return Api.Current.GetList<string>($"{ContextEndpoint}/{OVLModelNameEndpoint}/{tool}");
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }

        }
        public async Task<List<string>> GetOVLModelNameListAsync(string tool)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid); try
            {
                return await Api.Current.GetListAsync<string>($"{ContextEndpoint}/{OVLModelNameEndpoint}/{tool}");
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }

        }


        public IEnumerable<ContextModel> GetContextList(string fab)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid); try
            {
                return Api.Current.GetList<ContextModel>(ContextEndpoint,
                new QueryFilter("fab", fab));
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }

        }
        public async Task<List<ContextModel>> GetContextListAsync(params QueryFilter[] parameters)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid); try
            {
                return await Api.Current.GetListAsync<ContextModel>($"{ContextEndpoint}", parameters);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }

        }

        public ContextModel GetContextInfo(string fab, string tool, string product, string layer, string reticle, string recipe, string preTool, string preReticle)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid); try
            {
                return Api.Current.GetSingle<ContextModel>($"{ContextEndpoint}/{FabEndpoint}/{fab}/{ToolEndpoint}/{tool}/{ProductEndpoint}/{product}/{LayerEndpoint}/{layer}/{ReticleEndpoint}/{reticle}/{RecipeEndpoint}/{recipe}/{PreToolEndpoint}/{preTool}/{PreReticleEndpoint}/{preReticle}");
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }
        }

        public async Task<ContextModel> GetContextInfoAsync(string fab, string tool, string product, string layer, string reticle, string recipe, string preTool, string preReticle)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid); try
            {
                return await Api.Current.GetSingleAsync<ContextModel>($"{ContextEndpoint}/{FabEndpoint}/{fab}/{ToolEndpoint}/{tool}/{ProductEndpoint}/{product}/{LayerEndpoint}/{layer}/{ReticleEndpoint}/{reticle}/{RecipeEndpoint}/{recipe}/{PreToolEndpoint}/{preTool}/{PreReticleEndpoint}/{preReticle}");
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }

        }

        public DCDControlSetting GetDCDContextInfo(string fab, string tool, string product, string layer, string reticle, string recipe)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid); try
            {
                return Api.Current.GetSingle<DCDControlSetting>($"{ContextEndpoint}/{DCDContextInfoEndpoint}/{FabEndpoint}/{fab}/{ToolEndpoint}/{tool}/{ProductEndpoint}/{product}/{LayerEndpoint}/{layer}/{ReticleEndpoint}/{reticle}/{RecipeEndpoint}/{recipe}");
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }
        }

        public async Task<DCDControlSetting> GetDCDContextInfoAsync(string fab, string tool, string product, string layer, string reticle, string recipe)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid); try
            {
                return await Api.Current.GetSingleAsync<DCDControlSetting>($"{ContextEndpoint}/{DCDContextInfoEndpoint}/{FabEndpoint}/{fab}/{ToolEndpoint}/{tool}/{ProductEndpoint}/{product}/{LayerEndpoint}/{layer}/{ReticleEndpoint}/{reticle}/{RecipeEndpoint}/{recipe}");
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }

        }

        public OVLControlSetting GetOVLContextInfo(string fab, string tool, string product, string layer, string reticle, string recipe, string preTool, string preReticle)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid); try
            {
                return Api.Current.GetSingle<OVLControlSetting>($"{ContextEndpoint}/{OVLContextInfoEndpoint}/{FabEndpoint}/{fab}/{ToolEndpoint}/{tool}/{ProductEndpoint}/{product}/{LayerEndpoint}/{layer}/{ReticleEndpoint}/{reticle}/{RecipeEndpoint}/{recipe}/{PreToolEndpoint}/{preTool}/{PreReticleEndpoint}/{preReticle}");
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }
        }

        public async Task<OVLControlSetting> GetOVLContextInfoAsync(string fab, string tool, string product, string layer, string reticle, string recipe, string preTool, string preReticle)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid); try
            {
                return await Api.Current.GetSingleAsync<OVLControlSetting>($"{ContextEndpoint}/{OVLContextInfoEndpoint}/{FabEndpoint}/{fab}/{ToolEndpoint}/{tool}/{ProductEndpoint}/{product}/{LayerEndpoint}/{layer}/{ReticleEndpoint}/{reticle}/{RecipeEndpoint}/{recipe}/{PreToolEndpoint}/{preTool}/{PreReticleEndpoint}/{preReticle}");
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }

        }

        public ContextModel GetContext(string contextKey)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid); try
            {
                return Api.Current.GetSingle<ContextModel>($"{ContextEndpoint}/{contextKey}");
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }

        }
        public async Task<ContextModel> GetContextAsync(string contextKey)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid); try
            {
                return await Api.Current.GetSingleAsync<ContextModel>($"{ContextEndpoint}/{contextKey}");
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }

        }

        public Context CreateContext(Context context, string comment)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid); try
            {
                return Api.Current.PostNew(ContextEndpoint, context, comment);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }

        }
        public async Task<Context> CreateContextAsync(Context newContext, string comment)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid); try
            {
                return await Api.Current.PostNewAsync($"{ContextEndpoint}", newContext, comment);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }

        }

        public Context CreateContextAndSpec(Context context, string copySpecContextKey, string comment)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid); try
            {
                return Api.Current.PostNew($"{ContextEndpoint}/{copySpecContextKey}/{SpecEndpoint}", context, comment);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }

        }
        public async Task<Context> CreateContextAndSpecAsync(Context newContext, string copySpecContextKey, string comment)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid); try
            {
                return await Api.Current.PostNewAsync($"{ContextEndpoint}/{copySpecContextKey}/{SpecEndpoint}", newContext, comment);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }

        }

        public void DeleteContext(string contextKey, string comment)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid); try
            {
                Api.Current.Delete($"{ContextEndpoint}/{contextKey}", comment);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }

        }
        public async Task DeleteContextAsync(string contextKey, string comment)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid); try
            {
                await Api.Current.DeleteAsync($"{ContextEndpoint}/{contextKey}", comment);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }

        }

        public void ModifyContext(string contextKey, Context context, string comment)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid); try
            {
                Api.Current.PutUpdate($"{ContextEndpoint}/{contextKey}", context, comment);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }

        }
        public async Task ModifyContextAsync(string contextKey, Context context, string comment)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid); try
            {
                await Api.Current.PutUpdateAsync($"{ContextEndpoint}/{contextKey}", context, comment);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }

        }

        public void ModifyContextSpec(SpecSetting specSetting, string comment)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid); try
            {
                Api.Current.PutUpdate($"{ContextEndpoint}/{SpecEndpoint}", specSetting, comment);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }

        }
        public async Task ModifyContextSpecAsync(SpecSetting specSetting, string comment)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid); try
            {
                await Api.Current.PutUpdateAsync($"{ContextEndpoint}/{SpecEndpoint}", specSetting, comment);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }

        }

        public List<Specs> GetContextSpecList(string contextKey)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid); try
            {
                return Api.Current.GetList<Specs>($"{ContextEndpoint}/{contextKey}/{SpecEndpoint}");
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }

        }
        public async Task<List<Specs>> GetContextSpecListAsync(string contextKey)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid); try
            {
                return await Api.Current.GetListAsync<Specs>($"{ContextEndpoint}/{contextKey}/{SpecEndpoint}");
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }

        }
        #endregion
    }
}
