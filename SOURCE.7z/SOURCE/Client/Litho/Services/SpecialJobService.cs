﻿using System;
using System.Collections.Generic;
using System.Reflection;
using System.Threading.Tasks;
using AMAT.R2R.Client.Common.Extensions;
using AMAT.R2R.Client.Common.Helpers;
using AMAT.R2R.Client.Common.Services;
using AMAT.R2R.Client.Litho.Modules.SpecialJobSettings;
using AMAT.R2R.Shared.Litho.DTO;

namespace AMAT.R2R.Client.Litho.Services
{
    public class SpecialJobService : ISpecialJobService
    {
        const string SpecialJobEndpoint = "specialJob";
        const string SpecialJobParameterEndpoint = "specialParameter";

        #region Filter
        public async Task<List<SpecialJobModel>> GetSpecialJobListAsync(IList<QueryFilter> filters, IList<QuerySorter> sorters, int? skip, int? take)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid);
            try
            {
                return await Api.Current.GetListAsync<SpecialJobModel>(SpecialJobEndpoint, filters, sorters, skip, take);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }
        }
        public async Task<int> GetSpecialJobCount(List<QueryFilter> filters)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid);
            try
            {
                return await Api.Current.GetTotalCountAsync(SpecialJobEndpoint, filters);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }
        }
        public async Task<object[]> GetSpecialJobValueListAsync(string propertyName, List<QueryFilter> filters)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid);
            try
            {
                return await Api.Current.GetValueListAsync(SpecialJobEndpoint, propertyName, filters);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }
        }
        #endregion

        #region CURD
        public SpecialJobModel GetSpecialJob(string specialJobKey)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid); try
            {
                return Api.Current.GetSingle<SpecialJobModel>($"{SpecialJobEndpoint}/{specialJobKey}");
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }
            
        }
        public async Task<SpecialJobModel> GetSpecialJobAsync(string specialJobId)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid); try
            {
                return await Api.Current.GetSingleAsync<SpecialJobModel>($"{SpecialJobEndpoint}/{specialJobId.EscapeUrlChar()}");
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }
            
        }

        public List<SpecialJobModel> GetSpecialJobList(string fab)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid); try
            {
                return Api.Current.GetList<SpecialJobModel>(SpecialJobEndpoint, new QueryFilter("fab", fab));
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }

        }
        public async Task<List<SpecialJobModel>> GetSpecialJobListAsync(string fab)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid); try
            {
                return await Api.Current.GetListAsync<SpecialJobModel>(SpecialJobEndpoint, new QueryFilter("fab", fab));
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }

        }
        public async Task<List<SpecialJobModel>> GetSpecialJobListAsync(params QueryFilter[] parameters)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid); try
            {
                return await Api.Current.GetListAsync<SpecialJobModel>($"{SpecialJobEndpoint}", parameters);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }

        }


        public SpecialJob CreateSpecialJob(SpecialJob specialJob, string comment)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid); try
            {
                return Api.Current.PostNew(SpecialJobEndpoint, specialJob, comment);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }

        }
        public async Task<SpecialJob> CreateSpecialJobAsync(SpecialJob newSpecialJob, string comment)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid); try
            {
                return await Api.Current.PostNewAsync($"{SpecialJobEndpoint}", newSpecialJob, comment);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }

        }

        public void DeleteSpecialJob(string specialJobKey, string comment)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid); try
            {
                Api.Current.Delete($"{SpecialJobEndpoint}/{specialJobKey}", comment);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }

        }
        public async Task DeleteSpecialJobAsync(string specialJobId, string comment)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid); try
            {
                await Api.Current.DeleteAsync($"{SpecialJobEndpoint}/{specialJobId.EscapeUrlChar()}", comment);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }

        }

        public async Task UpdateSpecialJobAsync(string specialJobId, SpecialJob newSpecialJob, string comment)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid); try
            {
                await Api.Current.PutUpdateAsync($"{SpecialJobEndpoint}/{specialJobId.EscapeUrlChar()}", newSpecialJob, comment);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }

        }

        public async Task<List<SpecialJobParameter>> GetSpecialJobParameterAsync(string OVLModelName, int C2C, int FEM, string ContextKey)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid); try
            {
                return await Api.Current.GetSingleAsync<List<SpecialJobParameter>>($"{SpecialJobEndpoint}/{SpecialJobParameterEndpoint}/{OVLModelName}/{C2C}/{FEM}/{ContextKey}");
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }

        }
        public List<SpecialJobParameter> GetSpecialJobParameter(string OVLModelName, int C2C, int FEM, string ContextKey)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid); try
            {
                return Api.Current.GetSingle<List<SpecialJobParameter>>($"{SpecialJobEndpoint}/{SpecialJobParameterEndpoint}/{OVLModelName}/{C2C}/{FEM}/{ContextKey}");
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }

        }
        #endregion
    }
}
