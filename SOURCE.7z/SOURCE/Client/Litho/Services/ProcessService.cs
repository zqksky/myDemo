﻿using System;
using System.Collections.Generic;
using System.Reflection;
using System.Threading.Tasks;
using AMAT.R2R.Client.Common.Helpers;
using AMAT.R2R.Client.Common.Services;
using AMAT.R2R.Client.Litho.Modules.ProcessSettings;
using AMAT.R2R.Shared.Litho.DTO;

namespace AMAT.R2R.Client.Litho.Services
{
    public class ProcessService : IProcessService
    {
        const string ProcessEndpoint = "process";

        #region Filter
        public async Task<List<ProcessModel>> GetProcessListAsync(IList<QueryFilter> filters, IList<QuerySorter> sorters, int? skip, int? take)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid);
            try
            {
                return await Api.Current.GetListAsync<ProcessModel>(ProcessEndpoint, filters, sorters, skip, take);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }
        }
        public async Task<int> GetProcessCount(List<QueryFilter> filters)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid);
            try
            {
                return await Api.Current.GetTotalCountAsync(ProcessEndpoint, filters);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }
        }
        public async Task<object[]> GetProcessValueListAsync(string propertyName, List<QueryFilter> filters)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid);
            try
            {
                return await Api.Current.GetValueListAsync(ProcessEndpoint, propertyName, filters);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }
        }
        #endregion

        #region CURD
        public List<ProcessModel> GetProcessList(string fab)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid); try
            {
                return Api.Current.GetList<ProcessModel>(ProcessEndpoint, new QueryFilter("fab", fab));
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }

        }
        public async Task<List<ProcessModel>> GetProcessListAsync(string fab)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid); try
            {
                return await Api.Current.GetListAsync<ProcessModel>(ProcessEndpoint, new QueryFilter("fab", fab));
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }

        }


        public ProcessModel GetProcess(string processKey)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid); try
            {
                return Api.Current.GetSingle<ProcessModel>($"{ProcessEndpoint}/{processKey}");
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }

        }

        public async Task<ProcessModel> GetProcessAsync(string processKey)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid); try
            {
                return await Api.Current.GetSingleAsync<ProcessModel>($"{ProcessEndpoint}/{processKey}");
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }

        }

        public Process CreateProcess(Process process, string comment)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid); try
            {
                return Api.Current.PostNew(ProcessEndpoint, process, comment);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }

        }
        public async Task<Process> CreateProcessAsync(Process process, string comment)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid); try
            {
                return await Api.Current.PostNewAsync(ProcessEndpoint, process, comment);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }

        }

        public void DeleteProcess(string processKey, string comment)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid); try
            {
                Api.Current.Delete($"{ProcessEndpoint}/{processKey}", comment);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }

        }
        public async Task DeleteProcessAsync(string processKey, string comment)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid); try
            {
                await Api.Current.DeleteAsync($"{ProcessEndpoint}/{processKey}", comment);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }

        }

        public void ModifyProcess(string processKey, Process process, string comment)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid); try
            {
                Api.Current.PutUpdate($"{ProcessEndpoint}/{processKey}", process, comment);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }

        }
        public async Task ModifyProcessAsync(string processKey, Process process, string comment)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid); try
            {
                await Api.Current.PutUpdateAsync($"{ProcessEndpoint}/{processKey}", process, comment);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }

        }
        #endregion
    }
}
