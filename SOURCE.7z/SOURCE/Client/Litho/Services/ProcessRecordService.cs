﻿using System;
using System.Collections.Generic;
using System.Reflection;
using System.Threading.Tasks;
using AMAT.R2R.Client.Common.Extensions;
using AMAT.R2R.Client.Common.Helpers;
using AMAT.R2R.Client.Common.Services;
using AMAT.R2R.Client.Litho.Modules.ProcessRecordConfig;
using AMAT.R2R.Shared.Litho.DTO;

namespace AMAT.R2R.Client.Litho.Services
{
    public class ProcessRecordService : IProcessRecordService
    {
        const string ProcessRecordEndpoint = "processRecord";
        const string ChuckDataEndpoint = "chuckData";

        #region ProcessRecord
        public async Task<List<PreRecordDataModel>> GetProcessRecordListAsync()
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid); try
            {
                return await Api.Current.GetListAsync<PreRecordDataModel>($"{ProcessRecordEndpoint}");
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }

        }
        public async Task<List<PreRecordDataModel>> GetProcessRecordListAsync(params QueryFilter[] parameters)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid); try
            {
                return await Api.Current.GetListAsync<PreRecordDataModel>($"{ProcessRecordEndpoint}", parameters);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }

        }

        public PreRecordDataModel GetProcessRecord(string preRecordKey)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid); try
            {
                return Api.Current.GetSingle<PreRecordDataModel>($"{ProcessRecordEndpoint}/{preRecordKey}");
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }

        }
        public async Task<PreRecordDataModel> GetProcessRecordAsync(string preRecordKey)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid); try
            {
                return await Api.Current.GetSingleAsync<PreRecordDataModel>($"{ProcessRecordEndpoint}/{preRecordKey}");
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }

        }

        public OVLReferenceData CreateProcessRecord(OVLReferenceData preRecord, string comment)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid); try
            {
                return Api.Current.PostNew($"{ProcessRecordEndpoint}", preRecord, comment);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }

        }
        public async Task<OVLReferenceData> CreateProcessRecordAsync(OVLReferenceData newPreRecord, string comment)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid); try
            {
                return await Api.Current.PostNewAsync($"{ProcessRecordEndpoint}", newPreRecord, comment);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }

        }


        public void DeleteProcessRecord(string preRecordKey, string comment)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid); try
            {
                Api.Current.Delete($"{ProcessRecordEndpoint}/{preRecordKey}", comment);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }

        }
        public async Task DeleteProcessRecordAsync(string preRecordKey, string comment)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid); try
            {
                await Api.Current.DeleteAsync($"{ProcessRecordEndpoint}/{preRecordKey.EscapeUrlChar()}", comment);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }

        }
        #endregion

        #region ChuckData
        public async Task<List<ChuckDataModel>> GetChuckDataListAsync(string layer, string lot)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid); try
            {
                return await Api.Current.GetListAsync<ChuckDataModel>($"{ProcessRecordEndpoint}/{ChuckDataEndpoint}/{layer}/{lot}");
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }

        }
        public async Task<List<ChuckDataModel>> GetChuckDataListAsync(params QueryFilter[] parameters)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid); try
            {
                return await Api.Current.GetListAsync<ChuckDataModel>($"{ProcessRecordEndpoint}/{ChuckDataEndpoint}", parameters);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }

        }

        public ChuckDataModel GetChuckData(string chuckDataKey)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid); try
            {
                return Api.Current.GetSingle<ChuckDataModel>($"{ProcessRecordEndpoint}/{ChuckDataEndpoint}/{chuckDataKey}");
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }

        }
        public async Task<ChuckDataModel> GetChuckDataAsync(string chuckDataKey)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid); try
            {
                return await Api.Current.GetSingleAsync<ChuckDataModel>($"{ProcessRecordEndpoint}/{ChuckDataEndpoint}/{chuckDataKey}");
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }

        }

        public OVLChuckDedicate CreateChuckData(OVLChuckDedicate newPChuckData, string comment)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid); try
            {
                return Api.Current.PostNew($"{ProcessRecordEndpoint}/{ChuckDataEndpoint}", newPChuckData, comment);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }

        }
        public async Task<List<OVLChuckDedicate>> CreateChuckDataAsync(List<OVLChuckDedicate> newChuckDataList, string comment)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid); try
            {
                return await Api.Current.PostNewAsync($"{ProcessRecordEndpoint}/{ChuckDataEndpoint}", newChuckDataList, comment);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }

        }


        public void DeleteChuckData(string chuckDataKey, string comment)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid); try
            {
                Api.Current.Delete($"{ProcessRecordEndpoint}/{ChuckDataEndpoint}/{chuckDataKey}", comment);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }

        }
        public async Task DeleteChuckDataAsync(string chuckDataKey, string comment)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid); try
            {
                await Api.Current.DeleteAsync($"{ProcessRecordEndpoint}/{ChuckDataEndpoint}/{chuckDataKey.EscapeUrlChar()}", comment);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }

        }
        #endregion
    }
}
