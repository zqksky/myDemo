﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AMAT.R2R.Client.Common.Services;
using AMAT.R2R.Client.Litho.Modules.ProcessRecordConfig;
using AMAT.R2R.Shared.Litho.DTO;

namespace AMAT.R2R.Client.Litho.Services
{
    public interface IProcessRecordService
    {
        #region PreRecord
        void DeleteProcessRecord(string preRecordKey, string comment);
        Task DeleteProcessRecordAsync(string preRecordKey, string comment);

        OVLReferenceData CreateProcessRecord(OVLReferenceData preRecord, string comment);
        Task<OVLReferenceData> CreateProcessRecordAsync(OVLReferenceData newPreRecord, string comment);

        PreRecordDataModel GetProcessRecord(string preRecordKey);
        Task<PreRecordDataModel> GetProcessRecordAsync(string preRecordKey);
        Task<List<PreRecordDataModel>> GetProcessRecordListAsync();
        Task<List<PreRecordDataModel>> GetProcessRecordListAsync(params QueryFilter[] parameters);
        #endregion

        #region ChuckData
        void DeleteChuckData(string chuckDataKey, string comment);
        Task DeleteChuckDataAsync(string chuckDataKey, string comment);

        OVLChuckDedicate CreateChuckData(OVLChuckDedicate chuckData, string comment);
        Task<List<OVLChuckDedicate>> CreateChuckDataAsync(List<OVLChuckDedicate> newChuckDataList, string comment);

        ChuckDataModel GetChuckData(string chuckDataKey);
        Task<ChuckDataModel> GetChuckDataAsync(string chuckDataKey);
        Task<List<ChuckDataModel>> GetChuckDataListAsync(string layer, string lot);
        Task<List<ChuckDataModel>> GetChuckDataListAsync(params QueryFilter[] parameters);
        #endregion
    }
}
