﻿using System.Collections.Generic;
using System.Threading.Tasks;
using AMAT.R2R.Client.Common.Services;
using AMAT.R2R.Client.Litho.Modules.SpecialJobSettings;
using AMAT.R2R.Shared.Litho.DTO;

namespace AMAT.R2R.Client.Litho.Services
{
    public interface ISpecialJobService
    {
        #region Filter
        Task<List<SpecialJobModel>> GetSpecialJobListAsync(IList<QueryFilter> filters, IList<QuerySorter> sorters, int? skip, int? take);
        Task<int> GetSpecialJobCount(List<QueryFilter> filters);
        Task<object[]> GetSpecialJobValueListAsync(string propertyName, List<QueryFilter> filters);
        #endregion

        #region CURD
        SpecialJobModel GetSpecialJob(string specialJobKey);
        Task<SpecialJobModel> GetSpecialJobAsync(string specialJobId);

        List<SpecialJobModel> GetSpecialJobList(string fab);
        Task<List<SpecialJobModel>> GetSpecialJobListAsync(string fab);
        Task<List<SpecialJobModel>> GetSpecialJobListAsync(params QueryFilter[] parameters);

        Task UpdateSpecialJobAsync(string specialJobId, SpecialJob newSpecialJob, string comment);

        void DeleteSpecialJob(string specialJobKey, string comment);
        Task DeleteSpecialJobAsync(string specialJobId, string comment);

        SpecialJob CreateSpecialJob(SpecialJob specialJob, string comment);
        Task<SpecialJob> CreateSpecialJobAsync(SpecialJob newSpecialJob, string comment);

        List<SpecialJobParameter> GetSpecialJobParameter(string OVLModelName, int C2C, int FEM, string ContextKey);
        Task<List<SpecialJobParameter>> GetSpecialJobParameterAsync(string OVLModelName, int C2C, int FEM, string ContextKey);
        #endregion
    }
}
