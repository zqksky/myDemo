﻿using System.Collections.Generic;
using System.Threading.Tasks;
using AMAT.R2R.Client.Common.Services;
using AMAT.R2R.Shared.Litho.DTO;

namespace AMAT.R2R.Client.Litho.Services
{
    public interface ILotRunHistoryService
    {
        #region Filter
        Task<List<LotRunHistory>> GetLotRunHistoryListAsync(IList<QueryFilter> filters, IList<QuerySorter> sorters = null, int? skip = null, int? take = null);

        Task<object[]> GetLotRunHistoryValueListAsync(string propertyName, List<QueryFilter> filters);
        #endregion

    }
}
