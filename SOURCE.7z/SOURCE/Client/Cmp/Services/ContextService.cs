﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;
using AMAT.R2R.Client.Common.Helpers;
using AMAT.R2R.Client.Common.Messages;
using AMAT.R2R.Client.Common.Services;
using AMAT.R2R.Client.Cmp.Modules.ContextSettings;
using AMAT.R2R.Client.Cmp.Modules.ProcessSettings;
using AMAT.R2R.Shared.Base.DTO;
using AMAT.R2R.Shared.Cmp.DTO;
using DevExpress.Mvvm;

namespace AMAT.R2R.Client.Cmp.Services
{
    public class ContextService : IContextService
    {
        const string ContextEndpoint = "context";
        const string ContextInputEndpoint = "input";
        const string ContextConstantsEndpoint = "constants";


        public async Task<Context> CreateContextAsync(Context newContext, string comment)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid);
            try
            {
                return await Api.Current.PostNewAsync($"{ContextEndpoint}", newContext, comment);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }
        }

        public async Task<Context> CopyContextAsync(Context newContext, string contextKey, string comment)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid);
            try
            {
                return await Api.Current.PostNewAsync($"{ContextEndpoint}/{contextKey}/copy", newContext, comment);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }
        }

        public async Task DeleteContextAsync(string contextKey, string comment)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid);
            try
            {
                await Api.Current.DeleteAsync($"{ContextEndpoint}/{contextKey}", comment);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }
        }

        public async Task<ContextModel> GetContextAsync(string contextKey)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid);
            try
            {
                return await Api.Current.GetSingleAsync<ContextModel>($"{ContextEndpoint}/{contextKey}");
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }
        }

        public async Task<List<ContextModel>> GetContextListAsync(params QueryFilter[] parameters)
        {
            return await GetContextListAsync(parameters.ToList(), null, null, null);
        }

        public async Task<List<ContextModel>> GetContextListAsync(IList<QueryFilter> filters, IList<QuerySorter> sorters, int? skip, int? take)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid);
            try
            {
                return await Api.Current.GetListAsync<ContextModel>(ContextEndpoint, filters, sorters, skip, take);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }
        }
        public async Task<int> GetContextCount(List<QueryFilter> filters)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid);
            try
            {
                return await Api.Current.GetTotalCountAsync(ContextEndpoint, filters);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }
        }
        public async Task<object[]> GetContextValueListAsync(string propertyName, List<QueryFilter> filters)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid);
            try
            {
                return await Api.Current.GetValueListAsync(ContextEndpoint, propertyName, filters);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }
        }


        public async Task UpdateContextAsync(Context newContext, string contextKey, string comment)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid);
            try
            {
                await Api.Current.PutUpdateAsync($"{ContextEndpoint}/{contextKey}", newContext, comment);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }
        }

        public async Task UpdateContextInputAsync(Context context, string contextKey, string comment)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid);
            try
            {
                await Api.Current.PutUpdateAsync($"{ContextEndpoint}/{contextKey}/{ContextInputEndpoint}", context, comment);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }
        }

        public async Task UpdateContextVIDChannelAsync(Context context, string contextKey, string comment)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid);
            try
            {
                await Api.Current.PutUpdateAsync($"{ContextEndpoint}/{contextKey}/vidChannel", context, comment);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }
        }

        public async Task UpdateContextLifetimeSettingsAsync(Context context, string contextKey, string comment)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid);
            try
            {
                await Api.Current.PutUpdateAsync($"{ContextEndpoint}/{contextKey}/lifetimeSettings", context, comment);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }
        }

        public async Task UpdateContextSlaveParametersAsync(Context context, string contextKey, string comment)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid);
            try
            {
                await Api.Current.PutUpdateAsync($"{ContextEndpoint}/{contextKey}/slaveParameters", context, comment);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }
        }

        public async Task UpdateContextConstantsAsync(ContextConstants contextConstants, string contextKey, string comment)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid);
            try
            {
                await Api.Current.PutUpdateAsync($"{ContextEndpoint}/{contextKey}/{ContextConstantsEndpoint}", contextConstants, comment);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }
        }

        public async Task<ContextConstants> CreateContextConstantsAsync(ContextConstants contextConstants, string contextKey, string comment)
        {
            var guid = Guid.NewGuid();
            var method = nameof(CreateContextConstantsAsync);
            Logger.PerformanceStart(method, guid);
            try
            {
                return await Api.Current.PostNewAsync($"{ContextEndpoint}/{contextKey}/{ContextConstantsEndpoint}", contextConstants, comment);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }
        }

        public async Task UpdateContextOutputAsync(Context context, string contextKey, string comment)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid);
            try
            {
                await Api.Current.PutUpdateAsync($"{ContextEndpoint}/{contextKey}/output", context, comment);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }
        }

        public async Task UpdateContextPreMeasureAsync(Context context, string contextKey, string comment)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid);
            try
            {
                await Api.Current.PutUpdateAsync($"{ContextEndpoint}/{contextKey}/premeas", context, comment);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }
        }
    }
}
