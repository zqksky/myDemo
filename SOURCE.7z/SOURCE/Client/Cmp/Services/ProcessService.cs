﻿using System;
using System.Collections.Generic;
using System.Reflection;
using System.Threading.Tasks;
using AMAT.R2R.Client.Common.Extensions;
using AMAT.R2R.Client.Common.Helpers;
using AMAT.R2R.Client.Common.Messages;
using AMAT.R2R.Client.Common.Services;
using AMAT.R2R.Client.Cmp.Modules.ProcessSettings;
using AMAT.R2R.Shared.Base.DTO;
using AMAT.R2R.Shared.Cmp.DTO;
using DevExpress.Mvvm;
using DevExpress.Xpf.Data;
using AMAT.R2R.Client.Cmp.Modules.MaterializedViewSettings;

namespace AMAT.R2R.Client.Cmp.Services
{
    public class ProcessService : IProcessService
    {
        const string ProcessEndpoint = "process";
        const string StepMappingEndPoint = "stepMapping";


        #region Process Methods
        public async Task<List<ProcessModel>> GetProcessListAsync(IList<QueryFilter> filters, IList<QuerySorter> sorters, int? skip, int? take)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid);
            try
            {
                return await Api.Current.GetListAsync<ProcessModel>(ProcessEndpoint, filters, sorters, skip, take);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }
        }
        public async Task<int> GetProcessCount(List<QueryFilter> filters)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid);
            try
            {
                return await Api.Current.GetTotalCountAsync(ProcessEndpoint, filters);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }
        }
        public async Task<object[]> GetProcessValueListAsync(string propertyName, List<QueryFilter> filters)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid);
            try
            {
                return await Api.Current.GetValueListAsync(ProcessEndpoint, propertyName, filters);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }
        }

        public async Task<ProcessModel> GetProcessAsync(string processKey)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid);
            try
            {
                return await Api.Current.GetSingleAsync<ProcessModel>($"{ProcessEndpoint}/{processKey}");
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }
        }

        public async Task<Process> CreateProcessAsync(Process process, string comment)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid);
            try
            {
                return await Api.Current.PostNewAsync(ProcessEndpoint, process, comment);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }
        }

        public async Task DeleteProcessAsync(string processKey, string comment)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid);
            try
            {
                await Api.Current.DeleteAsync($"{ProcessEndpoint}/{processKey}", comment);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }
        }

        public async Task ModifyProcessAsync(string processKey, Process process, string comment)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid);
            try
            {
                await Api.Current.PutUpdateAsync($"{ProcessEndpoint}/{processKey}", process, comment);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }
        }

        public async Task<StepLink> CreateStepMappingAsync(string processKey, StepLink stepMapping, string comment)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid);
            try
            {
                return await Api.Current.PostNewAsync($"{ProcessEndpoint}/{processKey}/{StepMappingEndPoint}", stepMapping, comment);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }
        }

        public async Task DeleteStepMappingAsync(string processKey, string stepLinkKey, string comment)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid);
            try
            {
                await Api.Current.DeleteAsync($"{ProcessEndpoint}/{processKey}/{StepMappingEndPoint}/{stepLinkKey}", comment);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }
        }

        public async Task<ManualPreMetrology> GetManualPreMetrologyInfoAsync(string processKey)
        {
            var guid = Guid.NewGuid();
            var method = nameof(GetManualPreMetrologyInfoAsync);
            Logger.PerformanceStart(method, guid);
            try
            {
                return await Api.Current.GetSingleAsync<ManualPreMetrology>($"{ProcessEndpoint}/{processKey}/ManualPreMetrologyItem");
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }
        }

        public async Task<ManualPreMetrologyItem> AddManualPreMetrologyItemAsync(string processKey, ManualPreMetrologyItem item, string comment)
        {
            var guid = Guid.NewGuid();
            var method = nameof(AddManualPreMetrologyItemAsync);
            Logger.PerformanceStart(method, guid);
            try
            {
                return await Api.Current.PostNewAsync($"{ProcessEndpoint}/{processKey}/ManualPreMetrologyItem", item, comment);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }
        }

        public async Task DeleteManualPreMetrologyItemAsync(string processKey, string measDataItemName, string waferId, string comment)
        {
            var guid = Guid.NewGuid();
            var method = nameof(DeleteManualPreMetrologyItemAsync);
            Logger.PerformanceStart(method, guid);
            try
            {
                await Api.Current.DeleteAsync($"{ProcessEndpoint}/{processKey}/ManualPreMetrologyItem/{measDataItemName}/wafer/{waferId}", comment);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }
        }
        #endregion

    }
}
