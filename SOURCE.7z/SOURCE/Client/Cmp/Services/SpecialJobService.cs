﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;
using AMAT.R2R.Client.Common.Extensions;
using AMAT.R2R.Client.Common.Helpers;
using AMAT.R2R.Client.Common.Messages;
using AMAT.R2R.Client.Common.Services;
using AMAT.R2R.Client.Cmp.Modules.ProcessSettings;
using AMAT.R2R.Client.Cmp.Modules.SpecialJobSettings;
using AMAT.R2R.Shared.Base.DTO;
using AMAT.R2R.Shared.Cmp.DTO;
using DevExpress.Mvvm;

namespace AMAT.R2R.Client.Cmp.Services
{
    public class SpecialJobService : ISpecialJobService
    {
        const string SpecialJobEndpoint = "specialJob";

        public async Task<SpecialJob> CreateSpecialJobAsync(SpecialJob newSpecialJob, string comment)
        {
            var guid = Guid.NewGuid();
            var method = nameof(CreateSpecialJobAsync);
            Logger.PerformanceStart(method, guid); 
            try
            {
                return await Api.Current.PostNewAsync($"{SpecialJobEndpoint}", newSpecialJob, comment);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }
        }

        public async Task DeleteSpecialJobAsync(string specialJobId, string comment)
        {
            var guid = Guid.NewGuid();
            var method = nameof(DeleteSpecialJobAsync);
            Logger.PerformanceStart(method, guid); 
            try
            {
                await Api.Current.DeleteAsync($"{SpecialJobEndpoint}/{specialJobId.EscapeUrlChar()}", comment);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }
        }

        public async Task<SpecialJobModel> GetSpecialJobAsync(string specialJobId)
        {
            var guid = Guid.NewGuid();
            var method = nameof(GetSpecialJobAsync);
            Logger.PerformanceStart(method, guid); 
            try
            {
                return await Api.Current.GetSingleAsync<SpecialJobModel>($"{SpecialJobEndpoint}/{specialJobId.EscapeUrlChar()}");
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }
        }

        public async Task<List<SpecialJobModel>> GetSpecialJobListAsync(params QueryFilter[] parameters)
        {
            return await GetSpecialJobListAsync(parameters.ToList(), null, null, null);
        }

        public async Task<List<SpecialJobModel>> GetSpecialJobListAsync(IList<QueryFilter> filters, IList<QuerySorter> sorters, int? skip, int? take)
        {
            var guid = Guid.NewGuid();
            var method = nameof(GetSpecialJobListAsync);
            Logger.PerformanceStart(method, guid);
            try
            {
                return await Api.Current.GetListAsync<SpecialJobModel>(SpecialJobEndpoint, filters, sorters, skip, take);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }
        }
        public async Task<int> GetSpecialJobCount(List<QueryFilter> filters)
        {
            var guid = Guid.NewGuid();
            var method = nameof(GetSpecialJobCount);
            Logger.PerformanceStart(method, guid);
            try
            {
                return await Api.Current.GetTotalCountAsync(SpecialJobEndpoint, filters);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }
        }
        public async Task<object[]> GetSpecialJobValueListAsync(string propertyName, List<QueryFilter> filters)
        {
            var guid = Guid.NewGuid();
            var method = nameof(GetSpecialJobValueListAsync);
            Logger.PerformanceStart(method, guid);
            try
            {
                return await Api.Current.GetValueListAsync(SpecialJobEndpoint, propertyName, filters);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }
        }

        public async Task UpdateSpecialJobAsync(string specialJobId, SpecialJob newSpecialJob, string comment)
        {
            var guid = Guid.NewGuid();
            var method = nameof(UpdateSpecialJobAsync);
            Logger.PerformanceStart(method, guid); 
            try
            {
                await Api.Current.PutUpdateAsync($"{SpecialJobEndpoint}/{specialJobId.EscapeUrlChar()}", newSpecialJob, comment);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }
        }

    }
}
