﻿
using System.Collections.Generic;
using System.Threading.Tasks;
using AMAT.R2R.Client.Common.Services;
using AMAT.R2R.Client.Cmp.Modules.ProcessSettings;
using AMAT.R2R.Shared.Base.DTO;
using AMAT.R2R.Shared.Cmp.DTO;
using DevExpress.Xpf.Data;
using AMAT.R2R.Client.Cmp.Modules.MaterializedViewSettings;

namespace AMAT.R2R.Client.Cmp.Services
{
    public interface IProcessService
    {
        #region Process
        // Filter
        Task<List<ProcessModel>> GetProcessListAsync(IList<QueryFilter> filters, IList<QuerySorter> sorters, int? skip, int? take);
        Task<int> GetProcessCount(List<QueryFilter> lists);
        Task<object[]> GetProcessValueListAsync(string propertyName, List<QueryFilter> filters);

        // CURD
        Task<ProcessModel> GetProcessAsync(string processKey);
        Task<Process> CreateProcessAsync(Process process, string comment);
        Task ModifyProcessAsync(string processKey, Process process, string comment);
        Task DeleteProcessAsync(string processKey, string comment);
        Task<StepLink> CreateStepMappingAsync(string processKey, StepLink stepMapping, string comment);
        Task DeleteStepMappingAsync(string processKey, string stepLinkKey, string comment);

        Task<ManualPreMetrology> GetManualPreMetrologyInfoAsync(string processKey);
        Task<ManualPreMetrologyItem> AddManualPreMetrologyItemAsync(string processKey, ManualPreMetrologyItem item, string comment);
        Task DeleteManualPreMetrologyItemAsync(string processKey, string measDataItemName, string waferId, string comment);
        #endregion

    }

    public class PreMetrologyData
    {
    }
}
