﻿
using System.Collections.Generic;
using System.Threading.Tasks;
using AMAT.R2R.Client.Common.Services;
using AMAT.R2R.Client.Cmp.Modules.ContextSettings;
using AMAT.R2R.Client.Cmp.Modules.ProcessSettings;
using AMAT.R2R.Shared.Base.DTO;
using AMAT.R2R.Shared.Cmp.DTO;

namespace AMAT.R2R.Client.Cmp.Services
{
    public interface IContextService
    {
        Task DeleteContextAsync(string contextKey, string comment);

        Task<Context> CreateContextAsync(Context newContext, string comment);
        Task<Context> CopyContextAsync(Context newContext, string contextKey, string comment);

        Task<ContextModel> GetContextAsync(string contextKey);

        Task<List<ContextModel>> GetContextListAsync(params QueryFilter[] parameters);

        Task<List<ContextModel>> GetContextListAsync(IList<QueryFilter> filters, IList<QuerySorter> sorters, int? skip, int? take);
        Task<int> GetContextCount(List<QueryFilter> filters);
        Task<object[]> GetContextValueListAsync(string propertyName, List<QueryFilter> filters);

        Task UpdateContextAsync(Context newContext, string contextKey, string comment);
        Task UpdateContextInputAsync(Context context, string contextKey, string comment);
        Task UpdateContextVIDChannelAsync(Context context, string contextKey, string comment);
        Task UpdateContextLifetimeSettingsAsync(Context context, string contextKey, string comment);
        Task UpdateContextSlaveParametersAsync(Context context, string contextKey, string comment);
        Task UpdateContextConstantsAsync(ContextConstants contextConstants, string contextKey, string comment);
        Task<ContextConstants> CreateContextConstantsAsync(ContextConstants contextConstants, string contextKey, string comment);
        Task UpdateContextOutputAsync(Context context, string contextKey, string comment);
        Task UpdateContextPreMeasureAsync(Context context, string contextKey, string comment);
    }
}
