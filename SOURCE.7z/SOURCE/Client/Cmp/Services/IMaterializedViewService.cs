﻿
using System.Collections.Generic;
using System.Threading.Tasks;
using AMAT.R2R.Client.Common.Services;
using AMAT.R2R.Client.Cmp.Modules.MaterializedViewSettings;
using AMAT.R2R.Client.Cmp.Modules.ProcessSettings;
using AMAT.R2R.Shared.Base.DTO;
using AMAT.R2R.Shared.Cmp.DTO;

namespace AMAT.R2R.Client.Cmp.Services
{
    public interface IMaterializedViewService
    {
        Task<MaterializedViewModel> GetMaterializedViewAsync(string contextKey);
        Task<List<MaterializeViewParameterExtend>> GetMaterializedViewInputListAsync(string contextKey);
        Task<List<RunHist>> GetMaterializedViewRunHisListAsync(string contextKey);
        Task ChangeStatus(MaterializedView materializedView, string contextKey, string comment);
        Task ChangePiLot(MaterializedView materializedView, string contextKey, string comment);
        Task ResetStatus(MaterializedView materializedView, string contextKey, string comment);

        Task<int> GetMaterializedViewCount(List<QueryFilter> filters);
        Task<object[]> GetMaterializedViewValueListAsync(string propertyName, List<QueryFilter> filters);
        Task<List<MaterializedViewModel>> GetMaterializedViewListAsync(IList<QueryFilter> filters, IList<QuerySorter> sorters, int? skip, int? take);
        Task UpdatePilotIdAsync(string contextKey, string pilotId, string comment);

        Task<bool> GetManualPMAsync(string toolId, string modelGroup);
        Task SetManualPMAsync(string toolId, string modelGroup, bool pm, string comment);
    }
}
