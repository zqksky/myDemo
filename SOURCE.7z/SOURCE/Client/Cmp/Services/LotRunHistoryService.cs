﻿using System;
using System.Collections.Generic;
using System.Reflection;
using System.Threading.Tasks;
using AMAT.R2R.Client.Common.Helpers;
using AMAT.R2R.Client.Common.Services;
using AMAT.R2R.Shared.Cmp.DTO;

namespace AMAT.R2R.Client.Cmp.Services
{
    public class LotRunHistoryService : ILotRunHistoryService
    {
        const string LotRunHistoryEndpoint = "LotHistory";
        public async Task<List<LotRunHistory>> GetLotRunHistoryListAsync(IList<QueryFilter> filters, IList<QuerySorter> sorters = null, int? skip = null, int? take = null)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid);
            try
            {
                return await Api.Current.GetListAsync<LotRunHistory>(LotRunHistoryEndpoint, filters, sorters, skip, take);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }
        }

        public async Task<object[]> GetLotRunHistoryValueListAsync(string propertyName, List<QueryFilter> filters)
        {
            var guid = Guid.NewGuid();
            var method = MethodBase.GetCurrentMethod().Name;
            Logger.PerformanceStart(method, guid);
            try
            {
                return await Api.Current.GetValueListAsync(LotRunHistoryEndpoint, propertyName, filters);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }
        }
    }
}
