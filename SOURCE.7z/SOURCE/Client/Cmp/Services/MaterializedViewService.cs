﻿using System;
using System.Collections.Generic;
using System.Reflection;
using System.Threading.Tasks;
using AMAT.R2R.Client.Common.Extensions;
using AMAT.R2R.Client.Common.Helpers;
using AMAT.R2R.Client.Common.Messages;
using AMAT.R2R.Client.Common.Services;
using AMAT.R2R.Client.Cmp.Modules.MaterializedViewSettings;
using AMAT.R2R.Client.Cmp.Modules.ProcessSettings;
using AMAT.R2R.Shared.Base.DTO;
using AMAT.R2R.Shared.Cmp.DTO;
using DevExpress.Mvvm;

namespace AMAT.R2R.Client.Cmp.Services
{
    public class MaterializedViewService : IMaterializedViewService
    {
        const string MaterializedViewEndpoint = "Materialized";
        const string InputEndpoint = "input";
        const string RunHisEndpoint = "run";
        const string ChangeStatusEndpoint = "changestatus";
        const string ChangePiLotEndpoint = "changepilot";
        const string ResetStatusEndpoint = "reset";
        const string ToolEndpoint = "tool";
        const string ChamberEndpoint = "chamber";
        const string ChamberOffsetEndpoint = "offset";
        const string BookPilotEndpoint = "bookPilot";


        public async Task<MaterializedViewModel> GetMaterializedViewAsync(string contextKey)
        {
            var guid = Guid.NewGuid();
            var method = nameof(GetMaterializedViewAsync);
            Logger.PerformanceStart(method, guid); 
            try
            {
                return await Api.Current.GetSingleAsync<MaterializedViewModel>($"{MaterializedViewEndpoint}/{contextKey}");
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }
        }


        public async Task<List<MaterializedViewModel>> GetMaterializedViewListAsync(IList<QueryFilter> filters, IList<QuerySorter> sorters, int? skip, int? take)
        {
            var guid = Guid.NewGuid();
            var method = nameof(GetMaterializedViewListAsync);
            Logger.PerformanceStart(method, guid);
            try
            {
                return await Api.Current.GetListAsync<MaterializedViewModel>(MaterializedViewEndpoint, filters, sorters, skip, take);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }
        }

        public async Task<int> GetMaterializedViewCount(List<QueryFilter> filters)
        {
            var guid = Guid.NewGuid();
            var method = nameof(GetMaterializedViewCount);
            Logger.PerformanceStart(method, guid);
            try
            {
                return await Api.Current.GetTotalCountAsync(MaterializedViewEndpoint, filters);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }
        }
        public async Task<object[]> GetMaterializedViewValueListAsync(string propertyName, List<QueryFilter> filters)
        {
            var guid = Guid.NewGuid();
            var method = nameof(GetMaterializedViewValueListAsync);
            Logger.PerformanceStart(method, guid);
            try
            {
                return await Api.Current.GetValueListAsync(MaterializedViewEndpoint, propertyName, filters);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }
        }

        public async Task<List<MaterializeViewParameterExtend>> GetMaterializedViewInputListAsync(string contextKey)
        {
            var guid = Guid.NewGuid();
            var method = nameof(GetMaterializedViewInputListAsync);
            Logger.PerformanceStart(method, guid); 
            try
            {
                return await Api.Current.GetListAsync<MaterializeViewParameterExtend>($"{MaterializedViewEndpoint}/{contextKey}/{InputEndpoint}");
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }
        }

        public async Task<List<RunHist>> GetMaterializedViewRunHisListAsync(string contextKey)
        {
            var guid = Guid.NewGuid();
            var method = nameof(GetMaterializedViewRunHisListAsync);
            Logger.PerformanceStart(method, guid); 
            try
            {
                return await Api.Current.GetListAsync<RunHist>($"{MaterializedViewEndpoint}/{contextKey}/{RunHisEndpoint}");
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }
        }

        public async Task ChangeStatus(MaterializedView materializedView, string contextKey, string comment)
        {
            var guid = Guid.NewGuid();
            var method = nameof(ChangeStatus);
            Logger.PerformanceStart(method, guid); 
            try
            {
                await Api.Current.PutUpdateAsync($"{MaterializedViewEndpoint}/{contextKey}/{ChangeStatusEndpoint}", materializedView, comment);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }
        }

        public async Task ChangePiLot(MaterializedView materializedView, string contextKey, string comment)
        {
            var guid = Guid.NewGuid();
            var method = nameof(ChangePiLot);
            Logger.PerformanceStart(method, guid);
            try
            {
                await Api.Current.PutUpdateAsync($"{MaterializedViewEndpoint}/{contextKey}/{ChangePiLotEndpoint}", materializedView, comment);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }
        }

        public async Task ResetStatus(MaterializedView materializedView, string contextKey, string comment)
        {
            var guid = Guid.NewGuid();
            var method = nameof(ResetStatus);
            Logger.PerformanceStart(method, guid); 
            try
            {
                await Api.Current.PutUpdateAsync($"{MaterializedViewEndpoint}/{contextKey}/{ResetStatusEndpoint}", materializedView, comment);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }
        }

        public async Task UpdatePilotIdAsync(string contextKey, string pilotId, string comment)
        {
            var guid = Guid.NewGuid();
            var method = nameof(UpdatePilotIdAsync);
            Logger.PerformanceStart(method, guid);
            try
            {
                await Api.Current.PutUpdateAsync($"{MaterializedViewEndpoint}/{contextKey}/{BookPilotEndpoint}", pilotId, comment);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }
        }

        public async Task<bool> GetManualPMAsync(string toolId, string modelGroup)
        {
            var guid = Guid.NewGuid();
            var method = nameof(GetManualPMAsync);
            Logger.PerformanceStart(method, guid);
            try
            {
                return await Api.Current.GetSingleAsync<bool>($"{ToolEndpoint}/{toolId}/{ChamberEndpoint}/{modelGroup}/manualpm");
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }
        }

        public async Task SetManualPMAsync(string toolId, string modelGroup, bool pm, string comment)
        {
            var guid = Guid.NewGuid();
            var method = nameof(SetManualPMAsync);
            Logger.PerformanceStart(method, guid);
            try
            {
                await Api.Current.PutUpdateAsync($"{ToolEndpoint}/{toolId}/{ChamberEndpoint}/{modelGroup}/manualpm", pm, comment);
            }
            finally
            {
                Logger.PerformanceStop(method, guid);
            }
        }
    }
}
