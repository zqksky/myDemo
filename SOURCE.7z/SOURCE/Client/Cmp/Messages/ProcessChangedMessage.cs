﻿
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using AMAT.R2R.Client.Common.Enums;
using AMAT.R2R.Client.Common.Views;
using AMAT.R2R.Shared.Base.DTO;
using AMAT.R2R.Shared.Cmp.DTO;

namespace AMAT.R2R.Client.Cmp.Messages
{
    public class ProcessChangedMessage
    {
        public ObjectChangeType ChangeType { get; set; }

        public string ProcessKey { get; set; }
    }
}
