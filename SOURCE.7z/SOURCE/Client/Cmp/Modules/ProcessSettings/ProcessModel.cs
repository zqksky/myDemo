﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AMAT.R2R.Shared.Cmp.DTO;

namespace AMAT.R2R.Client.Cmp.Modules.ProcessSettings
{
    public class ProcessModel : Process, INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;

        public void NotifyPrePostSettingsChanges()
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(LastModifiedBy)));
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(LastModifiedTime)));
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(PreStep1)));
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(PreStep2)));
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(PreStep3)));
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(PostStep1)));
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(PostStep2)));
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(PostStep3)));
        }

        public string PreStep1
        {
            get
            {
                return PreMetrologyList == null || PreMetrologyList.Count < 1 ? string.Empty : PreMetrologyList[0].LinkedStep;
            }
        }

        public string PreStep2
        {
            get
            {
                return PreMetrologyList == null || PreMetrologyList.Count < 2 ? string.Empty : PreMetrologyList[1].LinkedStep;
            }
        }
        public string PreStep3
        {
            get
            {
                return PreMetrologyList == null || PreMetrologyList.Count < 3 ? string.Empty : PreMetrologyList[2].LinkedStep;
            }
        }


        public string PostStep1
        {
            get
            {
                return PostMetrologyList == null || PostMetrologyList.Count < 1 ? string.Empty : PostMetrologyList[0].LinkedStep;
            }
        }

        public string PostStep2
        {
            get
            {
                return PostMetrologyList == null || PostMetrologyList.Count < 2 ? string.Empty : PostMetrologyList[1].LinkedStep;
            }
        }
        public string PostStep3
        {
            get
            {
                return PostMetrologyList == null || PostMetrologyList.Count < 3 ? string.Empty : PostMetrologyList[2].LinkedStep;
            }
        }
        public string PreProcess1
        {
            get
            {
                return PreProcessList == null || PreProcessList.Count < 1 ? string.Empty : PreProcessList[0].LinkedStep;
            }
        }

        public string PreProcess2
        {
            get
            {
                return PreProcessList == null || PreProcessList.Count < 2 ? string.Empty : PreProcessList[1].LinkedStep;
            }
        }
        public string PreProcess3
        {
            get
            {
                return PreProcessList == null || PreProcessList.Count < 3 ? string.Empty : PreProcessList[2].LinkedStep;
            }
        }

        public string PreMeasCsv
        {
            get
            {
                return string.Join(",", PreMetrologyList.Select(m => m.LinkedStep));
            }
        }
        public string PostMeasCsv
        {
            get
            {
                return string.Join(",", PostMetrologyList.Select(m => m.LinkedStep));
            }
        }
        public string PreProcessCsv
        {
            get
            {
                return string.Join(",", PreProcessList.Select(m => m.LinkedStep));
            }
        }
    }
}
