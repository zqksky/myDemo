﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Threading.Tasks;
using System.Web.Configuration;
using AMAT.R2R.Client.Common.Enums;
using AMAT.R2R.Client.Common.Helpers;
using AMAT.R2R.Client.Common.Services;
using AMAT.R2R.Client.Cmp.Messages;
using AMAT.R2R.Client.Cmp.Modules.ContextSettings;
using AMAT.R2R.Client.Cmp.Services;
using AMAT.R2R.Shared.Base.Constants;
using AMAT.R2R.Shared.Base.DTO;
using AMAT.R2R.Shared.Cmp.DTO;
using DevExpress.Data.Filtering;
using DevExpress.Mvvm;
using DevExpress.Mvvm.DataAnnotations;
using DevExpress.Mvvm.Native;
using DevExpress.Xpf.Data;

namespace AMAT.R2R.Client.Cmp.Modules.ProcessSettings
{
    public class ProcessListViewModel : CmpViewModelBase
    {
        public const string Auth_Process = "Process";
        public const string Auth_Process_Add = "Process:Add";
        public const string Auth_Process_Copy = "Process:Copy";
        public const string Auth_Process_EditStepMapping = "Process:StepMapping";
        public const string Auth_Process_Delete = "Process:Delete";
        public const string Auth_Process_CreateContext = "Context:Create";


        public ProcessListViewModel()
        {
            Caption = "Process Settings";
            Icon = "SvgImages/Business Objects/BO_KPI_Definition.svg";
            PropertyChanged += OnPropertyChanged;
            Messenger.Default.Register<ProcessChangedMessage>(this, OnProcessChanged);

            InitializePagedSource();
        }

        #region Filtering & Paging

        private void InitializePagedSource()
        {
            #region Paged Source
            var pagedSource = new PagedAsyncSource()
            {
                ElementType = typeof(ProcessModel),
                KeyProperty = nameof(Process.ProcessKey),
                PageSize = 100,
                PageNavigationMode = PageNavigationMode.ArbitraryWithTotalPageCount
            };

#if DEBUG
            pagedSource.PageSize = 10;
#endif

            pagedSource.FetchPage += (o, e) =>
            {
                e.Result = FetchPageRowsAsync(e);
            };

            pagedSource.GetTotalSummaries += (o, e) =>
            {
                e.Result = GetSummariesAsync(e);
            };

            pagedSource.GetUniqueValues += (o, e) =>
            {
                e.Result = GetValueListAsync(e);
            };

            pagedSource.PropertyChanged += (o, e) =>
            {
                if (e.PropertyName == nameof(PagedAsyncSource.AreRowsFetching))
                {
                    IsLoading = PagedSource.AreRowsFetching;

                    // restore selection.
                    if (!IsLoading)
                    {
                        if (_lastSelectedItem != null)
                        {
                            foreach (var item in PagedSource)
                            {
                                var process = item as ProcessModel;
                                if (process.ProcessKey == _lastSelectedItem.ProcessKey)
                                {
                                    SelectedProcess = process;
                                    break;
                                }
                            }
                        }
                    }
                }
            };

            PagedSource = pagedSource;
            #endregion
        }


        ProcessModel _lastSelectedItem = null;

        private async Task<FetchRowsResult> FetchPageRowsAsync(FetchPageAsyncEventArgs e)
        {
            try
            {
                if (SelectedProcess != null)
                {
                    _lastSelectedItem = SelectedProcess;
                }

                var items = await ProcessService.GetProcessListAsync(e.Filter.MakeFilters(), e.MakeSorters(), e.Skip, e.Take);
                return new FetchRowsResult(items.ToArray(), hasMoreRows: items.Count == e.Take);
            }
            catch (Exception ex)
            {
                Logger.Error(ex);
                throw;
            }
        }

        private async Task<object[]> GetSummariesAsync(GetSummariesAsyncEventArgs e)
        {
            try
            {
                var summary = await ProcessService.GetProcessCount(e.Filter.MakeFilters());
                return e.Summaries.Select(x =>
                {
                    return x.SummaryType == SummaryType.Count ? (object)summary : throw new InvalidOperationException();
                }).ToArray();
            }
            catch (Exception ex)
            {
                Logger.Error(ex);
                throw;
            }
        }

        private async Task<object[]> GetValueListAsync(GetUniqueValuesAsyncEventArgs e)
        {
            try
            {
                return await ProcessService.GetProcessValueListAsync(e.PropertyName, e.Filter.MakeFilters());
            }
            catch (Exception ex)
            {
                Logger.Error(ex);
                throw;
            }
        }

        #endregion


        #region Events
        protected override void OnViewReadyAsync()
        {
            //Refresh();
        }

        public override void OnRemoving(CancelEventArgs e)
        {
            base.OnRemoving(e);

            PagedSource?.Dispose();
            Messenger.Default.Unregister<ProcessChangedMessage>(this, OnProcessChanged);
        }

        private async void OnPropertyChanged(object sender, System.ComponentModel.PropertyChangedEventArgs e)
        {
            if (e.PropertyName == nameof(SelectedProcess))
            {
                if (SelectedProcess != null)
                {
                    await GetProcessDetailsAsync();
                }
                else
                {
                    ClearProcessDetails();
                }
            }
        }

        private void OnProcessChanged(ProcessChangedMessage msg)
        {
            Refresh();
        }

        private async Task RefreshSingleProcess(ProcessModel process)
        {
            var lastModifiedTime = process.LastModifiedTime;
            ProcessModel newProcess = await ProcessService.GetProcessAsync(process.ProcessKey);

            process.LastModifiedBy = newProcess.LastModifiedBy;
            process.LastModifiedTime = newProcess.LastModifiedTime;
            process.NotifyPrePostSettingsChanges();

            if (SelectedProcess != null && process.ProcessKey == SelectedProcess.ProcessKey && lastModifiedTime != newProcess.LastModifiedTime)
            {
                await GetProcessDetailsAsync();
            }
        }
        #endregion

        #region Commands
        [Command]
        public void Refresh()
        {
            PagedSource.UpdateSummaries();
            PagedSource.RefreshRows();
        }

        public bool CanRefresh()
        {
            return !IsLoading;
        }

        private async Task GetProcessDetailsAsync()
        {
            if (SelectedProcess != null)
            {
                try
                {
                    IsHistoryLoading = true;
                    HistoryList = new ObservableCollection<TransactionHistory>(await GlobalService.GetHistoryAsync(ClientInfo.LoginArea, "Process", SelectedProcess.ProcessKey, null));
                }
                finally
                {
                    IsHistoryLoading = false;
                }
            }
            else
            {
                HistoryList?.Clear();
            }
        }

        [Command]
        public void Add()
        {
            ShowPopup("AddProcess", new AddProcessViewModel(null, FunctionMode.Add));
        }

        public bool CanAdd()
        {
            return AuthorityManager.HasAuthority(Auth_Process_Add);
        }

        [Command]
        public async void EditStepMapping()
        {
            await UpdateBeforeAction();
            ShowPopup("EditStepMapping", new EditStepMappingViewModel(SelectedProcess));
        }

        public bool CanEditStepMapping()
        {
            return SelectedProcess != null && !IsLoading && SelectedProcessList != null && SelectedProcessList.Count == 1 &&
                AuthorityManager.HasAuthority(Auth_Process_EditStepMapping);
        }


        [Command]
        public async void Delete()
        {
            await UpdateBeforeAction();
            if (IsConfirmed(out var comment, $"Delete Process"))
            {
                var toDeleteProcess = SelectedProcess;
                await ProcessService.DeleteProcessAsync(SelectedProcess.ProcessKey, comment);
                Messenger.Default.Send(new ProcessChangedMessage() { ChangeType = ObjectChangeType.Deleted, ProcessKey = toDeleteProcess.ProcessKey });
                MessageBoxService.ShowMessage($"Process {toDeleteProcess.ProcessKey} is deleted.", "Success", MessageButton.OK, MessageIcon.Information);
            }
        }

        public bool CanDelete()
        {
            return SelectedProcess != null && !IsLoading && SelectedProcessList != null && SelectedProcessList.Count == 1 &&
                AuthorityManager.HasAuthority(Auth_Process_Delete);
        }

        private void ClearProcessDetails()
        {
            HistoryList = new ObservableCollection<TransactionHistory>();
        }

        [Command]
        public async void AddContext()
        {
            await UpdateBeforeAction();
            ShowPopup("EditContext", new EditContextViewModel(SelectedProcess, new Context(), FunctionMode.Add));
        }

        public bool CanAddContext()
        {
            return SelectedProcess != null && !IsLoading && SelectedProcessList != null && SelectedProcessList.Count == 1 &&
                AuthorityManager.HasAuthority(Auth_Process_CreateContext);
        }


        protected async Task UpdateBeforeAction()
        {
            ShowWait();
            await RefreshSingleProcess(SelectedProcess);
            HideWait();
        }
        #endregion

        #region Properties

        public PagedAsyncSource PagedSource
        {
            get { return GetValue<PagedAsyncSource>(); }
            set { SetValue(value); }
        }

        public ProcessModel SelectedProcess
        {
            get { return GetValue<ProcessModel>(); }
            set { SetValue(value); }
        }
        public ObservableCollection<ProcessModel> SelectedProcessList { get; } = new ObservableCollection<ProcessModel>();


        #endregion
    }
}
