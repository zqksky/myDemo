﻿using System;
using AMAT.R2R.Client.Common.Enums;
using AMAT.R2R.Client.Common.Helpers;
using AMAT.R2R.Client.Common.ViewModels;
using AMAT.R2R.Client.Common.Views;
using AMAT.R2R.Client.Cmp.Messages;
using AMAT.R2R.Shared.Cmp.DTO;
using DevExpress.Mvvm;
using DevExpress.Mvvm.DataAnnotations;
using DevExpress.Mvvm.POCO;
using System.Collections.Generic;
using System.Collections.ObjectModel;

namespace AMAT.R2R.Client.Cmp.Modules.ProcessSettings
{
    public class EditStepMappingViewModel : CmpViewModelBase
    {
        private const string NA = "NA";
        public EditStepMappingViewModel(ProcessModel process)
        {
            OwnerProcess = process;
            Mode = FunctionMode.Modify;

            SizeToContent = System.Windows.SizeToContent.Manual;
            WindowHeight = 600;
            WindowWidth = 900;

            MeasureTypeList = new List<string>
            {
                "PreMeas",
                "PostMeas",
                "PreProcess",
            };

            Caption = "Edit Step Mapping";
            IsDirty = false;
        }

        protected override void OnViewReadyAsync()
        {
            Refresh();
        }

        private async void Refresh()
        {
            OwnerProcess = await ProcessService.GetProcessAsync(OwnerProcess.ProcessKey);
            var mappingList = new List<StepLink>();
            mappingList.AddRange(OwnerProcess.PreMetrologyList);
            mappingList.AddRange(OwnerProcess.PostMetrologyList);
            mappingList.AddRange(OwnerProcess.PreProcessList);

            StepMappingList = new ObservableCollection<StepLink>(mappingList);
        }

        [Command]
        public async void Add()
        {
            ValidateAndSetErrorFocus(nameof(MeasureType), nameof(LinkStep));

            if (HasErrors)
            {
                return;
            }

            if(MeasureType == "PreMeas")
            {
                if(OwnerProcess.PreMetrologyList.Count >= 3)
                {
                    MessageBoxService.ShowMessage("Can not add more than 3 PreMeas steps.", "Error", MessageButton.OK, MessageIcon.Stop);
                    return;
                }
            }
            else if(MeasureType == "PostMeas")
            {
                if (OwnerProcess.PostMetrologyList.Count >= 3)
                {
                    MessageBoxService.ShowMessage("Can not add more than 3 PostMeas steps.", "Error", MessageButton.OK, MessageIcon.Stop);
                    return;
                }
            }
            else
            {
                if (OwnerProcess.PreProcessList.Count >= 3)
                {
                    MessageBoxService.ShowMessage("Can not add more than 3 PreProcess steps.", "Error", MessageButton.OK, MessageIcon.Stop);
                    return;
                }
            }

            // 
            if (IsConfirmed(out string comment))
            {
                var stepMapping = new StepLink
                {
                    Fab = OwnerProcess.Fab,
                    LinkedStep = LinkStep,
                    MeasType = MeasureType
                };

                ShowWait();

                // todo

                await ProcessService.CreateStepMappingAsync(OwnerProcess.ProcessKey, stepMapping, comment);

                IsDirty = false;
                HideWait();
                Messenger.Default.Send(new ProcessChangedMessage() { ChangeType = ObjectChangeType.Updated, ProcessKey = OwnerProcess.ProcessKey });

                Refresh();

                MessageBoxService.ShowMessage($"Process '{OwnerProcess.ProcessKey}' added new Step Mapping '{stepMapping.StepLinkKey}'!", "Success", MessageButton.OK, MessageIcon.Information);

                MeasureType = string.Empty;
                LinkStep = string.Empty;

                IsDirty = false;
            }
        }

        public bool CanAdd()
        {
            return !string.IsNullOrEmpty(MeasureType) && !string.IsNullOrEmpty(LinkStep);
        }

        [Command]
        public async void Delete()
        {
            // todo
            if (IsConfirmed(out var comment))
            {
                ShowWait();

                var toDeleteMapping = SelectedStepMapping;

                await ProcessService.DeleteStepMappingAsync(OwnerProcess.ProcessKey, toDeleteMapping.StepLinkKey, comment);

                HideWait();
                Messenger.Default.Send(new ProcessChangedMessage() { ChangeType = ObjectChangeType.Updated, ProcessKey = OwnerProcess.ProcessKey });

                Refresh();

                MessageBoxService.ShowMessage($"Process '{OwnerProcess.ProcessKey}' deleted Step Mapping '{toDeleteMapping.StepLinkKey}'!", "Success", MessageButton.OK, MessageIcon.Information);

            }
        }

        public bool CanDelete()
        {
            return SelectedStepMapping != null;
        }

        protected override string GetError(string columnName)
        {
            switch (columnName)
            {
                case nameof(MeasureType):
                    return DataValidator.ValidString(MeasureType);
                case nameof(LinkStep):
                    return DataValidator.ValidString(LinkStep);
                default:
                    return null;
            }
        }


        #region Properties

        public ProcessModel OwnerProcess
        {
            get { return GetValue<ProcessModel>(); }
            set { SetValue(value); }
        }

        public string LinkStep
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(LinkStep));
            }
        }

        public string MeasureType
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(MeasureType));
            }
        }

        public List<string> MeasureTypeList
        {
            get { return GetValue<List<string>>(); }
            set { SetValue(value); }
        }

        public ObservableCollection<StepLink> StepMappingList
        {
            get { return GetValue<ObservableCollection<StepLink>>(); }
            set { SetValue(value); }
        }

        public StepLink SelectedStepMapping
        {
            get { return GetValue<StepLink>(); }
            set { SetValue(value); }
        }

        #endregion
    }
}
