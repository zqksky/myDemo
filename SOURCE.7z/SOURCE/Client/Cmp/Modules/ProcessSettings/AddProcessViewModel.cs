﻿using System;
using AMAT.R2R.Client.Common.Enums;
using AMAT.R2R.Client.Common.Helpers;
using AMAT.R2R.Client.Common.ViewModels;
using AMAT.R2R.Client.Common.Views;
using AMAT.R2R.Client.Cmp.Messages;
using AMAT.R2R.Shared.Cmp.DTO;
using DevExpress.Mvvm;
using DevExpress.Mvvm.DataAnnotations;
using DevExpress.Mvvm.POCO;

namespace AMAT.R2R.Client.Cmp.Modules.ProcessSettings
{
    public class AddProcessViewModel : CmpViewModelBase
    {
        private const string NA = "NA";
        public AddProcessViewModel(Process process, FunctionMode mode)
        {
            OriginalProcess = process;
            Mode = mode;

            if (process != null)
            {
                Fab = process.Fab;
                Product = process.Product;
                Step = process.ProcessStep;
            }
            else
            {
                Fab = ClientInfo.LoginFab;
            }

            SizeToContent = System.Windows.SizeToContent.Manual;

            Caption = Mode == FunctionMode.Modify ? "Edit Process" : "New Process";
            IsDirty = false;
        }

        protected override void OnViewReadyAsync()
        {
            if (Mode == FunctionMode.Add)
            {
                SetFocus(nameof(Product));
            }
        }

        [Command]
        public async void Save()
        {
            ValidateAndSetErrorFocus(nameof(Fab), nameof(Product), nameof(Step));

            if (HasErrors)
            {
                return;
            }

            // 
            if (IsConfirmed(out string comment))
            {
                var newProcess = new Process
                {
                    Fab = Fab,
                    Product = Product,
                    ProcessStep = Step,
                    LastModifiedBy = OriginalProcess?.LastModifiedBy,
                    LastModifiedTime = OriginalProcess != null ? OriginalProcess.LastModifiedTime : DateTime.MinValue
                };

                if (Mode == FunctionMode.Modify)
                {
                    ShowWait();
                    await ProcessService.ModifyProcessAsync(newProcess.ProcessKey, newProcess, comment);
                    IsDirty = false;
                    HideWait();
                    Messenger.Default.Send(new ProcessChangedMessage() { ChangeType = ObjectChangeType.Updated, ProcessKey = OriginalProcess.ProcessKey });
                    MessageBoxService.ShowMessage($"Process {newProcess.ProcessKey} is updated!", "Success", MessageButton.OK, MessageIcon.Information);
                }
                else
                {
                    ShowWait();
                    var createdProcess = await ProcessService.CreateProcessAsync(newProcess, comment);
                    IsDirty = false;
                    HideWait();
                    Messenger.Default.Send(new ProcessChangedMessage() { ChangeType = ObjectChangeType.Created, ProcessKey = createdProcess.ProcessKey });
                    MessageBoxService.ShowMessage($"Process {createdProcess.ProcessKey} is created!", "Success", MessageButton.OK, MessageIcon.Information);
                }

                IsOK = true;
                CloseWindow();
            }
        }

        public bool CanSave()
        {
            switch (Mode)
            {
                case FunctionMode.Add:
                    return true;
                case FunctionMode.Modify:
                    return IsDirty;
                default:
                    return true;
            }
        }

        protected override string GetError(string columnName)
        {
            switch (columnName)
            {
                case nameof(Fab):
                    return DataValidator.ValidString(Fab);
                case nameof(Product):
                    return DataValidator.ValidString(Product);
                case nameof(Step):
                    return DataValidator.ValidString(Step);
                default:
                    return null;
            }
        }


        #region Properties
        public Process OriginalProcess { get; private set; }

        public Process SubmittedProcess { get; set; }


        public string Fab
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(Fab));
            }
        }

        public string Product
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(Product));
            }
        }

        public string Step
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(Step));
            }
        }


        #endregion
    }
}
