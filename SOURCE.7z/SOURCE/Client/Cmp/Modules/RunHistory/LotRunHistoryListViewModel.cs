﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Dynamic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Data;
using AMAT.R2R.Client.Common.Helpers;
using AMAT.R2R.Client.Common.Services;
using AMAT.R2R.Shared.Cmp.DTO;
using DevExpress.Mvvm;
using DevExpress.Xpf.Data;

namespace AMAT.R2R.Client.Cmp.Modules.RunHistory
{
    public class LotRunHistoryListViewModel : CmpViewModelBase
    {
        public LotRunHistoryListViewModel()
        {
            Caption = "Lot History - Detail View";
            Icon = "SvgImages/Business Objects/BO_Audit_ChangeHistory.svg";
            PropertyChanged += OnPropertyChanged;
            ViewType = ViewType.Detail;
            IsVisibleBasicTool = true;
            IsVisibleBasicRecipe = false;
            IsVisibleInfoRecipe = true;
            IsVisibleBasicRecipe = false;
            IsTimeRangeMode = true;
        }

        #region Events

        protected async override void OnViewReadyAsync()
        {
            await ResetFilterValueListAsync();
        }

        public override void OnRemoving(CancelEventArgs e)
        {
            base.OnRemoving(e);
        }

        private void OnPropertyChanged(object sender, System.ComponentModel.PropertyChangedEventArgs e)
        {
            if (e.PropertyName == nameof(ViewType))
            {

            }
        }

        #endregion

        #region Commands

        internal async Task ResetFilterValueListAsync()
        {
            ShowWait();
            MasterList = new List<ExpandoObject>();
            DetailList = new List<ExpandoObject>();
            ToolList = (await LotRunHistoryService.GetLotRunHistoryValueListAsync(nameof(LotRunHistory.ProcessToolId), null)).Select(t => t?.ToString()).ToList();
            ProductList = (await LotRunHistoryService.GetLotRunHistoryValueListAsync(nameof(LotRunHistory.Product), null)).Select(t => t?.ToString()).ToList();
            //ChamberList = (await LotRunHistoryService.GetLotRunHistoryValueListAsync(nameof(LotRunHistory.RootLot), null)).Select(t => t?.ToString()).ToList();
            //StageList = (await LotRunHistoryService.GetLotRunHistoryValueListAsync(nameof(LotRunHistory.Stage), null)).Select(t => t?.ToString()).ToList();
            RecipeList = (await LotRunHistoryService.GetLotRunHistoryValueListAsync(nameof(LotRunHistory.ProcessRecipe), null)).Select(t => t?.ToString()).ToList();
            HideWait();
        }

        internal async Task RefreshAsync(List<QueryFilter> filters = null, List<QuerySorter> sorters = null, int? skip = null, int? take = null)
        {
            ShowWait();
            try
            {
                MasterList = new List<ExpandoObject>();
                DetailList = new List<ExpandoObject>();
                var list = await LotRunHistoryService.GetLotRunHistoryListAsync(filters, sorters, skip, take);

                if (list.Count > 0)
                {
                    switch (ViewType)
                    {
                        case ViewType.ByTool:
                            MasterList = list.GroupBy(h => h.ProcessToolId).Select(g => CreateMasterRow(g)).ToList();
                            break;
                        case ViewType.ByRecipe:
                            MasterList = list.GroupBy(h => h.ProcessRecipe).Select(g => CreateMasterRow(g)).ToList();
                            break;
                        case ViewType.Detail:
                            bool hasDuplicateLot = false;
                            var detailList = list.Select(l => CreateDetailRow(l)).ToList();
                            var duplicateList = new List<string>();
                            foreach (var item in detailList)
                            {
                                var detail = item as IDictionary<string, object>;
                                var id = detail["Id"];
                                foreach (var item2 in detailList)
                                {
                                    var detail2 = item2 as IDictionary<string, object>;
                                    if(detail != detail2)
                                    {
                                        var id2 = detail2["Id"];
                                        if(id.ToString() == id2.ToString())
                                        {
                                            duplicateList.Add(id.ToString());
                                            hasDuplicateLot = true;
                                        }
                                    }
                                }
                            }

                            if(!hasDuplicateLot)
                            {
                                DetailList = detailList;
                            }
                            else
                            {
                                var sb = new StringBuilder();
                                foreach (var id in duplicateList.Distinct())
                                {
                                    sb.AppendLine(id.ToString());
                                }
                                MessageBoxService.ShowMessage(sb.ToString(), "Duplicated Lot Data.", MessageButton.OK, MessageIcon.Error);
                            }

                            break;
                        default:
                            break;
                    }
                }
                else
                {
                    MasterList = new List<ExpandoObject>();
                    DetailList = new List<ExpandoObject>();
                }
            }
            finally
            {
                HideWait();
            }
        }

        private ExpandoObject CreateMasterRow(IGrouping<string, LotRunHistory> group)
        {
            IDictionary<string, object> masterRow = new ExpandoObject();

            var lastProcessedRun = group.FirstOrDefault(l => l.ProcessStamp == group.Max(h => h.ProcessStamp));

            if (lastProcessedRun != null)
            {
                // fill detail info.
                masterRow = FillDynamicObjectByRunHistory(lastProcessedRun, masterRow);

                // fill master info.

                // basic
                masterRow[nameof(LotRunHistory.ProcessToolId)] = lastProcessedRun.ProcessToolId;
                masterRow["ProcessedLot"] = group.Count();
                masterRow["ProcessedWafer"] = group.Aggregate(0, (cnt, history) => cnt + history.WaferQty);

                // last process info
                masterRow["Date"] = lastProcessedRun.ProcessStamp;

                masterRow["Mode"] = "";
            }

            List<ExpandoObject> detailList = new List<ExpandoObject>();

            foreach (var item in group)
            {
                detailList.Add(CreateDetailRow(item));
            }

            masterRow["DetailList"] = detailList;
            masterRow["SelectedDetail"] = detailList.FirstOrDefault();

            return masterRow as ExpandoObject;
        }

        private ExpandoObject CreateDetailRow(LotRunHistory runHistory)
        {
            IDictionary<string, object> detailRow = new ExpandoObject();
            return FillDynamicObjectByRunHistory(runHistory, detailRow);
        }

        private ExpandoObject FillDynamicObjectByRunHistory(LotRunHistory item, IDictionary<string, object> dynamicObject)
        {
            dynamicObject[nameof(LotRunHistory.LotId)] = item.LotId;
            dynamicObject[nameof(LotRunHistory.WaferId)] = item.WaferId;
            dynamicObject[nameof(LotRunHistory.Fab)] = item.Fab;
            dynamicObject[nameof(LotRunHistory.Product)] = item.Product;
            dynamicObject[nameof(LotRunHistory.ProcessRecipe)] = item.ProcessRecipe;
            dynamicObject[nameof(LotRunHistory.WaferList)] = item.WaferList;
            dynamicObject[nameof(LotRunHistory.ModelGroup)] = item.ModelGroup;
            dynamicObject[nameof(LotRunHistory.ProcessToolId)] = item.ProcessToolId;
            dynamicObject[nameof(LotRunHistory.ProcessStep)] = item.ProcessStep;
            dynamicObject[nameof(LotRunHistory.WaferQty)] = item.WaferQty;
            dynamicObject[nameof(LotRunHistory.ProcessStamp)] = item.ProcessStamp;
            dynamicObject[nameof(LotRunHistory.EstiTimeStamp)] = item.EstiTimeStamp;           
            dynamicObject[nameof(LotRunHistory.RecLevel)] = item.RecLevel;
            dynamicObject[nameof(LotRunHistory.R2RMode)] = item.R2RMode;
            dynamicObject[nameof(LotRunHistory.FbLevel)] = item.FbLevel;
            dynamicObject[nameof(LotRunHistory.Attribute)] = item.Attribute;
            dynamicObject[nameof(LotRunHistory.ProcessLocation)] = item.ProcessLocation;
            //dynamicObject[nameof(LotRunHistory.ReworkCnt)] = int.Parse(item.ReworkCnt);
            dynamicObject[nameof(LotRunHistory.SpecifyLot)] = item.SpecifyLot;
            dynamicObject[nameof(LotRunHistory.SplitId)] = item.SplitId;
            dynamicObject[nameof(LotRunHistory.RunCardId)] = item.RunCardId;
            dynamicObject[nameof(LotRunHistory.Feedback)] = item.Feedback;
            dynamicObject[nameof(LotRunHistory.Remark)] = item.Remark;
            dynamicObject[nameof(LotRunHistory.PilotFlag)] = item.PilotFlag;
            dynamicObject[nameof(LotRunHistory.TxId)] = item.TxId;
            dynamicObject[nameof(LotRunHistory.Id)] = item.Id;
            dynamicObject[nameof(LotRunHistory.ParentId)] = item.ParentId;
            dynamicObject[nameof(LotRunHistory.LotType)] = item.LotType;

            if (item.ProcessVaues != null)
            {
                for (var i = 0; i < item.ProcessVaues.Count; i++)
                {
                    var parameter = item.ProcessVaues[i];
                    dynamicObject[$"P_{i}_{parameter?.Name}"] = parameter == null ? null : parameter.IsNumeric ? NullableDataConverter.Convert<decimal>(parameter.Value) : (object)parameter.Value;
                }
            }

            if (item.EstimateValues != null)
            {
                for (var i = 0; i < item.EstimateValues.Count; i++)
                {
                    var parameter = item.EstimateValues[i];
                    dynamicObject[$"E_{i}_{parameter?.Name}"] = parameter == null ? null : parameter.IsNumeric ? NullableDataConverter.Convert<decimal>(parameter.Value) : (object)parameter.Value;
                }
            }

            if (item.PostMetrologyValues != null)
            {
                for (var i = 0; i < item.PostMetrologyValues.Count; i++)
                {
                    var parameter = item.PostMetrologyValues[i];
                    dynamicObject[$"M1_{i}_{parameter?.Name}"] = parameter == null ? null : parameter.IsNumeric ? NullableDataConverter.Convert<decimal>(parameter.Value) : (object)parameter.Value;
                }
            }

            if (item.PreMetrologyValues != null)
            {
                for (var i = 0; i < item.PreMetrologyValues.Count; i++)
                {
                    var parameter = item.PreMetrologyValues[i];
                    dynamicObject[$"M2_{i}_{parameter.Name}"] = parameter == null ? null : parameter.IsNumeric ? NullableDataConverter.Convert<decimal>(parameter.Value) : (object)parameter.Value;
                }
            }

            if (item.DefaultRecSettings != null)
            {
                for (var i = 0; i < item.DefaultRecSettings.Count; i++)
                {
                    var parameter = item.DefaultRecSettings[i];
                    dynamicObject[$"D_{i}_{parameter.Name}"] = parameter == null ? null : parameter.IsNumeric ? NullableDataConverter.Convert<decimal>(parameter.Value) : (object)parameter.Value;
                }
            }

            if (item.RecSettings != null)
            {
                for (var i = 0; i < item.RecSettings.Count; i++)
                {
                    var parameter = item.RecSettings[i];
                    dynamicObject[$"R_{i}_{parameter.Name}"] = parameter == null ? null : parameter.IsNumeric ? NullableDataConverter.Convert<decimal>(parameter.Value) : (object)parameter.Value;
                }
            }

            if (item.FinalRecSettings != null)
            {
                for (var i = 0; i < item.FinalRecSettings.Count; i++)
                {
                    var parameter = item.FinalRecSettings[i];
                    dynamicObject[$"F_{i}_{parameter.Name}"] = parameter == null ? null : parameter.IsNumeric ? NullableDataConverter.Convert<decimal>(parameter.Value) : (object)parameter.Value;
                }
            }

            //by zqk modify
            //if (item.FFOffsets != null)
            //{
            //    for (var i = 0; i < item.FFOffsets.Count; i++)
            //    {
            //        var parameter = item.FFOffsets[i];
            //        dynamicObject[$"C_{i}_{parameter.Name}"] = parameter == null ? null : parameter.IsNumeric ? NullableDataConverter.Convert<decimal>(parameter.Value) : (object)parameter.Value;
            //    }
            //}

            //if (item.LifeTime != null)
            //{
            //    for (var i = 0; i < item.LifeTime.Count; i++)
            //    {
            //        var parameter = item.LifeTime[i];
            //        dynamicObject[$"L_{i}_{parameter.Name}"] = parameter == null ? null : parameter.IsNumeric ? NullableDataConverter.Convert<decimal>(parameter.Value) : (object)parameter.Value;
            //    }
            //}

            //if (item.LifeTimeOffsets != null)
            //{
            //    for (var i = 0; i < item.LifeTimeOffsets.Count; i++)
            //    {
            //        var parameter = item.LifeTimeOffsets[i];
            //        dynamicObject[$"L2_{i}_{parameter.Name}"] = parameter == null ? null : parameter.IsNumeric ? NullableDataConverter.Convert<decimal>(parameter.Value) : (object)parameter.Value;
            //    }
            //}

            return dynamicObject as ExpandoObject;
        }

        public bool CanRefresh()
        {
            return !IsLoading;
        }


        #endregion

        #region Properties

        public bool IsVisibleBasicTool
        {
            get { return GetValue<bool>(); }
            set { SetValue(value); }
        }

        public bool IsVisibleBasicRecipe
        {
            get { return GetValue<bool>(); }
            set { SetValue(value); }
        }

        public bool IsVisibleInfoTool
        {
            get { return GetValue<bool>(); }
            set { SetValue(value); }
        }

        public bool IsVisibleInfoRecipe
        {
            get { return GetValue<bool>(); }
            set { SetValue(value); }
        }

        public bool IsTimeRangeMode
        {
            get { return GetValue<bool>(); }
            set { SetValue(value); }
        }
        public bool IsLastNDayMode
        {
            get { return GetValue<bool>(); }
            set { SetValue(value); }
        }
        public bool IsLastNRunMode
        {
            get { return GetValue<bool>(); }
            set { SetValue(value); }
        }

        public List<ExpandoObject> MasterList
        {
            get { return GetValue<List<ExpandoObject>>(); }
            set { SetValue(value); }
        }

        public List<ExpandoObject> DetailList
        {
            get { return GetValue<List<ExpandoObject>>(); }
            set { SetValue(value); }
        }

        public ExpandoObject SelectedMaster
        {
            get { return GetValue<ExpandoObject>(); }
            set { SetValue(value); }
        }

        public List<string> ToolList
        {
            get { return GetValue<List<string>>(); }
            set { SetValue(value); }
        }

        public List<string> ProductList
        {
            get { return GetValue<List<string>>(); }
            set { SetValue(value); }
        }
        public List<string> ChamberList
        {
            get { return GetValue<List<string>>(); }
            set { SetValue(value); }
        }

        public List<string> StageList
        {
            get { return GetValue<List<string>>(); }
            set { SetValue(value); }
        }

        public List<string> RecipeList
        {
            get { return GetValue<List<string>>(); }
            set { SetValue(value); }
        }

        public List<string> OvlModelList
        {
            get { return GetValue<List<string>>(); }
            set { SetValue(value); }
        }


        public ViewType ViewType
        {
            get { return GetValue<ViewType>(); }
            set { SetValue(value); }
        }

        #endregion
    }

    public class ViewTypeToBooleanConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            ViewType itemType = (ViewType)parameter;
            ViewType newValue = (ViewType)value;
            return itemType == newValue;
        }
        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            if ((bool)value)
                return (ViewType)parameter;
            return Binding.DoNothing;
        }
    }

    public enum ViewType
    {
        Detail,
        ByTool,
        ByRecipe,
    }
}
