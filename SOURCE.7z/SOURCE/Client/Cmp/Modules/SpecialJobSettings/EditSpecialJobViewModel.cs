﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using AMAT.R2R.Client.Cmp.Messages;
using AMAT.R2R.Client.Common.Enums;
using AMAT.R2R.Client.Common.Helpers;
using AMAT.R2R.Shared.Cmp.DTO;
using DevExpress.Mvvm;
using DevExpress.Mvvm.DataAnnotations;
using Newtonsoft.Json;

namespace AMAT.R2R.Client.Cmp.Modules.SpecialJobSettings
{
    public class EditSpecialJobViewModel : CmpViewModelBase
    {
        private const string NA = "NA";
        public EditSpecialJobViewModel(Context context, List<Context> currentContextList, SpecialJob sourceSpecialJob, FunctionMode mode)
        {
            CurrentContext = context;
            SizeToContent = System.Windows.SizeToContent.Manual;
            WindowHeight = 600;
            WindowWidth = 1000;
            SourceSpecialJob = sourceSpecialJob;
            Mode = mode;

            switch (mode)
            {
                case FunctionMode.None:
                    break;
                case FunctionMode.Add:
                    Caption = "Create Special Job";
                    break;
                case FunctionMode.Copy:
                    Caption = "Copy Special Job";
                    break;
                case FunctionMode.Modify:
                    Caption = "Edit Special Job";
                    break;
                case FunctionMode.Delete:
                    break;
                case FunctionMode.View:
                    break;
                default:
                    break;
            }
            if (currentContextList != null)
            {
                currentContextList = currentContextList.Where(p => p.ContextInputParas.Count > 0).ToList();
                CurrentContextList = new List<Context>(currentContextList);
                ModelGroupList = new ObservableCollection<string>(CurrentContextList.Select(p => p.ModelGroup).ToList());

                //SelectedModelGroups = new List<object>(ModelGroupList);

                SelectedModelGroups = new List<object>();
                SelectedModelGroups.Add(CurrentContext.ModelGroup);
            }
            else
            {
                ModelGroupList = new ObservableCollection<string>();

                //SelectedModelGroups = new List<object>(ModelGroupList);

                SelectedModelGroups = new List<object>();
                SelectedModelGroups.Add(SourceSpecialJob.ModelGroup);
            }
        }

        protected override void OnViewReadyAsync()
        {
            Refresh();
        }

        private void Refresh()
        {
            ShowWait();
            NewSpecialJobList = new List<SpecialJob>();
            if (Mode != FunctionMode.Add)
            {
                // clone source job.
                NewSpecialJob = JsonConvert.DeserializeObject<SpecialJob>(JsonConvert.SerializeObject(SourceSpecialJob));

                JobParameterList = new ObservableCollection<SpecialJobInputSetting>(NewSpecialJob.SpecialJobParameters.Select(p =>
                new SpecialJobInputSetting()
                {
                    ModelGroup = NewSpecialJob.ModelGroup,
                    ParameterName = p.ParameterName,
                    InputValue = p.InputValue,
                    Min = p.Min,
                    Max = p.Max,
                    Unit = p.Unit
                }));

                NewSpecialJobList.Add(NewSpecialJob);
            }
            else
            {
                List<SpecialJobInputSetting> ModelGroupParameterList =new List<SpecialJobInputSetting>();
                foreach (var context in CurrentContextList)
                {
                    NewSpecialJob = new SpecialJob
                    {
                        //by zqk note
                        Fab = context.Fab,
                        Product = context.Product,
                        Tool = context.Tool,
                        Recipe = context.Recipe,
                        ProcessStep = context.ProcessStep,
                        ModelGroup = context.ModelGroup,

                        // create default parameters
                        SpecialJobParameters = context.GetDefaultSpecialJobParameters(),

                        LotId = string.Empty,
                        RuncardId = NA,
                        SplitId = NA,
                    };

                    var JobParameterListTmp = new List<SpecialJobInputSetting>(NewSpecialJob.SpecialJobParameters.Select(p =>
                    new SpecialJobInputSetting()
                    {
                        ModelGroup = context.ModelGroup,
                        ParameterName = p.ParameterName,
                        InputValue = p.InputValue,
                        Min = p.Min,
                        Max = p.Max,
                        Unit = p.Unit
                    }));

                    NewSpecialJobList.Add(NewSpecialJob);

                    ModelGroupParameterList = ModelGroupParameterList.Concat(JobParameterListTmp).ToList<SpecialJobInputSetting>();
                }
                JobParameterList = new ObservableCollection<SpecialJobInputSetting>(ModelGroupParameterList);
            }

            foreach (var param in JobParameterList)
            {
                param.PropertyChanged += Param_PropertyChanged;
            }

            IsLot = NewSpecialJob.LotId != NA;
            LotId = NewSpecialJob.LotId;
            RunCardId = NewSpecialJob.RuncardId;
            SplitId = NewSpecialJob.SplitId;

            HideWait();

            IsDirty = false;
        }

        private void Param_PropertyChanged(object sender, System.ComponentModel.PropertyChangedEventArgs e)
        {
            if (e.PropertyName == nameof(SpecialJobInputSetting.InputValue))
            {
                IsDirty = true;

                ClearError($"{nameof(JobParameterList)}.{e.PropertyName}");
            }
        }

        [Command]
        public void ModelGroupEditValueChanged()
        {
            if (Mode == FunctionMode.Modify)
            {
                return;
            }
            if (ModelGroupList.Count > 0)
            {
                if (SelectedModelGroups == null || SelectedModelGroups.Count<1 )
                {
                    return;
                }
                NewSpecialJobList = new List<SpecialJob>();
                SelectedModelGroupList = new List<string>();
                foreach (var s in SelectedModelGroups)
                {
                    SelectedModelGroupList.Add(s.ToString());
                }
                List<SpecialJobInputSetting> ModelGroupParameterList = new List<SpecialJobInputSetting>();
                foreach (var context in CurrentContextList)
                {
                    if (!SelectedModelGroupList.Contains(context.ModelGroup))
                    {
                        continue;
                    }
                    NewSpecialJob = new SpecialJob
                    {
                        //by zqk note
                        Fab = context.Fab,
                        Product = context.Product,
                        Tool = context.Tool,
                        Recipe = context.Recipe,
                        ProcessStep = context.ProcessStep,
                        ModelGroup = context.ModelGroup,

                        // create default parameters
                        SpecialJobParameters = context.GetDefaultSpecialJobParameters(),

                        LotId = string.Empty,
                        RuncardId = NA,
                        SplitId = NA,
                    };

                    var JobParameterListTmp = new List<SpecialJobInputSetting>(NewSpecialJob.SpecialJobParameters.Select(p =>
                    new SpecialJobInputSetting()
                    {
                        ModelGroup = context.ModelGroup,
                        ParameterName = p.ParameterName,
                        InputValue = p.InputValue,
                        Min = p.Min,
                        Max = p.Max,
                        Unit = p.Unit
                    }));

                    NewSpecialJobList.Add(NewSpecialJob);

                    ModelGroupParameterList = ModelGroupParameterList.Concat(JobParameterListTmp).ToList<SpecialJobInputSetting>();
                }
                JobParameterList = new ObservableCollection<SpecialJobInputSetting>(ModelGroupParameterList);
            }
        }
        public bool CanModelGroupEditValue()
        {
            return true;
        }

        [Command]
        public async void Save()
        {
            if (IsLot)
            {
                ValidateAndSetErrorFocus(nameof(LotId));
            }
            else
            {
                ValidateAndSetErrorFocus(nameof(RunCardId), nameof(SplitId));
            }

            if (HasErrors) return;

            foreach (var item in JobParameterList)
            {
                if (item.Error != null)
                {
                    SetError($"{nameof(JobParameterList)}.{item.Error}", item[item.Error]);
                    SetFocus(nameof(JobParameterList));
                    return;
                }
            }

            if (IsConfirmed(out var comment))
            {
                #region
                if (Mode == FunctionMode.Add || Mode == FunctionMode.Copy)
                {
                    List<string> RunModelGroup = new List<string>();
                    foreach (var newSpecialJob in NewSpecialJobList)
                    {
                        if (RunModelGroup.Contains(newSpecialJob.ModelGroup))
                        {
                            continue;
                        }
                        RunModelGroup.Add(newSpecialJob.ModelGroup);

                        //newSpecialJob.ModelGroup = newSpecialJob.ModelGroup;
                        newSpecialJob.LotId = LotId;
                        newSpecialJob.RuncardId = RunCardId;
                        newSpecialJob.SplitId = SplitId;

                        foreach (var param in newSpecialJob.SpecialJobParameters)
                        {
                            param.InputValue = JobParameterList.FirstOrDefault(p => p.ParameterName == param.ParameterName && p.ModelGroup == newSpecialJob.ModelGroup)?.InputValue;
                        }

                        try
                        {
                            newSpecialJob.JobId = string.Empty;
                            ShowWait();
                            var createdJob = await SpecialJobService.CreateSpecialJobAsync(newSpecialJob, comment);
                            HideWait();
                        }
                        catch (Exception ex)
                        {
                            failedSpecialJobList.Add(newSpecialJob);
                            sb.AppendLine(LocalizationService.LocalizeException(ex));
                        }

                    }


                    var successCount = NewSpecialJobList.Count - failedSpecialJobList.Count;

                    if (successCount > 0)
                    {
                        var successSpecialJobList = NewSpecialJobList.Except(failedSpecialJobList);
                        foreach (var specialJob in successSpecialJobList)
                        {
                            Messenger.Default.Send(new SpecialJobChangedMessage() { ChangeType = ObjectChangeType.Created, JobId = specialJob.JobId });
                        }
                    }


                    // show error if any
                    if (failedSpecialJobList.Count <= 0)
                    {
                        MessageBoxService.ShowMessage($"{NewSpecialJobList.Count} SpecialJob's Updated successfully.", "Success", MessageButton.OK, MessageIcon.Information);
                    }
                    else
                    {
                        MessageBoxService.ShowMessage(sb.ToString(), $"Success Count: {successCount} Failed Count: { failedSpecialJobList.Count} ", MessageButton.OK, MessageIcon.Error);
                    }
                }
                else
                {
                    NewSpecialJob.LotId = LotId;
                    NewSpecialJob.RuncardId = RunCardId;
                    NewSpecialJob.SplitId = SplitId;

                    foreach (var param in NewSpecialJob.SpecialJobParameters)
                    {
                        param.InputValue = JobParameterList.FirstOrDefault(p => p.ParameterName == param.ParameterName)?.InputValue;
                    }
                    ShowWait();
                    await SpecialJobService.UpdateSpecialJobAsync(NewSpecialJob.JobId, NewSpecialJob, comment);
                    IsDirty = false;
                    HideWait();
                    Messenger.Default.Send(new SpecialJobChangedMessage() { ChangeType = ObjectChangeType.Updated, JobId = NewSpecialJob.JobId });
                    MessageBoxService.ShowMessage($"Special Job is updated!", "Success", MessageButton.OK, MessageIcon.Information);
                }
                #endregion

                #region New Test
                //if (Mode == FunctionMode.Add || Mode == FunctionMode.Copy)
                //{
                //    foreach (var newSpecialJob in NewSpecialJobList)
                //    {
                //        //newSpecialJob.ModelGroup = newSpecialJob.ModelGroup;
                //        newSpecialJob.LotId = LotId;
                //        newSpecialJob.RuncardId = RunCardId;
                //        newSpecialJob.SplitId = SplitId;

                //        foreach (var param in newSpecialJob.SpecialJobParameters)
                //        {
                //            param.InputValue = JobParameterList.FirstOrDefault(p => p.ParameterName == param.ParameterName && p.ModelGroup == newSpecialJob.ModelGroup)?.InputValue;
                //        }
                //    }

                //    StringBuilder sb = new StringBuilder();

                //    ShowWait();
                //    //await Task.Delay(5000);
                //    var taskList = NewSpecialJobList.Select(c => SpecialJobService.CreateSpecialJobAsync(c, comment)).ToList();

                //    try
                //    {
                //        await Task.WhenAll(taskList);
                //    }
                //    catch (Exception)
                //    {
                //        // ignore.
                //    }

                //    HideWait();
                //    int successCount = taskList.Count - taskList.Count(t => t.IsFaulted);

                //    if (successCount > 0)
                //    {
                //        Messenger.Default.Send(new SpecialJobChangedMessage() { ChangeType = ObjectChangeType.Created, JobId = NewSpecialJob.JobId });
                //    }
                //    if (taskList.Any(t => t.IsFaulted))
                //    {
                //        //var taskListFaulted = taskList.Where(c => c.IsFaulted).ToList();
                //        //foreach (var ex in taskListFaulted.Select(t => t.Exception))
                //        //{
                //        //    sb.AppendLine(LocalizationService.LocalizeException(ex));
                //        //}

                //        foreach (var ex in taskList.Where(t => t.IsFaulted).Select(t => t.Exception))
                //        {
                //            sb.AppendLine(LocalizationService.LocalizeException(ex));
                //        }
                //        MessageBoxService.ShowMessage(sb.ToString(), $"Success Count: {successCount} Failed Count: { taskList.Count(t => t.IsFaulted)} ", MessageButton.OK, MessageIcon.Error);
                //    }
                //    else
                //    {
                //        if (Mode == FunctionMode.Add)
                //        {
                //            MessageBoxService.ShowMessage($"{NewSpecialJobList.Count} Special Job created successfully.", "Success", MessageButton.OK, MessageIcon.Information);
                //        }
                //        else
                //        {
                //            MessageBoxService.ShowMessage($"{NewSpecialJobList.Count} Special Job copied successfully.", "Success", MessageButton.OK, MessageIcon.Information);
                //        }
                //    }
                //}
                //else
                //{
                //    NewSpecialJob.LotId = LotId;
                //    NewSpecialJob.RuncardId = RunCardId;
                //    NewSpecialJob.SplitId = SplitId;

                //    foreach (var param in NewSpecialJob.SpecialJobParameters)
                //    {
                //        param.InputValue = JobParameterList.FirstOrDefault(p => p.ParameterName == param.ParameterName)?.InputValue;
                //    }
                //    ShowWait();
                //    await SpecialJobService.UpdateSpecialJobAsync(NewSpecialJob.JobId, NewSpecialJob, comment);
                //    IsDirty = false;
                //    HideWait();
                //    Messenger.Default.Send(new SpecialJobChangedMessage() { ChangeType = ObjectChangeType.Updated, JobId = NewSpecialJob.JobId });
                //    MessageBoxService.ShowMessage($"Special Job is updated!", "Success", MessageButton.OK, MessageIcon.Information);
                //}
                #endregion


                // show updated list.
                Refresh();               

                CloseWindow();
            }
        }

        public bool CanSave()
        {
            return true;
        }

        protected override string GetError(string columnName)
        {
            switch (columnName)
            {
                case nameof(LotId):
                    if (IsLot)
                    {
                        return DataValidator.ValidateInOrder(
                            () => DataValidator.NotNull(LotId),
                            () => LotId == NA ? "Cannot be NA" : null);
                    }
                    else
                    {
                        return LotId == NA ? null : "Must be NA";
                    }
                case nameof(RunCardId):
                    if (IsLot)
                    {
                        return RunCardId == NA ? null : "Must be NA";
                    }
                    else
                    {
                        return DataValidator.ValidateInOrder(
                            () => DataValidator.NotNull(RunCardId),
                            () => DataValidator.UTF8StringMaxLength(RunCardId, 64),
                            () => RunCardId == NA ? "Cannot be NA" : null);
                    }
                case nameof(SplitId):
                    if (IsLot)
                    {
                        return SplitId == NA ? null : "Must be NA";
                    }
                    else
                    {
                        return DataValidator.ValidateInOrder(
                            () => DataValidator.NotNull(SplitId),
                            () => DataValidator.UTF8StringMaxLength(SplitId, 64),
                            () => SplitId == NA ? "Cannot be NA" : null);
                    }
                default:
                    return null;
            }
        }

        public void SetRunCardIdNA() => RunCardId = NA;
        public void SetSplitIdNA() => SplitId = NA;

        #region Properties

        public List<Context> CurrentContextList
        {
            get { return GetValue<List<Context>>(); }
            set { SetValue(value); }
        }

        public string SelectedModelGroup
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(SelectedModelGroup));
            }
        }
        public List<object> SelectedModelGroups
        {
            get { return GetValue<List<object>>(); }
            set
            {
                SetValue(value);
                ClearError(nameof(SelectedModelGroups));
            }
        }
        public ObservableCollection<string> ModelGroupList
        {
            get { return GetValue<ObservableCollection<string>>(); }
            set { SetValue(value); }
        }

        public List<string> SelectedModelGroupList
        {
            get { return GetValue<List<string>>(); }
            set { SetValue(value); }
        }
        public int ContextKey { get; set; }

        public Context CurrentContext
        {
            get { return GetValue<Context>(); }
            set { SetValue(value); }
        }

        public SpecialJob SourceSpecialJob
        {
            get { return GetValue<SpecialJob>(); }
            set { SetValue(value); }
        }

        public SpecialJob NewSpecialJob
        {
            get { return GetValue<SpecialJob>(); }
            set { SetValue(value); }
        }

        public List<SpecialJob> NewSpecialJobList
        {
            get { return GetValue<List<SpecialJob>>(); }
            set { SetValue(value); }
        }
        List<SpecialJob> failedSpecialJobList = new List<SpecialJob>();
        StringBuilder sb = new StringBuilder();

        public ObservableCollection<SpecialJobInputSetting> JobParameterList
        {
            get { return GetValue<ObservableCollection<SpecialJobInputSetting>>(); }
            set { SetValue(value); }
        }


        public string LotId
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(LotId));
            }
        }

        public string RunCardId
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(RunCardId));
            }
        }

        public string SplitId
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(SplitId));
            }
        }

        public bool IsLot
        {
            get { return GetValue<bool>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(IsLot));
                if (value)
                {
                    if (LotId == NA)
                    {
                        LotId = string.Empty;
                    }
                    RunCardId = NA;
                    SplitId = NA;
                }
                else
                {
                    if (RunCardId == NA)
                    {
                        RunCardId = string.Empty;
                    }
                    if (SplitId == NA)
                    {
                        SplitId = string.Empty;
                    }
                    LotId = NA;
                }
            }
        }
        #endregion
    }

    public class SpecialJobInputSetting : BindableBase, IDataErrorInfo
    {
        public string ModelGroup { get; set; }
        public string ParameterName { get; set; }
        public string Unit { get; set; }

        public decimal? InputValue
        {
            get { return GetValue<decimal?>(); }
            set { SetValue(value); }
        }

        public decimal? Min { get; set; }
        public decimal? Max { get; set; }
        public string Error
        {
            get
            {
                //return !string.IsNullOrEmpty(this[nameof(InputValue)]) ? $"{nameof(InputValue)}" : null;
                return DataValidator.ValidateInOrder(
                           () => DataValidator.NotNull(InputValue),
                           () => DataValidator.InRange(InputValue, Min, Max));
            }
        }


        public string this[string propertyName]
        {
            get
            {
                switch (propertyName)
                {
                    case nameof(InputValue):
                        return DataValidator.NotNull(InputValue);
                        
                    default:
                        return null;
                }
            }
        }
    }
}
