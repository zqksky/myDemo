﻿using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Threading.Tasks;
using AMAT.R2R.Client.Cmp.Messages;
using AMAT.R2R.Client.Common.Enums;
using AMAT.R2R.Client.Common.Helpers;
using AMAT.R2R.Shared.Base.DTO;
using AMAT.R2R.Shared.Cmp.DTO;
using DevExpress.Mvvm;
using DevExpress.Mvvm.DataAnnotations;
using DevExpress.Xpf.Data;

namespace AMAT.R2R.Client.Cmp.Modules.SpecialJobSettings
{
    public class SpecialJobListViewModel : CmpViewModelBase
    {
        public const string Auth_SpecialJob = "SpecialJob";
        public const string Auth_SpecalJob_Copy = "SpecialJob:Copy";
        public const string Auth_SpecalJob_Edit = "SpecialJob:Edit";
        public const string Auth_SpecalJob_Delete = "SpecialJob:Delete";

        public SpecialJobListViewModel()
        {
            Caption = "Special Job Settings";
            Icon = "SvgImages/Snap/SnapHeader.svg";

            PropertyChanged += OnPropertyChanged;
            Messenger.Default.Register<SpecialJobChangedMessage>(this, OnSpecialJobChanged);

            InitializePagedSource();
        }

        #region Filtering & Paging

        private void InitializePagedSource()
        {
            #region Paged Source
            var pagedSource = new PagedAsyncSource()
            {
                ElementType = typeof(SpecialJobModel),
                PageSize = 100,
                PageNavigationMode = PageNavigationMode.ArbitraryWithTotalPageCount
            };

#if DEBUG
            pagedSource.PageSize = 10;
#endif

            pagedSource.FetchPage += (o, e) =>
            {
                e.Result = FetchPageRowsAsync(e);
            };

            pagedSource.GetTotalSummaries += (o, e) =>
            {
                e.Result = GetSummariesAsync(e);
            };

            pagedSource.GetUniqueValues += (o, e) =>
            {
                e.Result = GetValueListAsync(e);
            };

            pagedSource.PropertyChanged += (o, e) =>
            {
                if (e.PropertyName == nameof(PagedAsyncSource.AreRowsFetching))
                {
                    IsLoading = PagedSource.AreRowsFetching;

                    // restore selection.
                    if (!IsLoading)
                    {
                        if (_lastSelectedItem != null)
                        {
                            foreach (var item in PagedSource)
                            {
                                var job = item as SpecialJobModel;
                                if (job.JobId == _lastSelectedItem.JobId)
                                {
                                    SelectedSpecialJob = job;
                                    break;
                                }
                            }
                        }
                    }
                }
            };

            PagedSource = pagedSource;
            #endregion
        }

        SpecialJobModel _lastSelectedItem = null;
        private async Task<FetchRowsResult> FetchPageRowsAsync(FetchPageAsyncEventArgs e)
        {
            try
            {
                if (SelectedSpecialJob != null)
                {
                    _lastSelectedItem = SelectedSpecialJob;
                }

                var items = await SpecialJobService.GetSpecialJobListAsync(e.Filter.MakeFilters(), e.MakeSorters(), e.Skip, e.Take);
                return new FetchRowsResult(items.ToArray(), hasMoreRows: items.Count == e.Take);
            }
            catch (Exception ex)
            {
                Logger.Error(ex);
                throw;
            }
        }

        private async Task<object[]> GetSummariesAsync(GetSummariesAsyncEventArgs e)
        {
            try
            {
                var summary = await SpecialJobService.GetSpecialJobCount(e.Filter.MakeFilters());
                return e.Summaries.Select(x =>
                {
                    return x.SummaryType == SummaryType.Count ? (object)summary : throw new InvalidOperationException();
                }).ToArray();
            }
            catch (Exception ex)
            {
                Logger.Error(ex);
                throw;
            }
        }

        private async Task<object[]> GetValueListAsync(GetUniqueValuesAsyncEventArgs e)
        {
            try
            {
                if (e.PropertyName == nameof(SpecialJob.JobCompleted) || e.PropertyName == nameof(SpecialJob.IsValid))
                {
                    var values = new object[] { true, false };
                    return await Task.Factory.StartNew(() => values);
                }
                else
                {
                    return await SpecialJobService.GetSpecialJobValueListAsync(e.PropertyName, e.Filter.MakeFilters());
                }
            }
            catch (Exception ex)
            {
                Logger.Error(ex);
                throw;
            }
        }

        #endregion

        #region Events

        protected override void OnViewReadyAsync()
        {
            //Refresh();
        }
        public override void OnRemoving(CancelEventArgs e)
        {
            base.OnRemoving(e);

            PagedSource?.Dispose();
            Messenger.Default.Unregister<SpecialJobChangedMessage>(this, OnSpecialJobChanged);
        }

        private async void OnPropertyChanged(object sender, System.ComponentModel.PropertyChangedEventArgs e)
        {
            if (e.PropertyName == nameof(SelectedSpecialJob))
            {
                if (SelectedSpecialJob != null)
                {
                    await GetSpecialJobDetailsAsync();
                }
                else
                {
                    ClearSpecialJobDetails();
                }
            }
        }

        private void OnSpecialJobChanged(SpecialJobChangedMessage msg)
        {
            Refresh();
        }

        private async Task UpdateSingleSpecialJob(SpecialJobModel specialJob)
        {
            SpecialJobModel newSpecialJob = null;
            DateTime lastModifiedTime = specialJob.LastModifiedTime;
            newSpecialJob = await SpecialJobService.GetSpecialJobAsync(specialJob.JobId);
            specialJob.LotId = newSpecialJob.LotId;
            specialJob.RuncardId = newSpecialJob.RuncardId;
            specialJob.SplitId = newSpecialJob.SplitId;
            specialJob.CreateTime = newSpecialJob.CreateTime;
            specialJob.JobCompleted = newSpecialJob.JobCompleted;
            specialJob.NotifyChanges();

            if (SelectedSpecialJob != null && specialJob.JobId == SelectedSpecialJob.JobId && specialJob.LastModifiedTime != lastModifiedTime)
            {
                await GetSpecialJobDetailsAsync();
            }
        }
        #endregion

        #region Commands

        [Command]
        public void Refresh()
        {
            PagedSource.UpdateSummaries();
            PagedSource.RefreshRows();
        }
        public bool CanRefresh()
        {
            return !IsLoading;
        }

        private async Task GetSpecialJobDetailsAsync()
        {
            if (SelectedSpecialJob != null)
            {
                var targetJob = SelectedSpecialJob;
                var refreshedJob = await SpecialJobService.GetSpecialJobAsync(targetJob.JobId);
                targetJob.LastModifiedBy = refreshedJob.LastModifiedBy;
                targetJob.LastModifiedTime = refreshedJob.LastModifiedTime;
                targetJob.UsedTime = refreshedJob.UsedTime;
                targetJob.UserId = refreshedJob.UserId;
                targetJob.IsValid = refreshedJob.IsValid;
                targetJob.JobCompleted = refreshedJob.JobCompleted;
                targetJob.SpecialJobParameters = refreshedJob.SpecialJobParameters;
                targetJob.RuncardId = refreshedJob.RuncardId;
                targetJob.SplitId = refreshedJob.SplitId;
                targetJob.LotId = refreshedJob.LotId;
                targetJob.NotifyChanges();

                try
                {
                    //SpecialJobParameterList = new ObservableCollection<SpecialJobParametersModel>();
                    SpecialJobParameterList = new ObservableCollection<SpecialJobParametersModel>(SelectedSpecialJob.SpecialJobParameters.Select(p =>
                    new SpecialJobParametersModel()
                    {
                        ModelGroup = SelectedSpecialJob.ModelGroup,
                        ParameterName = p.ParameterName,
                        InputValue = p.InputValue,
                        Min = p.Min,
                        Max = p.Max,
                        Fixed = p.Fixed,
                        PM = p.PM,
                        Reset = p.Reset,
                        Unit = p.Unit,
                    }));

                    IsHistoryLoading = true;
                    HistoryList = new ObservableCollection<TransactionHistory>(await GlobalService.GetHistoryAsync(ClientInfo.LoginArea, "SpecialJob", targetJob.JobKey, null));
                }
                finally
                {
                    IsHistoryLoading = false;
                }
            }
            else
            {
                HistoryList?.Clear();
            }
        }

        [Command]
        public async void CopySpecialJob()
        {
            await RefreshBeforeAction(SelectedSpecialJob);
            ShowPopup("EditSpecialJob", new EditSpecialJobViewModel(null, null, SelectedSpecialJob, FunctionMode.Copy));
        }

        public bool CanCopySpecialJob()
        {
            return SelectedSpecialJob != null && SelectedSpecialJobList.Count == 1 && !IsLoading && AuthorityManager.HasAuthority(Auth_SpecalJob_Copy);
        }

        [Command]
        public async void EditSpecialJob()
        {
            await RefreshBeforeAction(SelectedSpecialJob);
            ShowPopup("EditSpecialJob", new EditSpecialJobViewModel(null, null, SelectedSpecialJob, FunctionMode.Modify));
        }

        public bool CanEditSpecialJob()
        {
            return SelectedSpecialJob != null && SelectedSpecialJobList.Count == 1 && !IsLoading && 
                SelectedSpecialJob.IsValid && !SelectedSpecialJob.JobCompleted && AuthorityManager.HasAuthority(Auth_SpecalJob_Edit);
        }

        [Command]
        public async void DeleteSpecialJob()
        {
            await RefreshBeforeAction(SelectedSpecialJob);
            if (IsConfirmed(out var comment, $"Delete Special Job"))
            {
                var toDeleteSpecialJob = SelectedSpecialJob;
                await SpecialJobService.DeleteSpecialJobAsync(SelectedSpecialJob.JobId, comment);
                Messenger.Default.Send(new SpecialJobChangedMessage() { ChangeType = ObjectChangeType.Deleted, JobId = toDeleteSpecialJob.JobId });
                MessageBoxService.ShowMessage($"SpecialJob {toDeleteSpecialJob.JobId} is deleted.", "Success", MessageButton.OK, MessageIcon.Information);
            }
        }

        public bool CanDeleteSpecialJob()
        {
            return SelectedSpecialJob != null && SelectedSpecialJobList.Count == 1 && !IsLoading && 
                (SelectedSpecialJob.IsValid && !SelectedSpecialJob.JobCompleted ) && AuthorityManager.HasAuthority(Auth_SpecalJob_Delete);
        }

        public async Task RefreshBeforeAction(SpecialJobModel job)
        {
            ShowWait();
            await UpdateSingleSpecialJob(job);
            HideWait();
        }

        private void ClearSpecialJobDetails()
        {
            HistoryList = new ObservableCollection<TransactionHistory>();
        }

        #endregion

        #region Properties

        public PagedAsyncSource PagedSource
        {
            get { return GetValue<PagedAsyncSource>(); }
            set { SetValue(value); }
        }


        public ObservableCollection<SpecialJobModel> SpecialJobList
        {
            get { return GetValue<ObservableCollection<SpecialJobModel>>(); }
            set { SetValue(value); }
        }


        public SpecialJobModel SelectedSpecialJob
        {
            get { return GetValue<SpecialJobModel>(); }
            set { SetValue(value); }
        }

        public ObservableCollection<SpecialJobModel> SelectedSpecialJobList { get; } = new ObservableCollection<SpecialJobModel>();


        public ObservableCollection<string> FabList
        {
            get { return GetValue<ObservableCollection<string>>(); }
            set { SetValue(value); }
        }

        public ObservableCollection<string> ProductList
        {
            get { return GetValue<ObservableCollection<string>>(); }
            set { SetValue(value); }
        }

        public ObservableCollection<string> RecipeList
        {
            get { return GetValue<ObservableCollection<string>>(); }
            set { SetValue(value); }
        }

        public ObservableCollection<SpecialJobParametersModel> SpecialJobParameterList
        {
            get { return GetValue<ObservableCollection<SpecialJobParametersModel>>(); }
            set { SetValue(value); }
        }

        #endregion
    }
    public class SpecialJobParametersModel : BindableBase
    {
        public string ModelGroup { get; set; }
        public string JobId { get; set; }
        public string ParameterName { get; set; }
        public decimal? InputValue { get; set; }
        public decimal? Min { get; set; }
        public decimal? Max { get; set; }
        public decimal? Fixed { get; set; }
        public decimal? PM { get; set; }
        public decimal? Reset { get; set; }

        public string Unit { get; set; }
    }
}
