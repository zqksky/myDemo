﻿using System;
using System.Collections.ObjectModel;
using AMAT.R2R.Client.Common.Constants;
using AMAT.R2R.Client.Common.Helpers;
using AMAT.R2R.Client.Common.Messages;
using AMAT.R2R.Client.Common.Services;
using AMAT.R2R.Client.Common.ViewModels;
using AMAT.R2R.Client.Cmp.Modules.ProcessSettings;
using AMAT.R2R.Client.Cmp.Services;
using AMAT.R2R.Shared.Base.DTO;
using DevExpress.Mvvm;
using DevExpress.Mvvm.DataAnnotations;
using DevExpress.Mvvm.ModuleInjection;
using DevExpress.Mvvm.POCO;

namespace AMAT.R2R.Client.Cmp.Modules
{
    public abstract class CmpViewModelBase : SuperViewModel
    {
        protected IProcessService ProcessService { get { return ServiceContainer.GetService<IProcessService>(); } }
        protected IContextService ContextService { get { return ServiceContainer.GetService<IContextService>(); } }
        protected IGlobalService GlobalService { get { return ServiceContainer.GetService<IGlobalService>(); } }

        protected ISpecialJobService SpecialJobService { get { return ServiceContainer.GetService<ISpecialJobService>(); } }
        protected ILotRunHistoryService LotRunHistoryService { get { return ServiceContainer.GetService<ILotRunHistoryService>(); } }
        protected IMaterializedViewService MaterializedViewService { get { return ServiceContainer.GetService<IMaterializedViewService>(); } }
    }
}
