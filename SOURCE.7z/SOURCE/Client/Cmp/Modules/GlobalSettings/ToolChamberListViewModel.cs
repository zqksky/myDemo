﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading.Tasks;
using AMAT.R2R.Client.Common.Enums;
using AMAT.R2R.Client.Common.Helpers;
using AMAT.R2R.Client.Common.Services;
using AMAT.R2R.Client.Cmp.Messages;
using AMAT.R2R.Shared.Base.DTO;
using AMAT.R2R.Shared.Cmp.DTO;
using DevExpress.Mvvm;
using DevExpress.Mvvm.DataAnnotations;

namespace AMAT.R2R.Client.Cmp.Modules.ToolChamberSettings
{
    public class ToolChamberListViewModel : CmpViewModelBase
    {
        public const string Auth_Global = "GlobalSettings";
        public const string Auth_Global_Tool = "GlobalSettings:Tool";
        public const string Auth_Global_Tool_Add = "GlobalSettings:Tool:Add";
        public const string Auth_Global_Tool_Edit = "GlobalSettings:Tool:Edit";
        public const string Auth_Global_Tool_Delete = "GlobalSettings:Tool:Delete";
        public const string Auth_Global_Chamber = "GlobalSettings:Chamber";
        public const string Auth_Global_Chamber_Add = "GlobalSettings:Chamber:Add";
        public const string Auth_Global_Chamber_Edit = "GlobalSettings:Chamber:Edit";
        public const string Auth_Global_Chamber_Delete = "GlobalSettings:Chamber:Delete";
        public const string Auth_Global_Parameter = "GlobalSettings:Parameter";
        public const string Auth_Global_Parameter_Add = "GlobalSettings:Parameter:Add";
        public const string Auth_Global_Parameter_Edit = "GlobalSettings:Parameter:Edit";
        public const string Auth_Global_Parameter_Delete = "GlobalSettings:Parameter:Delete";

        public ToolChamberListViewModel()
        {
            Caption = "Tool Model Group Settings";
            Icon = "SvgImages/Business Objects/BO_Category.svg";

            PropertyChanged += OnPropertyChanged;
            Messenger.Default.Register<ToolChangedMessage>(this, OnToolChanged);
        }

        #region Events

        protected override void OnViewReadyAsync()
        {
            Refresh();
        }

        private void OnPropertyChanged(object sender, System.ComponentModel.PropertyChangedEventArgs e)
        {
            if (e.PropertyName == nameof(SelectedTool))
            {
                if (SelectedTool != null)
                {
                    GetToolChambers();
                }
                else
                {
                    ChamberList?.Clear();
                }
            }
        }

        private async void OnToolChanged(ToolChangedMessage msg)
        {
            // refresh updated toolChamber. 
            var tool = ToolList.FirstOrDefault(p => p.ToolId == msg.ToolId);
            switch (msg.ChangeType)
            {
                case ObjectChangeType.Created:
                    Refresh();
                    break;
                case ObjectChangeType.Deleted:
                    ToolList.Remove(tool);
                    break;
                case ObjectChangeType.Updated:
                    await UpdateSingleTool(tool.ToolId);

                    break;
                default:
                    break;

            }
        }

        private async Task UpdateSingleTool(string toolId)
        {
            var tool = ToolList.FirstOrDefault(t => t.ToolId == toolId);
            if (tool == null) return;

            var newTool = await GlobalService.GetToolAsync(toolId);
            tool.ToolModel = newTool.ToolModel;
            tool.ToolProcessType = newTool.ToolProcessType;
            tool.ToolType = newTool.ToolType;
            tool.ToolVendor = newTool.ToolVendor;
            tool.Chambers = newTool.Chambers;

            tool.NotifyChanges();

            if (SelectedTool != null && tool.ToolId == SelectedTool.ToolId)
            {
                GetToolChambers();
            }
        }
        #endregion

        #region Commands

        [Command]
        public async void Refresh()
        {
            try
            {
                IsLoading = true;

                var selectedToolIdList = SelectedToolList.Select(t => t.ToolId).ToList();

                var toolList = await GlobalService.GetToolListAsync();
                var toolModelList = toolList.Select(t => new ToolModel()
                {
                    ToolId = t.ToolId,
                    ToolModel = t.ToolModel,
                    ToolType = t.ToolType,
                    ToolVendor = t.ToolVendor,
                    ToolProcessType = t.ToolProcessType,
                    Chambers = t.Chambers
                }).OrderBy(t => t.ToolId);

                ToolList = new ObservableCollection<ToolModel>(toolModelList);

                SelectedToolList.Clear();

                if (selectedToolIdList.Count > 0)
                {
                    foreach (var id in selectedToolIdList)
                    {
                        if (!SelectedToolList.Any(t => t.ToolId == id))
                        {
                            SelectedToolList.Add(ToolList.FirstOrDefault(t => t.ToolId == id));
                        }
                    }
                }
            }
            finally
            {
                IsLoading = false;
            }
        }
        public bool CanRefresh()
        {
            return !IsLoading;
        }

        [Command]
        public async void RefreshSingle()
        {
            await UpdateSingleTool(SelectedTool.ToolId);
        }
        public bool CanRefreshSingle()
        {
            return !IsLoading && SelectedTool != null;
        }

        private void GetToolChambers()
        {
            if (SelectedTool != null)
            {
                ChamberList = new ObservableCollection<ChamberModel>(SelectedTool.Chambers.Select(p => new ChamberModel
                {
                    ChamberId = p.ChamberId,
                    ProcessType = p.ProcessType,
                    ToolId = p.ToolId,
                    UnitType = p.UnitType
                }).OrderBy(c => c.ChamberId));
            }
            else
            {
                ChamberList?.Clear();
            }
        }

        #region Tool Commands
        [Command]
        public void AddTool()
        {
            ShowPopup("EditTool", new EditToolViewModel(null, FunctionMode.Add));
        }

        public bool CanAddTool()
        {
            return true; ;// AuthorityManager.HasAuthority(Auth_Global_Tool_Add);
        }

        [Command]
        public void CopyTool()
        {
            ShowPopup("EditTool", new EditToolViewModel(SelectedTool, FunctionMode.Copy));
        }

        public bool CanCopyTool()
        {
            return SelectedTool != null && SelectedToolList.Count == 1;// && !IsLoading && AuthorityManager.HasAuthority(Auth_Global_Tool_Add);
        }

        [Command]
        public async void EditTool()
        {
            await RefreshToolBeforeAction(SelectedTool);
            ShowPopup("EditTool", new EditToolViewModel(SelectedTool, FunctionMode.Modify));
        }

        public bool CanEditTool()
        {
            return SelectedTool != null && SelectedToolList.Count == 1;// && !IsLoading && AuthorityManager.HasAuthority(Auth_Global_Tool_Edit);
        }

        [Command]
        public async void DeleteTool()
        {
            if (IsConfirmed(out var comment, $"Delete Tool"))
            {
                var toDeleteTool = SelectedTool;
                await GlobalService.DeleteToolAsync(SelectedTool.ToolId, comment);
                Messenger.Default.Send(new ToolChangedMessage() { ChangeType = ObjectChangeType.Deleted, ToolId = toDeleteTool.ToolId });
                MessageBoxService.ShowMessage($"Tool {toDeleteTool.ToolId} is deleted.", "Success", MessageButton.OK, MessageIcon.Information);
            }
        }

        public bool CanDeleteTool()
        {
            return SelectedTool != null && SelectedToolList.Count == 1;// && !IsLoading && AuthorityManager.HasAuthority(Auth_Global_Tool_Delete);
        }


        public async Task RefreshToolBeforeAction(ToolModel tool)
        {
            ShowWait();
            await UpdateSingleTool(tool.ToolId);
            HideWait();
        }
        #endregion


        #region Chamber Commands
        [Command]
        public void AddChamber()
        {
            if (SelectedTool != null)
            {
                ShowPopup("EditChamber", new EditChamberViewModel(SelectedTool, null, FunctionMode.Add));
            }
        }

        public bool CanAddChamber()
        {
            return SelectedTool != null && SelectedToolList.Count == 1 && !IsLoading;// && AuthorityManager.HasAuthority(Auth_Global_Chamber_Add);
        }

        [Command]
        public void CopyChamber()
        {
            if (SelectedTool != null && SelectedChamber != null)
            {
                ShowPopup("EditChamber", new EditChamberViewModel(SelectedTool, SelectedChamber, FunctionMode.Copy));
            }
        }

        public bool CanCopyChamber()
        {
            return SelectedChamber != null && !IsLoading;// && AuthorityManager.HasAuthority(Auth_Global_Chamber_Add);
        }

        [Command]
        public void EditChamber()
        {
            if (SelectedChamber != null)
            {
                ShowPopup("EditChamber", new EditChamberViewModel(SelectedTool, SelectedChamber, FunctionMode.Modify));
            }
        }

        public bool CanEditChamber()
        {
            return SelectedChamber != null && !IsLoading;// && AuthorityManager.HasAuthority(Auth_Global_Chamber_Edit);
        }

        [Command]
        public async void DeleteChamber()
        {
            if (SelectedChamber != null)
            {
                if (IsConfirmed(out var comment, $"Delete Chamber"))
                {
                    var toDeleteChamber = SelectedChamber;
                    await GlobalService.DeleteChamberAsync(toDeleteChamber.ToolId, toDeleteChamber.ChamberId, comment);
                    Messenger.Default.Send(new ToolChangedMessage() { ChangeType = ObjectChangeType.Updated, ToolId = toDeleteChamber.ToolId });
                    MessageBoxService.ShowMessage($"Chamber {toDeleteChamber.ToolId}:{toDeleteChamber.ChamberId} is deleted.", "Success", MessageButton.OK, MessageIcon.Information);
                }
            }
        }

        public bool CanDeleteChamber()
        {
            return SelectedChamber != null && !IsLoading;// && AuthorityManager.HasAuthority(Auth_Global_Chamber_Delete);
        }


        #endregion


        #endregion

        #region Properties


        public ObservableCollection<ToolModel> ToolList
        {
            get { return GetValue<ObservableCollection<ToolModel>>(); }
            set { SetValue(value); }
        }


        public ToolModel SelectedTool
        {
            get { return GetValue<ToolModel>(); }
            set { SetValue(value); }
        }

        public ObservableCollection<ToolModel> SelectedToolList { get; } = new ObservableCollection<ToolModel>();


        public ObservableCollection<ChamberModel> ChamberList
        {
            get { return GetValue<ObservableCollection<ChamberModel>>(); }
            set { SetValue(value); }
        }

        public ChamberModel SelectedChamber
        {
            get { return GetValue<ChamberModel>(); }
            set { SetValue(value); }
        }
        //public ObservableCollection<ChamberModel> SelectedChamberList { get; } = new ObservableCollection<ChamberModel>();

        #endregion
    }
}
