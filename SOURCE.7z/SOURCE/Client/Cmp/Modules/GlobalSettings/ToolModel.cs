﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AMAT.R2R.Shared.Base.DTO;
using AMAT.R2R.Shared.Cmp.DTO;
using Newtonsoft.Json;

namespace AMAT.R2R.Client.Cmp.Modules.ToolChamberSettings
{
    public class ToolModel : Tool, INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;

        public void NotifyChanges()
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(ToolModel)));
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(ToolVendor)));
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(ToolType)));
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(ToolProcessType)));
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Chambers)));
        }
    }

    public class ChamberModel : Chamber, INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;
    }
}
