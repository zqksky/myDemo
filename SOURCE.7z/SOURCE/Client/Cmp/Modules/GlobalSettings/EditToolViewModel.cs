﻿using System;
using AMAT.R2R.Client.Common.Enums;
using AMAT.R2R.Client.Common.Helpers;
using AMAT.R2R.Client.Common.ViewModels;
using AMAT.R2R.Client.Common.Views;
using AMAT.R2R.Client.Cmp.Messages;
using AMAT.R2R.Shared.Base.DTO;
using AMAT.R2R.Shared.Cmp.DTO;
using DevExpress.Mvvm;
using DevExpress.Mvvm.DataAnnotations;
using DevExpress.Mvvm.POCO;
using DevExpress.Xpf.Bars;

namespace AMAT.R2R.Client.Cmp.Modules.ToolChamberSettings
{
    public class EditToolViewModel : CmpViewModelBase
    {
        private const string NA = "NA";
        public EditToolViewModel(Tool tool, FunctionMode mode)
        {
            OriginalTool = tool;
            Mode = mode;

            if (mode != FunctionMode.Add)
            {
                ToolId = tool.ToolId;
                ToolVendor = tool.ToolVendor;
                ToolModel = tool.ToolModel;
                ToolType = tool.ToolType;
                ProcessModel = tool.ToolProcessType;
            }
            else
            {
            }

            Caption = Mode == FunctionMode.Modify ? "Edit Tool" : "New Tool";
            IsDirty = false;
        }

        protected override void OnViewReadyAsync()
        {
            if (Mode == FunctionMode.Add)
            {
                SetFocus(nameof(ToolId));
            }
        }


        [Command]
        public async void Save()
        {
            ValidateAndSetErrorFocus(nameof(ToolId), nameof(ToolVendor), nameof(ToolModel), nameof(ToolType), nameof(ProcessModel));

            if (HasErrors)
            {
                return;
            }

            // 
            if (IsConfirmed(out string comment))
            {
                var newTool = new Tool
                {
                    ToolId = ToolId,
                    ToolModel = ToolModel,
                    ToolVendor = ToolVendor,
                    ToolType = ToolType,
                    ToolProcessType = ProcessModel,
                };

                if (Mode == FunctionMode.Modify)
                {
                    ShowWait();
                    newTool.ToolId = OriginalTool.ToolId;
                    await GlobalService.UpdateToolAsync(newTool.ToolId, newTool, comment);
                    IsDirty = false;
                    HideWait();
                    Messenger.Default.Send(new ToolChangedMessage() { ChangeType = ObjectChangeType.Updated, ToolId = OriginalTool.ToolId });
                    MessageBoxService.ShowMessage($"Tool {newTool.ToolId} is updated!", "Success", MessageButton.OK, MessageIcon.Information);
                }
                else
                {
                    ShowWait();
                    var createdTool = await GlobalService.CreateToolAsync(newTool, comment);
                    IsDirty = false;
                    HideWait();
                    Messenger.Default.Send(new ToolChangedMessage() { ChangeType = ObjectChangeType.Created, ToolId = createdTool.ToolId });
                    MessageBoxService.ShowMessage($"Tool {createdTool.ToolId} is created!", "Success", MessageButton.OK, MessageIcon.Information);
                }

                IsOK = true;
                CloseWindow();
            }
        }

        public bool CanSave()
        {
            switch (Mode)
            {
                case FunctionMode.Add:
                    return true;
                case FunctionMode.Modify:
                    return IsDirty;
                default:
                    return true;
            }
        }

        protected override string GetError(string columnName)
        {
            switch (columnName)
            {
                case nameof(ToolId):
                    return DataValidator.ValidString(ToolId);
                case nameof(ToolVendor):
                    return DataValidator.ValidString(ToolVendor);
                case nameof(ToolModel):
                    return DataValidator.ValidString(ToolModel);
                case nameof(ToolType):
                    return DataValidator.ValidString(ToolType);
                case nameof(ProcessModel):
                    return DataValidator.ValidString(ProcessModel);
                default:
                    return null;
            }
        }


        #region Properties
        public Tool OriginalTool { get; private set; }

        public Tool SubmittedTool { get; set; }


        public string ToolId
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(ToolId));
            }
        }

        public string ToolVendor
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(ToolVendor));
            }
        }

        public string ToolModel
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(ToolModel));
            }
        }
        public string ProcessModel
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(ProcessModel));
            }
        }

        public string ToolType
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(ToolType));
            }
        }


        #endregion
    }
}
