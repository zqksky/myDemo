﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Threading.Tasks;
using AMAT.R2R.Client.Common.Enums;
using AMAT.R2R.Client.Common.Helpers;
using AMAT.R2R.Client.Cmp.Messages;
using AMAT.R2R.Client.Cmp.Properties;
using AMAT.R2R.Client.Cmp.Services;
using AMAT.R2R.Shared.Base.DTO;
using AMAT.R2R.Shared.Cmp.DTO;
using DevExpress.DirectX.Common.DXGI;
using DevExpress.Mvvm;
using DevExpress.Mvvm.DataAnnotations;
using DevExpress.Mvvm.Native;
using DevExpress.Mvvm.UI.Native;
using DevExpress.Utils;
using Newtonsoft.Json;
using AMAT.R2R.Client.Common.Extensions;

namespace AMAT.R2R.Client.Cmp.Modules.ContextSettings
{

    public class EditContextInputViewModel : CmpViewModelBase
    {
        public EditContextInputViewModel(Context context, FunctionMode mode)
        {
            OwnerContext = context ?? throw new ArgumentNullException(nameof(context));
            Mode = mode;

            SizeToContent = System.Windows.SizeToContent.Manual;
            WindowWidth = 1800;
            WindowHeight = 900;

            Caption = "Update Context Input";
            ParameterSettingList = new ObservableCollection<InputSettingModel>();
            PropertyChanged += EditContextInputViewModel_PropertyChanged;
        }

        private void EditContextInputViewModel_PropertyChanged(object sender, PropertyChangedEventArgs e)
        {
        }

        private async Task Reload()
        {
            ShowWait();
            OwnerContext = await ContextService.GetContextAsync(OwnerContext.ContextKey);
            Initialize();
            HideWait();
        }

        protected override void OnViewReadyAsync()
        {
            Initialize();
        }

        private async void Initialize()
        {
            ShowWait();

            try
            {
                ParameterList = new ObservableCollection<Parameter>(await GlobalService.GetProcessParameterListAsync(OwnerContext.Tool, OwnerContext.ModelGroup));

                LoadParameterSettings();
            }
            finally
            {
                HideWait();
            }

            IsDirty = false;
            IsPMDetectDirty = false;
            IsLifeTimeDirty = false;
            IsSlaveParameterDirty = false;
        }

        private void LoadParameterSettings()
        {
            List<InputSettingModel> parameterSettings = new List<InputSettingModel>();

            if (OwnerContext.ContextInputParas != null)
            {
                for (var i = 0; i < OwnerContext.ContextInputParas.Count; i++)
                {
                    var item = OwnerContext.ContextInputParas[i];
                    var parameterSetting = new InputSettingModel()
                    {
                        IsChecked = true,
                        Parameter = ParameterList.FirstOrDefault(p => p.ParameterName == item.Parameter?.ParameterName),
                        ParameterName = item.ParameterName,
                        Fixed = (decimal)item.Fixed,
                        Max = (decimal)item.Max,
                        Min = (decimal)item.Min,
                        PM = (decimal)item.PM,
                        Reset = (decimal)item.Reset,
                        Precision = item.Precision,
                        Tolerance = (decimal)item.Tolerance,
                        Unit = "",
                        Deadband = (decimal)item.Deadband,
                        FFDelta = (decimal)item.FFDelta,
                        FBDelta = (decimal)item.FBDelta,
                        ShiftInputLimit = item.ShiftInputLimitWithLifeTimeOffset,
                        UseRecOrUsedToFb = item.UseRecOrUsedToFb,
                        WaferProcessLocationRegex = item.WaferProcessLocationRegex,

                        ModelSlope1 = (decimal)item.ModelSlope.Cells[0][0],
                        ModelSlope2 = (decimal)item.ModelSlope.Cells[0][1],
                        ModelSlope3 = (decimal)item.ModelSlope.Cells[0][2],
                        ModelSlope4 = (decimal)item.ModelSlope.Cells[0][3],
                        ModelSlope5 = (decimal)item.ModelSlope.Cells[0][4],
                        ModelSlope6 = (decimal)item.ModelSlope.Cells[0][5],
                        ModelSlope7 = (decimal)item.ModelSlope.Cells[0][6],
                        ModelSlope8 = (decimal)item.ModelSlope.Cells[0][7],
                        ModelSlope9 = (decimal)item.ModelSlope.Cells[0][8],
                        ModelSlope10 = (decimal)item.ModelSlope.Cells[0][9],
                    };

                    parameterSettings.Add(parameterSetting);
                }

            }

            int currentCount = parameterSettings.Count;
            // make up 10 parameter settings.
            if (parameterSettings.Count < 10)
            {
                for (int i = 0; i < 10 - currentCount; i++)
                {
                    var newInputSetting = new InputSettingModel();

                    parameterSettings.Add(newInputSetting);
                }
            }

            ParameterSettingList = new ObservableCollection<InputSettingModel>(parameterSettings);

            UpdateParamTable();


            foreach (var ps in ParameterSettingList)
            {
                ps.PropertyChanged += ParameterSetting_PropertyChanged;
            }

            VIDChannel = OwnerContext.VIDChannels;
            PMDetect = OwnerContext.PMDetectVID; //json ignored
            //string[] tmp = string.IsNullOrEmpty(OwnerContext.VIDChannels) ? new string[] { } : OwnerContext.VIDChannels.Split(',');
            //PMDetect = OwnerContext.PMDetectIndex > 0 && OwnerContext.PMDetectIndex <= tmp.Length ? tmp[OwnerContext.PMDetectIndex - 1] : "";
            var lifeTimeSettings = OwnerContext.ContextInputParas.SelectMany(ip => ip.VIDLifeTimeItems).OrderBy(lt => lt.ParameterName).OrderBy(lt => lt.VIDIndex);

            var lifeTimeSettingModels = lifeTimeSettings.Select(lt => new LifeTimeSettingModel
            {
                IsNew = false,
                ParameterName = lt.ParameterName,
                SVID = lt.VID,
                VIDIndex = lt.VIDIndex,
                RangeStart = lt.RangeStart,
                RangeEnd = lt.RangeEnd,
                A = lt.A,
                B = lt.B,
                C = lt.C,
                Max = lt.Max,
            });

            LifeTimeSettingList = new ObservableCollection<LifeTimeSettingModel>(lifeTimeSettingModels);

            foreach (var lts in LifeTimeSettingList)
            {
                lts.PropertyChanged += LifeTimeSetting_PropertyChanged; ;
            }

            var slaveParameters = OwnerContext.ContextInputParas.SelectMany(ip => ip.SlaveInputs).OrderBy(si => si.ParameterName);

            var slaveParameterModels = slaveParameters.Select(lt => new SlaveParameterModel
            {
                IsNew = false,
                ParameterName = lt.ParameterName,
                Coefficient = lt.Coefficient,
                SlaveName = lt.SlaveName,
                Offset = lt.Offset
            });

            SlaveParameterList = new ObservableCollection<SlaveParameterModel>(slaveParameterModels);

            foreach (var sp in SlaveParameterList)
            {
                sp.PropertyChanged += SlaveParameter_PropertyChanged;
            }

            IsDirty = false;
        }

        private void SlaveParameter_PropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            IsSlaveParameterDirty = true;
        }

        private void LifeTimeSetting_PropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            if(e.PropertyName == nameof(LifeTimeSettingModel.SVID))
            {
                UpdateVIDChannel();
            }
            IsLifeTimeDirty = true;
        }

        private void UpdateVIDChannel()
        {
            var vidChannels = new List<string>();
            vidChannels.Add(PMDetect);
            vidChannels.AddRange(LifeTimeSettingList.Select(lt => lt.SVID));
            vidChannels = vidChannels.Distinct().ToList();
            vidChannels.Sort();
            VIDChannel = string.Join(",", vidChannels);
        }

        private void ParameterSetting_PropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            IsParameterSettingsDirty = true;

            if (e.PropertyName == nameof(InputSettingModel.IsChecked))
            {
                UpdateParamTable();
            }
            else
            {
                ClearError($"{nameof(ParameterSettingList)}.{e.PropertyName}");
            }
        }

        private void UpdateParamTable()
        {
            int outputNum = OwnerContext != null ? OwnerContext.OutputNum4Slope : 0;
            for (var i = 0; i < ParameterSettingList.Count; i++)
            {
                var item = ParameterSettingList[i];
                item.Index = i + 1;

                if (i == 0)
                {
                    item.IsReadOnlyIsChecked = ParameterSettingList[i + 1].IsChecked;
                }
                else if (i < 9)
                {
                    item.IsReadOnlyIsChecked = !ParameterSettingList[i - 1].IsChecked || ParameterSettingList[i + 1].IsChecked;
                }
                else
                {
                    item.IsReadOnlyIsChecked = !ParameterSettingList[i - 1].IsChecked;
                }


                if (!item.IsChecked)
                {
                    item.Parameter = null;
                    item.Fixed = 0;
                    item.PM = 0;
                    item.Reset = 0;
                    item.Min = 0;
                    item.Max = 0;
                    item.Precision = 2;
                    item.Tolerance = 0;
                    item.FFDelta = 0;
                    item.FBDelta = 0;
                    item.Deadband = 0;
                    item.ShiftInputLimit = true;
                    item.UseRecOrUsedToFb = "Rec";
                    item.WaferProcessLocationRegex = OwnerContext.ModelGroup;

                    item.ModelSlope1 = 0;
                    item.ModelSlope2 = 0;
                    item.ModelSlope3 = 0;
                    item.ModelSlope4 = 0;
                    item.ModelSlope5 = 0;
                    item.ModelSlope6 = 0;
                    item.ModelSlope7 = 0;
                    item.ModelSlope8 = 0;
                    item.ModelSlope9 = 0;
                    item.ModelSlope10 = 0;

                    item.IsEnableModelSlop1 = false;
                    item.IsEnableModelSlop2 = false;
                    item.IsEnableModelSlop3 = false;
                    item.IsEnableModelSlop4 = false;
                    item.IsEnableModelSlop5 = false;
                    item.IsEnableModelSlop6 = false;
                    item.IsEnableModelSlop7 = false;
                    item.IsEnableModelSlop8 = false;
                    item.IsEnableModelSlop9 = false;
                    item.IsEnableModelSlop10 = false;

                }
                else
                {
                    switch (outputNum)
                    {
                        case 0:
                            item.IsEnableModelSlop1 = false;
                            item.IsEnableModelSlop2 = false;
                            item.IsEnableModelSlop3 = false;
                            item.IsEnableModelSlop4 = false;
                            item.IsEnableModelSlop5 = false;
                            item.IsEnableModelSlop6 = false;
                            item.IsEnableModelSlop7 = false;
                            item.IsEnableModelSlop8 = false;
                            item.IsEnableModelSlop9 = false;
                            item.IsEnableModelSlop10 = false;

                            item.ModelSlope1 = 0;
                            item.ModelSlope2 = 0;
                            item.ModelSlope3 = 0;
                            item.ModelSlope4 = 0;
                            item.ModelSlope5 = 0;
                            item.ModelSlope6 = 0;
                            item.ModelSlope7 = 0;
                            item.ModelSlope8 = 0;
                            item.ModelSlope9 = 0;
                            item.ModelSlope10 = 0;
                            break;

                        case 1:
                            item.IsEnableModelSlop1 = true;
                            item.IsEnableModelSlop2 = false;
                            item.IsEnableModelSlop3 = false;
                            item.IsEnableModelSlop4 = false;
                            item.IsEnableModelSlop5 = false;
                            item.IsEnableModelSlop6 = false;
                            item.IsEnableModelSlop7 = false;
                            item.IsEnableModelSlop8 = false;
                            item.IsEnableModelSlop9 = false;
                            item.IsEnableModelSlop10 = false;

                            item.ModelSlope2 = 0;
                            item.ModelSlope3 = 0;
                            item.ModelSlope4 = 0;
                            item.ModelSlope5 = 0;
                            item.ModelSlope6 = 0;
                            item.ModelSlope7 = 0;
                            item.ModelSlope8 = 0;
                            item.ModelSlope9 = 0;
                            item.ModelSlope10 = 0;
                            break;
                        case 2:
                            item.IsEnableModelSlop1 = true;
                            item.IsEnableModelSlop2 = true;
                            item.IsEnableModelSlop3 = false;
                            item.IsEnableModelSlop4 = false;
                            item.IsEnableModelSlop5 = false;
                            item.IsEnableModelSlop6 = false;
                            item.IsEnableModelSlop7 = false;
                            item.IsEnableModelSlop8 = false;
                            item.IsEnableModelSlop9 = false;
                            item.IsEnableModelSlop10 = false;

                            item.ModelSlope3 = 0;
                            item.ModelSlope4 = 0;
                            item.ModelSlope5 = 0;
                            item.ModelSlope6 = 0;
                            item.ModelSlope7 = 0;
                            item.ModelSlope8 = 0;
                            item.ModelSlope9 = 0;
                            item.ModelSlope10 = 0;
                            break;
                        case 3:
                            item.IsEnableModelSlop1 = true;
                            item.IsEnableModelSlop2 = true;
                            item.IsEnableModelSlop3 = true;
                            item.IsEnableModelSlop4 = false;
                            item.IsEnableModelSlop5 = false;
                            item.IsEnableModelSlop6 = false;
                            item.IsEnableModelSlop7 = false;
                            item.IsEnableModelSlop8 = false;
                            item.IsEnableModelSlop9 = false;
                            item.IsEnableModelSlop10 = false;

                            item.ModelSlope4 = 0;
                            item.ModelSlope5 = 0;
                            item.ModelSlope6 = 0;
                            item.ModelSlope7 = 0;
                            item.ModelSlope8 = 0;
                            item.ModelSlope9 = 0;
                            item.ModelSlope10 = 0;
                            break;
                        case 4:
                            item.IsEnableModelSlop1 = true;
                            item.IsEnableModelSlop2 = true;
                            item.IsEnableModelSlop3 = true;
                            item.IsEnableModelSlop4 = true;
                            item.IsEnableModelSlop5 = false;
                            item.IsEnableModelSlop6 = false;
                            item.IsEnableModelSlop7 = false;
                            item.IsEnableModelSlop8 = false;
                            item.IsEnableModelSlop9 = false;
                            item.IsEnableModelSlop10 = false;

                            item.ModelSlope5 = 0;
                            item.ModelSlope6 = 0;
                            item.ModelSlope7 = 0;
                            item.ModelSlope8 = 0;
                            item.ModelSlope9 = 0;
                            item.ModelSlope10 = 0;
                            break;
                        case 5:
                            item.IsEnableModelSlop1 = true;
                            item.IsEnableModelSlop2 = true;
                            item.IsEnableModelSlop3 = true;
                            item.IsEnableModelSlop4 = true;
                            item.IsEnableModelSlop5 = true;
                            item.IsEnableModelSlop6 = false;
                            item.IsEnableModelSlop7 = false;
                            item.IsEnableModelSlop8 = false;
                            item.IsEnableModelSlop9 = false;
                            item.IsEnableModelSlop10 = false;

                            item.ModelSlope6 = 0;
                            item.ModelSlope7 = 0;
                            item.ModelSlope8 = 0;
                            item.ModelSlope9 = 0;
                            item.ModelSlope10 = 0;
                            break;
                        case 6:
                            item.IsEnableModelSlop1 = true;
                            item.IsEnableModelSlop2 = true;
                            item.IsEnableModelSlop3 = true;
                            item.IsEnableModelSlop4 = true;
                            item.IsEnableModelSlop5 = true;
                            item.IsEnableModelSlop6 = true;
                            item.IsEnableModelSlop7 = false;
                            item.IsEnableModelSlop8 = false;
                            item.IsEnableModelSlop9 = false;
                            item.IsEnableModelSlop10 = false;

                            item.ModelSlope7 = 0;
                            item.ModelSlope8 = 0;
                            item.ModelSlope9 = 0;
                            item.ModelSlope10 = 0;
                            break;
                        case 7:
                            item.IsEnableModelSlop1 = true;
                            item.IsEnableModelSlop2 = true;
                            item.IsEnableModelSlop3 = true;
                            item.IsEnableModelSlop4 = true;
                            item.IsEnableModelSlop5 = true;
                            item.IsEnableModelSlop6 = true;
                            item.IsEnableModelSlop7 = true;
                            item.IsEnableModelSlop8 = false;
                            item.IsEnableModelSlop9 = false;
                            item.IsEnableModelSlop10 = false;

                            item.ModelSlope8 = 0;
                            item.ModelSlope9 = 0;
                            item.ModelSlope10 = 0;
                            break;
                        case 8:
                            item.IsEnableModelSlop1 = true;
                            item.IsEnableModelSlop2 = true;
                            item.IsEnableModelSlop3 = true;
                            item.IsEnableModelSlop4 = true;
                            item.IsEnableModelSlop5 = true;
                            item.IsEnableModelSlop6 = true;
                            item.IsEnableModelSlop7 = true;
                            item.IsEnableModelSlop8 = true;
                            item.IsEnableModelSlop9 = false;
                            item.IsEnableModelSlop10 = false;

                            item.ModelSlope9 = 0;
                            item.ModelSlope10 = 0;
                            break;
                        case 9:
                            item.IsEnableModelSlop1 = true;
                            item.IsEnableModelSlop2 = true;
                            item.IsEnableModelSlop3 = true;
                            item.IsEnableModelSlop4 = true;
                            item.IsEnableModelSlop5 = true;
                            item.IsEnableModelSlop6 = true;
                            item.IsEnableModelSlop7 = true;
                            item.IsEnableModelSlop8 = true;
                            item.IsEnableModelSlop9 = true;
                            item.IsEnableModelSlop10 = false;

                            item.ModelSlope10 = 0;
                            break;
                        case 10:
                            item.IsEnableModelSlop1 = true;
                            item.IsEnableModelSlop2 = true;
                            item.IsEnableModelSlop3 = true;
                            item.IsEnableModelSlop4 = true;
                            item.IsEnableModelSlop5 = true;
                            item.IsEnableModelSlop6 = true;
                            item.IsEnableModelSlop7 = true;
                            item.IsEnableModelSlop8 = true;
                            item.IsEnableModelSlop9 = true;
                            item.IsEnableModelSlop10 = true;
                            break;
                        default:
                            break;
                    }
                }
            }
        }

        [Command]
        public async void UpdateInputParaSettings()
        {
            var checkedInputList = ParameterSettingList.Where(p => p.IsChecked).ToList();
            if (checkedInputList.Any(p => p != null && checkedInputList.Any(p2 => p2.Parameter == p.Parameter && p != p2)))
            {
                MessageBoxService.ShowMessage("An input with the same Parameter already exists.", "Duplicate Input", MessageButton.OK, MessageIcon.Error);
                return;
            }

            foreach (var item in checkedInputList)
            {
                if (item.Error != null)
                {
                    SetError($"{nameof(ParameterSettingList)}.{item.Error}", item[item.Error]);
                    SetFocus(nameof(ParameterSettingList));
                    return;
                }
            }

            if (!HasErrors)
            {

                if (HasErrors)
                {
                    return;
                }
            }


            if (IsConfirmed(out var comment))
            {
                ShowWait();

                var contextInputParas = new List<ContextInputPara>();
                // input parameters
                foreach (var ps in ParameterSettingList.Where(p => p.IsChecked))
                {
                    var inputPara = new ContextInputPara
                    {
                        ContextKey = OwnerContext.ContextKey,
                        InputIndex = ps.Index,
                        Parameter = ps.Parameter,
                        Fixed = (double)ps.Fixed.Value,
                        Max = (double)ps.Max.Value,
                        Min = (double)ps.Min.Value,
                        PM = (double)ps.PM.Value,
                        Reset = (double)ps.Reset.Value,
                        Precision = ps.Precision,
                        Tolerance = (double)ps.Tolerance.Value,
                        FFDelta = (double)ps.FFDelta.Value,
                        FBDelta = (double)ps.FBDelta.Value,
                        Deadband = (double)ps.Deadband.Value,
                        ShiftInputLimitWithLifeTimeOffset = ps.ShiftInputLimit.Value,
                        UseRecOrUsedToFb = ps.UseRecOrUsedToFb,
                        WaferProcessLocationRegex = ps.WaferProcessLocationRegex,
                    };

                    inputPara.ModelSlope.Cells[0][0] = (double)ps.ModelSlope1;
                    inputPara.ModelSlope.Cells[0][1] = (double)ps.ModelSlope2;
                    inputPara.ModelSlope.Cells[0][2] = (double)ps.ModelSlope3;
                    inputPara.ModelSlope.Cells[0][3] = (double)ps.ModelSlope4;
                    inputPara.ModelSlope.Cells[0][4] = (double)ps.ModelSlope5;
                    inputPara.ModelSlope.Cells[0][5] = (double)ps.ModelSlope6;
                    inputPara.ModelSlope.Cells[0][6] = (double)ps.ModelSlope7;
                    inputPara.ModelSlope.Cells[0][7] = (double)ps.ModelSlope8;
                    inputPara.ModelSlope.Cells[0][8] = (double)ps.ModelSlope9;
                    inputPara.ModelSlope.Cells[0][9] = (double)ps.ModelSlope10;

                    contextInputParas.Add(inputPara);
                }

                var submitContext = JsonConvert.DeserializeObject<ContextModel>(JsonConvert.SerializeObject(OwnerContext));

                submitContext.ContextInputParas = contextInputParas;
                // submit
                await ContextService.UpdateContextInputAsync(submitContext, submitContext.ContextKey, comment);

                IsParameterSettingsDirty = false;
                HideWait();

                // notify ContextList for update.
                Messenger.Default.Send(new ContextChangedMessage() { ChangeType = ObjectChangeType.Updated, ContextKey = OwnerContext.ContextKey });
                MessageBoxService.ShowMessage("Context Input Updated.", "Success", MessageButton.OK, MessageIcon.Information);

                await Reload();
            }
        }


        public bool CanUpdateInputParaSettings()
        {
            return IsParameterSettingsDirty && ParameterSettingList.Any(p => p.IsChecked);
        }

        [Command]
        public async void UpdatePMDetect()
        {
            if (IsConfirmed(out var comment))
            {
                ShowWait();
                var submitContext = JsonConvert.DeserializeObject<ContextModel>(JsonConvert.SerializeObject(OwnerContext));

                UpdateVIDChannel();
                submitContext.VIDChannels = VIDChannel;
                submitContext.PMDetectVID = PMDetect;
                await ContextService.UpdateContextVIDChannelAsync(submitContext, submitContext.ContextKey, comment);
                HideWait();

                // notify ContextList for update.
                Messenger.Default.Send(new ContextChangedMessage() { ChangeType = ObjectChangeType.Updated, ContextKey = OwnerContext.ContextKey });
                MessageBoxService.ShowMessage("Context PM Detect Updated.", "Success", MessageButton.OK, MessageIcon.Information);

                await Reload();
            }
        }

        public bool CanUpdatePMDetect()
        {
            return OwnerContext.ContextInputParas.Count > 0 && IsPMDetectDirty && !IsLifeTimeDirty && !IsParameterSettingsDirty;
        }
        #region Life Time Settings

        [Command]
        public void AddLifeTimeSetting()
        {
            var newSetting = new LifeTimeSettingModel()
            {
                A = 0.0,
                B = 0.0,
                C = 0.0,
                Max = 0.0,
                RangeStart = 0,
                RangeEnd = 0,
                ParameterName = null,
                IsNew = true
            };
            newSetting.PropertyChanged += LifeTimeSetting_PropertyChanged;

            LifeTimeSettingList.Add(newSetting);

            IsLifeTimeDirty = true;
        }

        public bool CanAddLifeTimeSetting()
        {
            return OwnerContext.ContextInputParas.Count > 0 && !IsPMDetectDirty && !IsParameterSettingsDirty;
        }

        [Command]
        public void DeleteLifeTimeSetting()
        {
            LifeTimeSettingList.Remove(SelectedLifeTimeSetting);
            IsLifeTimeDirty = true;
        }

        public bool CanDeleteLifeTimeSetting()
        {
            return SelectedLifeTimeSetting != null && !IsPMDetectDirty && !IsParameterSettingsDirty;
        }

        [Command]
        public async void SaveLifeTimeSetting()
        {
            if (IsConfirmed(out var comment))
            {
                ShowWait();
                var submitContext = JsonConvert.DeserializeObject<ContextModel>(JsonConvert.SerializeObject(OwnerContext));
                submitContext.VIDChannels = VIDChannel;
                submitContext.PMDetectVID = PMDetect;
                foreach (var input in submitContext.ContextInputParas)
                {
                    input.VIDLifeTimeItems = LifeTimeSettingList.Where(lt => lt.ParameterName == input.ParameterName).Select(lt => new VIDLifeTimeItem
                    {
                        ParameterName = lt.ParameterName,
                        VID = lt.SVID,
                        VIDIndex = lt.VIDIndex,
                        RangeStart = lt.RangeStart.Value,
                        RangeEnd = lt.RangeEnd.Value,
                        A = lt.A.Value,
                        B = lt.B.Value,
                        C = lt.C.Value,
                        Max = lt.Max.Value,
                    }).ToList();
                }
                await ContextService.UpdateContextLifetimeSettingsAsync(submitContext, submitContext.ContextKey, comment);
                HideWait();

                // notify ContextList for update.
                Messenger.Default.Send(new ContextChangedMessage() { ChangeType = ObjectChangeType.Updated, ContextKey = OwnerContext.ContextKey });
                MessageBoxService.ShowMessage("Context Life Time Settings Updated.", "Success", MessageButton.OK, MessageIcon.Information);

                await Reload();
            }
        }

        public bool CanSaveLifeTimeSetting()
        {
            return OwnerContext.ContextInputParas.Count > 0 && IsLifeTimeDirty && !IsPMDetectDirty && !IsParameterSettingsDirty;
        } 
        #endregion

        #region Slave Parameter Settings

        [Command]
        public void AddSlaveParameter()
        {
            var newSetting = new SlaveParameterModel()
            {
                ParameterName = null,
                SlaveName = null,
                Coefficient = 0.0,
                Offset = 0.0,
                IsNew = true
            };

            newSetting.PropertyChanged += SlaveParameter_PropertyChanged;

            SlaveParameterList.Add(newSetting);

            IsLifeTimeDirty = true;
        }

        public bool CanAddSlaveParameter()
        {
            return OwnerContext.ContextInputParas.Count > 0 && !IsParameterSettingsDirty;
        }

        [Command]
        public void DeleteSlaveParameter()
        {
            SlaveParameterList.Remove(SelectedSlaveParameter);
            IsSlaveParameterDirty = true;
        }

        public bool CanDeleteSlaveParameter()
        {
            return SelectedSlaveParameter != null && !IsParameterSettingsDirty;
        }

        [Command]
        public async void SaveSlaveParameter()
        {
            foreach (var item in SlaveParameterList)
            {
                if(item.ParameterName == item.SlaveName)
                {
                    MessageBoxService.ShowMessage("Slave Parameter should be different from Master Parameter.", "", MessageButton.OK, MessageIcon.Stop);
                    SetFocus(SlaveParameterList, nameof(SlaveParameterModel.SlaveName));
                    return;
                }
            }
            if (IsConfirmed(out var comment))
            {
                ShowWait();
                var submitContext = JsonConvert.DeserializeObject<ContextModel>(JsonConvert.SerializeObject(OwnerContext));
                submitContext.PMDetectVID = PMDetect;
                submitContext.VIDChannels = VIDChannel;
                foreach (var input in submitContext.ContextInputParas)
                {
                    input.SlaveInputs = SlaveParameterList.Where(lt => lt.ParameterName == input.ParameterName).Select(lt => new SlaveInput
                    {
                        ParameterName = lt.ParameterName,
                        Coefficient = lt.Coefficient.Value,
                        Offset = lt.Offset.Value,
                        SlaveName = lt.SlaveName

                    }).ToList();
                }
                await ContextService.UpdateContextSlaveParametersAsync(submitContext, submitContext.ContextKey, comment);
                HideWait();

                // notify ContextList for update.
                Messenger.Default.Send(new ContextChangedMessage() { ChangeType = ObjectChangeType.Updated, ContextKey = OwnerContext.ContextKey });
                MessageBoxService.ShowMessage("Context Slave Parameter Updated.", "Success", MessageButton.OK, MessageIcon.Information);

                await Reload();
            }
        }

        public bool CanSaveSlaveParameter()
        {
            return OwnerContext.ContextInputParas.Count > 0 && IsSlaveParameterDirty && SelectedSlaveParameter != null && !IsParameterSettingsDirty;
        } 
        #endregion


        protected override string GetError(string columnName)
        {
            switch (columnName)
            {
                default:
                    return null;
            }
        }

        #region Properties
        public Context OwnerContext { get; private set; }


        public ObservableCollection<Parameter> ParameterList
        {
            get { return GetValue<ObservableCollection<Parameter>>(); }
            set { SetValue(value); }
        }


        public ObservableCollection<InputSettingModel> ParameterSettingList
        {
            get { return GetValue<ObservableCollection<InputSettingModel>>(); }
            set { SetValue(value); }
        }

        private void UpdateIsDirty()
        {
            IsDirty = IsParameterSettingsDirty || IsPMDetectDirty || IsLifeTimeDirty || IsSlaveParameterDirty;
        }

        public bool IsParameterSettingsDirty
        {
            get { return GetValue<bool>(); }
            set
            {
                SetValue(value);
                UpdateIsDirty();
            }
        }

        public bool IsPMDetectDirty
        {
            get { return GetValue<bool>(); }
            set
            {
                SetValue(value);
                UpdateIsDirty();
            }
        }

        public bool IsLifeTimeDirty
        {
            get { return GetValue<bool>(); }
            set
            {
                SetValue(value);
                UpdateIsDirty();
            }
        }

        public bool IsSlaveParameterDirty
        {
            get { return GetValue<bool>(); }
            set
            {
                SetValue(value);
                UpdateIsDirty();
            }
        }

        public string VIDChannel
        {
            get { return GetValue<string>(); }
            set { SetValue(value); }
        }

        public string PMDetect
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                IsPMDetectDirty = true;
                ClearError(nameof(PMDetect));
            }
        }

        public ObservableCollection<LifeTimeSettingModel> LifeTimeSettingList
        {
            get { return GetValue<ObservableCollection<LifeTimeSettingModel>>(); }
            set { SetValue(value); }
        }

        public LifeTimeSettingModel SelectedLifeTimeSetting
        {
            get { return GetValue<LifeTimeSettingModel>(); }
            set { SetValue(value); }
        }

        public ObservableCollection<SlaveParameterModel> SlaveParameterList
        {
            get { return GetValue<ObservableCollection<SlaveParameterModel>>(); }
            set { SetValue(value); }
        }

        public SlaveParameterModel SelectedSlaveParameter
        {
            get { return GetValue<SlaveParameterModel>(); }
            set { SetValue(value); }
        }


        #endregion
    }

}
