﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data.Objects;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Documents;
using AMAT.R2R.Client.Common.Enums;
using AMAT.R2R.Client.Common.Helpers;
using AMAT.R2R.Client.Common.Messages;
using AMAT.R2R.Client.Common.Services;
using AMAT.R2R.Client.Common.ViewModels;
using AMAT.R2R.Client.Common.Views;
using AMAT.R2R.Client.Cmp.Messages;
using AMAT.R2R.Shared.Base.DTO;
using AMAT.R2R.Shared.Cmp.DTO;
using DevExpress.Mvvm;
using DevExpress.Mvvm.DataAnnotations;
using DevExpress.Mvvm.POCO;
using DevExpress.Xpf.Editors.Internal.TypedStyles;

namespace AMAT.R2R.Client.Cmp.Modules.ContextSettings
{
    public class EditContextViewModel : CmpViewModelBase
    {
        private const string NA = "NA";
        public EditContextViewModel(Process process, Context sourceContext, FunctionMode mode)
        {
            SizeToContent = System.Windows.SizeToContent.Manual;
            CurrentProcess = process;
            SourceContext = sourceContext;
            Mode = mode;

            switch (mode)
            {
                case FunctionMode.None:
                    break;
                case FunctionMode.Add:
                    Caption = "Create Context";
                    break;
                case FunctionMode.Copy:
                    Caption = "Copy Context";
                    break;
                default:
                    break;
            }

            PropertyChanged += OnPropertyChanged;

            ProcessContextList = new ObservableCollection<ContextModel>();
            IsDirty = false;
        }

        protected override void OnViewReadyAsync()
        {
            Refresh();
        }

        private async void OnPropertyChanged(object sender, System.ComponentModel.PropertyChangedEventArgs e)
        {
            if (e.PropertyName == nameof(Tool))
            {
                await UpdateModelGroupAsync();
            }
        }

        private async Task UpdateModelGroupAsync()
        {
            if (Tool != null)
            {
                ModelGroupList = (await GlobalService.GetChamberListAsync(Tool.ToolId)).Where(c => !ProcessContextList.Any(ctx => ctx.Tool == c.ToolId && ctx.ModelGroup == c.ChamberId)).Select(c => c.ChamberId).ToList();
            }
            else
            {
                ModelGroupList = new List<string>();
            }
            ModelGroup = null;
        }

        [Command]
        public async void Refresh()
        {
            Tool = null;
            ModelGroup = null;
            Recipe = null;

            if (Mode == FunctionMode.Add)
            {
                R2RMode = null;
                RecLevel = null;
            }
            else
            {
                R2RMode = SourceContext.R2RMode;
                RecLevel = SourceContext.RecLevel;
            }

            ShowWait();

            //CurrentProcess = await ProcessService.GetProcessAsync(CurrentProcess.ProcessKey);

            ProcessContextList = new ObservableCollection<ContextModel>(await ContextService.GetContextListAsync(
                new QueryFilter(nameof(Context.Fab), CurrentProcess.Fab),
                new QueryFilter(nameof(Context.Product), CurrentProcess.Product),
                new QueryFilter(nameof(Context.ProcessStep), CurrentProcess.ProcessStep)));

            // set copy source
            var sourceContext = ProcessContextList.FirstOrDefault(c => c.ContextKey == SourceContext?.ContextKey);
            if (sourceContext != null)
            {
                sourceContext.IsCopySource = true;
                sourceContext.NotifyChanges();
            }

            ProcessContextList.CollectionChanged += ProcessContextList_CollectionChanged;

            ToolList = await GlobalService.GetToolListAsync();

            HideWait();

            IsDirty = false;
        }

        private void ProcessContextList_CollectionChanged(object sender, System.Collections.Specialized.NotifyCollectionChangedEventArgs e)
        {
            IsDirty = ProcessContextList.Any(c => c.IsNew);
        }

        [Command]
        public void AddContext()
        {
            if (ProcessContextList.Any(c => c.Tool == Tool.ToolId && c.Recipe == Recipe && c.ModelGroup == ModelGroup))
            {
                MessageBoxService.ShowMessage("The context already exists.", "Duplicate Context", MessageButton.OK, MessageIcon.Stop);
                return;
            }


            if (Mode == FunctionMode.Add)
            {
                var newContext = new ContextModel()
                {
                    Fab = CurrentProcess.Fab,
                    Product = CurrentProcess.Product,
                    ProcessStep = CurrentProcess.ProcessStep,
                    Tool = Tool.ToolId,
                    Recipe = Recipe,
                    ModelGroup = ModelGroup,
                    R2RMode = R2RMode.Value,
                    RecLevel = RecLevel.Value,
                    IsNew = true
                };
                ProcessContextList.Add(newContext);
                SelectedContext = newContext;
            }
            else
            {
                var newContext = Newtonsoft.Json.JsonConvert.DeserializeObject<ContextModel>(Newtonsoft.Json.JsonConvert.SerializeObject(SourceContext));
                newContext.Tool = Tool.ToolId;
                newContext.Recipe = Recipe;
                newContext.ModelGroup = ModelGroup;
                //newContext.R2RMode = R2RMode.Value;
                //newContext.RecLevel = RecLevel.Value;
                newContext.IsNew = true;

                ProcessContextList.Add(newContext);
                SelectedContext = newContext;
            }
            _ = UpdateModelGroupAsync();
        }

        public bool CanAddContext()
        {
            return Tool != null && !string.IsNullOrEmpty(Recipe) && !string.IsNullOrEmpty(ModelGroup) && R2RMode.HasValue && RecLevel.HasValue;
        }

        [Command]
        public async void DeleteContext()
        {
            if (SelectedContext.IsNew)
            {
                ProcessContextList.Remove(SelectedContext);
            }
            else
            {
                if (IsConfirmed(out var comment))
                {
                    var toDeleteId = SelectedContext.ContextKey;
                    await ContextService.DeleteContextAsync(toDeleteId, comment);
                    Messenger.Default.Send(new ContextChangedMessage() { ChangeType = ObjectChangeType.Deleted, ContextKey = toDeleteId });
                    Refresh();
                }
            }
            await UpdateModelGroupAsync();
        }

        public bool CanDeleteContext()
        {
            return SelectedContext != null && SelectedContext.IsNew;
        }

        [Command]
        public async void Save()
        {
            var newContextList = ProcessContextList.Where(c => c.IsNew).ToList();

            StringBuilder sb = new StringBuilder();
            // 
            if (IsConfirmed(out string comment))
            {
                ShowWait();

                int successCount = 0;
                foreach (var context in newContextList)
                {
                    try
                    {
                        if (Mode == FunctionMode.Add)
                        {
                            await ContextService.CreateContextAsync(context, comment);
                        }
                        else
                        {
                            await ContextService.CopyContextAsync(context, SourceContext.ContextKey, comment);
                        }

                        successCount++;
                    }
                    catch (Exception ex)
                    {
                        sb.AppendLine(LocalizationService.LocalizeException(ex));
                    }
                }


                HideWait();

                var failedCount = newContextList.Count() - successCount;

                if (successCount > 0)
                {
                    Messenger.Default.Send(new ContextChangedMessage() { ChangeType = ObjectChangeType.Created, ContextKey = "" });
                }

                if (failedCount > 0)
                {
                    MessageBoxService.ShowMessage(sb.ToString(), $"Success Count: {successCount} Failed Count: {failedCount} ", MessageButton.OK, MessageIcon.Error);
                }
                else
                {
                    if (Mode == FunctionMode.Add)
                    {
                        MessageBoxService.ShowMessage($"{newContextList.Count} Context created successfully.", "Success", MessageButton.OK, MessageIcon.Information);
                    }
                    else
                    {
                        MessageBoxService.ShowMessage($"{newContextList.Count} Context copied successfully.", "Success", MessageButton.OK, MessageIcon.Information);
                    }
                }

                // show updated list.
                Refresh();
            }
        }

        public bool CanSave()
        {
            switch (Mode)
            {
                case FunctionMode.Add:
                    return ProcessContextList.Any(c => c.IsNew);
                case FunctionMode.Copy:
                    return ProcessContextList.Any(c => c.IsNew);
                case FunctionMode.Modify:
                    return IsDirty;
                default:
                    return true;
            }
        }

        protected override string GetError(string columnName)
        {
            switch (columnName)
            {
                default:
                    return null;
            }
        }

        #region Properties
        public Process CurrentProcess { get; private set; }

        public Context SourceContext { get; private set; }

        public Tool Tool
        {
            get { return GetValue<Tool>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(Tool));
            }
        }

        public string Recipe
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(Recipe));
            }
        }

        public string ModelGroup
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(ModelGroup));
            }
        }

        public ObservableCollection<ContextModel> ProcessContextList
        {
            get { return GetValue<ObservableCollection<ContextModel>>(); }
            set { SetValue(value); }
        }

        public ContextModel SelectedContext
        {
            get { return GetValue<ContextModel>(); }
            set { SetValue(value); }
        }

        public List<Tool> ToolList
        {
            get { return GetValue<List<Tool>>(); }
            set { SetValue(value); }
        }

        public List<Chamber> ChamberList
        {
            get { return GetValue<List<Chamber>>(); }
            set { SetValue(value); }
        }

        public List<string> ModelGroupList
        {
            get { return GetValue<List<string>>(); }
            set { SetValue(value); }
        }


        public R2RMode? R2RMode
        {
            get { return GetValue<R2RMode?>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
            }
        }

        public RecLevel? RecLevel
        {
            get { return GetValue<RecLevel?>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
            }
        }


        #endregion
    }
}
