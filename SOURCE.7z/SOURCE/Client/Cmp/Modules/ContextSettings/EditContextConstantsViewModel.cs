﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Threading.Tasks;
using AMAT.R2R.Client.Common.Enums;
using AMAT.R2R.Client.Common.Helpers;
using AMAT.R2R.Client.Cmp.Messages;
using AMAT.R2R.Client.Cmp.Properties;
using AMAT.R2R.Client.Cmp.Services;
using AMAT.R2R.Shared.Base.DTO;
using AMAT.R2R.Shared.Cmp.DTO;
using DevExpress.DirectX.Common.DXGI;
using DevExpress.Mvvm;
using DevExpress.Mvvm.DataAnnotations;
using DevExpress.Mvvm.Native;
using DevExpress.Mvvm.UI.Native;
using DevExpress.Utils;

namespace AMAT.R2R.Client.Cmp.Modules.ContextSettings
{

    public class EditContextConstantsViewModel : CmpViewModelBase
    {
        public EditContextConstantsViewModel(Context context)
        {
            WindowWidth = 1100;
            //WindowHeight = 400;
            SizeToContent = System.Windows.SizeToContent.Height;
            OwnerContext = context ?? throw new ArgumentNullException(nameof(context));
            OriginalSettings = context.ContextConstants;

            if (string.IsNullOrEmpty(OwnerContext.ContextConstants.ContextKey))
            {
                Mode = FunctionMode.Add;
                //ControlFlag = ControlFlag.Fixed;
                Caption = "Create Context Constants";
            }
            else
            {
                Mode = FunctionMode.Modify;
                Caption = "Update Context Constants";
            }

            PropertyChanged += EditContextConstantsViewModel_PropertyChanged;
        }

        private void EditContextConstantsViewModel_PropertyChanged(object sender, PropertyChangedEventArgs e)
        {
        }

        protected override void OnViewReadyAsync()
        {
            Initialize();
        }

        private void Initialize()
        {
            if (OriginalSettings != null && Mode == FunctionMode.Modify)
            {
                BoundaryMaxCount = OriginalSettings.BoundaryMaxCount;

                MaxQueueDays = OriginalSettings.MaxQueueDays;
                OOCMaxCount = OriginalSettings.OOCMaxCount;
                OOSMaxCount = OriginalSettings.OOSMaxCount;
                OOLMaxCountRecVsUsed = OriginalSettings.OOLMaxCountRecVsUsed;
                StatesDuration = OriginalSettings.StatesDuration;
                FBOnOOC = OriginalSettings.FBOnOOC;
                FBOnOOS = OriginalSettings.FBOnOOS;
                FFOnOOC = OriginalSettings.FFOnOOC;
                FFOnOOS = OriginalSettings.FFOnOOS;
                ForceChildLotFF = OriginalSettings.ForceChildLotFF;
                InvalidChildLot = OriginalSettings.InvalidChildLot;
                ResetStatesAtPreTargetChange = OriginalSettings.ResetStatesAtPreTargetChange;
                ResetStatesAtPostTargetChange = OriginalSettings.ResetStatesAtPostTargetChange;
                UpdateFBTarget = OriginalSettings.UpdateFBTarget;
                UpdateFFTarget = OriginalSettings.UpdateFFTarget;
                DeltaControl = OriginalSettings.DeltaControl;
                FB = OriginalSettings.FB;
                FF = OriginalSettings.FF;
                LifeTime = OriginalSettings.LifeTime;
                UsePostRemeasData = OriginalSettings.UsePostRemeasData;
                UsePreRmeasData = OriginalSettings.UsePreRmeasData;
                UseProductContext = OriginalSettings.UseProductContext;
                UseRecipeContext = OriginalSettings.UseRecipeContext;
                IsDirty = false;
            }
            else
            {
                // default values.
                BoundaryMaxCount = 3;
                MaxQueueDays = 99999;
                OOCMaxCount = 3;
                OOSMaxCount = 3;
                OOLMaxCountRecVsUsed = 3;
                StatesDuration = 30.0;
                FBOnOOC = false;
                FBOnOOS = false;
                FFOnOOC = true;
                FFOnOOS = true;
                ForceChildLotFF = false;
                InvalidChildLot = false;
                ResetStatesAtPreTargetChange = true;
                ResetStatesAtPostTargetChange = false;
                UpdateFBTarget = false;
                UpdateFFTarget = false;
                DeltaControl = false;
                FB = true;
                FF = false;
                LifeTime = false;
                UsePostRemeasData = true;
                UsePreRmeasData = true;
                UseProductContext = true;
                UseRecipeContext = true;
                IsDirty = true;
            }

        }


        [Command]
        public async void CreateOrUpdate()
        {
            ValidateAndSetErrorFocus(
                nameof(BoundaryMaxCount),
                nameof(MaxQueueDays),
                nameof(OOCMaxCount),
                nameof(OOSMaxCount),
                nameof(OOLMaxCountRecVsUsed),
                nameof(StatesDuration));

            if (HasErrors)
            {
                return;
            }

            if (IsConfirmed(out var comment))
            {
                ShowWait();

                var newSettings = new ContextConstants
                {
                    ContextKey = OwnerContext.ContextKey,
                    BoundaryMaxCount = BoundaryMaxCount.Value,
                    MaxQueueDays = MaxQueueDays.Value,
                    OOCMaxCount = OOCMaxCount.Value,
                    OOSMaxCount = OOSMaxCount.Value,
                    OOLMaxCountRecVsUsed = OOLMaxCountRecVsUsed.Value,
                    StatesDuration = StatesDuration.Value,
                    DeltaControl = DeltaControl.Value,
                    FBOnOOC = FBOnOOC.Value,
                    FBOnOOS = FBOnOOS.Value,
                    FFOnOOC = FFOnOOC.Value,
                    FFOnOOS = FFOnOOS.Value,
                    ForceChildLotFF = ForceChildLotFF.Value,
                    InvalidChildLot = InvalidChildLot.Value,
                    ResetStatesAtPreTargetChange = ResetStatesAtPreTargetChange.Value,
                    ResetStatesAtPostTargetChange = ResetStatesAtPostTargetChange.Value,
                    UpdateFBTarget = UpdateFBTarget.Value,
                    UpdateFFTarget = UpdateFFTarget.Value,
                    FB = FB.Value,
                    FF = FF.Value,
                    LifeTime = LifeTime.Value,
                    UsePostRemeasData = UsePostRemeasData.Value,
                    UsePreRmeasData = UsePreRmeasData.Value,
                    UseProductContext = UseProductContext.Value,
                    UseRecipeContext = UseRecipeContext.Value,
                };

                if (Mode == FunctionMode.Add)
                {
                    await ContextService.CreateContextConstantsAsync(newSettings, OwnerContext.ContextKey, comment);
                    IsDirty = false;
                    HideWait();
                    Messenger.Default.Send(new ContextChangedMessage() { ChangeType = ObjectChangeType.Updated, ContextKey = OwnerContext.ContextKey });
                    MessageBoxService.ShowMessage("Context Constants Created.", "Success", MessageButton.OK, MessageIcon.Information);
                }
                else
                {
                    await ContextService.UpdateContextConstantsAsync(newSettings, OwnerContext.ContextKey, comment);
                    IsDirty = false;
                    HideWait();
                    Messenger.Default.Send(new ContextChangedMessage() { ChangeType = ObjectChangeType.Updated, ContextKey = OwnerContext.ContextKey });
                    MessageBoxService.ShowMessage("Context Constants Updated.", "Success", MessageButton.OK, MessageIcon.Information);
                }

                IsOK = true;
                CloseWindow();
            }
        }

        public bool CanCreateOrUpdate()
        {
            return IsDirty;
        }

        protected override string GetError(string columnName)
        {
            switch (columnName)
            {
                case nameof(BoundaryMaxCount):
                    return DataValidator.ValidateInOrder(
                        () => DataValidator.NotNull(BoundaryMaxCount),
                        () => DataValidator.LargerThanOrEqualTo(BoundaryMaxCount, 1));
                case nameof(MaxQueueDays):
                    return DataValidator.ValidateInOrder(
                        () => DataValidator.NotNull(MaxQueueDays),
                        () => DataValidator.LargerThanOrEqualTo((decimal)MaxQueueDays, 0));
                case nameof(OOCMaxCount):
                    return DataValidator.ValidateInOrder(
                        () => DataValidator.NotNull(OOCMaxCount),
                        () => DataValidator.LargerThanOrEqualTo((decimal)OOCMaxCount, 1));
                case nameof(OOSMaxCount):
                    return DataValidator.ValidateInOrder(
                        () => DataValidator.NotNull(OOSMaxCount),
                        () => DataValidator.LargerThanOrEqualTo((decimal)OOSMaxCount, 1));
                case nameof(OOLMaxCountRecVsUsed):
                    return DataValidator.ValidateInOrder(
                        () => DataValidator.NotNull(OOLMaxCountRecVsUsed),
                        () => DataValidator.LargerThanOrEqualTo((decimal)OOLMaxCountRecVsUsed, 1));
                case nameof(StatesDuration):
                    return DataValidator.ValidateInOrder(
                        () => DataValidator.NotNull(StatesDuration),
                        () => DataValidator.LargerThanOrEqualTo((decimal)StatesDuration, 0));
                default:
                    return null;
            }
        }

        #region Properties
        public Context OwnerContext { get; private set; }

        public ContextConstants OriginalSettings { get; private set; }

        public bool? OptUseTarget
        {
            get { return GetValue<bool?>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(OptUseTarget));
            }
        }
        public bool? UpdateFFTarget
        {
            get { return GetValue<bool?>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(UpdateFFTarget));
            }
        }
        public bool? ForceChildLotFF
        {
            get { return GetValue<bool?>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(ForceChildLotFF));
            }
        }
        public bool? UpdateFBTarget
        {
            get { return GetValue<bool?>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(UpdateFBTarget));
            }
        }
        public bool? FFOnOOS
        {
            get { return GetValue<bool?>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(FFOnOOS));
            }
        }
        public bool? FFOnOOC
        {
            get { return GetValue<bool?>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(FFOnOOC));
            }
        }
        public bool? FBOnOOS
        {
            get { return GetValue<bool?>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(FBOnOOS));
            }
        }
        public bool? ResetStatesAtPreTargetChange
        {
            get { return GetValue<bool?>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(ResetStatesAtPreTargetChange));
            }
        }
        public bool? InvalidChildLot
        {
            get { return GetValue<bool?>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(InvalidChildLot));
            }
        }
        public bool? FBOnOOC
        {
            get { return GetValue<bool?>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(FBOnOOC));
            }
        }
        public double? StatesDuration
        {
            get { return GetValue<double?>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(StatesDuration));
            }
        }
        public int? OOLMaxCountRecVsUsed
        {
            get { return GetValue<int?>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(OOLMaxCountRecVsUsed));
            }
        }
        public int? OOSMaxCount
        {
            get { return GetValue<int?>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(OOSMaxCount));
            }
        }
        public double? MaxQueueDays
        {
            get { return GetValue<double?>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(MaxQueueDays));
            }
        }
        public int? OOCMaxCount
        {
            get { return GetValue<int?>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(OOCMaxCount));
            }
        }
        public bool? ResetStatesAtPostTargetChange
        {
            get { return GetValue<bool?>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(ResetStatesAtPostTargetChange));
            }
        }
        public bool? DeltaControl
        {
            get { return GetValue<bool?>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(DeltaControl));
            }
        }
        public bool? FF
        {
            get { return GetValue<bool?>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(FF));
            }
        }
        public bool? LifeTime
        {
            get { return GetValue<bool?>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(LifeTime));
            }
        }
        public bool? UsePostRemeasData
        {
            get { return GetValue<bool?>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(UsePostRemeasData));
            }
        }

        public bool? UsePreRmeasData
        {
            get { return GetValue<bool?>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(UsePreRmeasData));
            }
        }
        public bool? UseProductContext
        {
            get { return GetValue<bool?>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(UseProductContext));
            }
        }
        public bool? UseRecipeContext
        {
            get { return GetValue<bool?>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(UseRecipeContext));
            }
        }


        public bool? FB
        {
            get { return GetValue<bool?>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(FB));
            }
        }

        public int? BoundaryMaxCount
        {
            get { return GetValue<int?>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(BoundaryMaxCount));
            }
        }


        #endregion
    }
}
