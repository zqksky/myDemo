﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AMAT.R2R.Shared.Cmp.DTO;
using Newtonsoft.Json;

namespace AMAT.R2R.Client.Cmp.Modules.ContextSettings
{
    public class ContextModel : Context, INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;

        public void NotifyChanges()
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Parameters)));
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Fixed)));
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Min)));
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Max)));
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(R2RMode)));
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(RecLevel)));
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(PreMetrologyParameter)));
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(PreMetrologyTarget)));
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(PreMetrologyUpperLimit)));
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(PreMetrologyLowerLimit)));
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(OutputParameter)));
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(OutputTarget)));
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(OutputUpperLimit)));
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(OutputLowerLimit)));
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(SlaveParameter)));
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(ContextConstants)));
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(VIDChannels)));
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(PMDetectIndex)));
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(PMDetectVID)));
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(OutputNum4Slope)));
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(ContextInputParas)));
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(IsConstantDefined)));
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(LastModifiedBy)));
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(LastModifiedTime)));
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(IsCopySource)));
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(IsNew)));
        }


        [JsonIgnore]
        public string Parameters
        {
            get
            {
                return ContextInputParas == null ? string.Empty : string.Join(",", ContextInputParas.Select(p => p.ParameterName));
            }
        }


        [JsonIgnore]
        public string Fixed
        {
            get
            {
                return ContextInputParas == null ? string.Empty : string.Join(",", ContextInputParas.Select(p => p.Fixed));
            }
        }


        [JsonIgnore]
        public string Min
        {
            get
            {
                return ContextInputParas == null ? string.Empty : string.Join(",", ContextInputParas.Select(p => p.Min));
            }
        }


        [JsonIgnore]
        public string Max
        {
            get
            {
                return ContextInputParas == null ? string.Empty : string.Join(",", ContextInputParas.Select(p => p.Max));
            }
        }


        [JsonIgnore]
        public string PreMetrologyParameter
        {
            get
            {
                return PreMeasurements == null ? string.Empty : string.Join(";", PreMeasurements.Select(m => string.Join(",", m.ContextOutputs.Select(o => o.MeasItemName))));
            }
        }

        [JsonIgnore]
        public string PreMetrologyTarget
        {
            get
            {
                return PreMeasurements == null ? string.Empty : string.Join(";", PreMeasurements.Select(m => string.Join(",", m.ContextOutputs.Select(o => o.Target))));
            }
        }

        [JsonIgnore]
        public string PreMetrologyLowerLimit
        {
            get
            {
                return PreMeasurements == null ? string.Empty : string.Join(";", PreMeasurements.Select(m => string.Join(",", m.ContextOutputs.Select(o => o.LowerLimit))));
            }
        }

        [JsonIgnore]
        public string PreMetrologyUpperLimit
        {
            get
            {
                return PreMeasurements == null ? string.Empty : string.Join(";", PreMeasurements.Select(m => string.Join(",", m.ContextOutputs.Select(o => o.UpperLimit))));
            }
        }

        [JsonIgnore]
        public string OutputParameter
        {
            get
            {
                return Outputs == null ? string.Empty : string.Join(";", Outputs.Select(m => string.Join(",", m.ContextOutputs.Select(o => o.MeasItemName))));
            }
        }

        [JsonIgnore]
        public string OutputTarget
        {
            get
            {
                return Outputs == null ? string.Empty : string.Join(";", Outputs.Select(m => string.Join(",", m.ContextOutputs.Select(o => o.Target))));
            }
        }

        [JsonIgnore]
        public string OutputLowerLimit
        {
            get
            {
                return Outputs == null ? string.Empty : string.Join(";", Outputs.Select(m => string.Join(",", m.ContextOutputs.Select(o => o.LowerLimit))));
            }
        }

        [JsonIgnore]
        public string OutputUpperLimit
        {
            get
            {
                return Outputs == null ? string.Empty : string.Join(";", Outputs.Select(m => string.Join(",", m.ContextOutputs.Select(o => o.UpperLimit))));
            }
        }

        [JsonIgnore]
        public string SlaveParameter
        {
            get
            {
                return ContextInputParas == null ? string.Empty : string.Join(";", ContextInputParas.Select(p => string.Join(",", p.SlaveInputs.Select(s => s.SlaveName))).ToList());
            }
        }

        [JsonIgnore]
        public bool IsConstantDefined
        {
            get { return !string.IsNullOrEmpty(ContextConstants.ContextKey); }
        }


        [JsonIgnore]
        public bool? FF
        {
            get { return IsConstantDefined ? ContextConstants.FF : (bool ?)null; }
        }

        [JsonIgnore]
        public bool? FB
        {
            get { return IsConstantDefined ? ContextConstants.FB : (bool?)null; }
        }

        [JsonIgnore]
        public bool? LifeTime
        {
            get { return IsConstantDefined ? ContextConstants.LifeTime : (bool?)null; }
        }

        [JsonIgnore]
        public bool? DeltaControl
        {
            get { return IsConstantDefined ? ContextConstants.DeltaControl : (bool?)null; }
        }

        [JsonIgnore]
        public bool? ForceChildLotFF
        {
            get { return IsConstantDefined ? ContextConstants.ForceChildLotFF : (bool?)null; }
        }


        [JsonIgnore]
        public bool IsNew { get; set; }


        [JsonIgnore]
        public bool IsCopySource { get; set; }


    }
}
