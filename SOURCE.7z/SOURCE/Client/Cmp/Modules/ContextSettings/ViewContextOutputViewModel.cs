﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Threading.Tasks;
using AMAT.R2R.Client.Common.Enums;
using AMAT.R2R.Client.Common.Helpers;
using AMAT.R2R.Client.Cmp.Messages;
using AMAT.R2R.Client.Cmp.Properties;
using AMAT.R2R.Client.Cmp.Services;
using AMAT.R2R.Shared.Base.DTO;
using AMAT.R2R.Shared.Cmp.DTO;
using DevExpress.DirectX.Common.DXGI;
using DevExpress.Mvvm;
using DevExpress.Mvvm.DataAnnotations;
using DevExpress.Mvvm.Native;
using DevExpress.Mvvm.UI.Native;
using DevExpress.Utils;
using Newtonsoft.Json;
using AMAT.R2R.Client.Common.Extensions;
using AMAT.R2R.Client.Common.ViewModels;

namespace AMAT.R2R.Client.Cmp.Modules.ContextSettings
{
    public class ViewContextOutputViewModel : SuperViewModel
    {
        public SettingType SettingType { get; set; }
        public ViewContextOutputViewModel(Context context, SettingType settingType)
        {
            OwnerContext = context ?? throw new ArgumentNullException(nameof(context));
            Mode = FunctionMode.View;
            SettingType = settingType;
            Initialize();
        }


        protected override void OnViewReadyAsync()
        {
            //Initialize();
        }

        private void Initialize()
        {
            ShowWait();

            try
            {
                LoadParameterSettings();
                IsGridView = SettingType == SettingType.Output ? OwnerContext.Outputs.SelectMany(g => g.ContextOutputs).Count() > 1 : OwnerContext.PreMeasurements.SelectMany(g => g.ContextOutputs).Count() > 1;
            }
            finally
            {
                HideWait();
            }

            IsDirty = false;
        }

        private void LoadParameterSettings()
        {
            var sourceGroupList = SettingType == SettingType.Output ? OwnerContext.Outputs : OwnerContext.PreMeasurements;

            var groups = sourceGroupList.Select(group => new OutputGroupModel
            {
                GroupName = group.OutputGroupName,

                OutputSettingList = new ObservableCollection<OutputSettingsModel>(group.ContextOutputs.Select(output => new OutputSettingsModel
                {
                    MeasItemName = output.MeasItemName,
                    LowerSpecLimit = (decimal)output.LowerSpecLimit,
                    LowerLimit = (decimal)output.LowerLimit,
                    UpperLimit = (decimal)output.UpperLimit,
                    UpperSpecLimit = (decimal)output.UpperSpecLimit,
                    Coefficients = (decimal)output.Coefficients,
                    CoefficientsPiRun = (decimal)output.CoefficientsPiRun,
                    MeasDFCRange = output.MeasDFCRange,
                    MinSitesRequired = output.MinSitesRequired,
                    MaxOocSitesAllowed = output.MaxOocSitesAllowed,
                    MaxOosSitesAllowed = output.MaxOosSitesAllowed,
                    QualityItemName = output.QualityItemName,
                    QualityThreshold = (decimal)output.QualityThreshold,
                    Target = (decimal)output.Target,
                    Precision = output.Precision,
                    Index = output.Index,
                    Multiplier = (decimal)output.Multiplier,
                    OCAP = output.OCAP,
                    SiteOrders = output.SiteOrders,
                    GroupName = group.OutputGroupName,
                }).OrderBy(o => o.Index))
            });
            OutputGroupList = new ObservableCollection<OutputGroupModel>(groups.OrderBy(g => g.GroupName));

            foreach (var group in OutputGroupList)
            {
                group.SelectedOutputSetting = group.OutputSettingList.FirstOrDefault();
            }

            SelectedGroup = OutputGroupList.FirstOrDefault();

            IsDirty = false;
        }

        #region Properties
        public Context OwnerContext { get; private set; }

        public ObservableCollection<OutputGroupModel> OutputGroupList
        {
            get { return GetValue<ObservableCollection<OutputGroupModel>>(); }
            set { SetValue(value); }
        }

        public OutputGroupModel SelectedGroup
        {
            get { return GetValue<OutputGroupModel>(); }
            set { SetValue(value); }
        }


        public List<OutputSettingsModel> AllOutputSettingList
        {
            get { return GetValue<List<OutputSettingsModel>>(); }
            set { SetValue(value); }
        }

        public bool IsEditView
        {
            get { return GetValue<bool>(); }
            set
            {
                SetValue(value);
            }
        }

        public bool IsGridView
        {
            get { return GetValue<bool>(); }
            set
            {
                SetValue(value);
                IsEditView = !IsGridView;
                RaisePropertyChanged(nameof(IsEditView));
                if (value)
                {
                    AllOutputSettingList = OutputGroupList.SelectMany(g => g.OutputSettingList).ToList();
                }
            }
        }

        #endregion
    }
}
