﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Threading.Tasks;
using AMAT.R2R.Client.Common.Enums;
using AMAT.R2R.Client.Common.ViewModels;
using AMAT.R2R.Client.Cmp.Messages;
using AMAT.R2R.Client.Cmp.Properties;
using AMAT.R2R.Client.Cmp.Services;
using AMAT.R2R.Shared.Base.DTO;
using AMAT.R2R.Shared.Cmp.DTO;
using DevExpress.DirectX.Common.DXGI;
using DevExpress.Mvvm;
using DevExpress.Mvvm.DataAnnotations;
using DevExpress.Mvvm.Native;
using DevExpress.Mvvm.UI.Native;
using DevExpress.Utils;

namespace AMAT.R2R.Client.Cmp.Modules.ContextSettings
{
    /// <summary>
    /// make this class as light as possible so that performance is the best
    /// </summary>
    public class ViewContextInputViewModel
    {
        public ViewContextInputViewModel(Context context)
        {
            OwnerContext = context ?? throw new ArgumentNullException(nameof(context));

            Initialize();
        }

        private void Initialize()
        {
            LoadParameterSettings();
        }


        private void LoadParameterSettings()
        {
            List<ParameterSetting> parameterSettings = new List<ParameterSetting>();

            if (OwnerContext.ContextInputParas != null)
            {
                for (var i = 0; i < OwnerContext.ContextInputParas.Count; i++)
                {
                    var item = OwnerContext.ContextInputParas[i];
                    var parameterSetting = new ParameterSetting
                    {
                        IsChecked = true,
                        ParameterName = item.ParameterName,
                        Fixed = (decimal)item.Fixed,
                        Max = (decimal)item.Max,
                        Min = (decimal)item.Min,
                        PM = (decimal)item.PM,
                        Reset = (decimal)item.Reset,
                        Precision = item.Precision,
                        Tolerance = (decimal)item.Tolerance,
                        Unit = "",
                        Deadband = (decimal)item.Deadband,
                        FFDelta = (decimal)item.FFDelta,
                        FBDelta = (decimal)item.FBDelta,
                        ShiftInputLimit = item.ShiftInputLimitWithLifeTimeOffset,
                        UseRecOrUsedToFb = item.UseRecOrUsedToFb,
                        WaferProcessLocationRegex = item.WaferProcessLocationRegex,

                        ModelSlope1 = (decimal)item.ModelSlope.Cells[0][0],
                        ModelSlope2 = (decimal)item.ModelSlope.Cells[0][1],
                        ModelSlope3 = (decimal)item.ModelSlope.Cells[0][2],
                        ModelSlope4 = (decimal)item.ModelSlope.Cells[0][3],
                        ModelSlope5 = (decimal)item.ModelSlope.Cells[0][4],
                        ModelSlope6 = (decimal)item.ModelSlope.Cells[0][5],
                        ModelSlope7 = (decimal)item.ModelSlope.Cells[0][6],
                        ModelSlope8 = (decimal)item.ModelSlope.Cells[0][7],
                        ModelSlope9 = (decimal)item.ModelSlope.Cells[0][8],
                        ModelSlope10 = (decimal)item.ModelSlope.Cells[0][9],
                    };

                    parameterSettings.Add(parameterSetting);
                }
            }

            ParameterSettingList = new List<ParameterSetting>(parameterSettings);

            UpdateParamTable();

            LifeTimeSettings = OwnerContext.ContextInputParas.SelectMany(ip => ip.VIDLifeTimeItems).OrderBy(lt => lt.ParameterName).OrderBy(lt => lt.VIDIndex).ToList();

            SlaveParameters = OwnerContext.ContextInputParas.SelectMany(ip => ip.SlaveInputs).OrderBy(si => si.ParameterName).ToList();
        }

        private void UpdateParamTable()
        {
            int outputNum = OwnerContext != null ? OwnerContext.OutputNum4Slope : 0;
            for (var i = 0; i < ParameterSettingList.Count; i++)
            {
                var item = ParameterSettingList[i];
                item.Index = i + 1;


                if (!item.IsChecked)
                {
                    item.Fixed = 0;
                    item.PM = 0;
                    item.Reset = 0;
                    item.Min = 0;
                    item.Max = 0;
                    item.Precision = 2;
                    item.Tolerance = 0;
                    item.FFDelta = 0;
                    item.FBDelta = 0;
                    item.Deadband = 0;
                    item.ShiftInputLimit = true;
                    item.UseRecOrUsedToFb = "Rec";
                    item.WaferProcessLocationRegex = OwnerContext.ModelGroup;

                    item.ModelSlope1 = 0;
                    item.ModelSlope2 = 0;
                    item.ModelSlope3 = 0;
                    item.ModelSlope4 = 0;
                    item.ModelSlope5 = 0;
                    item.ModelSlope6 = 0;
                    item.ModelSlope7 = 0;
                    item.ModelSlope8 = 0;
                    item.ModelSlope9 = 0;
                    item.ModelSlope10 = 0;

                    item.IsEnableModelSlop1 = false;
                    item.IsEnableModelSlop2 = false;
                    item.IsEnableModelSlop3 = false;
                    item.IsEnableModelSlop4 = false;
                    item.IsEnableModelSlop5 = false;
                    item.IsEnableModelSlop6 = false;
                    item.IsEnableModelSlop7 = false;
                    item.IsEnableModelSlop8 = false;
                    item.IsEnableModelSlop9 = false;
                    item.IsEnableModelSlop10 = false;

                }
                else
                {
                    switch (outputNum)
                    {
                        case 0:
                            item.IsEnableModelSlop1 = false;
                            item.IsEnableModelSlop2 = false;
                            item.IsEnableModelSlop3 = false;
                            item.IsEnableModelSlop4 = false;
                            item.IsEnableModelSlop5 = false;
                            item.IsEnableModelSlop6 = false;
                            item.IsEnableModelSlop7 = false;
                            item.IsEnableModelSlop8 = false;
                            item.IsEnableModelSlop9 = false;
                            item.IsEnableModelSlop10 = false;

                            item.ModelSlope1 = 0;
                            item.ModelSlope2 = 0;
                            item.ModelSlope3 = 0;
                            item.ModelSlope4 = 0;
                            item.ModelSlope5 = 0;
                            item.ModelSlope6 = 0;
                            item.ModelSlope7 = 0;
                            item.ModelSlope8 = 0;
                            item.ModelSlope9 = 0;
                            item.ModelSlope10 = 0;
                            break;

                        case 1:
                            item.IsEnableModelSlop1 = true;
                            item.IsEnableModelSlop2 = false;
                            item.IsEnableModelSlop3 = false;
                            item.IsEnableModelSlop4 = false;
                            item.IsEnableModelSlop5 = false;
                            item.IsEnableModelSlop6 = false;
                            item.IsEnableModelSlop7 = false;
                            item.IsEnableModelSlop8 = false;
                            item.IsEnableModelSlop9 = false;
                            item.IsEnableModelSlop10 = false;

                            item.ModelSlope2 = 0;
                            item.ModelSlope3 = 0;
                            item.ModelSlope4 = 0;
                            item.ModelSlope5 = 0;
                            item.ModelSlope6 = 0;
                            item.ModelSlope7 = 0;
                            item.ModelSlope8 = 0;
                            item.ModelSlope9 = 0;
                            item.ModelSlope10 = 0;
                            break;
                        case 2:
                            item.IsEnableModelSlop1 = true;
                            item.IsEnableModelSlop2 = true;
                            item.IsEnableModelSlop3 = false;
                            item.IsEnableModelSlop4 = false;
                            item.IsEnableModelSlop5 = false;
                            item.IsEnableModelSlop6 = false;
                            item.IsEnableModelSlop7 = false;
                            item.IsEnableModelSlop8 = false;
                            item.IsEnableModelSlop9 = false;
                            item.IsEnableModelSlop10 = false;

                            item.ModelSlope3 = 0;
                            item.ModelSlope4 = 0;
                            item.ModelSlope5 = 0;
                            item.ModelSlope6 = 0;
                            item.ModelSlope7 = 0;
                            item.ModelSlope8 = 0;
                            item.ModelSlope9 = 0;
                            item.ModelSlope10 = 0;
                            break;
                        case 3:
                            item.IsEnableModelSlop1 = true;
                            item.IsEnableModelSlop2 = true;
                            item.IsEnableModelSlop3 = true;
                            item.IsEnableModelSlop4 = false;
                            item.IsEnableModelSlop5 = false;
                            item.IsEnableModelSlop6 = false;
                            item.IsEnableModelSlop7 = false;
                            item.IsEnableModelSlop8 = false;
                            item.IsEnableModelSlop9 = false;
                            item.IsEnableModelSlop10 = false;

                            item.ModelSlope4 = 0;
                            item.ModelSlope5 = 0;
                            item.ModelSlope6 = 0;
                            item.ModelSlope7 = 0;
                            item.ModelSlope8 = 0;
                            item.ModelSlope9 = 0;
                            item.ModelSlope10 = 0;
                            break;
                        case 4:
                            item.IsEnableModelSlop1 = true;
                            item.IsEnableModelSlop2 = true;
                            item.IsEnableModelSlop3 = true;
                            item.IsEnableModelSlop4 = true;
                            item.IsEnableModelSlop5 = false;
                            item.IsEnableModelSlop6 = false;
                            item.IsEnableModelSlop7 = false;
                            item.IsEnableModelSlop8 = false;
                            item.IsEnableModelSlop9 = false;
                            item.IsEnableModelSlop10 = false;

                            item.ModelSlope5 = 0;
                            item.ModelSlope6 = 0;
                            item.ModelSlope7 = 0;
                            item.ModelSlope8 = 0;
                            item.ModelSlope9 = 0;
                            item.ModelSlope10 = 0;
                            break;
                        case 5:
                            item.IsEnableModelSlop1 = true;
                            item.IsEnableModelSlop2 = true;
                            item.IsEnableModelSlop3 = true;
                            item.IsEnableModelSlop4 = true;
                            item.IsEnableModelSlop5 = true;
                            item.IsEnableModelSlop6 = false;
                            item.IsEnableModelSlop7 = false;
                            item.IsEnableModelSlop8 = false;
                            item.IsEnableModelSlop9 = false;
                            item.IsEnableModelSlop10 = false;

                            item.ModelSlope6 = 0;
                            item.ModelSlope7 = 0;
                            item.ModelSlope8 = 0;
                            item.ModelSlope9 = 0;
                            item.ModelSlope10 = 0;
                            break;
                        case 6:
                            item.IsEnableModelSlop1 = true;
                            item.IsEnableModelSlop2 = true;
                            item.IsEnableModelSlop3 = true;
                            item.IsEnableModelSlop4 = true;
                            item.IsEnableModelSlop5 = true;
                            item.IsEnableModelSlop6 = true;
                            item.IsEnableModelSlop7 = false;
                            item.IsEnableModelSlop8 = false;
                            item.IsEnableModelSlop9 = false;
                            item.IsEnableModelSlop10 = false;

                            item.ModelSlope7 = 0;
                            item.ModelSlope8 = 0;
                            item.ModelSlope9 = 0;
                            item.ModelSlope10 = 0;
                            break;
                        case 7:
                            item.IsEnableModelSlop1 = true;
                            item.IsEnableModelSlop2 = true;
                            item.IsEnableModelSlop3 = true;
                            item.IsEnableModelSlop4 = true;
                            item.IsEnableModelSlop5 = true;
                            item.IsEnableModelSlop6 = true;
                            item.IsEnableModelSlop7 = true;
                            item.IsEnableModelSlop8 = false;
                            item.IsEnableModelSlop9 = false;
                            item.IsEnableModelSlop10 = false;

                            item.ModelSlope8 = 0;
                            item.ModelSlope9 = 0;
                            item.ModelSlope10 = 0;
                            break;
                        case 8:
                            item.IsEnableModelSlop1 = true;
                            item.IsEnableModelSlop2 = true;
                            item.IsEnableModelSlop3 = true;
                            item.IsEnableModelSlop4 = true;
                            item.IsEnableModelSlop5 = true;
                            item.IsEnableModelSlop6 = true;
                            item.IsEnableModelSlop7 = true;
                            item.IsEnableModelSlop8 = true;
                            item.IsEnableModelSlop9 = false;
                            item.IsEnableModelSlop10 = false;

                            item.ModelSlope9 = 0;
                            item.ModelSlope10 = 0;
                            break;
                        case 9:
                            item.IsEnableModelSlop1 = true;
                            item.IsEnableModelSlop2 = true;
                            item.IsEnableModelSlop3 = true;
                            item.IsEnableModelSlop4 = true;
                            item.IsEnableModelSlop5 = true;
                            item.IsEnableModelSlop6 = true;
                            item.IsEnableModelSlop7 = true;
                            item.IsEnableModelSlop8 = true;
                            item.IsEnableModelSlop9 = true;
                            item.IsEnableModelSlop10 = false;

                            item.ModelSlope10 = 0;
                            break;
                        case 10:
                            item.IsEnableModelSlop1 = true;
                            item.IsEnableModelSlop2 = true;
                            item.IsEnableModelSlop3 = true;
                            item.IsEnableModelSlop4 = true;
                            item.IsEnableModelSlop5 = true;
                            item.IsEnableModelSlop6 = true;
                            item.IsEnableModelSlop7 = true;
                            item.IsEnableModelSlop8 = true;
                            item.IsEnableModelSlop9 = true;
                            item.IsEnableModelSlop10 = true;
                            break;
                        default:
                            break;
                    }
                }
            }
        }

        #region Properties

        public Context OwnerContext { get; private set; }


        public IList<ParameterSetting> ParameterSettingList { get; set; }

        public List<Parameter> ParameterList { get; set; }

        public List<VIDLifeTimeItem> LifeTimeSettings { get; set; }
        public List<SlaveInput> SlaveParameters { get; set; }

        #endregion
    }

    public class ParameterSetting
    {
        public int Index { get; set; }

        public bool IsChecked { get; set; }

        public bool IsReadOnlyIsChecked { get; set; }

        public string ParameterName { get; set; }

        public decimal? Fixed { get; set; }

        public decimal? Min { get; set; }

        public decimal? Max { get; set; }

        public string Unit { get; set; }
        public decimal? Deadband { get; set; }
        public bool IsEnableModelSlop1 { get; set; }
        public bool IsEnableModelSlop2 { get; set; }
        public bool IsEnableModelSlop3 { get; set; }
        public bool IsEnableModelSlop4 { get; set; }
        public bool IsEnableModelSlop5 { get; set; }
        public bool IsEnableModelSlop6 { get; set; }
        public bool IsEnableModelSlop7 { get; set; }
        public bool IsEnableModelSlop8 { get; set; }
        public bool IsEnableModelSlop9 { get; set; }
        public bool IsEnableModelSlop10 { get; set; }

        public decimal? FBPostDelta { get; set; }
        public decimal? ModelSlope1 { get; set; }
        public decimal? ModelSlope2 { get; set; }
        public decimal? ModelSlope3 { get; set; }
        public decimal? ModelSlope4 { get; set; }
        public decimal? ModelSlope5 { get; set; }
        public decimal? ModelSlope6 { get; set; }
        public decimal? ModelSlope7 { get; set; }
        public decimal? ModelSlope8 { get; set; }
        public decimal? ModelSlope9 { get; set; }
        public decimal? ModelSlope10 { get; set; }
        public decimal PM { get; internal set; }
        public decimal Reset { get; internal set; }
        public int Precision { get; internal set; }
        public decimal Tolerance { get; internal set; }
        public decimal FFDelta { get; internal set; }
        public decimal FBDelta { get; internal set; }
        public bool ShiftInputLimit { get; internal set; }
        public string UseRecOrUsedToFb { get; internal set; }
        public string WaferProcessLocationRegex { get; internal set; }
    }

}
