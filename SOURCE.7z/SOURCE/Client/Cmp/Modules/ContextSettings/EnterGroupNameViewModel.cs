﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using AMAT.R2R.Client.Common.ViewModels;
using AMAT.R2R.Shared.Base.DTO;
using DevExpress.Mvvm;
using DevExpress.Mvvm.DataAnnotations;

namespace AMAT.R2R.Client.Cmp.Modules.ContextSettings
{
    public class EnterGroupNameViewModel : SuperViewModel
    {
        public EnterGroupNameViewModel()
        {
            SizeToContent = System.Windows.SizeToContent.WidthAndHeight;
            Caption = "Enter Group Name";
            IsDirty = false;
        }
        

        protected override void OnViewReadyAsync()
        {
            SetFocus(nameof(GroupName));
        }

        public string GroupName
        {
            get { return GetValue<string>(); }
            set { SetValue(value); }
        }


        [Command]
        public void Select()
        {
            IsOK = true;
            CloseWindow();
        }

        public bool CanSelect()
        {
            return !string.IsNullOrEmpty(GroupName);
        }

    }
}
