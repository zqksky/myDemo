﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Threading.Tasks;
using AMAT.R2R.Client.Common.Enums;
using AMAT.R2R.Client.Common.Helpers;
using AMAT.R2R.Client.Common.Services;
using AMAT.R2R.Client.Cmp.Messages;
using AMAT.R2R.Shared.Base.DTO;
using AMAT.R2R.Shared.Cmp.DTO;
using DevExpress.Mvvm;
using DevExpress.Mvvm.DataAnnotations;
using DevExpress.Xpf.Data;
using AMAT.R2R.Client.Cmp.Modules.SpecialJobSettings;
using AMAT.R2R.Client.Common.Extensions;

namespace AMAT.R2R.Client.Cmp.Modules.ContextSettings
{
    public class ContextListViewModel : CmpViewModelBase
    {
        public const string Auth_Context = "Context";
        public const string Auth_Context_Copy = "Context:Copy";
        public const string Auth_Context_BatchUpdate = "Context:BatchUpdate";
        public const string Auth_Context_Delete = "Context:Delete";
        public const string Auth_Context_InputSettings = "Context:InputSettings";
        public const string Auth_Context_Constants = "Context:Constants";
        public const string Auth_Context_OutputSettings = "Context:OutputSettings";
        public const string Auth_Context_PreMeasurement = "Context:PreMeasurement";
        public const string Auth_Context_CreateSpecialJob = "SpecialJob:Create"; 
        public ContextListViewModel()
        {
            Caption = "Context Settings";
            Icon = "SvgImages/Business Objects/BO_KPI_Scorecard.svg";
            PropertyChanged += OnPropertyChanged;
            Messenger.Default.Register<ContextChangedMessage>(this, OnContextChanged);

            InitializePagedSource();
        }

        #region Filtering & Paging

        private void InitializePagedSource()
        {
            #region Paged Source
            var pagedSource = new PagedAsyncSource()
            {
                ElementType = typeof(ContextModel),
                KeyProperty = nameof(ContextModel.ContextKey),
                PageSize = 100,
                PageNavigationMode = PageNavigationMode.ArbitraryWithTotalPageCount
            };

#if DEBUG
            pagedSource.PageSize = 10;
#endif

            pagedSource.FetchPage += (o, e) =>
            {
                e.Result = FetchPageRowsAsync(e);
            };

            pagedSource.GetTotalSummaries += (o, e) =>
            {
                e.Result = GetSummariesAsync(e);
            };

            pagedSource.GetUniqueValues += (o, e) =>
            {
                e.Result = GetValueListAsync(e);
            };

            pagedSource.PropertyChanged += (o, e) =>
            {
                if (e.PropertyName == nameof(PagedAsyncSource.AreRowsFetching))
                {
                    IsLoading = PagedSource.AreRowsFetching;

                    // restore selection.
                    if (!IsLoading)
                    {
                        if (_lastSelectedItem != null)
                        {
                            foreach (var item in PagedSource)
                            {
                                var context = item as ContextModel;
                                if (context.ContextKey == _lastSelectedItem.ContextKey)
                                {
                                    SelectedContext = context;
                                    break;
                                }
                            }
                        }
                    }
                }
            };

            PagedSource = pagedSource;
            #endregion
        }

        ContextModel _lastSelectedItem = null;
        private async Task<FetchRowsResult> FetchPageRowsAsync(FetchPageAsyncEventArgs e)
        {
            try
            {
                if (SelectedContext != null)
                {
                    _lastSelectedItem = SelectedContext;
                }

                var items = await ContextService.GetContextListAsync(e.Filter.MakeFilters(), e.MakeSorters(), e.Skip, e.Take);
                return new FetchRowsResult(items.ToArray(), hasMoreRows: items.Count == e.Take);
            }
            catch (Exception ex)
            {
                Logger.Error(ex);
                throw;
            }
        }

        private async Task<object[]> GetSummariesAsync(GetSummariesAsyncEventArgs e)
        {
            try
            {
                var summary = await ContextService.GetContextCount(e.Filter.MakeFilters());
                return e.Summaries.Select(x =>
                {
                    return x.SummaryType == SummaryType.Count ? (object)summary : throw new InvalidOperationException();
                }).ToArray();
            }
            catch (Exception ex)
            {
                Logger.Error(ex);
                throw;
            }
        }

        private async Task<object[]> GetValueListAsync(GetUniqueValuesAsyncEventArgs e)
        {
            try
            {
                var propertyName = e.PropertyName;
                if (propertyName == nameof(Context.R2RMode))
                {
                    var values = Enum.GetValues(typeof(R2RMode)).Cast<object>().Select(f => f.ToString()).ToArray();
                    return await Task.Factory.StartNew(() => values);
                }
                else if (propertyName == nameof(Context.RecLevel))
                {
                    var values = Enum.GetValues(typeof(RecLevel)).Cast<object>().Select(f => f.ToString()).ToArray();
                    return await Task.Factory.StartNew(() => values);
                }
                else if (
                    propertyName == nameof(ContextModel.IsConstantDefined) ||
                    propertyName == nameof(ContextConstants.FF) ||
                    propertyName == nameof(ContextConstants.FB) ||
                    propertyName == nameof(ContextConstants.DeltaControl) ||
                    propertyName == nameof(ContextConstants.LifeTime) ||
                    propertyName == nameof(ContextConstants.ForceChildLotFF))
                {
                    var values = new object[] { true, false };
                    return await Task.Factory.StartNew(() => values);
                }
                else
                {
                    return await ContextService.GetContextValueListAsync(propertyName, e.Filter.MakeFilters());
                }
            }
            catch (Exception ex)
            {
                Logger.Error(ex);
                throw;
            }
        }

        #endregion


        #region Events

        protected override void OnViewReadyAsync()
        {
            //Refresh();
        }
        public override void OnRemoving(CancelEventArgs e)
        {
            base.OnRemoving(e);

            PagedSource?.Dispose();
            Messenger.Default.Unregister<ContextChangedMessage>(this, OnContextChanged);
        }

        private async void OnPropertyChanged(object sender, System.ComponentModel.PropertyChangedEventArgs e)
        {
            if (e.PropertyName == nameof(SelectedContext))
            {
                if (SelectedContext != null)
                {
                    await GetContextDetailsAsync();
                }
                else
                {
                    ClearContextDetails();
                }
            }
        }

        private void OnContextChanged(ContextChangedMessage msg)
        {
            Refresh();
        }

        private async Task UpdateSingleContext(ContextModel context)
        {
            var lastModifiedTime = context.LastModifiedTime;
            var newContext = await ContextService.GetContextAsync(context.ContextKey);
            context.Process = newContext.Process;
            context.LastModifiedBy = newContext.LastModifiedBy;
            context.LastModifiedTime = newContext.LastModifiedTime;
            context.NotifyChanges();

            if (SelectedContext != null && context.ContextKey == SelectedContext.ContextKey && lastModifiedTime != newContext.LastModifiedTime)
            {
                await GetContextDetailsAsync();
            }
        }
        #endregion

        #region Commands

        [Command]
        public void Refresh()
        {
            PagedSource.UpdateSummaries();
            PagedSource.RefreshRows();
        }

        public bool CanRefresh()
        {
            return !IsLoading;
        }

        private async Task GetContextDetailsAsync()
        {
            if (SelectedContext != null)
            {
                ContextInputVM = new ViewContextInputViewModel(SelectedContext);
                ContextOutputVM = new ViewContextOutputViewModel(SelectedContext, SettingType.Output);
                ContextPreMetroVM = new ViewContextOutputViewModel(SelectedContext, SettingType.PreMeasurement);

                try
                {
                    IsHistoryLoading = true;
                    HistoryList = new ObservableCollection<TransactionHistory>(await GlobalService.GetHistoryAsync(ClientInfo.LoginArea, "Context", SelectedContext.ContextKey, null));
                }
                finally
                {
                    IsHistoryLoading = false;
                }
            }
            else
            {
                HistoryList?.Clear();
            }
        }

        [Command]
        public async void CopyContext()
        {
            await UpdateBeforeAction();
            ShowPopup("EditContext", new EditContextViewModel(SelectedContext.Process, SelectedContext, FunctionMode.Copy));
        }

        public bool CanCopyContext()
        {
            return SelectedContext != null && SelectedContextList.Count == 1 && !IsLoading &&
                AuthorityManager.HasAuthority(Auth_Context_Copy);
        }

        [Command]
        public async void BatchUpdateContext()
        {
            await UpdateBeforeAction();
            ShowPopup("BatchUpdateContext", new BatchUpdateContextViewModel(SelectedContextList.ToList()));
        }

        public bool CanBatchUpdateContext()
        {
            return SelectedContextList != null && SelectedContextList.Count > 0 && !IsLoading &&
                AuthorityManager.HasAuthority(Auth_Context_BatchUpdate);
        }

        [Command]
        public async void DeleteContext()
        {
            await UpdateBeforeAction();
            if (IsConfirmed(out var comment, $"Delete Context"))
            {
                var toDeleteContext = SelectedContext;
                await ContextService.DeleteContextAsync(SelectedContext.ContextKey, comment);
                Messenger.Default.Send(new ContextChangedMessage() { ChangeType = ObjectChangeType.Deleted, ContextKey = toDeleteContext.ContextKey });
                MessageBoxService.ShowMessage($"Context {toDeleteContext.ContextKey} is deleted.", "Success", MessageButton.OK, MessageIcon.Information);
            }
        }

        public bool CanDeleteContext()
        {
            return SelectedContext != null && SelectedContextList.Count == 1 && !IsLoading &&
                AuthorityManager.HasAuthority(Auth_Context_Delete);
        }

        private void ClearContextDetails()
        {
            _lastSelectedItem = null;
            ContextInputVM = null;
            ContextOutputVM = null;
            ContextPreMetroVM = null;
            HistoryList?.Clear();
        }


        [Command]
        public async void EditContextInput()
        {
            await UpdateBeforeAction();
            ShowPopup("EditContextInput", new EditContextInputViewModel(SelectedContext, FunctionMode.Modify));
        }

        public bool CanEditContextInput()
        {
            return SelectedContext != null && SelectedContextList.Count == 1 && !IsLoading &&
                AuthorityManager.HasAuthority(Auth_Context_InputSettings);
        }

        [Command]
        public async void EditContextConstants()
        {
            await UpdateBeforeAction();
            ShowPopup("EditContextConstants", new EditContextConstantsViewModel(SelectedContext));
        }

        public bool CanEditContextConstants()
        {
            return SelectedContext != null && SelectedContextList.Count == 1 && !IsLoading && AuthorityManager.HasAuthority(Auth_Context_Constants);
        }

        [Command]
        public async void EditContextOutputs()
        {
            await UpdateBeforeAction();
            ShowPopup("EditContextOutput", new EditContextOutputViewModel(SelectedContext, SettingType.Output));
        }

        public bool CanEditContextOutputs()
        {
            return SelectedContext != null && SelectedContextList.Count == 1 && !IsLoading && AuthorityManager.HasAuthority(Auth_Context_OutputSettings);
        }

        [Command]
        public async void EditContextPreMeasures()
        {
            await UpdateBeforeAction();
            ShowPopup("EditContextOutput", new EditContextOutputViewModel(SelectedContext, SettingType.PreMeasurement));
        }

        public bool CanEditContextPreMeasures()
        {
            return SelectedContext != null && SelectedContextList.Count == 1 && !IsLoading && AuthorityManager.HasAuthority(Auth_Context_PreMeasurement);
        }


        public async Task UpdateBeforeAction()
        {
            ShowWait();
            await Task.WhenAll(SelectedContextList.Select(context => UpdateSingleContext(context)));
            HideWait();
        }

        [Command]
        public async void CreateSpecialJob()
        {
            await UpdateBeforeAction();
            string key = string.Format("{0}:{1}:{2}:{3}:{4}", SelectedContext.Fab, SelectedContext.Product, SelectedContext.ProcessStep, SelectedContext.Tool, SelectedContext.Recipe);
            var contextList = await ContextService.GetContextListAsync(new QueryFilter[] { new QueryFilter("fab", ClientInfo.LoginFab), new QueryFilter("product", SelectedContext.Product), new QueryFilter("ProcessStep", SelectedContext.ProcessStep), new QueryFilter("tool", SelectedContext.Tool), new QueryFilter("recipe", SelectedContext.Recipe) });
            var ModelGroupContexList = contextList.FindAll(p => p.ContextKey.Contains(key));
            ShowPopup("EditSpecialJob", new EditSpecialJobViewModel(SelectedContext, ModelGroupContexList.ToList<Context>(), new SpecialJob(), FunctionMode.Add));
        }

        public bool CanCreateSpecialJob()
        {
            return SelectedContext != null && SelectedContextList.Count == 1 && SelectedContext.ContextInputParas.Count > 0 && !IsLoading && AuthorityManager.HasAuthority(Auth_Context_CreateSpecialJob);
        }

        #endregion

        #region Properties


        public PagedAsyncSource PagedSource
        {
            get { return GetValue<PagedAsyncSource>(); }
            set { SetValue(value); }
        }


        public ViewContextInputViewModel ContextInputVM
        {
            get { return GetValue<ViewContextInputViewModel>(); }
            set { SetValue(value); }
        }
        public ViewContextOutputViewModel ContextOutputVM
        {
            get { return GetValue<ViewContextOutputViewModel>(); }
            set { SetValue(value); }
        }
        public ViewContextOutputViewModel ContextPreMetroVM
        {
            get { return GetValue<ViewContextOutputViewModel>(); }
            set { SetValue(value); }
        }


        public ObservableCollection<ContextModel> ContextList
        {
            get { return GetValue<ObservableCollection<ContextModel>>(); }
            set { SetValue(value); }
        }

        public ContextModel SelectedContext
        {
            get { return GetValue<ContextModel>(); }
            set { SetValue(value); }
        }

        public ObservableCollection<ContextModel> SelectedContextList { get; } = new ObservableCollection<ContextModel>();


        public ObservableCollection<string> FabList
        {
            get { return GetValue<ObservableCollection<string>>(); }
            set { SetValue(value); }
        }

        public ObservableCollection<string> ProductList
        {
            get { return GetValue<ObservableCollection<string>>(); }
            set { SetValue(value); }
        }

        public ObservableCollection<string> RecipeList
        {
            get { return GetValue<ObservableCollection<string>>(); }
            set { SetValue(value); }
        }
        #endregion
    }


    internal class ContextFilter
    {
        public ContextFilter(string product = null, string recipe = null, string stage = null, string stepNumber = null, string stepName = null, bool? processEnabled = null, bool? contextGroupEnabled = null, string lastModifiedBy = null)
        {
            ProductId = product;
            Recipe = recipe;
            Stage = stage;
            StepName = stepName;
            StepNumber = stepNumber;
            ProcessEnabled = processEnabled;
            ContextGroupEnabled = contextGroupEnabled;
            LastModifiedBy = lastModifiedBy;
        }
        public string ProductId { get; private set; }
        public string Recipe { get; private set; }
        public string Stage { get; private set; }
        public string StepNumber { get; private set; }
        public string StepName { get; private set; }
        public bool? ProcessEnabled { get; private set; }
        public bool? ContextGroupEnabled { get; private set; }
        public string LastModifiedBy { get; private set; }


        public string Tool { get; private set; }
        public string Chamber { get; private set; }
        public string ContextGroup { get; private set; }
    }
}
