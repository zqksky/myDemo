﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data.Objects;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Documents;
using AMAT.R2R.Client.Common.Enums;
using AMAT.R2R.Client.Common.Helpers;
using AMAT.R2R.Client.Common.Messages;
using AMAT.R2R.Client.Common.Services;
using AMAT.R2R.Client.Common.ViewModels;
using AMAT.R2R.Client.Common.Views;
using AMAT.R2R.Client.Cmp.Messages;
using AMAT.R2R.Shared.Base.DTO;
using AMAT.R2R.Shared.Cmp.DTO;
using DevExpress.Mvvm;
using DevExpress.Mvvm.DataAnnotations;
using DevExpress.Mvvm.Native;
using DevExpress.Mvvm.POCO;
using DevExpress.Xpf.Bars;
using Newtonsoft.Json;

namespace AMAT.R2R.Client.Cmp.Modules.ContextSettings
{
    public class BatchUpdateContextViewModel : CmpViewModelBase
    {
        private const string NA = "NA";

        public BatchUpdateContextViewModel(List<ContextModel> contextList)
        {
            if (contextList is null)
            {
                throw new ArgumentNullException(nameof(contextList));
            }

            ContextList = new ObservableCollection<ContextModel>(contextList);

            SizeToContent = System.Windows.SizeToContent.Manual;
            Mode = FunctionMode.Modify;
            Caption = "Batch Update Context";
        }

        private void Initialize()
        {
            if (ContextList.Select(c => c.R2RMode).Distinct().Count() > 1)
            {
                R2RMode = null;
            }
            else
            {
                R2RMode = ContextList.First().R2RMode;
            }


            if (ContextList.Select(c => c.RecLevel).Distinct().Count() > 1)
            {
                RecLevel = null;
            }
            else
            {
                RecLevel = ContextList.First().RecLevel;
            }


            if (ContextList.Select(c => c.ContextConstants.FF).Distinct().Count() > 1)
            {
                FF = null;
            }
            else
            {
                FF = ContextList.First().ContextConstants.FF;
            }

            if (ContextList.Select(c => c.ContextConstants.FB).Distinct().Count() > 1)
            {
                FB = null;
            }
            else
            {
                FB = ContextList.First().ContextConstants.FB;
            }

            if (ContextList.Select(c => c.ContextConstants.LifeTime).Distinct().Count() > 1)
            {
                LifeTime = null;
            }
            else
            {
                LifeTime = ContextList.First().ContextConstants.LifeTime;
            }

            if (ContextList.Select(c => c.ContextConstants.DeltaControl).Distinct().Count() > 1)
            {
                DeltaControl = null;
            }
            else
            {
                DeltaControl = ContextList.First().ContextConstants.DeltaControl;
            }


            IsR2RModeChanged = false;
            IsRecLevelChanged = false;
            IsConstantsChanged = false;
            IsDirty = false;
        }

        protected override void OnViewReadyAsync()
        {
            Initialize();
        }

        [Command]
        public async void UpdateContext(string fieldName)
        {
            List<ContextModel> failList = new List<ContextModel>();
            StringBuilder sb = new StringBuilder();
            // 
            if (IsConfirmed(out string comment))
            {
                ShowWait();

                foreach (var context in ContextList)
                {
                    try
                    {
                        // clone context.
                        var newContext = JsonConvert.DeserializeObject<Context>(JsonConvert.SerializeObject(context));
                        switch (fieldName)
                        {
                            case "R2RMode":
                                newContext.R2RMode = R2RMode.Value;
                                await ContextService.UpdateContextAsync(newContext, newContext.ContextKey, comment);
                                break;
                            case "RecLevel":
                                newContext.RecLevel = RecLevel.Value;
                                await ContextService.UpdateContextAsync(newContext, newContext.ContextKey, comment);
                                break;
                            case "Constants":
                                newContext.ContextConstants.FF = FF.Value;
                                newContext.ContextConstants.FB = FB.Value;
                                newContext.ContextConstants.LifeTime = LifeTime.Value;
                                newContext.ContextConstants.DeltaControl = DeltaControl.Value;
                                await ContextService.UpdateContextConstantsAsync(newContext.ContextConstants, newContext.ContextKey, comment);
                                break;
                            default:
                                break;
                        }
                    }
                    catch (Exception ex)
                    {
                        failList.Add(context);
                        sb.AppendLine(LocalizationService.LocalizeException(ex));
                    }
                }

                HideWait();

                var successCount = ContextList.Count - failList.Count;

                if (successCount > 0)
                {
                    var successList = ContextList.Except(failList);
                    foreach (var context in successList)
                    {
                        Messenger.Default.Send(new ContextChangedMessage() { ChangeType = ObjectChangeType.Updated, ContextKey = context.ContextKey });
                    }
                }

                // show updated list.
                Initialize();
                // show error if any
                if (failList.Count <= 0)
                {
                    MessageBoxService.ShowMessage($"{successCount} updated successfully.", "Success", MessageButton.OK, MessageIcon.Information);
                }
                else if (successCount > 0)
                {
                    MessageBoxService.ShowMessage($"{successCount} updated successfully.\n{failList.Count} update failed.\n{sb}", "Partial Success", MessageButton.OK, MessageIcon.Error);
                }
                else
                {
                    MessageBoxService.ShowMessage($"Update failed.\n{sb}", "Error", MessageButton.OK, MessageIcon.Error);
                }
            }
        }

        public bool CanUpdateContext(string fieldName)
        {
            switch (fieldName)
            {
                case "R2RMode":
                    return R2RMode.HasValue && IsR2RModeChanged;
                case "RecLevel":
                    return RecLevel.HasValue && IsRecLevelChanged;
                case "Constants":
                    return FF.HasValue && FB.HasValue && LifeTime.HasValue && DeltaControl.HasValue && IsConstantsChanged;
                default:
                    return false;
            }
        }

        protected override string GetError(string columnName)
        {
            switch (columnName)
            {
                default:
                    return null;
            }
        }

        #region Properties

        public ObservableCollection<ContextModel> ContextList
        {
            get { return GetValue<ObservableCollection<ContextModel>>(); }
            set { SetValue(value); }
        }

        public R2RMode? R2RMode
        {
            get { return GetValue<R2RMode?>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                IsR2RModeChanged = true;
            }
        }

        public RecLevel? RecLevel
        {
            get { return GetValue<RecLevel?>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                IsRecLevelChanged = true;
            }
        }

        public bool? FF
        {
            get { return GetValue<bool?>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                IsConstantsChanged = true;
            }
        }

        public bool? FB
        {
            get { return GetValue<bool?>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                IsConstantsChanged = true;
            }
        }
        public bool? LifeTime
        {
            get { return GetValue<bool?>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                IsConstantsChanged = true;
            }
        }

        public bool? DeltaControl
        {
            get { return GetValue<bool?>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                IsConstantsChanged = true;
            }
        }

        public bool IsR2RModeChanged
        {
            get { return GetValue<bool>(); }
            set { SetValue(value); }
        }

        public bool IsConstantsChanged
        {
            get { return GetValue<bool>(); }
            set { SetValue(value); }
        }

        public bool IsRecLevelChanged
        {
            get { return GetValue<bool>(); }
            set { SetValue(value); }
        }



        #endregion
    }
}
