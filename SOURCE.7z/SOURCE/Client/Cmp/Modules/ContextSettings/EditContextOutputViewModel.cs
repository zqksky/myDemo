﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Threading.Tasks;
using AMAT.R2R.Client.Common.Enums;
using AMAT.R2R.Client.Common.Helpers;
using AMAT.R2R.Client.Cmp.Messages;
using AMAT.R2R.Client.Cmp.Properties;
using AMAT.R2R.Client.Cmp.Services;
using AMAT.R2R.Shared.Base.DTO;
using AMAT.R2R.Shared.Cmp.DTO;
using DevExpress.DirectX.Common.DXGI;
using DevExpress.Mvvm;
using DevExpress.Mvvm.DataAnnotations;
using DevExpress.Mvvm.Native;
using DevExpress.Mvvm.UI.Native;
using DevExpress.Utils;
using Newtonsoft.Json;
using AMAT.R2R.Client.Common.Extensions;

namespace AMAT.R2R.Client.Cmp.Modules.ContextSettings
{
    public enum SettingType
    {
        Output,
        PreMeasurement
    }

    public class EditContextOutputViewModel : CmpViewModelBase
    {
        public SettingType SettingType { get; set; }
        public bool IsFromContextList { get; set; }
        public EditContextOutputViewModel(Context context, SettingType settingType, bool isFromContextList = true)
        {
            OwnerContext = context ?? throw new ArgumentNullException(nameof(context));
            Mode = FunctionMode.Modify;
            SettingType = settingType;

            SizeToContent = System.Windows.SizeToContent.Manual;
            WindowWidth = 1200;
            WindowHeight = 700;

            IsFromContextList = isFromContextList;

            Caption = $"Update Context {settingType}";

            var targetSettingType = settingType == SettingType.Output ? "PreMeasurement" : "Outputs";

            CopyButtonContent = $"Copy to {targetSettingType} Settings";

            PropertyChanged += EditContextOutputViewModel_PropertyChanged;

            IsEditView = true;
        }

        private void EditContextOutputViewModel_PropertyChanged(object sender, PropertyChangedEventArgs e)
        {
        }

        protected override void OnViewReadyAsync()
        {
            Initialize();
        }

        private async void Initialize()
        {
            ShowWait();

            try
            {
                ParameterList = new ObservableCollection<Parameter>(await GlobalService.GetMetroParameterListAsync());

                QualityItemNameList = GlobalService.GetGOFItemList();

                LoadParameterSettings();
            }
            finally
            {
                HideWait();
            }

            IsDirty = false;
        }

        private void LoadParameterSettings()
        {
            var sourceGroupList = SettingType == SettingType.Output ? OwnerContext.Outputs : OwnerContext.PreMeasurements;

            var groups = sourceGroupList.Select(group => new OutputGroupModel
            {
                GroupName = group.OutputGroupName,

                OutputSettingList = new ObservableCollection<OutputSettingsModel>(group.ContextOutputs.Select(output => new OutputSettingsModel
                {
                    MeasItemName = output.MeasItemName,
                    LowerSpecLimit = (decimal)output.LowerSpecLimit,
                    LowerLimit = (decimal)output.LowerLimit,
                    UpperLimit = (decimal)output.UpperLimit,
                    UpperSpecLimit = (decimal)output.UpperSpecLimit,
                    Coefficients = (decimal)output.Coefficients,
                    CoefficientsPiRun = (decimal)output.CoefficientsPiRun,
                    MeasDFCRange = output.MeasDFCRange,
                    MinSitesRequired = output.MinSitesRequired,
                    MaxOocSitesAllowed = output.MaxOocSitesAllowed,
                    MaxOosSitesAllowed = output.MaxOosSitesAllowed,
                    QualityItemName = output.QualityItemName,
                    QualityThreshold = (decimal)output.QualityThreshold,
                    Target = (decimal)output.Target,
                    Precision = output.Precision,
                    Index = output.Index,
                    Multiplier = (decimal)output.Multiplier,
                    OCAP = output.OCAP,
                    SiteOrders = output.SiteOrders,
                    GroupName = group.OutputGroupName,
                }).OrderBy(o => o.Index))
            });
            OutputGroupList = new ObservableCollection<OutputGroupModel>(groups.OrderBy(g => g.GroupName));

            foreach (var group in OutputGroupList)
            {
                foreach (var output in group.OutputSettingList)
                {
                    output.IsDirty = false;
                    output.PropertyChanged += Output_PropertyChanged;
                }
                group.SelectedOutputSetting = group.OutputSettingList.FirstOrDefault();
                group.IsDirty = false;
                group.PropertyChanged += Group_PropertyChanged;
            }

            OutputGroupList.CollectionChanged += OutputGroupList_CollectionChanged;

            SelectedGroup = OutputGroupList.FirstOrDefault();

            IsDirty = false;

            //if (OutputGroupList.Count == 0)
            //{
            //    AddGroup();
            //    SelectedGroup = OutputGroupList.FirstOrDefault();
            //}

            //if (SelectedGroup.OutputSettingList.Count == 0)
            //{
            //    AddIndex();
            //    SelectedGroup.SelectedOutputSetting = SelectedGroup.OutputSettingList.FirstOrDefault();
            //}
        }

        private void Output_PropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            // every change in each output setting will set the Group's IsDirty to True.
            var ownerGroup = OutputGroupList.FirstOrDefault(group => group.OutputSettingList.Any(output => output == sender));
            if (ownerGroup != null)
            {
                ownerGroup.IsDirty = true;
            }
        }

        private void Group_PropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            // any Group's IsDirty = true will set the View's IsDirty to True.
            if (e.PropertyName == nameof(OutputGroupModel.IsDirty))
            {
                if ((sender as OutputGroupModel).IsDirty)
                {
                    IsDirty = true;
                }
            }
        }

        private void OutputGroupList_CollectionChanged(object sender, System.Collections.Specialized.NotifyCollectionChangedEventArgs e)
        {
            IsDirty = true;
        }


        protected override string GetError(string columnName)
        {
            switch (columnName)
            {
                default:
                    return null;
            }
        }

        #region Commands

        [Command]
        public void AddGroup()
        {
            var enterGroupNameViewModel = new EnterGroupNameViewModel();
            if (ShowPopup("EnterGroupName", enterGroupNameViewModel).IsOK)
            {
                AddGroupByName(enterGroupNameViewModel.GroupName);
            }
        }

        private void AddGroupByName(string groupName)
        {
            var newGroup = new OutputGroupModel() { GroupName = groupName };
            if (SelectedGroup != null)
            {
                // copy selected group.
                newGroup.OutputSettingList = new ObservableCollection<OutputSettingsModel>();

                foreach (var output in SelectedGroup.OutputSettingList)
                {
                    var newSetting = CopyOutputSetting(output);
                    newSetting.GroupName = newGroup.GroupName;
                    newSetting.PropertyChanged += Output_PropertyChanged;
                    newSetting.IsDirty = true;
                    newGroup.OutputSettingList.Add(newSetting);
                }
                newGroup.SelectedOutputSetting = newGroup.OutputSettingList.FirstOrDefault();
                newGroup.GroupName = groupName;
            }
            else
            {
                // create default setting..
                var newSetting = new OutputSettingsModel
                {
                    Index = 1,
                    IsDirty = true
                };
                newSetting.GroupName = newGroup.GroupName;
                newSetting.PropertyChanged += Output_PropertyChanged;
                newGroup.OutputSettingList.Add(newSetting);
                newGroup.SelectedOutputSetting = newSetting;
                newGroup.IsDirty = true;
            }

            newGroup.PropertyChanged += Group_PropertyChanged;

            OutputGroupList.Add(newGroup);
            SelectedGroup = newGroup;
        }

        private static OutputSettingsModel CopyOutputSetting(OutputSettingsModel output)
        {
            return new OutputSettingsModel()
            {
                MeasItemName = output.MeasItemName,
                LowerSpecLimit = output.LowerSpecLimit,
                LowerLimit = output.LowerLimit,
                UpperLimit = output.UpperLimit,
                UpperSpecLimit = output.UpperSpecLimit,
                Coefficients = output.Coefficients,
                CoefficientsPiRun = output.CoefficientsPiRun,
                MeasDFCRange = output.MeasDFCRange,
                MinSitesRequired = output.MinSitesRequired,
                MaxOocSitesAllowed = output.MaxOocSitesAllowed,
                MaxOosSitesAllowed = output.MaxOosSitesAllowed,
                QualityItemName = output.QualityItemName,
                QualityThreshold = output.QualityThreshold,
                Target = output.Target,
                Precision = output.Precision,
                Index = output.Index,
                Multiplier = output.Multiplier,
                OCAP = output.OCAP,
                SiteOrders = output.SiteOrders,
            };
        }

        [Command]
        public void DeleteGroup()
        {
            if (SelectedGroup != null)
            {
                SelectedGroup.OutputSettingList.ForEach(output => output.PropertyChanged -= Output_PropertyChanged);
                SelectedGroup.PropertyChanged -= Group_PropertyChanged;
                OutputGroupList.Remove(SelectedGroup);
                SelectedGroup = OutputGroupList.FirstOrDefault();
                IsDirty = true;
            }
        }

        [Command]
        public void AddIndex()
        {
            if (SelectedGroup != null)
            {
                var newSetting = new OutputSettingsModel();
                if (SelectedGroup.SelectedOutputSetting != null)
                {
                    // copy selected setting.
                    newSetting = CopyOutputSetting(SelectedGroup.SelectedOutputSetting);
                }
                else
                {
                    // default setting.
                    newSetting.QualityThreshold = (decimal)0.9;
                    newSetting.Coefficients = (decimal)0.3;
                    newSetting.CoefficientsPiRun = (decimal)1.0;
                    newSetting.Multiplier = (decimal)1.0;
                    newSetting.MinSitesRequired = 9;
                    newSetting.MaxOocSitesAllowed = 3;
                    newSetting.MaxOosSitesAllowed = 3;
                    newSetting.Precision = 3;
                }

                newSetting.GroupName = SelectedGroup.GroupName;
                newSetting.Index = SelectedGroup.OutputSettingList.Count > 0 ? SelectedGroup.OutputSettingList.Max(output => output.Index) + 1 : 1;
                newSetting.IsDirty = true;
                newSetting.PropertyChanged += Output_PropertyChanged;

                SelectedGroup.OutputSettingList.Add(newSetting);
                SelectedGroup.SelectedOutputSetting = newSetting;
                SelectedGroup.IsDirty = true;
            }
        }

        [Command]
        public void DeleteIndex()
        {
            if (SelectedGroup != null && SelectedGroup.SelectedOutputSetting != null)
            {
                SelectedGroup.SelectedOutputSetting.PropertyChanged -= Output_PropertyChanged;
                SelectedGroup.OutputSettingList.Remove(SelectedGroup.SelectedOutputSetting);
                SelectedGroup.IsDirty = true;
            }
        }

        private bool ValidateGroupSettings()
        {
            foreach (var group in OutputGroupList)
            {
                foreach (var output in group.OutputSettingList)
                {
                    output.Validate();
                    if (output.HasErrors)
                    {
                        SelectedGroup = group;
                        SelectedGroup.SelectedOutputSetting = output;
                        return false;
                    }
                }
            }
            return true;
        }

        [Command]
        public async void Save()
        {
            if(!ValidateGroupSettings())
            {
                return;
            }

            if (IsConfirmed(out var comment, $"Save {SettingType} Settings"))
            {
                ShowWait();

                var submitContext = JsonConvert.DeserializeObject<ContextModel>(JsonConvert.SerializeObject(OwnerContext));

                if (SettingType == SettingType.Output)
                {
                    submitContext.Outputs = MakeContextOutputGroupDTOList();
                    await ContextService.UpdateContextOutputAsync(submitContext, OwnerContext.ContextKey, comment);
                }
                else
                {
                    submitContext.PreMeasurements = MakeContextOutputGroupDTOList();
                    await ContextService.UpdateContextPreMeasureAsync(submitContext, OwnerContext.ContextKey, comment);
                }

                IsDirty = false;

                HideWait();

                Messenger.Default.Send(new ContextChangedMessage() { ChangeType = ObjectChangeType.Updated, ContextKey = OwnerContext.ContextKey });

                MessageBoxService.ShowMessage($"{SettingType} Settings are saved.", "Success!", MessageButton.OK, MessageIcon.Information);

                CloseWindow();
            }
        }

        private static ContextOutput ConvertOutputModelToDTO(OutputSettingsModel output)
        {
            return new ContextOutput
            {
                Coefficients = (double)output.Coefficients.Value,
                CoefficientsPiRun = (double)output.CoefficientsPiRun.Value,
                Index = output.Index,
                LowerLimit = (double)output.LowerLimit.Value,
                LowerSpecLimit = (double)output.LowerSpecLimit.Value,
                UpperLimit = (double)output.UpperLimit.Value,
                UpperSpecLimit = (double)output.UpperSpecLimit,
                MaxOocSitesAllowed = (int)output.MaxOocSitesAllowed.Value,
                MaxOosSitesAllowed = (int)output.MaxOosSitesAllowed.Value,
                MeasDFCRange = output.MeasDFCRange,
                MeasItemName = output.MeasItemName,
                MinSitesRequired = (int)output.MinSitesRequired.Value,
                Multiplier = (double)output.Multiplier.Value,
                OCAP = output.OCAP,
                Precision = (int)output.Precision.Value,
                QualityItemName = output.QualityItemName,
                QualityThreshold = (double)output.QualityThreshold.Value,
                SiteOrders = output.SiteOrders,
                Target = (double)output.Target,
            };
        }

        public bool CanSave()
        {
            return OutputGroupList != null && OutputGroupList.All(g => g.OutputSettingList.Count > 0) && IsDirty;
        }

        [Command]
        public async void CopyToPreMeasOrOutput()
        {
            if (!ValidateGroupSettings())
            {
                return;
            }

            var targetSettingType = SettingType == SettingType.Output ? "PreMeasurement" : "Outputs";

            if (IsConfirmed(out var comment, $"Copy to {targetSettingType}"))
            {
                ShowWait();

                var submitContext = JsonConvert.DeserializeObject<ContextModel>(JsonConvert.SerializeObject(OwnerContext));

                if (SettingType == SettingType.Output)
                {
                    submitContext.PreMeasurements = MakeContextOutputGroupDTOList();
                    await ContextService.UpdateContextPreMeasureAsync(submitContext, OwnerContext.ContextKey, comment);
                }
                else
                {
                    submitContext.Outputs = MakeContextOutputGroupDTOList();
                    await ContextService.UpdateContextOutputAsync(submitContext, OwnerContext.ContextKey, comment);
                }

                HideWait();

                Messenger.Default.Send(new ContextChangedMessage() { ChangeType = ObjectChangeType.Updated, ContextKey = OwnerContext.ContextKey });

                MessageBoxService.ShowMessage($"{SettingType} Settings are copied to {targetSettingType} Settings.", "Success!", MessageButton.OK, MessageIcon.Information);
                CloseWindow();
            }
        }

        private List<ContextOutputGroup> MakeContextOutputGroupDTOList()
        {
            var groups = new List<ContextOutputGroup>();

            foreach (var item in OutputGroupList)
            {
                var group = new ContextOutputGroup
                {
                    ContextKey = OwnerContext.ContextKey,
                    OutputGroupName = item.GroupName,
                    ContextOutputs = new List<ContextOutput>()
                };

                foreach (var output in item.OutputSettingList)
                {
                    var setting = ConvertOutputModelToDTO(output);
                    group.ContextOutputs.Add(setting);
                }

                groups.Add(group);
            }
            return groups;
        }

        public bool CanCopyToPreMeasOrOutput()
        {
            // if is dirty, must save before copy.
            return !IsDirty;
        }


        #endregion

        #region Properties
        public Context OwnerContext { get; private set; }


        public ObservableCollection<Parameter> ParameterList
        {
            get { return GetValue<ObservableCollection<Parameter>>(); }
            set { SetValue(value); }
        }

        public ObservableCollection<OutputGroupModel> OutputGroupList
        {
            get { return GetValue<ObservableCollection<OutputGroupModel>>(); }
            set { SetValue(value); }
        }

        public OutputGroupModel SelectedGroup
        {
            get { return GetValue<OutputGroupModel>(); }
            set { SetValue(value); }
        }

        public List<OutputSettingsModel> AllOutputSettingList
        {
            get { return GetValue<List<OutputSettingsModel>>(); }
            set { SetValue(value); }
        }
        public List<string> QualityItemNameList
        {
            get { return GetValue<List<string>>(); }
            set { SetValue(value); }
        }


        public bool IsEditView
        {
            get { return GetValue<bool>(); }
            set
            {
                SetValue(value);
            }
        }

        public bool IsGridView
        {
            get { return GetValue<bool>(); }
            set
            {
                SetValue(value);
                IsEditView = !IsGridView;
                RaisePropertyChanged(nameof(IsEditView));
                if (value)
                {
                    AllOutputSettingList = OutputGroupList.SelectMany(g => g.OutputSettingList).ToList();
                }
            }
        }

        public string CopyButtonContent
        {
            get { return GetValue<string>(); }
            set { SetValue(value); }
        }


        #endregion
    }


}
