﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Threading.Tasks;
using AMAT.R2R.Client.Common.Enums;
using AMAT.R2R.Client.Common.Helpers;
using AMAT.R2R.Client.Cmp.Messages;
using AMAT.R2R.Client.Cmp.Properties;
using AMAT.R2R.Client.Cmp.Services;
using AMAT.R2R.Shared.Base.DTO;
using AMAT.R2R.Shared.Cmp.DTO;
using DevExpress.DirectX.Common.DXGI;
using DevExpress.Mvvm;
using DevExpress.Mvvm.DataAnnotations;
using DevExpress.Mvvm.Native;
using DevExpress.Mvvm.UI.Native;
using DevExpress.Utils;
using Newtonsoft.Json;
using AMAT.R2R.Client.Common.ViewModels;

namespace AMAT.R2R.Client.Cmp.Modules.ContextSettings
{
    public class OutputSettingsModel : SuperViewModel
    {
        public OutputSettingsModel()
        {
        }

        protected override void OnViewReadyAsync()
        {

        }

        public string MeasItemName
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(MeasItemName));
            }
        }

        public string QualityItemName
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(QualityItemName));
            }
        }

        public int Index
        {
            get { return GetValue<int>(); }
            set
            {
                SetValue(value);
            }
        }

        public decimal? QualityThreshold
        {
            get { return GetValue<decimal?>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(QualityThreshold));
            }
        }

        public decimal? Target
        {
            get { return GetValue<decimal?>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(Target));
            }
        }
        public decimal? LowerSpecLimit
        {
            get { return GetValue<decimal?>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(LowerSpecLimit));
            }
        }

        public decimal? LowerLimit
        {
            get { return GetValue<decimal?>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(LowerLimit));
            }
        }

        public decimal? UpperLimit
        {
            get { return GetValue<decimal?>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(UpperLimit));
            }
        }

        public decimal? UpperSpecLimit
        {
            get { return GetValue<decimal?>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(UpperSpecLimit));
            }
        }

        public decimal? Multiplier
        {
            get { return GetValue<decimal?>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(Multiplier));
            }
        }

        public decimal? Coefficients
        {
            get { return GetValue<decimal?>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(Coefficients));
            }
        }

        public decimal? CoefficientsPiRun
        {
            get { return GetValue<decimal?>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(CoefficientsPiRun));
            }
        }

        public string SiteOrders
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(SiteOrders));
            }
        }

        public string MeasDFCRange
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(MeasDFCRange));
            }
        }

        public decimal? MinSitesRequired
        {
            get { return GetValue<decimal?>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(MinSitesRequired));
            }
        }

        public decimal? MaxOocSitesAllowed
        {
            get { return GetValue<decimal?>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(MaxOocSitesAllowed));
            }
        }

        public decimal? MaxOosSitesAllowed
        {
            get { return GetValue<decimal?>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(MaxOosSitesAllowed));
            }
        }

        public string OCAP
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(OCAP));
            }
        }

        public int? Precision
        {
            get { return GetValue<int?>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(Precision));
            }
        }

        public string GroupName { get; set; }

        protected override string GetError(string columnName)
        {
            switch (columnName)
            {
                case nameof(MeasItemName):
                    return DataValidator.NotNull(MeasItemName);
                case nameof(LowerLimit):
                    return DataValidator.ValidateInOrder(
                        () => DataValidator.NotNull(LowerLimit),
                        () => DataValidator.SmallerThanOrEqualTo(LowerLimit, UpperLimit));
                case nameof(UpperLimit):
                    return DataValidator.ValidateInOrder(
                        () => DataValidator.NotNull(UpperLimit),
                        () => DataValidator.LargerThanOrEqualTo(UpperLimit, LowerLimit));
                case nameof(LowerSpecLimit):
                    return DataValidator.ValidateInOrder(
                        () => DataValidator.NotNull(LowerSpecLimit),
                        () => DataValidator.SmallerThanOrEqualTo(LowerSpecLimit, UpperSpecLimit));
                case nameof(UpperSpecLimit):
                    return DataValidator.ValidateInOrder(
                        () => DataValidator.NotNull(UpperSpecLimit),
                        () => DataValidator.LargerThanOrEqualTo(UpperSpecLimit, LowerSpecLimit));
                case nameof(Target):
                    return DataValidator.ValidateInOrder(
                        () => DataValidator.NotNull(Target),
                        () => DataValidator.InRange(Target, LowerLimit, UpperLimit));
                case nameof(QualityItemName):
                    return DataValidator.NotNull(QualityItemName);
                case nameof(QualityThreshold):
                    return DataValidator.ValidateInOrder(
                        () => DataValidator.NotNull(QualityThreshold),
                        () => DataValidator.InRange(QualityThreshold, 0, 1));
                case nameof(Multiplier):
                    return DataValidator.NotNull(Multiplier);
                case nameof(Coefficients):
                    return DataValidator.ValidateInOrder(
                        () => DataValidator.NotNull(Coefficients),
                        () => DataValidator.InRange(Coefficients, 0, 1));
                case nameof(CoefficientsPiRun):
                    return DataValidator.ValidateInOrder(
                        () => DataValidator.NotNull(CoefficientsPiRun),
                        () => DataValidator.InRange(CoefficientsPiRun, 0, 1));
                case nameof(SiteOrders):
                    return DataValidator.NotNull(SiteOrders);
                case nameof(MeasDFCRange):
                    return null;
                case nameof(MinSitesRequired):
                    return DataValidator.ValidateInOrder(
                        () => DataValidator.NotNull(MinSitesRequired),
                        () => DataValidator.LargerThan(MinSitesRequired, 0));
                case nameof(MaxOocSitesAllowed):
                    return DataValidator.ValidateInOrder(
                        () => DataValidator.NotNull(MaxOocSitesAllowed),
                        () => DataValidator.LargerThanOrEqualTo(MaxOocSitesAllowed, 0));
                case nameof(MaxOosSitesAllowed):
                    return DataValidator.ValidateInOrder(
                        () => DataValidator.NotNull(MaxOosSitesAllowed),
                        () => DataValidator.LargerThanOrEqualTo(MaxOosSitesAllowed, 0));
                case nameof(OCAP):
                    return null;
                case nameof(Precision):
                    return DataValidator.ValidateInOrder(
                        () => DataValidator.NotNull(Precision),
                        () => DataValidator.InRange(Precision, 1, 10));
                default:
                    return null;
            }
        }

        internal void Validate()
        {
            ValidateAndSetErrorFocus(
                nameof(MeasItemName),
                nameof(Index),
                nameof(LowerLimit),
                nameof(UpperLimit),
                nameof(LowerSpecLimit),
                nameof(UpperSpecLimit),
                nameof(QualityItemName),
                nameof(QualityThreshold),
                nameof(Target),
                nameof(Multiplier),
                nameof(Coefficients),
                nameof(CoefficientsPiRun),
                nameof(SiteOrders),
                nameof(MeasDFCRange),
                nameof(MinSitesRequired),
                nameof(MaxOocSitesAllowed),
                nameof(MaxOosSitesAllowed),
                nameof(OCAP),
                nameof(Precision));
        }
    }

    public class OutputGroupModel : BindableBase
    {
        public OutputGroupModel()
        {
            OutputSettingList = new ObservableCollection<OutputSettingsModel>();
        }

        public ObservableCollection<OutputSettingsModel> OutputSettingList
        {
            get { return GetValue<ObservableCollection<OutputSettingsModel>>(); }
            set { SetValue(value); }
        }

        public OutputSettingsModel SelectedOutputSetting
        {
            get { return GetValue<OutputSettingsModel>(); }
            set { SetValue(value); }
        }

        public string GroupName
        {
            get { return GetValue<string>(); }
            set { SetValue(value); }
        }

        public bool IsDirty
        {
            get { return GetValue<bool>(); }
            set { SetValue(value); }
        }


    }

}
