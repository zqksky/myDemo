﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Threading.Tasks;
using AMAT.R2R.Client.Common.Enums;
using AMAT.R2R.Client.Common.Helpers;
using AMAT.R2R.Client.Cmp.Messages;
using AMAT.R2R.Client.Cmp.Properties;
using AMAT.R2R.Client.Cmp.Services;
using AMAT.R2R.Shared.Base.DTO;
using AMAT.R2R.Shared.Cmp.DTO;
using DevExpress.DirectX.Common.DXGI;
using DevExpress.Mvvm;
using DevExpress.Mvvm.DataAnnotations;
using DevExpress.Mvvm.Native;
using DevExpress.Mvvm.UI.Native;
using DevExpress.Utils;
using Newtonsoft.Json;

namespace AMAT.R2R.Client.Cmp.Modules.ContextSettings
{

    public class LifeTimeSettingModel : BindableBase, IDataErrorInfo
    {
        public bool IsNew
        {
            get { return GetValue<bool>(); }
            set { SetValue(value); }
        }

        public string ParameterName
        {
            get { return GetValue<string>(); }
            set { SetValue(value); }
        }

        public string SVID
        {
            get { return GetValue<string>(); }
            set { SetValue(value); }
        }

        public int VIDIndex
        {
            get { return GetValue<int>(); }
            set { SetValue(value); }
        }

        public double? RangeStart
        {
            get { return GetValue<double?>(); }
            set { SetValue(value); }
        }

        public double? RangeEnd
        {
            get { return GetValue<double?>(); }
            set { SetValue(value); }
        }

        public double? A
        {
            get { return GetValue<double?>(); }
            set { SetValue(value); }
        }

        public double? B
        {
            get { return GetValue<double?>(); }
            set { SetValue(value); }
        }
        public double? C
        {
            get { return GetValue<double?>(); }
            set { SetValue(value); }
        }
        public double? Max
        {
            get { return GetValue<double?>(); }
            set { SetValue(value); }
        }

        public string Error
        {
            get
            {
                if (!string.IsNullOrEmpty(this[nameof(ParameterName)]))
                {
                    return $"{nameof(ParameterName)}";
                }
                else if (!string.IsNullOrEmpty(this[nameof(SVID)]))
                {
                    return $"{nameof(SVID)}";
                }
                else if (!string.IsNullOrEmpty(this[nameof(VIDIndex)]))
                {
                    return $"{nameof(VIDIndex)}";
                }
                else if (!string.IsNullOrEmpty(this[nameof(RangeStart)]))
                {
                    return $"{nameof(RangeStart)}";
                }
                else if (!string.IsNullOrEmpty(this[nameof(RangeEnd)]))
                {
                    return $"{nameof(RangeEnd)}";
                }
                else if (!string.IsNullOrEmpty(this[nameof(A)]))
                {
                    return $"{nameof(A)}";
                }
                else if (!string.IsNullOrEmpty(this[nameof(B)]))
                {
                    return $"{nameof(B)}";
                }
                else if (!string.IsNullOrEmpty(this[nameof(C)]))
                {
                    return $"{nameof(C)}";
                }
                else if (!string.IsNullOrEmpty(this[nameof(Max)]))
                {
                    return $"{nameof(Max)}";
                }
                else
                {
                    return null;
                }
            }
        }


        public string this[string propertyName]
        {
            get
            {
                switch (propertyName)
                {
                    case nameof(ParameterName):
                        return DataValidator.NotNull(ParameterName);
                    case nameof(SVID):
                        return DataValidator.NotNull(SVID);
                    case nameof(VIDIndex):
                        return DataValidator.NotNull(VIDIndex);
                    case nameof(RangeStart):
                        return DataValidator.NotNull(RangeStart);
                    case nameof(RangeEnd):
                        return DataValidator.NotNull(RangeEnd);
                    case nameof(A):
                        return DataValidator.NotNull(A);
                    case nameof(B):
                        return DataValidator.NotNull(B);
                    case nameof(C):
                        return DataValidator.NotNull(C);
                    case nameof(Max):
                        return DataValidator.NotNull(Max);
                    default:
                        return null;
                }
            }
        }
    }
}
