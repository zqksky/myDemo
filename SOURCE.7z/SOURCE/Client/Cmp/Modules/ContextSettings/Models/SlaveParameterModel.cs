﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Threading.Tasks;
using AMAT.R2R.Client.Common.Enums;
using AMAT.R2R.Client.Common.Helpers;
using AMAT.R2R.Client.Cmp.Messages;
using AMAT.R2R.Client.Cmp.Properties;
using AMAT.R2R.Client.Cmp.Services;
using AMAT.R2R.Shared.Base.DTO;
using AMAT.R2R.Shared.Cmp.DTO;
using DevExpress.DirectX.Common.DXGI;
using DevExpress.Mvvm;
using DevExpress.Mvvm.DataAnnotations;
using DevExpress.Mvvm.Native;
using DevExpress.Mvvm.UI.Native;
using DevExpress.Utils;
using Newtonsoft.Json;

namespace AMAT.R2R.Client.Cmp.Modules.ContextSettings
{

    public class SlaveParameterModel : BindableBase, IDataErrorInfo
    {
        public bool IsNew
        {
            get { return GetValue<bool>(); }
            set { SetValue(value); }
        }

        public string ParameterName
        {
            get { return GetValue<string>(); }
            set { SetValue(value); }
        }

        public string SlaveName
        {
            get { return GetValue<string>(); }
            set { SetValue(value); }
        }

        public double? Coefficient
        {
            get { return GetValue<double?>(); }
            set { SetValue(value); }
        }

        public double? Offset
        {
            get { return GetValue<double?>(); }
            set { SetValue(value); }
        }

        public string Error
        {
            get
            {
                if (!string.IsNullOrEmpty(this[nameof(ParameterName)]))
                {
                    return $"{nameof(ParameterName)}";
                }
                else if (!string.IsNullOrEmpty(this[nameof(SlaveName)]))
                {
                    return $"{nameof(SlaveName)}";
                }
                else if (!string.IsNullOrEmpty(this[nameof(Coefficient)]))
                {
                    return $"{nameof(Coefficient)}";
                }
                else if (!string.IsNullOrEmpty(this[nameof(Offset)]))
                {
                    return $"{nameof(Offset)}";
                }
                else
                {
                    return null;
                }
            }
        }


        public string this[string propertyName]
        {
            get
            {
                switch (propertyName)
                {
                    case nameof(ParameterName):
                        return DataValidator.NotNull(ParameterName);
                    case nameof(SlaveName):
                        return DataValidator.NotNull(SlaveName);
                    case nameof(Coefficient):
                        return DataValidator.NotNull(Coefficient);
                    case nameof(Offset):
                        return DataValidator.NotNull(Offset);
                    default:
                        return null;
                }
            }
        }
    }
}
