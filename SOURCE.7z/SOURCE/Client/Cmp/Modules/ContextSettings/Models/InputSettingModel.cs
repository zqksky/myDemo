﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Threading.Tasks;
using AMAT.R2R.Client.Common.Enums;
using AMAT.R2R.Client.Common.Helpers;
using AMAT.R2R.Client.Cmp.Messages;
using AMAT.R2R.Client.Cmp.Properties;
using AMAT.R2R.Client.Cmp.Services;
using AMAT.R2R.Shared.Base.DTO;
using AMAT.R2R.Shared.Cmp.DTO;
using DevExpress.DirectX.Common.DXGI;
using DevExpress.Mvvm;
using DevExpress.Mvvm.DataAnnotations;
using DevExpress.Mvvm.Native;
using DevExpress.Mvvm.UI.Native;
using DevExpress.Utils;
using Newtonsoft.Json;

namespace AMAT.R2R.Client.Cmp.Modules.ContextSettings
{
    public class InputSettingModel : BindableBase, IDataErrorInfo
    {
        public InputSettingModel()
        {
        }


        public int Index
        {
            get { return GetValue<int>(); }
            set { SetValue(value); }
        }


        public bool IsChecked
        {
            get { return GetValue<bool>(); }
            set { SetValue(value); }
        }

        public bool IsReadOnlyIsChecked
        {
            get { return GetValue<bool>(); }
            set { SetValue(value); }
        }

        public Parameter Parameter
        {
            get { return GetValue<Parameter>(); }
            set { SetValue(value); }
        }

        public string ParameterName
        {
            get { return GetValue<string>(); }
            set { SetValue(value); }
        }

        public decimal? Fixed
        {
            get { return GetValue<decimal?>(); }
            set { SetValue(value); }
        }
        public decimal? PM
        {
            get { return GetValue<decimal?>(); }
            set { SetValue(value); }
        }
        public decimal? Reset
        {
            get { return GetValue<decimal?>(); }
            set { SetValue(value); }
        }

        public decimal? Min
        {
            get { return GetValue<decimal?>(); }
            set { SetValue(value); }
        }

        public decimal? Max
        {
            get { return GetValue<decimal?>(); }
            set { SetValue(value); }
        }

        public int Precision
        {
            get { return GetValue<int>(); }
            set { SetValue(value); }
        }
        public decimal? Tolerance
        {
            get { return GetValue<decimal?>(); }
            set { SetValue(value); }
        }

        public string Unit
        {
            get { return GetValue<string>(); }
            set { SetValue(value); }
        }
        public decimal? FFDelta
        {
            get { return GetValue<decimal?>(); }
            set { SetValue(value); }
        }
        public decimal? FBDelta
        {
            get { return GetValue<decimal?>(); }
            set { SetValue(value); }
        }

        public decimal? Deadband
        {
            get { return GetValue<decimal?>(); }
            set { SetValue(value); }
        }
        public bool? ShiftInputLimit
        {
            get { return GetValue<bool?>(); }
            set { SetValue(value); }
        }
        public string UseRecOrUsedToFb
        {
            get { return GetValue<string>(); }
            set { SetValue(value); }
        }
        public string WaferProcessLocationRegex
        {
            get { return GetValue<string>(); }
            set { SetValue(value); }
        }

        public decimal? ModelSlope1
        {
            get { return GetValue<decimal?>(); }
            set { SetValue(value); }
        }
        public decimal? ModelSlope2
        {
            get { return GetValue<decimal?>(); }
            set { SetValue(value); }
        }
        public decimal? ModelSlope3
        {
            get { return GetValue<decimal?>(); }
            set { SetValue(value); }
        }
        public decimal? ModelSlope4
        {
            get { return GetValue<decimal?>(); }
            set { SetValue(value); }
        }
        public decimal? ModelSlope5
        {
            get { return GetValue<decimal?>(); }
            set { SetValue(value); }
        }
        public decimal? ModelSlope6
        {
            get { return GetValue<decimal?>(); }
            set { SetValue(value); }
        }
        public decimal? ModelSlope7
        {
            get { return GetValue<decimal?>(); }
            set { SetValue(value); }
        }
        public decimal? ModelSlope8
        {
            get { return GetValue<decimal?>(); }
            set { SetValue(value); }
        }
        public decimal? ModelSlope9
        {
            get { return GetValue<decimal?>(); }
            set { SetValue(value); }
        }
        public decimal? ModelSlope10
        {
            get { return GetValue<decimal?>(); }
            set { SetValue(value); }
        }

        public bool IsEnableModelSlop1
        {
            get { return GetValue<bool>(); }
            set { SetValue(value); }
        }
        public bool IsEnableModelSlop2
        {
            get { return GetValue<bool>(); }
            set { SetValue(value); }
        }
        public bool IsEnableModelSlop3
        {
            get { return GetValue<bool>(); }
            set { SetValue(value); }
        }
        public bool IsEnableModelSlop4
        {
            get { return GetValue<bool>(); }
            set { SetValue(value); }
        }
        public bool IsEnableModelSlop5
        {
            get { return GetValue<bool>(); }
            set { SetValue(value); }
        }
        public bool IsEnableModelSlop6
        {
            get { return GetValue<bool>(); }
            set { SetValue(value); }
        }
        public bool IsEnableModelSlop7
        {
            get { return GetValue<bool>(); }
            set { SetValue(value); }
        }
        public bool IsEnableModelSlop8
        {
            get { return GetValue<bool>(); }
            set { SetValue(value); }
        }
        public bool IsEnableModelSlop9
        {
            get { return GetValue<bool>(); }
            set { SetValue(value); }
        }
        public bool IsEnableModelSlop10
        {
            get { return GetValue<bool>(); }
            set { SetValue(value); }
        }

        public string Error
        {
            get
            {
                if (!string.IsNullOrEmpty(this[nameof(Parameter)]))
                {
                    return $"{nameof(Parameter)}";
                }
                else if (!string.IsNullOrEmpty(this[nameof(Fixed)]))
                {
                    return $"{nameof(Fixed)}";
                }
                else if (!string.IsNullOrEmpty(this[nameof(PM)]))
                {
                    return $"{nameof(PM)}";
                }
                else if (!string.IsNullOrEmpty(this[nameof(Reset)]))
                {
                    return $"{nameof(Reset)}";
                }
                else if (!string.IsNullOrEmpty(this[nameof(Min)]))
                {
                    return $"{nameof(Min)}";
                }
                else if (!string.IsNullOrEmpty(this[nameof(Max)]))
                {
                    return $"{nameof(Max)}";
                }
                else if (!string.IsNullOrEmpty(this[nameof(Precision)]))
                {
                    return $"{nameof(Precision)}";
                }
                else if (!string.IsNullOrEmpty(this[nameof(Tolerance)]))
                {
                    return $"{nameof(Tolerance)}";
                }
                else if (!string.IsNullOrEmpty(this[nameof(FFDelta)]))
                {
                    return $"{nameof(FFDelta)}";
                }
                else if (!string.IsNullOrEmpty(this[nameof(FBDelta)]))
                {
                    return $"{nameof(FBDelta)}";
                }
                else if (!string.IsNullOrEmpty(this[nameof(Deadband)]))
                {
                    return $"{nameof(Deadband)}";
                }
                else if (!string.IsNullOrEmpty(this[nameof(ShiftInputLimit)]))
                {
                    return $"{nameof(ShiftInputLimit)}";
                }
                else if (!string.IsNullOrEmpty(this[nameof(UseRecOrUsedToFb)]))
                {
                    return $"{nameof(UseRecOrUsedToFb)}";
                }
                else if (!string.IsNullOrEmpty(this[nameof(WaferProcessLocationRegex)]))
                {
                    return $"{nameof(WaferProcessLocationRegex)}";
                }
                else if (!string.IsNullOrEmpty(this[nameof(ModelSlope1)]))
                {
                    return $"{nameof(ModelSlope1)}";
                }
                else if (!string.IsNullOrEmpty(this[nameof(ModelSlope2)]))
                {
                    return $"{nameof(ModelSlope2)}";
                }
                else if (!string.IsNullOrEmpty(this[nameof(ModelSlope3)]))
                {
                    return $"{nameof(ModelSlope3)}";
                }
                else if (!string.IsNullOrEmpty(this[nameof(ModelSlope4)]))
                {
                    return $"{nameof(ModelSlope4)}";
                }
                else if (!string.IsNullOrEmpty(this[nameof(ModelSlope5)]))
                {
                    return $"{nameof(ModelSlope5)}";
                }
                else if (!string.IsNullOrEmpty(this[nameof(ModelSlope6)]))
                {
                    return $"{nameof(ModelSlope6)}";
                }
                else if (!string.IsNullOrEmpty(this[nameof(ModelSlope7)]))
                {
                    return $"{nameof(ModelSlope7)}";
                }
                else if (!string.IsNullOrEmpty(this[nameof(ModelSlope8)]))
                {
                    return $"{nameof(ModelSlope8)}";
                }
                else if (!string.IsNullOrEmpty(this[nameof(ModelSlope9)]))
                {
                    return $"{nameof(ModelSlope9)}";
                }
                else if (!string.IsNullOrEmpty(this[nameof(ModelSlope10)]))
                {
                    return $"{nameof(ModelSlope10)}";
                }
                else
                {
                    return null;
                }
            }
        }


        public string this[string propertyName]
        {
            get
            {
                if (!IsChecked) return null;
                switch (propertyName)
                {
                    case nameof(Parameter):
                        return DataValidator.NotNull(Parameter);
                    case nameof(Fixed):
                        return DataValidator.ValidateInOrder(
                            () => DataValidator.NotNull(Fixed),
                            () => DataValidator.LargerThanOrEqualTo(Fixed, Min),
                            () => DataValidator.SmallerThanOrEqualTo(Fixed, Max)
                            );
                    case nameof(PM):
                        return DataValidator.ValidateInOrder(
                            () => DataValidator.NotNull(PM),
                            () => DataValidator.LargerThanOrEqualTo(PM, Min),
                            () => DataValidator.SmallerThanOrEqualTo(PM, Max)
                            );
                    case nameof(Reset):
                        return DataValidator.ValidateInOrder(
                            () => DataValidator.NotNull(Reset),
                            () => DataValidator.LargerThanOrEqualTo(Reset, Min),
                            () => DataValidator.SmallerThanOrEqualTo(Reset, Max)
                            );
                    case nameof(Min):
                        return DataValidator.ValidateInOrder(
                            () => DataValidator.NotNull(Min),
                            () => DataValidator.SmallerThanOrEqualTo(Min, Max)
                            );
                    case nameof(Max):
                        return DataValidator.ValidateInOrder(
                            () => DataValidator.NotNull(Max),
                            () => DataValidator.LargerThanOrEqualTo(Max, Min)
                            );
                    case nameof(Precision):
                        return DataValidator.ValidateInOrder(
                            () => DataValidator.NotNull(Precision),
                            () => DataValidator.InRange(Precision, 1, 10)
                            );
                    case nameof(Tolerance):
                        return DataValidator.ValidateInOrder(
                            () => DataValidator.NotNull(Tolerance),
                            () => DataValidator.LargerThanOrEqualTo(Tolerance, 0)
                            );
                    case nameof(FFDelta):
                        return DataValidator.ValidateInOrder(
                            () => DataValidator.NotNull(FFDelta),
                            () => DataValidator.LargerThanOrEqualTo(FFDelta, 0)
                            );
                    case nameof(FBDelta):
                        return DataValidator.ValidateInOrder(
                            () => DataValidator.NotNull(FBDelta),
                            () => DataValidator.LargerThanOrEqualTo(FBDelta, 0)
                            );

                    case nameof(Deadband):
                        return DataValidator.ValidateInOrder(
                            () => DataValidator.NotNull(Deadband),
                            () => DataValidator.LargerThanOrEqualTo(Deadband, 0)
                            );

                    case nameof(ShiftInputLimit):
                        return DataValidator.NotNull(ShiftInputLimit);

                    case nameof(UseRecOrUsedToFb):
                        return DataValidator.ValidateInOrder(
                            () => DataValidator.NotNull(UseRecOrUsedToFb),
                            () => DataValidator.UTF8StringMaxLength(UseRecOrUsedToFb, 40)
                            );
                    case nameof(WaferProcessLocationRegex):
                        return DataValidator.ValidateInOrder(
                            () => DataValidator.NotNull(WaferProcessLocationRegex),
                            () => DataValidator.UTF8StringMaxLength(WaferProcessLocationRegex, 40)
                            );

                    case nameof(ModelSlope1):
                    case nameof(ModelSlope2):
                    case nameof(ModelSlope3):
                    case nameof(ModelSlope4):
                    case nameof(ModelSlope5):
                    case nameof(ModelSlope6):
                    case nameof(ModelSlope7):
                    case nameof(ModelSlope8):
                    case nameof(ModelSlope9):
                    case nameof(ModelSlope10):
                        return DataValidator.ValidateInOrder(
                        () => DataValidator.NotNull(ModelSlope1),
                        () => DataValidator.NotNull(ModelSlope2),
                        () => DataValidator.NotNull(ModelSlope3),
                        () => DataValidator.NotNull(ModelSlope4),
                        () => DataValidator.NotNull(ModelSlope5),
                        () => DataValidator.NotNull(ModelSlope6),
                        () => DataValidator.NotNull(ModelSlope7),
                        () => DataValidator.NotNull(ModelSlope8),
                        () => DataValidator.NotNull(ModelSlope9),
                        () => DataValidator.NotNull(ModelSlope10),
                        () => IsEnableModelSlop10 ? DataValidator.NotZero(new decimal?[] { ModelSlope1, ModelSlope2, ModelSlope3, ModelSlope4, ModelSlope5, ModelSlope6, ModelSlope7, ModelSlope8, ModelSlope9, ModelSlope10 }) :
                              IsEnableModelSlop9 ? DataValidator.NotZero(new decimal?[] { ModelSlope1, ModelSlope2, ModelSlope3, ModelSlope4, ModelSlope5, ModelSlope6, ModelSlope7, ModelSlope8, ModelSlope9 }) :
                              IsEnableModelSlop8 ? DataValidator.NotZero(new decimal?[] { ModelSlope1, ModelSlope2, ModelSlope3, ModelSlope4, ModelSlope5, ModelSlope6, ModelSlope7, ModelSlope8 }) :
                              IsEnableModelSlop7 ? DataValidator.NotZero(new decimal?[] { ModelSlope1, ModelSlope2, ModelSlope3, ModelSlope4, ModelSlope5, ModelSlope6, ModelSlope7 }) :
                              IsEnableModelSlop6 ? DataValidator.NotZero(new decimal?[] { ModelSlope1, ModelSlope2, ModelSlope3, ModelSlope4, ModelSlope5, ModelSlope6 }) :
                              IsEnableModelSlop5 ? DataValidator.NotZero(new decimal?[] { ModelSlope1, ModelSlope2, ModelSlope3, ModelSlope4, ModelSlope5 }) :
                              IsEnableModelSlop4 ? DataValidator.NotZero(new decimal?[] { ModelSlope1, ModelSlope2, ModelSlope3, ModelSlope4 }) :
                              IsEnableModelSlop3 ? DataValidator.NotZero(new decimal?[] { ModelSlope1, ModelSlope2, ModelSlope3 }) :
                              IsEnableModelSlop2 ? DataValidator.NotZero(new decimal?[] { ModelSlope1, ModelSlope2 }) :
                              IsEnableModelSlop1 ? DataValidator.NotZero(new decimal?[] { ModelSlope1 }) :
                              null
                        );

                    default:
                        return null;
                }
            }
        }
    }
}
