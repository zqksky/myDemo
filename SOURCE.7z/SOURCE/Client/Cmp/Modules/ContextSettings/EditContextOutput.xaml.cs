﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace AMAT.R2R.Client.Cmp.Modules.ContextSettings
{
    /// <summary>
    /// Interaction logic for EditContextOutput.xaml
    /// </summary>
    public partial class EditContextOutput : UserControl
    {
        public EditContextOutput()
        {
            InitializeComponent();
        }

        // https://supportcenter.devexpress.com/ticket/details/t522280/selection-of-row-overrides-the-back-colors-of-cells-in-gridcontrol
        private void View_CustomCellAppearance(object sender, DevExpress.Xpf.Grid.CustomCellAppearanceEventArgs e)
        {
            e.Result = e.ConditionalValue;
            e.Handled = true;
        }
    }
}
