﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Data.Objects;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Documents;
using AMAT.R2R.Client.Common.Enums;
using AMAT.R2R.Client.Common.Helpers;
using AMAT.R2R.Client.Common.Messages;
using AMAT.R2R.Client.Common.Services;
using AMAT.R2R.Client.Common.ViewModels;
using AMAT.R2R.Client.Common.Views;
using AMAT.R2R.Client.Cmp.Messages;
using AMAT.R2R.Shared.Base.DTO;
using AMAT.R2R.Shared.Cmp.DTO;
using DevExpress.Mvvm;
using DevExpress.Mvvm.DataAnnotations;
using DevExpress.Mvvm.Native;
using DevExpress.Mvvm.POCO;
using DevExpress.Xpf.Bars;
using Newtonsoft.Json;

namespace AMAT.R2R.Client.Cmp.Modules.MaterializedViewSettings
{
    public class PreChamberLineAVGViewModel : CmpViewModelBase
    {
        private const string NA = "NA";

        public MaterializedView OriginalMaterialized { get; set; }

        public PreChamberLineAVGViewModel(MaterializedView materialized)
        {
            SizeToContent = System.Windows.SizeToContent.Manual;
            WindowWidth = 800;
            WindowHeight = 400;
            Mode = FunctionMode.Modify;
            Caption = "Pre chamber Line AVG";
            OriginalMaterialized = materialized;
        }

        protected override void OnViewReadyAsync()
        {
            IsDirty = false;

        }


        [Command]
        public async void Update()
        {
            if (IsConfirmed(out var comment))
            {

            }
        }

        public bool CanUpdate()
        {
            return IsDirty;
        }



        protected override string GetError(string columnName)
        {
            switch (columnName)
            {
                //case nameof(PilotId):
                //    return DataValidator.NotNull(PilotId);
                default:
                    return null;
            }
        }

        #region Properties

        public ObservableCollection<PreChamberLineAvgItem> ItemList
        {
            get { return GetValue<ObservableCollection<PreChamberLineAvgItem>>(); }
            set { SetValue(value); }
        }



        #endregion
    }

}
