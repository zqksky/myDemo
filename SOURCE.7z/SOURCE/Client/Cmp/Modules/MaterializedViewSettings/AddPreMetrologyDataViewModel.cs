﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Data.Objects;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Data;
using System.Windows.Documents;
using AMAT.R2R.Client.Common.Enums;
using AMAT.R2R.Client.Common.Helpers;
using AMAT.R2R.Client.Common.Messages;
using AMAT.R2R.Client.Common.Services;
using AMAT.R2R.Client.Common.ViewModels;
using AMAT.R2R.Client.Common.Views;
using AMAT.R2R.Client.Cmp.Messages;
using AMAT.R2R.Shared.Base.DTO;
using AMAT.R2R.Shared.Cmp.DTO;
using DevExpress.Mvvm;
using DevExpress.Mvvm.DataAnnotations;
using DevExpress.Mvvm.Native;
using DevExpress.Mvvm.POCO;
using DevExpress.Xpf.Bars;
using Newtonsoft.Json;
using System.Globalization;

namespace AMAT.R2R.Client.Cmp.Modules.MaterializedViewSettings
{
    public class AddPreMetrologyDataViewModel : CmpViewModelBase
    {
        private const string NA = "NA";

        public AddPreMetrologyDataViewModel(string processKey)
        {
            if (string.IsNullOrEmpty(processKey))
            {
                throw new ArgumentNullException(nameof(processKey));
            }

            ProcessKey = processKey;

            SizeToContent = System.Windows.SizeToContent.Manual;
            Mode = FunctionMode.Modify;
            Caption = "Add Manual PreMetrology Data";
            ManualPreMetrologyItemList = new ObservableCollection<ManualPreMetrologyItemExtend>();

            PropertyChanged += AddPreMetrologyDataViewModel_PropertyChanged;
        }

        private async void AddPreMetrologyDataViewModel_PropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            if (e.PropertyName == nameof(SelectedMetrology))
            {
                if(SelectedMetrology != null)
                {
                    var items = await ProcessService.GetManualPreMetrologyInfoAsync(ProcessKey);
                    ManualPreMetrologyItemList = new ObservableCollection<ManualPreMetrologyItemExtend>(items.ManualPreMetrologyItems.Select(i=>
                    JsonConvert.DeserializeObject<ManualPreMetrologyItemExtend>(JsonConvert.SerializeObject(i))));
                    ManualPreMetrologyItemList.CollectionChanged += ManualPreMetrologyItemList_CollectionChanged;

                    ManualPreMetrologyItemList.ForEach(i=> i.PropertyChanged += Item_PropertyChanged);

                    UpdateFilteredItemList();
                }
            }
        }

        private void Item_PropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            IsDirty = true;
        }

        protected override async void OnViewReadyAsync()
        {
            await RefreshList();
        }

        public async Task RefreshList()
        {
            ShowWait();
            try
            {
                var process = await ProcessService.GetProcessAsync(ProcessKey);
                MeasureItemList = await GlobalService.GetMetroParameterListAsync();


                PreMetrologyList = MeasureItemList.Select(p => new PreMetrology()
                {
                    Fab = process.Fab,
                    ProcessStep = process.ProcessStep,
                    Product = process.Product,
                    ProcessKey = process.ProcessKey,
                    MeasDataItemName = p.ParameterName
                }).ToList();

                SelectedMetrology = PreMetrologyList.First();

                TotalSiteQtyList = Enumerable.Range(1, 20).ToList();
                TotalSiteQty = 5;

                IsDirty = false;
            }
            finally
            {
                HideWait();
            }
        }

        private void ManualPreMetrologyItemList_CollectionChanged(object sender, System.Collections.Specialized.NotifyCollectionChangedEventArgs e)
        {
            UpdateFilteredItemList();
        }

        private void UpdateFilteredItemList()
        {
            if (SelectedMetrology != null)
            {
                FilteredItemList = new ObservableCollection<ManualPreMetrologyItemExtend>(ManualPreMetrologyItemList.Where(i => i.MeasDataItemName == SelectedMetrology.MeasDataItemName));
            }
            else
            {
                FilteredItemList = ManualPreMetrologyItemList;
            }
        }

        [Command]
        public void Add()
        {
            ValidateAndSetErrorFocus(nameof(WaferId));

            if (FilteredItemList.Any(i => i.WaferId == WaferId))
            {
                MessageBoxService.ShowMessage("This wafer already has data item.", "Can not add", MessageButton.OK, MessageIcon.Stop);
                SetFocus(nameof(WaferId));
                return;
            }

            if (HasErrors)
            {
                return;
            }

            var newItem = new ManualPreMetrologyItemExtend()
            {
                ProcessStep = SelectedMetrology.ProcessStep,
                ProcessKey = SelectedMetrology.ProcessKey,
                Product = SelectedMetrology.Product,
                Fab = SelectedMetrology.Fab,
                MeasDataItemName = SelectedMetrology.MeasDataItemName,
                WaferId = WaferId,
                TotalSiteQty = TotalSiteQty,
                IsAdd = true,
            };
            ManualPreMetrologyItemList.Add(newItem);
            IsDirty = true;
        }

        public bool CanAdd()
        {
            return SelectedMetrology != null;
        }

        [Command]
        public void Delete()
        {
            if (SelectedItem.IsAdd)
            {
                ManualPreMetrologyItemList.Remove(SelectedItem);
                IsDirty = true;
            }
            else
            {
                SelectedItem.IsDelete = true;
            }
        }

        public bool CanDelete()
        {
            return SelectedItem != null;
        }

        [Command]
        public void Undelete()
        {
            SelectedItem.IsDelete = false;
        }

        public bool CanUndelete()
        {
            return SelectedItem != null;
        }

        [Command]
        public async void Refresh()
        {
            if (IsDirty)
            {

            }

            await RefreshList();
        }

        [Command]
        public async void Save()
        {
            var saveList = ManualPreMetrologyItemList.Where(i => i.IsAdd || i.IsDelete).ToList();

            List<ManualPreMetrologyItemExtend> failedList = new List<ManualPreMetrologyItemExtend>();
            StringBuilder sb = new StringBuilder();
            // 
            if (IsConfirmed(out string comment))
            {
                ShowWait();

                foreach (var item in saveList)
                {
                    try
                    {
                        if (item.IsDelete)
                        {
                            await ProcessService.DeleteManualPreMetrologyItemAsync(ProcessKey, item.MeasDataItemName, item.WaferId, comment);
                        }
                        else
                        {
                            await ProcessService.AddManualPreMetrologyItemAsync(ProcessKey, JsonConvert.DeserializeObject<ManualPreMetrologyItem>(JsonConvert.SerializeObject(item)), comment);
                        }
                    }
                    catch (Exception ex)
                    {
                        failedList.Add(item);
                        sb.AppendLine(LocalizationService.LocalizeException(ex));
                    }
                }

                HideWait();

                var successCount = saveList.Count - failedList.Count;

                if (successCount > 0)
                {
                    await RefreshList();
                }

                // restore failed item
                foreach (var item in failedList)
                {

                }

                // show error if any
                if (failedList.Count <= 0)
                {
                    MessageBoxService.ShowMessage($"{successCount} items saved successfully.", "Success", MessageButton.OK, MessageIcon.Information);
                }
                else if (successCount > 0)
                {
                    MessageBoxService.ShowMessage($"{successCount} items saved successfully.\n{failedList.Count} items save failed.\n{sb}", "Partial Success", MessageButton.OK, MessageIcon.Information);
                }
                else
                {
                    MessageBoxService.ShowMessage($"Save failed.\n{sb}", "Error", MessageButton.OK, MessageIcon.Error);
                }
            }
        }

        public bool CanSave()
        {
            return ManualPreMetrologyItemList.Any(i => i.IsDelete || i.IsAdd) || IsDirty;
        }

        protected override string GetError(string columnName)
        {
            switch (columnName)
            {
                case nameof(WaferId):
                    return DataValidator.ValidString(WaferId);
                default:
                    return null;
            }
        }

        #region Properties
        public string ProcessKey { get; }

        public string ValueListRegex
        {
            get { return GetValue<string>(); }
            set { SetValue(value); }
        }

        public string Values
        {
            get { return GetValue<string>(); }
            set { SetValue(value); }
        }


        public bool IsAddOpen
        {
            get { return GetValue<bool>(); }
            set { SetValue(value); }
        }

        public List<PreMetrology> PreMetrologyList
        {
            get { return GetValue<List<PreMetrology>>(); }
            set { SetValue(value); }
        }

        public PreMetrology SelectedMetrology
        {
            get { return GetValue<PreMetrology>(); }
            set { SetValue(value); }
        }


        public ObservableCollection<ManualPreMetrologyItemExtend> ManualPreMetrologyItemList
        {
            get { return GetValue<ObservableCollection<ManualPreMetrologyItemExtend>>(); }
            set { SetValue(value); }
        }
        public ObservableCollection<ManualPreMetrologyItemExtend> FilteredItemList
        {
            get { return GetValue<ObservableCollection<ManualPreMetrologyItemExtend>>(); }
            set { SetValue(value); }
        }

        public ObservableCollection<ManualPreMetrologyItemExtend> SelectedItemList { get; } = new ObservableCollection<ManualPreMetrologyItemExtend>();

        public ManualPreMetrologyItemExtend SelectedItem
        {
            get { return GetValue<ManualPreMetrologyItemExtend>(); }
            set { SetValue(value); }
        }

        public List<Parameter> MeasureItemList
        {
            get { return GetValue<List<Parameter>>(); }
            set { SetValue(value); }
        }

        public List<string> QualityItemList
        {
            get { return GetValue<List<string>>(); }
            set { SetValue(value); }
        }

        public List<int> TotalSiteQtyList
        {
            get { return GetValue<List<int>>(); }
            set { SetValue(value); }
        }

        public int TotalSiteQty
        {
            get { return GetValue<int>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(TotalSiteQty));
            }
        }
        public string WaferId
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(WaferId));
            }
        }

        #endregion
    }

    public class ManualPreMetrologyItemExtend : INotifyPropertyChanged
    {
        public bool IsAdd { get; set; }


        bool _isDelete;
        public bool IsDelete
        {
            get
            {
                return _isDelete;
            }
            set
            {
                _isDelete = value;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(IsDelete)));
            }
        }

        string _fab;
        public string Fab
        {
            get
            {
                return _fab;
            }
            set
            {
                _fab = value;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Fab)));
            }
        }


        string _product;
        public string Product
        {
            get
            {
                return _product;
            }
            set
            {
                _product = value;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Product)));
            }
        }

        string _processStep;
        public string ProcessStep
        {
            get
            {
                return _processStep;
            }
            set
            {
                _processStep = value;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(ProcessStep)));
            }
        }

        string _processKey;
        public string ProcessKey
        {
            get
            {
                return _processKey;
            }
            set
            {
                _processKey = value;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(ProcessKey)));
            }
        }

        string _measDataItemName;
        public string MeasDataItemName
        {
            get
            {
                return _measDataItemName;
            }
            set
            {
                _measDataItemName = value;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(MeasDataItemName)));
            }
        }


        string _waferId;
        public string WaferId
        {
            get
            {
                return _waferId;
            }
            set
            {
                _waferId = value;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(WaferId)));
            }
        }

        int _totalSiteQty;
        public int TotalSiteQty
        {
            get
            {
                return _totalSiteQty;
            }
            set
            {
                _totalSiteQty = value;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(TotalSiteQty)));
            }
        }

        double? _value01;
        public double? Value01
        {
            get
            {
                return _value01;
            }
            set
            {
                _value01 = value;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Value01)));
            }
        }

        double? _value02;
        public double? Value02
        {
            get
            {
                return _value02;
            }
            set
            {
                _value02 = value;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Value02)));
            }
        }

        double? _value03;
        public double? Value03
        {
            get
            {
                return _value03;
            }
            set
            {
                _value03 = value;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Value03)));
            }
        }

        double? _value04;
        public double? Value04
        {
            get
            {
                return _value04;
            }
            set
            {
                _value04 = value;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Value04)));
            }
        }

        double? _value05;
        public double? Value05
        {
            get
            {
                return _value05;
            }
            set
            {
                _value05 = value;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Value05)));
            }
        }

        double? _value06;
        public double? Value06
        {
            get
            {
                return _value06;
            }
            set
            {
                _value06= value;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Value06)));
            }
        }

        double? _value07;
        public double? Value07
        {
            get
            {
                return _value07;
            }
            set
            {
                _value07 = value;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Value07)));
            }
        }

        double? _value08;
        public double? Value08
        {
            get
            {
                return _value08;
            }
            set
            {
                _value08 = value;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Value08)));
            }
        }

        double? _value09;
        public double? Value09
        {
            get
            {
                return _value09;
            }
            set
            {
                _value09 = value;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Value09)));
            }
        }

        double? _value10;
        public double? Value10
        {
            get
            {
                return _value10;
            }
            set
            {
                _value10 = value;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Value10)));
            }
        }

        double? _value11;
        public double? Value11
        {
            get
            {
                return _value11;
            }
            set
            {
                _value11 = value;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Value11)));
            }
        }

        double? _value12;
        public double? Value12
        {
            get
            {
                return _value12;
            }
            set
            {
                _value12 = value;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Value12)));
            }
        }

        double? _value13;
        public double? Value13
        {
            get
            {
                return _value13;
            }
            set
            {
                _value13 = value;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Value13)));
            }
        }

        double? _value14;
        public double? Value14
        {
            get
            {
                return _value14;
            }
            set
            {
                _value14 = value;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Value14)));
            }
        }

        double? _value15;
        public double? Value15
        {
            get
            {
                return _value15;
            }
            set
            {
                _value15 = value;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Value15)));
            }
        }

        double? _value16;
        public double? Value16
        {
            get
            {
                return _value16;
            }
            set
            {
                _value16 = value;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Value16)));
            }
        }

        double? _value17;
        public double? Value17
        {
            get
            {
                return _value17;
            }
            set
            {
                _value17 = value;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Value17)));
            }
        }

        double? _value18;
        public double? Value18
        {
            get
            {
                return _value18;
            }
            set
            {
                _value18 = value;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Value18)));
            }
        }

        double? _value19;
        public double? Value19
        {
            get
            {
                return _value19;
            }
            set
            {
                _value19 = value;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Value19)));
            }
        }

        double? _value20;
        public double? Value20
        {
            get
            {
                return _value20;
            }
            set
            {
                _value20 = value;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Value20)));
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;
    }

    public class PreMetrology
    {
        public string Fab { get; set; }
        public string Product { get; set; }
        public string ProcessStep { get; set; }

        public string ProcessKey { get; set; }
        public string MeasDataItemName { get; set; }
    }

    public class CanEditValueConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (int.TryParse(parameter?.ToString(), out var index) && int.TryParse(value?.ToString(), out var max))
            {
                return index <= max;
            }
            else
            {
                throw new InvalidOperationException("value is not integer.");
            }
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}
