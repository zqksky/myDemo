﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data.Objects;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Documents;
using AMAT.R2R.Client.Common.Enums;
using AMAT.R2R.Client.Common.Helpers;
using AMAT.R2R.Client.Common.Messages;
using AMAT.R2R.Client.Common.Services;
using AMAT.R2R.Client.Common.ViewModels;
using AMAT.R2R.Client.Common.Views;
using AMAT.R2R.Client.Cmp.Messages;
using AMAT.R2R.Shared.Base.DTO;
using AMAT.R2R.Shared.Cmp.DTO;
using DevExpress.Mvvm;
using DevExpress.Mvvm.DataAnnotations;
using DevExpress.Mvvm.Native;
using DevExpress.Mvvm.POCO;
using DevExpress.Xpf.Bars;
using Newtonsoft.Json;

namespace AMAT.R2R.Client.Cmp.Modules.MaterializedViewSettings
{
    public class LinkControlViewModel : CmpViewModelBase
    {
        public LinkControlViewModel()
        {
            WindowHeight = 500;
            WindowWidth = 880;
            SizeToContent = System.Windows.SizeToContent.Manual;
            Mode = FunctionMode.Modify;
            Caption = "Link Control";
        }

        public async Task RefreshList()
        {
            IsLoading = true;
            try
            {
                var displaIndexList = Enumerable.Range(1, 10);
                ItemList = new ObservableCollection<LinkControlItem>(displaIndexList.Select(i => new LinkControlItem() { DisplayIndex = i, NormFactor = 1, TuningLimit = 99999 }));
            }
            finally
            {
                IsLoading = false;
            }
        }

        private void Initialize()
        {
            RefreshList();
        }

        protected override void OnViewReadyAsync()
        {
            Initialize();
        }

        protected override string GetError(string columnName)
        {
            switch (columnName)
            {
                default:
                    return null;
            }
        }

        [Command]
        public void CreateLink()
        {
            ShowWait();
            try
            {
                // MaterializedViewService.CreateLink
            }
            finally
            {
                HideWait();
            }
        }

        #region Properties


        public ObservableCollection<LinkControlItem> ItemList
        {
            get { return GetValue<ObservableCollection<LinkControlItem>>(); }
            set { SetValue(value); }
        }

        #endregion
    }

    public class LinkControlItem : BindableBase
    {
        public int DisplayIndex
        {
            get { return GetValue<int>(); }
            set
            {
                SetValue(value);
            }
        }

        public int? InputIndex
        {
            get { return GetValue<int?>(); }
            set { SetValue(value); }
        }

        public decimal? NormFactor
        {
            get { return GetValue<decimal?>(); }
            set { SetValue(value); }
        }

        public int? TuningLimit
        {
            get { return GetValue<int?>(); }
            set { SetValue(value); }
        }
    }
}
