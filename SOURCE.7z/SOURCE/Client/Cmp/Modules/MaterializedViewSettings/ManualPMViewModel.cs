﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data.Objects;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Documents;
using AMAT.R2R.Client.Common.Enums;
using AMAT.R2R.Client.Common.Helpers;
using AMAT.R2R.Client.Common.Messages;
using AMAT.R2R.Client.Common.Services;
using AMAT.R2R.Client.Common.ViewModels;
using AMAT.R2R.Client.Common.Views;
using AMAT.R2R.Client.Cmp.Messages;
using AMAT.R2R.Shared.Base.DTO;
using AMAT.R2R.Shared.Cmp.DTO;
using DevExpress.Mvvm;
using DevExpress.Mvvm.DataAnnotations;
using DevExpress.Mvvm.Native;
using DevExpress.Mvvm.POCO;
using DevExpress.Xpf.Bars;
using Newtonsoft.Json;

namespace AMAT.R2R.Client.Cmp.Modules.MaterializedViewSettings
{
    public class ManualPMViewModel : CmpViewModelBase
    {
        public MaterializedView OriginalMaterialView { get; set; }
        public ManualPMViewModel(MaterializedView materializedView)
        {
            OriginalMaterialView = materializedView;
            WindowHeight = 500;
            WindowWidth = 880;
            SizeToContent = System.Windows.SizeToContent.Manual;
            Mode = FunctionMode.Modify;
            Caption = "Manual PM";
        }

        public async Task RefreshList()
        {
            IsLoading = true;
            try
            {
                var modelGroupList = await GlobalService.GetChamberListAsync(OriginalMaterialView.Tool);

                List<ModelGroupPM> mgpList = new List<ModelGroupPM>();
                foreach (var modelGroup in modelGroupList)
                {
                    var mgp = new ModelGroupPM()
                    {
                        ToolId = modelGroup.ToolId,
                        ModelGroup = modelGroup.ChamberId,
                        ManualPM = await MaterializedViewService.GetManualPMAsync(modelGroup.ToolId, modelGroup.ChamberId)
                    };
                    mgp.PropertyChanged += Mgp_PropertyChanged;
                    mgpList.Add(mgp);
                }


                if(PMList != null && PMList.Count > 0)
                {
                    PMList.ForEach(pm => pm.PropertyChanged -= Mgp_PropertyChanged);
                }

                PMList = new ObservableCollection<ModelGroupPM>(mgpList);
            }
            finally
            {
                IsDirty = false;
                IsLoading = false;
            }
        }

        private void Mgp_PropertyChanged(object sender, System.ComponentModel.PropertyChangedEventArgs e)
        {
            IsDirty = true;
        }

        protected override async void OnViewReadyAsync()
        {
            await RefreshList();
        }

        protected override string GetError(string columnName)
        {
            switch (columnName)
            {
                default:
                    return null;
            }
        }

        [Command]
        public async void Update()
        {
            try
            {
                List<ModelGroupPM> failList = new List<ModelGroupPM>();
                StringBuilder sb = new StringBuilder();
                // 
                if (IsConfirmed(out string comment))
                {
                    ShowWait();

                    foreach (var pm in PMList)
                    {
                        try
                        {
                            await MaterializedViewService.SetManualPMAsync(pm.ToolId, pm.ModelGroup, pm.ManualPM, comment);
                        }
                        catch (Exception ex)
                        {
                            failList.Add(pm);
                            sb.AppendLine(LocalizationService.LocalizeException(ex));
                        }
                    }

                    HideWait();

                    var successCount = PMList.Count - failList.Count;

                    // show error if any
                    if (failList.Count <= 0)
                    {
                        MessageBoxService.ShowMessage($"{successCount} updated successfully.", "Success", MessageButton.OK, MessageIcon.Information);
                    }
                    else if (successCount > 0)
                    {
                        MessageBoxService.ShowMessage($"{successCount} updated successfully.\n{failList.Count} update failed.\n{sb}", $"Partial Success", MessageButton.OK, MessageIcon.Information);
                    }
                    else
                    {
                        MessageBoxService.ShowMessage($"Update failed.\n{sb}", $"Error", MessageButton.OK, MessageIcon.Error);
                    }

                    ShowWait();
                    if (successCount > 0)
                    {
                        await RefreshList();
                    }

                    // show updated list.
                    await RefreshList();
                    HideWait();
                }
            }
            finally
            {
                HideWait();
            }
        }

        public bool CanUpdate()
        {
            return IsDirty;
        }

        #region Properties

        public ObservableCollection<ModelGroupPM> PMList
        {
            get { return GetValue<ObservableCollection<ModelGroupPM>>(); }
            set { SetValue(value); }
        }

        #endregion
    }

    public class ModelGroupPM : BindableBase
    {
        public string ToolId
        {
            get { return GetValue<string>(); }
            set { SetValue(value); }
        }

        public string ModelGroup
        {
            get { return GetValue<string>(); }
            set { SetValue(value); }
        }

        public bool ManualPM
        {
            get { return GetValue<bool>(); }
            set { SetValue(value); }
        }


    }

}
