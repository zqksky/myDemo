﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AMAT.R2R.Shared.Cmp.DTO;
using Newtonsoft.Json;

namespace AMAT.R2R.Client.Cmp.Modules.MaterializedViewSettings
{
    public class MaterializedViewModel : MaterializedView, INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;

        public void NotifyChanges()
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(LastModifiedBy)));
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(LastModifiedTime)));
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Context)));
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(MaterializeViewParameters)));
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(OnTargetEstimate)));
        }

        [JsonIgnore]
        public Context Context
        {
            get; set;
        }

        public bool IsValid { get; set; }

        [JsonIgnore]
        public bool IsConstantDefined
        {
            get { return !string.IsNullOrEmpty(Constants.ContextKey); }
        }

        [JsonIgnore]
        public bool IsThreadTrackingDefined
        {
            get { return !string.IsNullOrEmpty(ThreadTracking.ContextKey); }
        }

        [JsonIgnore]
        public bool? FF
        {
            get { return IsConstantDefined ? Constants.FF : (bool?)null; }
        }

        [JsonIgnore]
        public bool? FB
        {
            get { return IsConstantDefined ? Constants.FB : (bool?)null; }
        }

        [JsonIgnore]
        public double? StatesDuration
        {
            get { return IsConstantDefined ? Constants.StatesDuration : (double?)null; }
        }


        /*
        [JsonIgnore]
        public string BookedPiLotId
        {
            get { return IsThreadTrackingDefined ? ThreadTracking.BookedPiLotId: null; }
        }
        */


        [JsonIgnore]
        public ThreadStatus? Status
        {
            get { return IsThreadTrackingDefined ? ThreadTracking.Status : (ThreadStatus?)null; }
        }
    }
}
