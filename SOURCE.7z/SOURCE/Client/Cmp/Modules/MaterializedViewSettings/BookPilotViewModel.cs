﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Data.Objects;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Documents;
using AMAT.R2R.Client.Common.Enums;
using AMAT.R2R.Client.Common.Helpers;
using AMAT.R2R.Client.Common.Messages;
using AMAT.R2R.Client.Common.Services;
using AMAT.R2R.Client.Common.ViewModels;
using AMAT.R2R.Client.Common.Views;
using AMAT.R2R.Client.Cmp.Messages;
using AMAT.R2R.Shared.Base.DTO;
using AMAT.R2R.Shared.Cmp.DTO;
using DevExpress.Mvvm;
using DevExpress.Mvvm.DataAnnotations;
using DevExpress.Mvvm.Native;
using DevExpress.Mvvm.POCO;
using DevExpress.Xpf.Bars;
using Newtonsoft.Json;

namespace AMAT.R2R.Client.Cmp.Modules.MaterializedViewSettings
{
    public class BookPilotViewModel : CmpViewModelBase
    {
        private const string NA = "NA";
        private readonly List<string> _originalContextKeyList;

        public BookPilotViewModel(List<MaterializedViewModel> materializedViewList)
        {
            if (materializedViewList is null)
            {
                throw new ArgumentNullException(nameof(materializedViewList));
            }


            _originalContextKeyList = materializedViewList.Select(m => m.ContextKey).ToList();

            MaterializedViewList = new ObservableCollection<MaterializedViewModel>(materializedViewList);

            WindowHeight = 500;
            WindowWidth = 1280;
            SizeToContent = System.Windows.SizeToContent.Manual;
            Mode = FunctionMode.Modify;
            Caption = "Book a Pi Lot";
        }


        public async Task RefreshList()
        {
            IsLoading = true;
            try
            {
                MaterializedViewList = new ObservableCollection<MaterializedViewModel>(await Task.WhenAll(_originalContextKeyList.Select(id => MaterializedViewService.GetMaterializedViewAsync(id))));
            }
            finally
            {
                IsLoading = false;
            }
        }

        private void Initialize()
        {
            PiLotId = null;
            Status = null;
            IsThreadStatusChanged = false;
            IsPiLotIdChanged = false;
            IsDirty = false;
        }


        protected override async void OnViewReadyAsync()
        {
            await RefreshList();
            MaterializedViewList.ForEach(v => SelectedMaterializedViewList.Add(v));
            Initialize();
        }

        [Command]
        public async void UpdateMaterializedView(string fieldName)
        {
            if (fieldName == "ChangeStatus")
            {
                ValidateAndSetErrorFocus(nameof(Status));
                if (HasErrors)
                {
                    return;
                }
            }

            if (fieldName == "ChangePiLot")
            {
                ValidateAndSetErrorFocus(nameof(PiLotId));
                if (HasErrors)
                {
                    return;
                }
            }

            List<MaterializedViewModel> failList = new List<MaterializedViewModel>();
            StringBuilder sb = new StringBuilder();
            // 
            if (IsConfirmed(out string comment))
            {
                ShowWait();

                foreach (var materializedView in SelectedMaterializedViewList)
                {
                    try
                    {
                        var context = await ContextService.GetContextAsync(materializedView.ContextKey);
                        switch (fieldName)
                        {
                            case "ChangeStatus":
                                materializedView.ThreadTracking.Status = Status.Value;
                                await MaterializedViewService.ChangeStatus(materializedView, materializedView.ContextKey, comment);
                                break;
                            case "ChangePiLot":
                                //materializedView.ThreadTracking.Status = Status.Value;
                                materializedView.BookedPiLotId = PiLotId;
                                await MaterializedViewService.ChangePiLot(materializedView, materializedView.ContextKey, comment);
                                break;

                            case "ResetStatus":
                                await MaterializedViewService.ResetStatus(materializedView, materializedView.ContextKey, comment);
                                break;
                            default:
                                break;
                        }
                    }
                    catch (Exception ex)
                    {
                        failList.Add(materializedView);
                        sb.AppendLine(LocalizationService.LocalizeException(ex));
                    }
                }

                HideWait();

                var successCount = SelectedMaterializedViewList.Count - failList.Count;

                // show error if any
                if (failList.Count <= 0)
                {
                    MessageBoxService.ShowMessage($"{successCount} updated successfully.", "Success", MessageButton.OK, MessageIcon.Information);
                }
                else if (successCount > 0)
                {
                    MessageBoxService.ShowMessage($"{successCount} updated successfully.\n{failList.Count} update failed.\n{sb}", $"Partial Success", MessageButton.OK, MessageIcon.Information);
                }
                else
                {
                    MessageBoxService.ShowMessage($"Update failed.\n{sb}", $"Error", MessageButton.OK, MessageIcon.Error);
                }

                ShowWait();
                if (successCount > 0)
                {
                    await RefreshList();
                    var successMaterializedViewList = SelectedMaterializedViewList.Except(failList);
                    foreach (var materializedView in successMaterializedViewList)
                    {
                        Messenger.Default.Send(new ContextChangedMessage() { ChangeType = ObjectChangeType.Updated, ContextKey = materializedView.ContextKey });
                    }
                }

                MaterializedViewList.ForEach(v => SelectedMaterializedViewList.Add(v));
                // show updated list.
                Initialize();
                HideWait();
            }
        }

        public bool CanUpdateMaterializedView(string fieldName)
        {
            if (SelectedMaterializedView == null) return false;
            switch (fieldName)
            {
                case "ChangeStatus":
                    return Status != null && IsThreadStatusChanged && SelectedMaterializedViewList.Count > 0&& !SelectedMaterializedViewList.Select(t=>t.Status).ToList().Contains(null);
                case "ChangePiLot":
                    return IsPiLotIdChanged;
                case "ResetStatus":
                    return SelectedMaterializedViewList.Count > 0;
                default:
                    return false;
            }
        }

        protected override string GetError(string columnName)
        {
            switch (columnName)
            {
                case nameof(PiLotId):
                    return DataValidator.ValidString(PiLotId, 40, false);
                default:
                    return null;
            }
        }

        #region Properties


        public ObservableCollection<MaterializedViewModel> MaterializedViewList
        {
            get { return GetValue<ObservableCollection<MaterializedViewModel>>(); }
            set { SetValue(value); }
        }


        public MaterializedViewModel SelectedMaterializedView
        {
            get { return GetValue<MaterializedViewModel>(); }
            set { SetValue(value); }
        }
        public ObservableCollection<MaterializedViewModel> SelectedMaterializedViewList { get; } = new ObservableCollection<MaterializedViewModel>();

        public ThreadStatus? Status
        {
            get { return GetValue<ThreadStatus?>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                IsThreadStatusChanged = true;
            }
        }

        public string PiLotId
        {
            get { return GetValue<string>(); }
            set
            {
                SetValue(value);
                IsDirty = true;
                ClearError(nameof(PiLotId));
                IsPiLotIdChanged = true;
            }
        }

        public bool IsThreadStatusChanged
        {
            get { return GetValue<bool>(); }
            set { SetValue(value); }
        }

        public bool IsPiLotIdChanged
        {
            get { return GetValue<bool>(); }
            set { SetValue(value); }
        }

        #endregion
    }

}
