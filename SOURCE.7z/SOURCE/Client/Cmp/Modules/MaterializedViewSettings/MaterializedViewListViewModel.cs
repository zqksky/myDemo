﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Threading.Tasks;
using AMAT.R2R.Client.Common.Enums;
using AMAT.R2R.Client.Common.Helpers;
using AMAT.R2R.Client.Common.Services;
using AMAT.R2R.Client.Cmp.Messages;
using AMAT.R2R.Client.Cmp.Modules.SpecialJobSettings;
using AMAT.R2R.Shared.Base.DTO;
using AMAT.R2R.Shared.Cmp.DTO;
using DevExpress.Mvvm;
using DevExpress.Mvvm.DataAnnotations;
using DevExpress.Xpf.Core.HandleDecorator.Helpers;
using DevExpress.Xpf.Core.Native;
using DevExpress.Xpf.Data;
using AMAT.R2R.Client.Cmp.Modules.ContextSettings;
using AMAT.R2R.Client.Common.Extensions;

namespace AMAT.R2R.Client.Cmp.Modules.MaterializedViewSettings
{
    public class MaterializedViewListViewModel : CmpViewModelBase
    {
        public const string Auth_MaterialView = "MaterialView";

        public const string Auth_MaterialView_AddPreMetrologyData = "MaterialView:AddPreMetrologyData";
        public const string Auth_MaterialView_BookPilot = "MaterialView:BookPilot";
        public const string Auth_MaterialView_LinkControl = "MaterialView:LinkControl";
        public const string Auth_Context_OutputSettings = "MaterialView:OutputSettings";
        public const string Auth_Context_PreMeasurement = "MaterialView:PreMeasurement";

        public MaterializedViewListViewModel()
        {
            Caption = "Materialized View Settings";
            Icon = "SvgImages/XAF/ModelEditor_Business_Object_Model.svg";
            PropertyChanged += OnPropertyChanged;
            Messenger.Default.Register<MaterializedViewChangedMessage>(this, OnMaterializedViewChanged);
            Messenger.Default.Register<ContextChangedMessage>(this, OnContextChanged);


            InitializePagedSource();
        }

        #region Filtering & Paging

        private void InitializePagedSource()
        {
            #region Paged Source
            var pagedSource = new PagedAsyncSource()
            {
                ElementType = typeof(MaterializedViewModel),
                KeyProperty = nameof(MaterializedViewModel.ContextKey),
                PageSize = 100,
                PageNavigationMode = PageNavigationMode.ArbitraryWithTotalPageCount
            };

#if DEBUG
            pagedSource.PageSize = 10;
#endif

            pagedSource.FetchPage += (o, e) =>
            {
                e.Result = FetchPageRowsAsync(e);
            };

            pagedSource.GetTotalSummaries += (o, e) =>
            {
                e.Result = GetSummariesAsync(e);
            };

            pagedSource.GetUniqueValues += (o, e) =>
            {
                e.Result = GetValueListAsync(e);
            };

            pagedSource.PropertyChanged += (o, e) =>
            {
                if (e.PropertyName == nameof(PagedAsyncSource.AreRowsFetching))
                {
                    IsLoading = PagedSource.AreRowsFetching;

                    // restore selection.
                    if (!IsLoading)
                    {
                        if (_lastSelectedItem != null)
                        {
                            foreach (var item in PagedSource)
                            {
                                var view = item as MaterializedViewModel;
                                if (view.ContextKey == _lastSelectedItem.ContextKey)
                                {
                                    SelectedMaterializedView = view;
                                    break;
                                }
                            }
                        }
                    }
                }
            };

            PagedSource = pagedSource;
            #endregion
        }


        MaterializedViewModel _lastSelectedItem = null;
        private async Task<FetchRowsResult> FetchPageRowsAsync(FetchPageAsyncEventArgs e)
        {
            try
            {
                if (SelectedMaterializedView != null)
                {
                    _lastSelectedItem = SelectedMaterializedView;
                }

                var items = await MaterializedViewService.GetMaterializedViewListAsync(e.Filter.MakeFilters(), e.MakeSorters(), e.Skip, e.Take);
                return new FetchRowsResult(items.ToArray(), hasMoreRows: items.Count == e.Take);
            }
            catch (Exception ex)
            {
                Logger.Error(ex);
                throw;
            }
        }

        private async Task<object[]> GetSummariesAsync(GetSummariesAsyncEventArgs e)
        {
            try
            {
                var summary = await MaterializedViewService.GetMaterializedViewCount(e.Filter.MakeFilters());
                return e.Summaries.Select(x =>
                {
                    return x.SummaryType == SummaryType.Count ? (object)summary : throw new InvalidOperationException();
                }).ToArray();
            }
            catch (Exception ex)
            {
                Logger.Error(ex);
                throw;
            }
        }

        private async Task<object[]> GetValueListAsync(GetUniqueValuesAsyncEventArgs e)
        {
            try
            {
                var propertyName = e.PropertyName;
                if (propertyName == nameof(MaterializedView.R2RMode))
                {
                    var values = Enum.GetValues(typeof(R2RMode)).Cast<object>().Select(f => f.ToString()).ToArray();
                    return await Task.Factory.StartNew(() => values);
                }
                else if (propertyName == nameof(MaterializedView.RecLevel))
                {
                    var values = Enum.GetValues(typeof(RecLevel)).Cast<object>().Select(f => f.ToString()).ToArray();
                    return await Task.Factory.StartNew(() => values);
                }
                else if (
                    propertyName == nameof(ContextConstants.FF) ||
                    propertyName == nameof(ContextConstants.FB))
                {
                    var values = new object[] { true, false };
                    return await Task.Factory.StartNew(() => values);
                }
                else
                {
                    return await MaterializedViewService.GetMaterializedViewValueListAsync(e.PropertyName, e.Filter.MakeFilters());
                }
            }
            catch (Exception ex)
            {
                Logger.Error(ex);
                throw;
            }
        }

        #endregion

        #region Events

        protected override void OnViewReadyAsync()
        {
            //Refresh();
        }
        public override void OnRemoving(CancelEventArgs e)
        {
            base.OnRemoving(e);

            PagedSource?.Dispose();
            Messenger.Default.Unregister<ContextChangedMessage>(this, OnContextChanged);
            Messenger.Default.Unregister<MaterializedViewChangedMessage>(this, OnMaterializedViewChanged);
        }

        private async void OnPropertyChanged(object sender, System.ComponentModel.PropertyChangedEventArgs e)
        {
            if (e.PropertyName == nameof(SelectedMaterializedView))
            {
                if (SelectedMaterializedView == null)
                {
                    ClearDetails();
                }
                else
                {
                    if (SelectedMaterializedView.Context == null)
                    {
                        SelectedMaterializedView.Context = await ContextService.GetContextAsync(SelectedMaterializedView.ContextKey);
                    }

                    await UpdateCurrentDetailPage();
                }
            }
            else if (e.PropertyName == nameof(SelectedDetailPageIndex))
            {
                await UpdateCurrentDetailPage();
            }
            else if(e.PropertyName == nameof(FilterString))
            {

            }
        }


        private async Task UpdateCurrentDetailPage()
        {
            switch (SelectedDetailPageIndex)
            {
                case 0:
                    try
                    {
                        MaterializedViewInputList?.Clear();
                        IsInputLoading = true;
                        if (SelectedMaterializedView != null)
                        {
                            var view = SelectedMaterializedView;
                            var list = await MaterializedViewService.GetMaterializedViewInputListAsync(view.ContextKey);
                            list.ForEach(p => p.Index = $"Input {list.IndexOf(p) + 1}");

                            if (SelectedMaterializedView != null && SelectedMaterializedView.ContextKey == view.ContextKey)
                            {
                                MaterializedViewInputList = new ObservableCollection<MaterializeViewParameterExtend>(list);
                            }
                        }
                    }
                    finally
                    {
                        IsInputLoading = false;
                    }
                    break;
                case 1:
                    try
                    {
                        MaterializedViewRunHisList?.Clear();
                        IsRunHisLoading = true;
                        if (SelectedMaterializedView != null)
                        {
                            MaterializedViewRunHisList = new ObservableCollection<RunHist>(await MaterializedViewService.GetMaterializedViewRunHisListAsync(SelectedMaterializedView.ContextKey));
                        }
                    }
                    finally
                    {
                        IsRunHisLoading = false;
                    }
                    break;
                case 2:
                    try
                    {
                        IsHistoryLoading = true;
                        HistoryList?.Clear();
                        if (SelectedMaterializedView != null)
                        {
                            HistoryList = new ObservableCollection<TransactionHistory>(await GlobalService.GetHistoryAsync(ClientInfo.LoginArea, "Context", SelectedMaterializedView.ContextKey, null));
                        }
                    }
                    finally
                    {
                        IsHistoryLoading = false;
                    }
                    break;
                default:
                    break;
            }
        }

        private void OnMaterializedViewChanged(MaterializedViewChangedMessage msg)
        {
            Refresh();
        }


        private void OnContextChanged(ContextChangedMessage msg)
        {
            Refresh();
        }

        private async Task UpdateSingleMaterializedView(MaterializedViewModel materializedView)
        {
            var lastModifiedTime = materializedView.LastModifiedTime;
            var newMaterializedView = await MaterializedViewService.GetMaterializedViewAsync(materializedView.ContextKey);


            materializedView.LastModifiedBy = newMaterializedView.LastModifiedBy;
            materializedView.LastModifiedTime = newMaterializedView.LastModifiedTime;
            materializedView.MaterializeViewParameters = newMaterializedView.MaterializeViewParameters;
            materializedView.Context = await ContextService.GetContextAsync(SelectedMaterializedView.ContextKey);
            materializedView.NotifyChanges();

            if (SelectedMaterializedView != null && materializedView.ContextKey == SelectedMaterializedView.ContextKey && lastModifiedTime != newMaterializedView.LastModifiedTime)
            {
                await UpdateCurrentDetailPage();
            }
        }
        #endregion

        #region Commands

        [Command]
        public void Refresh()
        {
            PagedSource.UpdateSummaries();
            PagedSource.RefreshRows();
        }

        public bool CanRefresh()
        {
            return !IsLoading;
        }

        [Command]
        public void AddPreMetrologyData()
        {
            ShowPopup("AddPreMetrologyData", new AddPreMetrologyDataViewModel(string.Format("{0}:{1}:{2}", SelectedMaterializedView.Fab, SelectedMaterializedView.Product, SelectedMaterializedView.ProcessStep)));
        }


        public bool CanAddPreMetrologyData()
        {
            return SelectedMaterializedView != null && SelectedMaterializedViewList.Count == 1 && !IsLoading;// && AuthorityManager.HasAuthority(Auth_MaterialView_AddPreMetrologyData);
        }

        [Command]
        public void BookPilot()
        {
            ShowPopup("BookPilot", new BookPilotViewModel(SelectedMaterializedViewList.ToList()));
        }

        public bool CanBookPilot()
        {
            return SelectedMaterializedViewList.Count != 0 && !IsLoading;
        }

        [Command]
        public async void LinkControl()
        {
            await UpdateBeforeAction();
            ShowPopup("LinkControl", new LinkControlViewModel());
        }

        public bool CanLinkControl()
        {
            return SelectedMaterializedView != null && SelectedMaterializedViewList.Count == 1 && !IsLoading; // && AuthorityManager.HasAuthority(Auth_MaterialView_Change);
        }


        [Command]
        public async void ManualPM()
        {
            await UpdateBeforeAction();
            ShowPopup("ManualPM", new ManualPMViewModel(SelectedMaterializedView));
        }

        public bool CanManualPM()
        {
            return SelectedMaterializedView != null && SelectedMaterializedViewList.Count == 1 && !IsLoading; // && AuthorityManager.HasAuthority(Auth_MaterialView_Change);
        }

        [Command]
        public void FilterContext()
        {
            FilterString = $"[{nameof(MaterializedView.Product)}]='{SelectedMaterializedView.Product}' AND [{nameof(MaterializedView.ProcessStep)}]='{SelectedMaterializedView.ProcessStep}' AND [{nameof(MaterializedView.Tool)}]='{SelectedMaterializedView.Tool}' AND [{nameof(MaterializedView.Recipe)}]='{SelectedMaterializedView.Recipe}'";
        }

        public bool CanFilterContext()
        {
            return SelectedMaterializedView != null && SelectedMaterializedViewList.Count == 1 && !IsLoading;
        }


        [Command]
        public async void PreChamberLineAVG()
        {
            await UpdateBeforeAction();
            ShowPopup("PreChamberLineAVG", new PreChamberLineAVGViewModel(SelectedMaterializedView));
        }

        public bool CanPreChamberLineAVG()
        {
            return SelectedMaterializedView != null && SelectedMaterializedViewList.Count == 1 && !IsLoading; // && AuthorityManager.HasAuthority(Auth_MaterialView_Change);
        }

        [Command]
        public async void EditContextConstants()
        {
            await UpdateBeforeAction();
            ShowPopup("EditContextConstants", new EditContextConstantsViewModel(SelectedMaterializedView.Context));
        }

        public bool CanEditContextConstants()
        {
            return SelectedMaterializedView?.Context != null && SelectedMaterializedViewList.Count == 1 && !IsLoading; // && !IsLoading && AuthorityManager.HasAuthority(Auth_Context_Constants);
        }

        [Command]
        public async void EditContextOutputs()
        {
            await UpdateBeforeAction();
            ShowPopup("EditContextOutput", new EditContextOutputViewModel(SelectedMaterializedView.Context, SettingType.Output, false));
        }

        public bool CanEditContextOutputs()
        {
            return SelectedMaterializedView?.Context != null && SelectedMaterializedViewList.Count == 1 && !IsLoading; // && AuthorityManager.HasAuthority(Auth_Context_OutputSettings);
        }

        [Command]
        public async void EditContextPreMeasures()
        {
            await UpdateBeforeAction();
            ShowPopup("EditContextOutput", new EditContextOutputViewModel(SelectedMaterializedView.Context, SettingType.PreMeasurement, false));
        }

        public bool CanEditContextPreMeasures()
        {
            return SelectedMaterializedView?.Context != null && SelectedMaterializedViewList.Count == 1 && !IsLoading; // && AuthorityManager.HasAuthority(Auth_Context_PreMeasurement);
        }


        private void ClearDetails()
        {
            _lastSelectedItem = null;
            HistoryList?.Clear();
            MaterializedViewInputList?.Clear();
            MaterializedViewRunHisList?.Clear();
        }


        public async Task UpdateBeforeAction()
        {
            ShowWait();
            await Task.WhenAll(SelectedMaterializedViewList.Select(materializedView => UpdateSingleMaterializedView(materializedView)));
            HideWait();
        }

        #endregion

        #region Properties

        public string FilterString
        {
            get { return GetValue<string>(); }
            set { SetValue(value); }
        }



        public PagedAsyncSource PagedSource
        {
            get { return GetValue<PagedAsyncSource>(); }
            set { SetValue(value); }
        }
        public bool IsInputLoading
        {
            get { return GetValue<bool>(); }
            set { SetValue(value); }
        }

        public bool IsRunHisLoading
        {
            get { return GetValue<bool>(); }
            set { SetValue(value); }
        }

        public ObservableCollection<MaterializedViewModel> MaterializedViewList
        {
            get { return GetValue<ObservableCollection<MaterializedViewModel>>(); }
            set { SetValue(value); }
        }

        public MaterializedViewModel SelectedMaterializedView
        {
            get { return GetValue<MaterializedViewModel>(); }
            set { SetValue(value); }
        }

        public ObservableCollection<MaterializedViewModel> SelectedMaterializedViewList { get; } = new ObservableCollection<MaterializedViewModel>();

        public int SelectedDetailPageIndex
        {
            get { return GetValue<int>(); }
            set { SetValue(value); }
        }


        public ObservableCollection<MaterializeViewParameterExtend> MaterializedViewInputList
        {
            get { return GetValue<ObservableCollection<MaterializeViewParameterExtend>>(); }
            set { SetValue(value); }
        }
        public ObservableCollection<RunHist> MaterializedViewRunHisList
        {
            get { return GetValue<ObservableCollection<RunHist>>(); }
            set { SetValue(value); }
        }


        public ObservableCollection<string> FabList
        {
            get { return GetValue<ObservableCollection<string>>(); }
            set { SetValue(value); }
        }

        public ObservableCollection<string> ProductList
        {
            get { return GetValue<ObservableCollection<string>>(); }
            set { SetValue(value); }
        }

        public ObservableCollection<string> RecipeList
        {
            get { return GetValue<ObservableCollection<string>>(); }
            set { SetValue(value); }
        }
        #endregion

    }

    public class MaterializeViewParameterExtend : MaterializeViewParameter
    {
        public string Index { get; set; }
    }
}
