﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AMAT.R2R.Shared.Base.DTO;

namespace AMAT.R2R.Shared.Cmp.DTO
{

    public class PreChamberLineAvg : BaseDto
    {
        public PreChamberLineAvg()
        {
            PreChamberLineAvgItems = new List<PreChamberLineAvgItem>();
        }

        public Process Process { get; set; }

        public List<PreChamberLineAvgItem> PreChamberLineAvgItems;

        public override bool Validate(out string errorMessage)
        {
            errorMessage = "";
            return true;
        }
    }

    public class PreChamberLineAvgItem : BaseDto
    {
        public PreChamberLineAvgItem()
        {

        }
        public string Fab { get; set; }

        public string Product { get; set; }

        public string ProcessStep { get; set; }

        public string ProcessKey { get; set; }

        public string PreTool { get; set; }
        public string PreSubTool { get; set; }
        public string MeasDataItemName { get; set; }
        public bool UsePreMeasEwma{get;set;}
        public double GofThresdhold { get; set; }
        public double Lambda { get; set; }
        public double PreProcessExpiredTimeNOD { get; set; }

        public override bool Validate(out string errorMessage)
        {
            errorMessage = "";
            return true;
        }
    }

}
