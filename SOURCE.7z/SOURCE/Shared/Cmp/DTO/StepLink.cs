﻿using System;
using System.Collections.Generic;

using System.Linq;
using System.Threading.Tasks;
using AMAT.R2R.Shared.Base.DTO;
using Newtonsoft.Json;

namespace AMAT.R2R.Shared.Cmp.DTO
{
    public class StepLink : BaseDto
    {
        public StepLink()
        {

        }

        [JsonIgnore]
        public string StepLinkKey
        { 
            get { return string.Format("{0}:{1}:{2}", Fab, MeasType, LinkedStep); }
        }
        public string Fab { get; set; }
        public string MeasType { get; set; }

        public string LinkedStep { get; set; }


        public override bool Validate(out string errorMessage)
        {
            errorMessage = "";
            StepLink metro = (StepLink)this;
            if (string.IsNullOrEmpty(metro.Fab) ||
                string.IsNullOrEmpty(metro.MeasType) ||
                string.IsNullOrEmpty(metro.LinkedStep) ||
                metro.Fab.StartsWith(" ") ||
                metro.MeasType.StartsWith(" ") ||
                metro.LinkedStep.StartsWith(" "))
            {
                errorMessage = "Empty value found!";
            }
            if (string.IsNullOrEmpty(errorMessage)) return true;
            else return false;
        }

    }

}
