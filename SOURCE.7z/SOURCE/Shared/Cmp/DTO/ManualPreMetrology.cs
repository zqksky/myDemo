﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AMAT.R2R.Shared.Base.DTO;

namespace AMAT.R2R.Shared.Cmp.DTO
{
    public class ManualPreMetrology : BaseDto
    {
        public ManualPreMetrology()
        {
            ManualPreMetrologyItems = new List<ManualPreMetrologyItem>();
        }

        public Process Process { get; set; }

        public List<ManualPreMetrologyItem> ManualPreMetrologyItems;

        public override bool Validate(out string errorMessage)
        {
            errorMessage = "";
            return true;
        }
    }

    public class ManualPreMetrologyItem : BaseDto
    {
        public string Fab { get; set; }
        public string Product { get; set; }
        public string ProcessStep { get; set; }

        public string ProcessKey { get; set; }
        public string MeasDataItemName { get; set; }

        public string WaferId { get; set; }
        public int TotalSiteQty { get; set; }
        public double? Value01 { get; set; }
        public double? Value02 { get; set; }
        public double? Value03 { get; set; }
        public double? Value04 { get; set; }
        public double? Value05 { get; set; }
        public double? Value06 { get; set; }
        public double? Value07 { get; set; }
        public double? Value08 { get; set; }
        public double? Value09 { get; set; }
        public double? Value10 { get; set; }
        public double? Value11 { get; set; }
        public double? Value12 { get; set; }
        public double? Value13 { get; set; }
        public double? Value14 { get; set; }
        public double? Value15 { get; set; }
        public double? Value16 { get; set; }
        public double? Value17 { get; set; }
        public double? Value18 { get; set; }
        public double? Value19 { get; set; }
        public double? Value20 { get; set; }

        public override bool Validate(out string errorMessage)
        {
            errorMessage = "";
            if (string.IsNullOrEmpty(errorMessage)) return true;
            return false;
        }
    }
}
