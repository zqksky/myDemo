﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime;
using System.Threading.Tasks;
using AMAT.R2R.Shared.Base.DTO;
using Newtonsoft.Json;

namespace AMAT.R2R.Shared.Cmp.DTO
{
    public enum RecLevel { LL, WL }
    public enum R2RMode { Active, Fixed, Constrainted }

    public enum ThreadStatus { None, Normal, PiRun, WaitPiRunLotMeasurement }

    public enum MappingType { PreMeas, PostMeas, PreProcess }

    public class Context : BaseDto
    {
        public Context()
        {
            ContextConstants = new ContextConstants();
            Outputs = new List<ContextOutputGroup>();
            PreMeasurements = new List<ContextOutputGroup>();
            ContextInputParas = new List<ContextInputPara>();
            
            PMDetectIndex = 1;
            
        }

        public Process Process { get; set; }

        public ContextConstants ContextConstants { get; set; }

        public List<ContextOutputGroup> Outputs { get; set; }

        public List<ContextOutputGroup> PreMeasurements { get; set; }

        public List<ContextInputPara> ContextInputParas { get; set; }

        public string Fab { get; set; }

        public string Product { get; set; }

        public string ProcessStep { get; set; }

        public string Recipe { get; set; }

        public string Tool { get; set; }

        public string ModelGroup { get; set; }

        public R2RMode R2RMode { get; set; }

        public RecLevel RecLevel { get; set; }

        public DateTime LastModifiedTime { get; set; }

        //the ConfigMode information

        [JsonIgnore]
        public string PMDetectVID { 
            get 
            {
                if(string.IsNullOrEmpty(VIDChannels)) return "";
                string[] tmps = VIDChannels.Split(',');

                return PMDetectIndex > 0 && PMDetectIndex <= tmps.Length ? tmps[PMDetectIndex - 1] : ""; ;
            }
            set
            {

                if (string.IsNullOrEmpty(VIDChannels)) { VIDChannels = value; PMDetectIndex = 1; }
                else 
                {
                    string[] tmps = VIDChannels.Split(',');
                    List<string> t = new List<string>(tmps);
                    if (tmps.Contains(value))
                    {
                        PMDetectIndex = t.IndexOf(value) + 1;
                    }
                    else
                    {
                        t.Add(value);
                        VIDChannels = string.Join(",", t.ToArray());
                        PMDetectIndex = t.Count;
                    }
                }
            }
        }
        public int PMDetectIndex { get; set; }
        //csv
        public string VIDChannels { get; set; }
        [JsonIgnore]
        public double[] ControllerQ { get { return new Matrix<double>(10, ContextInputParas.Select(t => t.ControllerQ).ToList(), 50000).ColumnArray(0); } }
        [JsonIgnore]
        public double[] ControllerR { get { return new Matrix<double>(10, ContextInputParas.Select(t => t.ControllerR).ToList(), 0).ColumnArray(0); } }
        [JsonIgnore]
        public double[] ModelSlope1 { get { return ContextInputParas.Count() > 0 ? ContextInputParas[0].ModelSlope.RowArray(0) : new Matrix<double>(1, 10, 0).RowArray(0); } }
        [JsonIgnore]
        public double[] ModelSlope2 { get { return ContextInputParas.Count() > 1 ? ContextInputParas[1].ModelSlope.RowArray(0) : new Matrix<double>(1, 10, 0).RowArray(0); } }
        [JsonIgnore]
        public double[] ModelSlope3 { get { return ContextInputParas.Count() > 2 ? ContextInputParas[2].ModelSlope.RowArray(0) : new Matrix<double>(1, 10, 0).RowArray(0); } }
        [JsonIgnore]
        public double[] ModelSlope4 { get { return ContextInputParas.Count() > 3 ? ContextInputParas[3].ModelSlope.RowArray(0) : new Matrix<double>(1, 10, 0).RowArray(0); } }
        [JsonIgnore]
        public double[] ModelSlope5 { get { return ContextInputParas.Count() > 4 ? ContextInputParas[4].ModelSlope.RowArray(0) : new Matrix<double>(1, 10, 0).RowArray(0); } }
        [JsonIgnore]
        public double[] ModelSlope6 { get { return ContextInputParas.Count() > 5 ? ContextInputParas[5].ModelSlope.RowArray(0) : new Matrix<double>(1, 10, 0).RowArray(0); } }
        [JsonIgnore]
        public double[] ModelSlope7 { get { return ContextInputParas.Count() > 6 ? ContextInputParas[6].ModelSlope.RowArray(0) : new Matrix<double>(1, 10, 0).RowArray(0); } }
        [JsonIgnore]
        public double[] ModelSlope8 { get { return ContextInputParas.Count() > 7 ? ContextInputParas[7].ModelSlope.RowArray(0) : new Matrix<double>(1, 10, 0).RowArray(0); } }
        [JsonIgnore]
        public double[] ModelSlope9 { get { return ContextInputParas.Count() > 8 ? ContextInputParas[8].ModelSlope.RowArray(0) : new Matrix<double>(1, 10, 0).RowArray(0); } }
        [JsonIgnore]
        public double[] ModelSlope10 { get { return ContextInputParas.Count() > 9 ? ContextInputParas[9].ModelSlope.RowArray(0) : new Matrix<double>(1, 10, 0).RowArray(0); } }



        public List<SpecialJobParameter> GetDefaultSpecialJobParameters() => ContextInputParas?.Select(cip => new SpecialJobParameter
        {
            JobId = "NA",
            ParameterName = cip.ParameterName,
            InputValue = new decimal(cip.Fixed),
            Max = new decimal(cip.Max),
            Min = new decimal(cip.Min),
            Unit = "",//cip.Unit,
            PM = new decimal(cip.PM),
            Reset = new decimal(cip.Reset)
        }).ToList();

        [JsonIgnore]
        public string ValidateString
        {
            get 
            {
                if (Process == null) return "Process Is Null";
                if (ContextConstants == null) return "Missing Constants";
                if (ContextInputParas == null || ContextInputParas.Count == 0) return "Missing Input";
                if (Outputs == null || Outputs.Count == 0) return "Missing Output";
                if (ContextConstants.FF && ContextConstants.DeltaControl) return "FF and DeltaControl conflit";
                if (ContextConstants.FF && (PreMeasurements == null || PreMeasurements.Count == 0)) return "Missing PreMeas";

                //check master and slave parameter name confilt
                List<string> masterNames = ContextInputParas == null ? new List<string>() : this.ContextInputParas.Select(t => t.ParameterName).ToList();
                foreach (ContextInputPara cip in this.ContextInputParas)
                {
                    foreach (SlaveInput si in cip.SlaveInputs)
                    {
                        if (masterNames.Exists(t => t == si.SlaveName))
                        {
                            return $"{cip.ParameterName} has some slave parameter name conflit!";
                        }
                    }
                }

                return null;
            }
        }

        public string LastModifiedBy { get; set; }

 
        [JsonIgnore]
        public string ProcessKey
        {
            get { return Process == null ? "" : Process.ProcessKey; }
        }

        [JsonIgnore]
        public string ContextKey
        {
            get { return string.Format("{0}:{1}:{2}:{3}:{4}:{5}", Fab, Product, ProcessStep, Tool, Recipe, ModelGroup); }
        }

        [JsonIgnore]
        public int OutputNum4Slope
        {
            get
            {
                if (this.Outputs == null || this.Outputs.Count == 0) return 0;
                //check if all index count is same beween outputs
                bool valid = false;
                int i0 = -1;
                int i1 = -1;
                foreach (ContextOutputGroup copp in this.Outputs)
                {
                    if(i0<0) i0 = copp.ContextOutputs == null ? 0 : copp.ContextOutputs.Count;
                    i1= copp.ContextOutputs == null ? 0 : copp.ContextOutputs.Count;
                    valid = i0 == i1;
                }
                return valid ? i0 : 0;
            }
        }

        public override bool Validate(out string errorMessage)
        {
            errorMessage = "";
            Context context = (Context)this;
            if (string.IsNullOrEmpty(context.Fab) ||
                string.IsNullOrEmpty(context.Product) ||
                string.IsNullOrEmpty(context.ProcessStep) ||
                string.IsNullOrEmpty(context.Recipe) ||
                string.IsNullOrEmpty(context.Tool) ||
                string.IsNullOrEmpty(context.ModelGroup)  ||
                context.Fab.StartsWith(" ") ||
                context.Product.StartsWith(" ") ||
                context.ProcessStep.StartsWith(" ") ||
                context.Recipe.StartsWith(" ") ||
                context.Tool.StartsWith(" ") ||
                context.ModelGroup.StartsWith(" "))
            {
                errorMessage = "Empty value found!";
                return false;
            }

            //check master and slave parameter name confilt
            List<string> masterNames = ContextInputParas== null ? new List<string>() : this.ContextInputParas.Select(t => t.ParameterName).ToList();
            foreach(ContextInputPara cip in this.ContextInputParas)
            {
                foreach(SlaveInput si in cip.SlaveInputs)
                {
                    if (masterNames.Exists(t => t == si.SlaveName))
                    {
                        errorMessage = string.IsNullOrEmpty(errorMessage) ? "" : errorMessage + ",";
                        errorMessage += $"{cip.ParameterName} has some slave parameter name conflit!";
                    }  
                }
            }

            if (string.IsNullOrEmpty(errorMessage)) return true;
            return false;
        }
    }
}
