﻿using System;
using System.Collections.Generic;

using System.Linq;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;
using AMAT.R2R.Shared.Base.DTO;
using Newtonsoft.Json;

namespace AMAT.R2R.Shared.Cmp.DTO
{
    public class MaterializedView : BaseDto
    {
        public MaterializedView()
        {
            MaterializeViewParameters = new List<MaterializeViewParameter>();
            Constants = new ContextConstants();
            ThreadTracking = new ThreadTracking();
        }

        private ContextConstants constants;
        public ContextConstants Constants { 
            get { return this.constants; }
            set { this.constants = value; }
        }

        public ThreadTracking ThreadTracking { get; set; }
        public string Fab { get; set; }

        public string Product { get; set; }

        public string ProcessStep { get; set; }

        public string Recipe { get; set; }

        public string Tool { get; set; }

        public string ModelGroup { get; set; }

        public R2RMode R2RMode { get; set; }

        public RecLevel RecLevel { get; set; }

        public DateTime LastModifiedTime { get; set; }

        public string LastModifiedBy { get; set; }
       
        public string ContextKey { get; set; }

        //misc
        public string BookedPiLotId { get; set; }
        public bool ManualPM { get; set; }


        [JsonIgnore]
        public List<double?> OnTargetEstimate { get { return this.MaterializeViewParameters.Select(t => t.OnTargetEstimate).ToList(); } }

        public List<MaterializeViewParameter> MaterializeViewParameters { get; set; }


        public override bool Validate(out string errorMessage)
        {
            errorMessage = "";
            return true;
        }
    }

    public class MaterializeViewParameter : BaseDto
    {
        public string InputParameter { get; set; }

        public double InputFixedValue { get; set; }

        public double PM { get; set; }

        public double Reset { get; set; }

        public double? OnTargetEstimate { get; set; }

        public string Unit { get; set; }

        public double UpperLimt { get; set; }

        public double LowerLimit { get; set; }

        public double Deadband { get; set; }

        public override bool Validate(out string errorMessage)
        {
            errorMessage = "";
            if (string.IsNullOrEmpty(errorMessage)) return true;
            return false;
        }
    }
}
