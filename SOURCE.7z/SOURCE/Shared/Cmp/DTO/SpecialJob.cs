﻿using System;
using System.Collections.Generic;
using System.Linq;
using AMAT.R2R.Shared.Base.DTO;

namespace AMAT.R2R.Shared.Cmp.DTO
{
    public class SpecialJobParameter : BaseDto
    {
        public string JobId { get; set; }
        public string ParameterName { get; set; }
        public decimal? InputValue { get; set; }
        public decimal? Min { get; set; }
        public decimal? Max { get; set; }
        public decimal? Fixed { get; set; }
        public decimal? PM { get; set; }
        public decimal? Reset { get; set; }

        public string Unit { get; set; }

        public override bool Validate(out string errorMessage)
        {
            errorMessage = "";
            return true;
        }
    }
    public class SpecialJob : BaseDto
    {
        public SpecialJob()
        {
            this.SpecialJobParameters = new List<SpecialJobParameter>();

        }

        public string JobKey { get { return string.Format("{0}:{1}:{2}:{3}:{4}:{5}:{6}:{7}:{8}", LotId, RuncardId, SplitId, Fab, Product, ProcessStep, Tool,Recipe, ModelGroup); } }
        public string Fab { get; set; }
        public string Product { get; set; }
        public string ProcessStep { get; set; }
        public string Tool { get; set; }
        public string Recipe { get; set; }
        public string ModelGroup { get; set; }
        public string JobId { get; set; }
        public string RuncardId { get; set; }
        public string SplitId { get; set; }
        public string LotId { get; set; }
        public bool JobCompleted { get; set; }
        public string UserId { get; set; }
        public DateTime CreateTime { get; set; }
        public DateTime? UsedTime { get; set; }
        public string FillBlanks { get; set; }
        public bool IsValid { get; set; }
        public List<SpecialJobParameter> SpecialJobParameters { get; set; }

        public DateTime LastModifiedTime { get; set; }

        public string LastModifiedBy { get; set; }

        public override CompareResult Compare(Object oldJob)
        {
            CompareResult result = base.Compare(oldJob);
            CompareResult result1 = new CompareResult() { IsChange = false, ChangeContent = "" };
            SpecialJob osj = (SpecialJob)oldJob;

            List<string> InputParameters = this.SpecialJobParameters.Select(t => t.ParameterName).ToList();
            List<decimal?> InputValues = this.SpecialJobParameters.Select(t => t.InputValue).ToList();
            for (int i = 0; i < InputParameters.Count(); i++)
            {
                int j = osj.SpecialJobParameters.FindIndex(t => t.ParameterName.Equals(InputParameters[i]));
                if (i < 0)
                {
                    result1.IsChange = true;
                    result1.ChangeContent = result1.ChangeContent + InputParameters[i] + " Added\r\n";
                }
                else if (!InputValues[i].Equals(osj.SpecialJobParameters[i].InputValue))
                {
                    result1.IsChange = true;
                    result1.ChangeContent = result1.ChangeContent + InputParameters[i] + ":" + osj.SpecialJobParameters[i].InputValue + "->" + InputValues[i] + "\r\n";
                }
            }
            for (int i = 0; i < osj.SpecialJobParameters.Count(); i++)
            {
                int j = InputParameters.IndexOf(osj.SpecialJobParameters[i].ParameterName);
                if (i < 0)
                {
                    result1.IsChange = true;
                    result1.ChangeContent = result1.ChangeContent + osj.SpecialJobParameters[i].ParameterName + " Delete\r\n";
                }
            }
            result.Add(result1);
            return result;
        }

        public override bool Validate(out string errorMessage)
        {
            errorMessage = "";
            if (string.IsNullOrEmpty(this.Fab) ||
                string.IsNullOrEmpty(this.Tool) ||
                string.IsNullOrEmpty(this.ModelGroup) ||
                string.IsNullOrEmpty(this.Product) ||
                string.IsNullOrEmpty(this.ProcessStep) ||
                string.IsNullOrEmpty(this.Recipe) ||
                string.IsNullOrEmpty(this.LotId) ||
                string.IsNullOrEmpty(this.RuncardId) ||
                string.IsNullOrEmpty(this.SplitId)
                //||this.InputParameters==null|| this.InputParameters.Count()==0 ||
                //this.InputValues == null || this.InputValues.Count() == 0
                )
            {
                errorMessage = "Not Valid";
            }

            if ("NA".Equals(LotId) && "NA".Equals(RuncardId) && "NA".Equals(SplitId))
            {
                errorMessage = "Not Valid LotId or RunCardId";
            }

            if (this.SpecialJobParameters == null || this.SpecialJobParameters.Count() <= 0)
            {
                errorMessage = "None Parameters found";
            }

            /*if (this.InputParameters.Count() != this.InputValues.Count())
            {
                errorMessage= "Not Valid Parameter";
            }
            for (int i = 0; i < this.InputParameters.Count(); i++)
            {
                if (string.IsNullOrEmpty(InputParameters[i]) || InputValues[i] == null)
                {
                    errorMessage= "Empty Value found";
                }
            }*/

            if (string.IsNullOrEmpty(errorMessage)) return true;
            else
                return false;
        }

    }
}
