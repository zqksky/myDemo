﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;
using AMAT.R2R.Shared.Base.DTO;
using Newtonsoft.Json;

namespace AMAT.R2R.Shared.Cmp.DTO
{
    /// <summary>
    /// The inputsettings of the context
    /// </summary>
    public class ContextInputPara : BaseDto
    {
        public ContextInputPara()
        {

            SlaveInputs = new List<SlaveInput>();
            VIDLifeTimeItems = new List<VIDLifeTimeItem>();
            ModelSlope = new Matrix<double>(1, 10, 0);
            ControllerQ = 50000;
            ControllerR = 1;
        }
        public string ContextKey { get; set; }
        public Parameter Parameter { get; set; }
        public int InputIndex { get; set; }

        [JsonIgnore]
        public string ParameterName { get { return this.Parameter.ParameterName; } }
        public double Fixed { get; set; }

        public double PM { get; set; }

        public double Reset { get; set; }
        public double Max { get; set; }
        public double Min { get; set; }

        public int Precision { get; set; }

        public double Tolerance { get; set; }
        public double FFDelta { get; set; }
        public double FBDelta { get; set; }

        //the feedback Qs/Rs States
        //public double Coefficient { get; set; }
        public double Deadband { get; set; }

        public string WaferProcessLocationRegex{ get; set; }

        public string UseRecOrUsedToFb { get; set; }

        public Boolean ShiftInputLimitWithLifeTimeOffset { get; set; }

        public List<SlaveInput> SlaveInputs { get; set; }
        public List<VIDLifeTimeItem> VIDLifeTimeItems { get; set; }



        //public string Unit { get; set; }

        //Model related columns
        public Matrix<double> ModelSlope { get; set; }
        public double ControllerQ { get; set; }
        public double ControllerR { get; set; }

        public override CompareResult Compare(Object oldContextInputPara)
        {
            return base.Compare(oldContextInputPara);
        }

        public override bool Validate(out string errorMessage)
        {
            errorMessage = "";
            if (Parameter == null || string.IsNullOrEmpty(Parameter.ParameterName))
            {
                errorMessage = "None Valid ParameterName\r\n";
            }

            if (string.IsNullOrEmpty(errorMessage)) return true;
            else return false;
        }
    }

    public class SlaveInput
    {
        public string ParameterName { get; set; }

        public string SlaveName { get; set; }

        public double Coefficient { get; set; }

        public double Offset { get; set; }
    }

    public class VIDLifeTimeItem
    {
        public string ParameterName { get; set; }

        public string VID { get; set; }

        public int VIDIndex { get; set; }

        public double RangeStart { get; set; }

        public double RangeEnd { get; set; }

        public double A { get; set; }

        public double B { get; set; }

        public double C { get; set; }

        public double Max { get; set; }
    }


}
