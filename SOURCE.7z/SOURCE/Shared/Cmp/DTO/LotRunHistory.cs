﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AMAT.R2R.Shared.Base.DTO;

namespace AMAT.R2R.Shared.Cmp.DTO
{
    public class LotRunHistory : BaseDto
    {
        public string Id { get; set; }

        public string TxId { get; set; }

        public string ModelingTick { get; set; }

        public string ParentId { get; set; }

        public string LotId { get; set; }

        public string WaferId { get; set; }

        public int WaferQty { get; set; }

        public string WaferList { get; set; }

        public string ProcessToolId { get; set; }

        public string ModelGroup { get; set; }

        public string Product { get; set; }

        public string ProcessRecipe { get; set; }

        public string ProcessStep { get; set; }

        public string Fab { get; set;}

        public string RecLevel { get; set; }

        public string R2RMode { get; set; }

        public string FbLevel { get; set; }

        public string Attribute { get; set; }

        public string ProcessLocation { get; set; }
        public List<LotHistoryParameter> LifeTime { get; set; }

        public List<LotHistoryParameter> LifeTimeOffsets { get; set; }

        public List<LotHistoryParameter> FFOffsets { get; set; }
        public List<LotHistoryParameter> DefaultRecSettings { get; set; }
        public List<LotHistoryParameter> RecSettings { get; set; }

        public List<LotHistoryParameter> FinalRecSettings { get; set; }

        public DateTime? ProcessStamp { get; set; }
        public List<LotHistoryParameter> ProcessVaues  { get;set;}

        public DateTime? PreTimeStamp { get; set; }
        public List<LotHistoryParameter> PreMetrologyValues { get; set; }

        public DateTime? PostTimeStamp { get; set; }
        public List<LotHistoryParameter> PostMetrologyValues { get; set; }

        public DateTime? EstiTimeStamp { get; set; }
        public List<LotHistoryParameter> EstimateValues { get; set; }

        public int ReworkCnt { get; set; }

        public string SpecifyLot { get; set; }

        public string PilotFlag { get; set; }

        public string LotType { get; set; }

        public string RunCardId { get; set; }

        public string SplitId { get; set; }

        public string Feedback { get; set; }

        public string Remark { get; set; }
        public override bool Validate(out string errorMessage)
        {
            errorMessage = "";

            return true;
        }

        public List<LotRunHistory> waferHist { get; set; }

    }

    public class LotHistoryParameter
    {
        private string val;
        public string Name { get; set; }
        public string Value {
            get
            {
                if (string.IsNullOrEmpty(val)) return string.Empty;
                if (!IsNumeric) return val;
                //Decimal dData = 0.0M;
                
                if(Decimal.TryParse(val.ToString(), System.Globalization.NumberStyles.Any, null ,out decimal dData))
                {
                    return Math.Round(dData, 8).ToString();
                }
                else
                {
                    return "NaN";
                }
            }
            set { val = value; }
        } 

        //number or string
        public bool IsNumeric { get; set; }

    }

}
