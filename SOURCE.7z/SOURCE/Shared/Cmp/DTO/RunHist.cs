﻿using System;
using System.Collections.Generic;

using System.Linq;
using System.Threading.Tasks;
using AMAT.R2R.Shared.Base.DTO;
using Newtonsoft.Json;

namespace AMAT.R2R.Shared.Cmp.DTO
{
    public class RunHist : BaseDto
    {
        public RunHist()
        {

        }

        public string HznKey { get; set; }

        public DateTime? CalcTimesStamp { get; set; }

        public DateTime? UsedTimeStamp { get; set; }

        public DateTime? PostTimeStamp { get; set; }

        public string Fab { get; set; }

        public string Product { get; set; }

        public string ProcessStep { get; set; }

        public string Recipe { get; set; }

        public string Tool { get; set; }

        public string ModelGroup { get; set; }

        public R2RMode R2RMode { get; set; }

        public RecLevel RecLevel { get; set; }

        public string LotType { get; set; }

        public string LotId { get; set; }

        public string WaferScribe { get; set; }

        public string WaferList { get; set; }

        public string PreMetrology { get; set; }

        public string FFOffset { get; set; }

        public string LifeTimeOffsets { get; set; }

        public string FinalRecSettings { get; set; }

        public string UsedSettings { get; set; }

        public string PostMetrology { get; set; }

        public string NewRecSettingsFb { get; set; }

        public string States { get; set; }

        public string ModifiedBy { get; set; }

        public string Feedback { get; set; }

        public string Remark { get; set; }

        public string SpecifyLot { get; set; }

        public string PilotFlag { get; set; }

        public string RunCardId { get; set; }

        public string Valid { get; set; }
        public override bool Validate(out string errorMessage)
        {
            errorMessage = "";
            return true;
        }
    }

}
