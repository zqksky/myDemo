﻿using System;
using System.Collections.Generic;

using System.Linq;
using System.Threading.Tasks;
using AMAT.R2R.Shared.Base.DTO;
using Newtonsoft.Json;

namespace AMAT.R2R.Shared.Cmp.DTO
{
    public class Process : BaseDto
    {
        public Process()
        {
            
        }

        public string Fab { get; set; }

        public string Product { get; set; }

        public string ProcessStep { get; set; }

        public IList<StepLink> PreMetrologyList { get; set; }

        public IList<StepLink> PostMetrologyList { get; set; }

        public IList<StepLink> PreProcessList { get; set; }

        [JsonIgnore]
        public bool HasPreStep 
        {
            get { return PreMetrologyList != null && PreMetrologyList.Count > 0; }
        }

        [JsonIgnore]
        public bool HasPostStep 
        {
            get { return PostMetrologyList != null && PostMetrologyList.Count > 0;  }
         }

        public DateTime LastModifiedTime { get; set; }

        public string LastModifiedBy { get; set; }


        [JsonIgnore]
        public string ProcessKey
        {
            get { return string.Format("{0}:{1}:{2}", Fab, Product, ProcessStep); }
        }


        public override bool Validate(out string errorMessage)
        {
            errorMessage = "";
            Process process = (Process)this;
            if (string.IsNullOrEmpty(process.Fab) ||
                string.IsNullOrEmpty(process.Product) ||
                string.IsNullOrEmpty(process.ProcessStep) ||
                process.Fab.StartsWith(" ") ||
                process.Product.StartsWith(" ") ||
                process.ProcessStep.StartsWith(" "))
            {
                errorMessage = "Empty value found!";
            }
            if (string.IsNullOrEmpty(errorMessage)) return true;
            else return false;
        }

    }

}
