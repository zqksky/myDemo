﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AMAT.R2R.Shared.Base.DTO;

namespace AMAT.R2R.Shared.Cmp.DTO
{
    /// <summary>
    /// The Constants of the context
    /// </summary>
    public class ContextConstants : BaseDto
    {
        public ContextConstants()
        {

        }
        public string ContextKey { get; set; }

        public int BoundaryMaxCount { get; set; }

        public double MaxQueueDays { get; set; }

        public int OOCMaxCount { get; set; }

        public int OOSMaxCount { get; set; }

        public int OOLMaxCountRecVsUsed { get; set; }

        public double StatesDuration { get; set; }

        public bool FBOnOOC { get; set; }

        public bool FBOnOOS { get; set; }

        public bool FFOnOOC { get; set; }

        public bool FFOnOOS { get; set; }

        public bool ForceChildLotFF { get; set; }

        public bool InvalidChildLot { get; set; }

        public bool ResetStatesAtPreTargetChange { get; set; }

        public bool ResetStatesAtPostTargetChange { get; set; }

        public bool UpdateFBTarget { get; set; }

        public bool UpdateFFTarget { get; set; }

        public bool DeltaControl { get; set; }

        public bool FB { get; set; }

        public bool FF { get; set; }
        public bool LifeTime { get; set; }
        public bool UsePostRemeasData { get; set; }
    
        public bool UsePreRmeasData { get; set; }
        public bool UseProductContext { get; set; }
        public bool UseRecipeContext { get; set; }

        public override CompareResult Compare(object oldContextConstants)
        {
            return base.Compare(oldContextConstants);
        }

        public override bool Validate(out string errorMessage)
        {
            errorMessage = "";
            if (DeltaControl  && FF)
            {
                errorMessage = "DeltaControl and FF can't be enalbe at same time.\r\n";
            }
             

            if (string.IsNullOrEmpty(errorMessage)) return true;
            return false;

        }
    }
}
