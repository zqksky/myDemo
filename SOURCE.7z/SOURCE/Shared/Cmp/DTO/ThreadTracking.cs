﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AMAT.R2R.Shared.Base.DTO;

namespace AMAT.R2R.Shared.Cmp.DTO
{
    /// <summary>
    /// The Constants of the context
    /// </summary>
    public class ThreadTracking : BaseDto
    {
        public ThreadTracking()
        {

        }

        //public string BookedPiLotId { get; set; }
        public string ContextKey { get; set; }

        public int ConsCntOfUsingBoundary { get; set; }

        public int ConsCntOfRecVsUsedOol { get; set; }

        public int ConsCntOfOoc { get; set; }

        public int ConsCntOfOos { get; set; }

        public string LastProcessPreTargetValues { get; set; }

        public string LastProcessTargetValues { get; set; }
      
        public string LastR2RMode { get; set; }

        public string ProcessRecValuesForNextLot { get; set; }

        public ThreadStatus Status { get; set; }

        public string LastModelValuesRow01 { get; set; }

        public string LastModelValuesRow02 { get; set; }

        public string LastModelValuesRow03 { get; set; }

        public string LastModelValuesRow04 { get; set; }

        public string LastModelValuesRow05 { get; set; }

        public string LastModelValuesRow06 { get; set; }

        public string LastModelValuesRow07 { get; set; }

        public string LastModelValuesRow08 { get; set; }

        public string LastModelValuesRow09 { get; set; }

        public string LastModelValuesRow10 { get; set; }

        public double Offset01 { get; set; }

        public double Offset02 { get; set; }

        public double Offset03 { get; set; }

        public double Offset04 { get; set; }

        public double Offset05 { get; set; }

        public double Offset06 { get; set; }

        public double Offset07 { get; set; }

        public double Offset08 { get; set; }

        public double Offset09 { get; set; }

        public double Offset10 { get; set; }

        public double State01 { get; set; }

        public double State02 { get; set; }

        public double State03 { get; set; }

        public double State04 { get; set; }

        public double State05 { get; set; }

        public double State06 { get; set; }

        public double State07 { get; set; }

        public double State08 { get; set; }

        public double State09 { get; set; }

        public double State10 { get; set; }

        public double State11 { get; set; }

        public double State12 { get; set; }

        public double State13 { get; set; }

        public double State14 { get; set; }

        public double State15 { get; set; }

        public double State16 { get; set; }

        public double State17 { get; set; }

        public double State18 { get; set; }

        public double State19 { get; set; }

        public double State20 { get; set; }

        public string LastLotStageLifeTime { get; set; } //??

        public DateTime LastPMTime { get; set; }

        public DateTime LastResetTime { get; set; }

        public DateTime LastStateUpdateTime { get; set; }

        public string Remark { get; set; }

        public Boolean IsValid { get; set; }
        
        public override bool Validate(out string errorMessage)
        {
            errorMessage = "";
            

            if (string.IsNullOrEmpty(errorMessage)) return true;
            return false;

        }
    }
}
