﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AMAT.R2R.Shared.Base.DTO;

namespace AMAT.R2R.Shared.Cmp.DTO
{
    /// <summary>
    /// The Constants of the context
    /// </summary>
    public class ContextOutputGroup : BaseDto
    {
        public ContextOutputGroup()
        {
            ContextOutputs = new List<ContextOutput>();
        }
        public string ContextKey { get; set; }

        public string OutputGroupName { get; set; }

        public List<ContextOutput> ContextOutputs { get; set; }


        public override CompareResult Compare(Object oldContextConstants)
        {
            return base.Compare(oldContextConstants);
        }

        public override bool Validate(out string errorMessage)
        {
            errorMessage = "";
             

            if (string.IsNullOrEmpty(errorMessage)) return true;
            return false;

        }
    }

    public class ContextOutput
    {
        public ContextOutput() { }

        public int Index { get; set; }
        public string MeasItemName { get; set; }

        public double QualityThreshold { get; set; }

        public string QualityItemName { get; set; }


        public double Target { get; set; }

        public double LowerSpecLimit { get; set; }

        public double LowerLimit { get; set; }

        public double UpperLimit { get; set; }

        public double UpperSpecLimit { get; set; }

        public double Multiplier { get; set; }

        public double Coefficients { get; set; }

        public double CoefficientsPiRun { get; set; }

        public string SiteOrders { get; set; }

        public string MeasDFCRange { get; set; }

        public int MinSitesRequired { get; set; }

        public int MaxOocSitesAllowed { get; set; }

        public int MaxOosSitesAllowed { get; set; }

        public string OCAP { get; set; }

        public int Precision { get; set; }

    }
}
