﻿using System;
using System.Collections.Generic;

using System.Linq;
using System.Threading.Tasks;
using AMAT.R2R.Shared.Base.DTO;
using Newtonsoft.Json;

namespace AMAT.R2R.Shared.Etch.DTO
{
    public class Process : BaseDto
    {
        public Process()
        {
            AvailablePreMetrology = new List<PreMetrology>();
            AvailablePostMetrology = new List<PostMetrology>();
            OutputSettings = new List<OutputSetting>();
            FeedforwardSettings = new List<FeedforwardSetting>();
        }

        public string Fab { get; set; }

        public string ProductId { get; set; }

        public string Recipe { get; set; }

        public string StepName { get; set; }

        public string StepNumber { get; set; }

        public string Stage { get; set; }

        [JsonIgnore]
        public string ProcessKey
        {
            get { return string.Format("{0}:{1}:{2}:{3}:{4}:{5}", Fab, ProductId, Stage, Recipe, StepName, StepNumber); }
        }

        public bool ProcessEnabled { get; set; }

        public bool OptContextGroupEnabled { get; set; }

        public DateTime LastModifiedTime { get; set; }

        public string LastModifiedBy { get; set; }


        public List<PreMetrology> AvailablePreMetrology { get; set; }

        public List<PostMetrology> AvailablePostMetrology { get; set; }

        public List<OutputSetting> OutputSettings { get; set; }

        public List<FeedforwardSetting> FeedforwardSettings { get; set; }

        public int ProcessId { get; set; }

        public override bool Validate(out string errorMessage)
        {
            errorMessage = "";
            Process process = (Process)this;
            if (string.IsNullOrEmpty(process.Fab) ||
                string.IsNullOrEmpty(process.ProductId) ||
                string.IsNullOrEmpty(process.Stage) ||
                string.IsNullOrEmpty(process.Recipe) ||
                string.IsNullOrEmpty(process.StepName) ||
                string.IsNullOrEmpty(process.StepNumber) ||
                process.Fab.StartsWith(" ") ||
                process.ProductId.StartsWith(" ") ||
                process.Stage.StartsWith(" ") ||
                process.Recipe.StartsWith(" ") ||
                process.StepName.StartsWith(" ") ||
                process.StepNumber.StartsWith(" "))
            {
                errorMessage = "Empty value found!";
            }
            if (string.IsNullOrEmpty(errorMessage)) return true;
            else return false;
        }

    }

}
