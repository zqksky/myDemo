﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;
using AMAT.R2R.Shared.Base.DTO;
using Newtonsoft.Json;

namespace AMAT.R2R.Shared.Etch.DTO
{
    /// <summary>
    /// The inputsettings of the context
    /// </summary>
    public class ContextInputPara : BaseDto
    {
        public ContextInputPara()
        {
            this.FBNegDelta = -1;
            this.FBPostDelta = 1;
            this.ModelSlope = new Matrix<double>(1, 10, 0);
            this.LinearConstraint1Coff = 0;
            this.LinearConstraint2Coff = 0;
            this.Slot1Compensation = 0;
            this.QsStatesEst = 1;
            this.RsStatesEst = 0.13;
            this.SlaveInputs = new List<SlaveInput>();
        }
        public string ContextKey { get; set; }
        public Parameter Parameter { get; set; }
        public int InputIndex { get; set; }

        [JsonIgnore]
        public string ParameterName { get { return this.Parameter.ParameterName; } }
        public decimal DefaultRecommandValue { get; set; }
        public decimal UpperLimit { get; set; }
        public decimal LowerLimit { get; set; }
        public decimal Deadband { get; set; }
        public string Unit { get; set; }

        public int Precision { get; set; }
        public double UsedConversion { get; set; }
        public double RecVsUsedLimit { get; set; }
        public List<SlaveInput> SlaveInputs { get; set; }
        public int ContextId { get; set; }

        //
        public double FBNegDelta { get; set; }
        public double FBPostDelta { get; set; }

        /*
        public double FFNegDelta { get; set; }

        public double FFPostDelta { get; set; }
        */
        public Matrix<double> ModelSlope { get; set; }

        public double LinearConstraint1Coff { get; set; }
        public double LinearConstraint2Coff { get; set; }
        public double Slot1Compensation { get; set; }
        public double Slot2Compensation { get; set; }
        public double QsStatesEst { get; set; }
        public double RsStatesEst { get; set; }

        public override CompareResult Compare(Object oldContextInputPara)
        {
            return base.Compare(oldContextInputPara);
        }

        public override bool Validate(out string errorMessage)
        {
            errorMessage = "";
            if (Parameter == null || string.IsNullOrEmpty(Parameter.ParameterName))
            {
                errorMessage = "None Valid ParameterName\r\n";
            }

            //if(DefaultRecommandValue==null || UpperLimit==null || LowerLimit==null || Deadband == null)
            //{
            //    errorMessage = errorMessage+ "Default Value or Limit or Deadband Couldn't be Null\r\n";
            //}

            if (Precision <= 0 || QsStatesEst <= 0 || RsStatesEst <= 0)
            {
                errorMessage = errorMessage + "StatesEst Q/R , Precision couldn't be zero\r\n";
            }

            if (RecVsUsedLimit < 0)
            {
                errorMessage = errorMessage + "RecVsUsedLimit couldn't less than zero\r\n";
            }

            if (ModelSlope == null || ModelSlope.IsZero())
            {
                errorMessage = errorMessage + "ModelSlope couldn't be zero\r\n";
            }

            if (InputIndex <= 0)
            {
                errorMessage = errorMessage + "InputIndex should great than zero\r\n";
            }

            if (string.IsNullOrEmpty(Unit))
            {
                errorMessage = errorMessage + "Unit can't be Empty\r\n";
            }

            if (string.IsNullOrEmpty(errorMessage)) return true;
            else return false;
        }
    }

    public class SlaveInput
    {
        public string ParameterName { get; set; }

        public double Coefficient { get; set; }

        public double Offset { get; set; }
    }
}
