﻿using System;
using System.Collections.Generic;

using System.Linq;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;
using AMAT.R2R.Shared.Base.DTO;
using Newtonsoft.Json;

namespace AMAT.R2R.Shared.Etch.DTO
{
    public class MaterializedView : BaseDto
    {
        public MaterializedView()
        {
            this.MaterializeViewParameters = new List<MaterializeViewParameter>();
            this.States = new List<double?>(new Matrix<double?>(1, 20, null).RowArray(0));

            MaterializeViewParameters = new List<MaterializeViewParameter>();

        }

        public DateTime LastModifiedTime { get; set; }

        public string LastModifiedBy { get; set; }
        public int ProcessId { get; set; }

        public string ProcessKey { get; set; }

        public int ContextId { get; set; }
        public string ContextKey { get; set; }
        public string Fab { get; set; }

        public string ProductId { get; set; }

        public string Recipe { get; set; }

        public string StepName { get; set; }

        public string StepNumber { get; set; }

        public string Stage { get; set; }

        public string Tool { get; set; }

        public string Chamber { get; set; }

        public string ContextGroup { get; set; }

        public List<double?> States { get; set; }

        public ControlFlag ControlFlag { get; set; }

        public ControlLevel ControlLevel { get; set; }

        public ControlType ControlType { get; set; }

        public ThreadStatus ThreadStatus { get; set; }

        public DateTime? LastEstiTime { get; set; }

        public DateTime? LastResetTime { get; set; }

        public int EstiExpiredDay { get; set; }

        public string BookedPiLotId { get; set; }

        public decimal? PreMetroLineAvg { get; set; }
        public DateTime? PreMetroLineLastUpdateTime { get; set; }
        public decimal? PreMetroLineFFDisb { get; set; }

        public string LotListSinceLastValidMetro { get; set; }

        public string LotlistConsecutiveGof { get; set; }

        public string LotlistConsecutiveOos { get; set; }

        public double CounterConsecutiveMaxAdjust { get; set; }

        public string LastStageLot { get; set; }

        public string LastStageTime { get; set; }

        public bool IsValid { get; set; }

        public string Remark { get; set; }

        [JsonIgnore]
        public List<double?> OnTargetEstimate { get { return this.MaterializeViewParameters.Select(t => t.OnTargetEstimate).ToList(); } }

        public List<MaterializeViewParameter> MaterializeViewParameters { get; set; }


        public override bool Validate(out string errorMessage)
        {
            errorMessage = "";
            return true;
        }
    }

    public class MaterializeViewParameter : BaseDto
    {
        public string InputParameter { get; set; }

        public double InputFixedValue { get; set; }

        public double? OnTargetEstimate { get; set; }

        public double ChamberOffset { get; set; }

        public string Unit { get; set; }

        public double UpperLimt { get; set; }

        public double LowerLimit { get; set; }

        public double Deadband { get; set; }

        public override bool Validate(out string errorMessage)
        {
            errorMessage = "";
            if (string.IsNullOrEmpty(errorMessage)) return true;
            return false;
        }
    }
}
