﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime;
using System.Threading.Tasks;
using AMAT.R2R.Shared.Base.DTO;
using Newtonsoft.Json;

namespace AMAT.R2R.Shared.Etch.DTO
{
    public enum ControlLevel { LotLevel, WaferLevel }
    public enum ControlFlag { Active, Fixed, Constrainted }
    public enum ControlType { FFFB, FB }

    // public enum ThreadStatus { Normal, PiRun, WaitPiRunLotMeasurement, PiRunLotFail, UnKnown }
    public enum ThreadStatus { None, Normal, PiRun, WaitPiRunLotMeasurement }
    public enum HydraFlag { On, Off }
    public enum MappingType { PreMeas, PostMeas }

    public class Context : BaseDto
    {
        public Context()
        {
            ContextConstants = new ContextConstants();
            ContextInput = new ContextInput();
        }

        public Process Process { get; set; }

        public string Fab { get; set; }

        public string ProductId { get; set; }

        public string Stage { get; set; }

        public string Recipe { get; set; }

        public string StepName { get; set; }

        public string StepNumber { get; set; }

        public string Tool { get; set; }

        public string Chamber { get; set; }

        public string ContextGroup { get; set; }

        [JsonIgnore]
        public bool IsConstantDefined
        {
            get { return ContextConstants.ContextId != 0; }
        }

        [JsonIgnore]
        public bool IsInputDefined
        {
            get { return ContextInputParas.Count != 0; }
        }

        [JsonIgnore]
        public string ProcessKey
        {
            get { return Process == null ? "" : Process.ProcessKey; }
        }

        public int OutputNum4Slope() 
        {
            if(this.Process == null || this.Process.OutputSettings == null || this.Process.OutputSettings.Count==0) return 0;

            int i = this.Process.OutputSettings.Count(t => t.ZonalFlag);

            if (i == 0) return this.Process.OutputSettings.Count;

            if(i==1 && this.Process.OutputSettings.Count == 1)
            {
                int slopes = 0;
                bool nBreak = false ;
                if (!string.IsNullOrEmpty(this.Process.OutputSettings[0].ZonalDefinition001_Output) && !nBreak) slopes++; else nBreak = true;
                if (!string.IsNullOrEmpty(this.Process.OutputSettings[0].ZonalDefinition002_Output) && !nBreak) slopes++; else nBreak = true;
                if (!string.IsNullOrEmpty(this.Process.OutputSettings[0].ZonalDefinition003_Output) && !nBreak) slopes++; else nBreak = true;
                if (!string.IsNullOrEmpty(this.Process.OutputSettings[0].ZonalDefinition004_Output) && !nBreak) slopes++; else nBreak = true;
                if (!string.IsNullOrEmpty(this.Process.OutputSettings[0].ZonalDefinition005_Output) && !nBreak) slopes++; else nBreak = true;
                if (!string.IsNullOrEmpty(this.Process.OutputSettings[0].ZonalDefinition006_Output) && !nBreak) slopes++; else nBreak = true;
                if (!string.IsNullOrEmpty(this.Process.OutputSettings[0].ZonalDefinition007_Output) && !nBreak) slopes++; else nBreak = true;
                if (!string.IsNullOrEmpty(this.Process.OutputSettings[0].ZonalDefinition008_Output) && !nBreak) slopes++; else nBreak = true;
                if (!string.IsNullOrEmpty(this.Process.OutputSettings[0].ZonalDefinition009_Output) && !nBreak) slopes++; else nBreak = true;
                if (!string.IsNullOrEmpty(this.Process.OutputSettings[0].ZonalDefinition010_Output) && !nBreak) slopes++; else nBreak = true;
                return slopes;
            }

            return 0; 
        }

        [JsonIgnore]
        public string ContextKey
        {
            get { return string.Format("{0}:{1}:{2}:{3}:{4}:{5}:{6}:{7}:{8}", Fab, ProductId, Stage, Recipe, StepName, StepNumber, Tool, Chamber, ContextGroup); }
        }


        [JsonIgnore]
        public bool OptContextGroupEnabled { get { return Process == null ? false : Process.OptContextGroupEnabled; } }

        public ControlFlag ControlFlag { get; set; }

        public ControlLevel ControlLevel { get; set; }

        public ControlType ControlType { get; set; }

        [JsonIgnore]
        public double EstiExpiredDay
        {
            get
            {
                return ContextConstants.OptMaxTimeLastEstDays;
            }
        }



        public ContextInput ContextInput
        {
            get; set;
        }


        [JsonIgnore]
        public List<ContextInputPara> ContextInputParas { get { return ContextInput.ContextInputParas; } }


        public ContextConstants ContextConstants { get; set; }


        [JsonIgnore]
        public ContextMisc ContextMisc { get { return ContextInput.ContextMisc; } }


        [JsonIgnore]
        public int InputSize { get { return ContextInputParas == null ? 0 : ContextInputParas.Count(); } }


        [JsonIgnore]
        public int OutputSize { get { return Process == null || Process.OutputSettings == null ? 0 : Process.OutputSettings.Count(); } }


        public int TotalPostStepNumber { get; set; }


        public int TotalPreStepNumber { get; set; }


        [JsonIgnore]
        public double ControllerQ { get { return ContextInput.ContextMisc.ControllerQ; } }


        [JsonIgnore]
        public double ControllerR { get { return ContextInput.ContextMisc.ControllerR; } }


        [JsonIgnore]
        public double[] QsStatesEst { get { return new Matrix<double>(10, ContextInputParas.Select(t => t.QsStatesEst).ToList(), 0).ColumnArray(0); } }


        [JsonIgnore]
        public double[] RsStatesEst { get { return new Matrix<double>(10, ContextInputParas.Select(t => t.RsStatesEst).ToList(), 0).ColumnArray(0); } }


        [JsonIgnore]
        public double[] ModelSlope01 { get { return ContextInputParas.Count() > 0 ? ContextInputParas[0].ModelSlope.RowArray(0) : new Matrix<double>(1, 10, 0).RowArray(0); } }


        [JsonIgnore]
        public double[] ModelSlope02 { get { return ContextInputParas.Count() > 1 ? ContextInputParas[1].ModelSlope.RowArray(0) : new Matrix<double>(1, 10, 0).RowArray(0); } }


        [JsonIgnore]
        public double[] ModelSlope03 { get { return ContextInputParas.Count() > 2 ? ContextInputParas[2].ModelSlope.RowArray(0) : new Matrix<double>(1, 10, 0).RowArray(0); } }

        [JsonIgnore]
        public double[] ModelSlope04 { get { return ContextInputParas.Count() > 3 ? ContextInputParas[3].ModelSlope.RowArray(0) : new Matrix<double>(1, 10, 0).RowArray(0); } }


        [JsonIgnore]
        public double[] ModelSlope05 { get { return ContextInputParas.Count() > 4 ? ContextInputParas[4].ModelSlope.RowArray(0) : new Matrix<double>(1, 10, 0).RowArray(0); } }


        [JsonIgnore]
        public double[] ModelSlope06 { get { return ContextInputParas.Count() > 5 ? ContextInputParas[5].ModelSlope.RowArray(0) : new Matrix<double>(1, 10, 0).RowArray(0); } }

        [JsonIgnore]
        public double[] ModelSlope07 { get { return ContextInputParas.Count() > 6 ? ContextInputParas[6].ModelSlope.RowArray(0) : new Matrix<double>(1, 10, 0).RowArray(0); } }

        [JsonIgnore]
        public double[] ModelSlope08 { get { return ContextInputParas.Count() > 7 ? ContextInputParas[7].ModelSlope.RowArray(0) : new Matrix<double>(1, 10, 0).RowArray(0); } }

        [JsonIgnore]
        public double[] ModelSlope09 { get { return ContextInputParas.Count() > 8 ? ContextInputParas[8].ModelSlope.RowArray(0) : new Matrix<double>(1, 10, 0).RowArray(0); } }

        [JsonIgnore]
        public double[] ModelSlope10 { get { return ContextInputParas.Count() > 9 ? ContextInputParas[9].ModelSlope.RowArray(0) : new Matrix<double>(1, 10, 0).RowArray(0); } }

        [JsonIgnore]
        public double[] FBNegDelta { get { return new Matrix<double>(10, ContextInputParas.Select(t => t.FBNegDelta).ToList(), 0).ColumnArray(0); } }

        [JsonIgnore]
        public double[] FBPostDelta { get { return new Matrix<double>(10, ContextInputParas.Select(t => t.FBPostDelta).ToList(), 0).ColumnArray(0); } }

        [JsonIgnore]
        public double[] FFCoefficient { get { return ContextMisc.FFCoefficient; } }

        /*
        public Matrix<decimal> FFNegDelta { get; set; }

        public Matrix<decimal> FFPostDelta { get; set; }
        */

        [JsonIgnore]
        public double[] Slot1Compensation { get { return new Matrix<double>(10, ContextInputParas.Select(t => t.Slot1Compensation).ToList(), 0).ColumnArray(0); } }

        [JsonIgnore]
        public double[] Slot2Compensation { get { return new Matrix<double>(10, ContextInputParas.Select(t => t.Slot2Compensation).ToList(), 0).ColumnArray(0); } }

        [JsonIgnore]
        public double[] LinearConstraint1Coff { get { return new Matrix<double>(10, ContextInputParas.Select(t => t.LinearConstraint1Coff).ToList(), 0).ColumnArray(0); } }

        [JsonIgnore]
        public double[] LinearConstraint2Coff { get { return new Matrix<double>(10, ContextInputParas.Select(t => t.LinearConstraint2Coff).ToList(), 0).ColumnArray(0); } }

        [JsonIgnore]
        public double Linear1Min { get { return ContextInput.ContextMisc.Linear1Min; } }

        [JsonIgnore]
        public double Linear2Min { get { return ContextInput.ContextMisc.Linear2Min; } }

        [JsonIgnore]
        public double Linear1Max { get { return ContextInput.ContextMisc.Linear1Max; } }

        [JsonIgnore]
        public double Linear2Max { get { return ContextInput.ContextMisc.Linear2Max; } }

        public int ProcessId { get; set; }

        public int ContextId { get; set; }

        public DateTime LastModifiedTime { get; set; }

        public string LastModifiedBy { get; set; }


        public List<SpecialJobParameter> GetDefaultSpecialJobParameters() => ContextInputParas?.Select(cip => new SpecialJobParameter
        {
            JobId = "NA",
            ParameterName = cip.ParameterName,
            InputValue = cip.DefaultRecommandValue,
            Max = cip.UpperLimit,
            Min = cip.LowerLimit,
            Unit = cip.Unit,
        }).ToList();

        public override bool Validate(out string errorMessage)
        {
            errorMessage = "";
            Context context = (Context)this;
            if (string.IsNullOrEmpty(context.Fab) ||
                string.IsNullOrEmpty(context.ProductId) ||
                string.IsNullOrEmpty(context.Stage) ||
                string.IsNullOrEmpty(context.Recipe) ||
                string.IsNullOrEmpty(context.StepName) ||
                string.IsNullOrEmpty(context.StepNumber) ||
                string.IsNullOrEmpty(context.Tool) ||
                string.IsNullOrEmpty(context.Chamber) ||
                string.IsNullOrEmpty(context.ContextGroup) ||
                context.Fab.StartsWith(" ") ||
                context.ProductId.StartsWith(" ") ||
                context.Stage.StartsWith(" ") ||
                context.Recipe.StartsWith(" ") ||
                context.StepName.StartsWith(" ") ||
                context.StepNumber.StartsWith(" ") ||
                context.Tool.StartsWith(" ") ||
                context.Chamber.StartsWith(" ") ||
                context.ContextGroup.StartsWith(" "))
            {
                errorMessage = "Empty value found!";
                return false;
            }

            if (Process != null && !Process.OptContextGroupEnabled && !"NA".Equals(ContextGroup))
            {
                errorMessage = "the ContextGroup is not correct";
                return false;
            }

            /*
            if(this.ContextInput!=null && this.ContextInput.ContextInputParas!=null && this.ContextInputParas.Count() > 0)
            {
                if (!this.ContextInput.Validate(out errorMessage)) return false;
            }

            if (this.ContextConstants != null )
            {
                if (!this.ContextConstants.Validate(out errorMessage)) return false;
            }
            */
            if (string.IsNullOrEmpty(errorMessage)) return true;
            return false;
        }
    }
}
