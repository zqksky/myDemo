﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AMAT.R2R.Shared.Base.DTO;

namespace AMAT.R2R.Shared.Etch.DTO
{
    public class LotRunHistory : BaseDto
    {
        public string Id { get; set; }

        public string TxId { get; set; }

        public string ModelingTick { get; set; }

        public string ParentId { get; set; }

        public string LotId { get; set; }

        //csv string
        public string WaferId { get; set; }

        public string Tool { get; set; }

        public string Chamber { get; set; }

        public string ProductId { get; set; }

        public string Recipe { get; set; }

        public string Stage { get; set; }

        public string StepName { get; set; }

        public string StepNumber { get; set; }

        public string ContextGroup { get; set; }

        public string ControlFlag { get; set; }

        public string ControlLevel { get; set; }

        public string ControlType { get; set; }

        public int WaferQty { get; set; }

        public List<LotHistoryParameter> DefaultRecSettings { get; set; }
        public List<LotHistoryParameter> RecSettings { get; set; }

        public List<LotHistoryParameter> FinalRecSettings { get; set; }

        public List<LotHistoryParameter> ChamberOffsets { get; set; }

        public DateTime? ProcessStamp { get; set; }
        public List<LotHistoryParameter> ProcessVaues  { get;set;}

        public DateTime? PreTimeStamp { get; set; }
        public List<LotHistoryParameter> PreMetrologyValues { get; set; }

        public DateTime? PostTimeStamp { get; set; }
        public List<LotHistoryParameter> PostMetrologyValues { get; set; }

        public DateTime? EstiTimeStamp { get; set; }
        public List<LotHistoryParameter> EstimateValues { get; set; }

        public string MotherLot { get; set; }

        public string ReworkCnt { get; set; }

        public string SpecifyLot { get; set; }

        public string PilotFlag { get; set; }

        public string RunCardId { get; set; }

        public string SplitId { get; set; }

        public string Feedback { get; set; }

        public string Remark { get; set; }
        public override bool Validate(out string errorMessage)
        {
            errorMessage = "";

            return true;
        }

        public List<LotRunHistory> waferHist { get; set; }

    }

    public class LotHistoryParameter
    {
        private string val;
        public string Name { get; set; }
        public string Value {
            get
            {
                if (string.IsNullOrEmpty(val)) return string.Empty;
                if (!IsNumeric) return val;
                //Decimal dData = 0.0M;
                
                if(Decimal.TryParse(val.ToString(), System.Globalization.NumberStyles.Any, null ,out decimal dData))
                {
                    return Math.Round(dData, 8).ToString();
                }
                else
                {
                    return "NaN";
                }
            }
            set { val = value; }
        } 

        //number or string
        public bool IsNumeric { get; set; }

    }

}
