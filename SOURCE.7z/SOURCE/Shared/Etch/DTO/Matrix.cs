﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;

namespace AMAT.R2R.Shared.Etch.DTO
{
    public class Matrix<T>
    {
        public string Name { get; set; }

        public int Row { get; set; }

        public int Column { get; set; }

        public Matrix()
        {

        }
        public Matrix(int row, List<T> initValues, T defaultValue)
        {
            Row = row;
            Column = 1;
            cells = new T[row][];
            for (int i = 0; i < row; i++)
            {
                cells[i] = new T[1];
            }
            int len = initValues == null ? 0 : initValues.Count();
            for (int i = 0; i < row; i++)
            {
                cells[i][0] = i < len ? initValues[i] : defaultValue;
            }
        }

        public Matrix(int row, string strCSV, T defaultValue)
        {
            Row = row;
            Column = 1;
            cells = new T[row][];
            for (int i = 0; i < row; i++)
            {
                cells[i] = new T[1];
            }
            string[] initValues = strCSV.Split(',');
            int len = initValues == null ? 0 : initValues.Count();
            for (int i = 0; i < row; i++)
            {
                double d = double.Parse(initValues.Length > i ? initValues[i] : "0");
                cells[i][0] = i < len ? (T)Convert.ChangeType(d, typeof(T)) : defaultValue;
            }
        }

        public Matrix(int row, int column, T defaultValue)
        {
            Row = row;
            Column = column;
            cells = new T[row][];
            for (int i = 0; i < row; i++)
            {
                cells[i] = new T[column];
            }
            for (int i = 0; i < row; i++)
            {
                for (int j = 0; j < column; j++)
                {
                    cells[i][j] = defaultValue;
                }
            }
        }

        public Matrix(T[,] value)
        {
            Row = value.GetLength(0);
            Column = value.GetLength(1);
            cells = new T[Row][];
            for (int i = 0; i < Row; i++)
            {
                cells[i] = new T[Column];
            }

            for (int i = 0; i < Row; i++)
            {
                for (int j = 0; j < Column; j++)
                {
                    cells[i][j] = value[i, j];
                }
            }
        }


        public T[][] Cells
        {
            get { return this.cells; }
            set
            {
                this.cells = value;
                if (this.cells == null) { this.Row = 0; this.Column = 0; }
                else
                {
                    this.Row = this.cells.Length;
                    this.Column = this.cells[0].Length;
                }
            }
        }


        private T[][] cells;

        public T this[int row, int column]
        {
            get { return cells[row][column]; }
            set { cells[row][column] = value; }
        }

        public string RowCSV(int row)
        {
            if (row >= Row || row < 0) return "";

            return string.Join(",", cells[row].ToArray());
        }

        public string ColumnCSV(int column)
        {
            if (column >= Column || column < 0) return "";

            List<T> res = new List<T>();
            for (int i = 0; i < Row; i++)
            {
                res.Add(cells[i][column]);
            }
            return string.Join(",", res.ToArray());
        }

        public T[] RowArray(int row)
        {
            if (row >= Row || row < 0) return new T[Column];
            return cells[row];
            /*
            List<T> res = new List<T>();
            for (int j = 0; j < Column; j++)
            {
                res.Add(cells[row][j]);
            }
            return res.ToArray();*/
        }

        public T[] ColumnArray(int column)
        {
            if (column >= Column || column < 0) return new T[Row];
            List<T> res = new List<T>();
            for (int i = 0; i < Row; i++)
            {
                res.Add(cells[i][column]);
            }
            return res.ToArray();
        }

        public bool IsZero()
        {
            bool notZero = true;
            for (int i = 0; i < Row; i++)
            {
                notZero = cells[i].Any(t => !"0".Equals(t.ToString()));
                if (notZero) break;
                /*
            for (int j = 0; j < Column; j++)
            {
                if (!"0".Equals(cells[i][i].ToString()))
                {
                    flag = false;
                    break;
                }
            }
            if (!flag) break;
            */
            }

            return !notZero;
        }

        public Matrix<T> Transform()
        {
            T[,] cellx = new T[this.Column, this.Row];
            for (int i = 0; i < Row; i++)
            {
                for (int j = 0; j < Column; j++)
                {
                    cellx[j, i] = cells[i][j];
                }
            }

            return new Matrix<T>(cellx);
        }




    }
}
