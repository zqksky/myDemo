﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AMAT.R2R.Shared.Base.DTO;

namespace AMAT.R2R.Shared.Etch.DTO
{
    public class PreMetrology : BaseDto
    {
        public string ProcessKey { get; set; }

        public string MetrologyKey { get { return string.Format("{0}:{1}:{2}:{3}:{4}", Fab, MetroStage, MetroRecipe, MetroStepName, MetroStepNumber); } }

        public string Fab { get; set; }

        public string MetroStepName { get; set; }

        public string MetroStepNumber { get; set; }

        public string MetroRecipe { get; set; }

        public string MetroStage { get; set; }

        public int ProcessId { get; set; }

        public override CompareResult Compare(Object oldPreMetrology)
        {
            return base.Compare(oldPreMetrology);
        }

        public override bool Validate(out string errorMessage)
        {
            errorMessage = "";
            if (string.IsNullOrEmpty(Fab) ||
                string.IsNullOrEmpty(MetroStepName) ||
                string.IsNullOrEmpty(MetroStepNumber) ||
                string.IsNullOrEmpty(MetroRecipe) ||
                string.IsNullOrEmpty(MetroStage) ||
                ProcessId <= 0 ||
                string.IsNullOrEmpty(ProcessKey))
            {
                errorMessage = "Empty value found";
            }
            if (string.IsNullOrEmpty(errorMessage)) return true;
            return false;
        }
    }
}
