﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AMAT.R2R.Shared.Base.DTO;

namespace AMAT.R2R.Shared.Etch.DTO
{
    public class FeedforwardSetting : BaseDto
    {
        public string ProcessKey { get; set; }

        public int OutputIndex { get; set; }

        public Parameter Parameter { get; set; }

        public decimal Target { get; set; }

        public decimal UpperLimit { get; set; }

        public decimal LowerLimit { get; set; }

        public string Unit { get; set; }

        public decimal QualityThreshold { get; set; }

        public string QualityItemName { get; set; }

        public List<PreMetrology> PreMetrologys { get; set; }

        public bool OptUseOOLPreMetro { get; set; }

        public bool OptUseOOLRange { get; set; }

        public bool OptUseOOLStdDev { get; set; }

        public decimal OptStdDevThreshold { get; set; }

        public decimal OptRangeThreshold { get; set; }

        public int OptNoOfSitePerWafer { get; set; }

        public decimal OptOffsetPerSlot { get; set; }

        public decimal OptMinPercentRemaining { get; set; }

        public bool OptLowerBetterFilt { get; set; }

        public decimal OptLambda { get; set; }

        public int ProcessId { get; set; }

        public int PreMetroId { get; set; }

        public override CompareResult Compare(object oldFeedforwardSetting)
        {
            CompareResult cr = base.Compare(oldFeedforwardSetting);
            FeedforwardSetting oldOs = (FeedforwardSetting)oldFeedforwardSetting;
            if (!PreMetrologys[0].MetrologyKey.Equals(oldOs.PreMetrologys[0].MetrologyKey))
            {
                cr.Add(new CompareResult() { IsChange = true, ChangeContent = "PostMetrology:" + oldOs.PreMetrologys[0].MetrologyKey + "->" + PreMetrologys[0].MetrologyKey });
            }
            return cr;

        }

        public override bool Validate(out string errorMessage)
        {
            errorMessage = "";
            if (PreMetrologys == null || PreMetrologys.Count != 1)
            {
                errorMessage = "None PostMetrology Found\r\n";
            }

            if (Parameter == null || string.IsNullOrEmpty(Parameter.ParameterName))
            {
                errorMessage += "None Valid Paramter Found\r\n";
            }


            //if (Target == null || UpperLimit == null || LowerLimit == null || QualityThreshold == null)
            //{
            //    errorMessage += "Limit,Taret,QualityThreshold cound not be Empty\r\n";
            //}

            if (Target < LowerLimit || Target > UpperLimit)
            {
                errorMessage += "Target / LowerLimit / UpperLimit Conflit \r\n";
            }

            if (ProcessId <= 0)
            {
                errorMessage += "InValid Id Found\r\n";
            }

            if (string.IsNullOrEmpty(QualityItemName) || QualityThreshold <= 0)
            {
                errorMessage += "InValid QualityItemName or QualityThreshold(should > 0)\r\n";
            }

            if (string.IsNullOrEmpty(Unit))
            {
                errorMessage += "Unit could not be Empty\r\n";
            }

            if (OptUseOOLRange && OptRangeThreshold < 0)
            {
                errorMessage += "OptRangeThreshold should greater than or equal 0\r\n";
            }

            if (OptUseOOLStdDev && OptStdDevThreshold < 0)
            {
                errorMessage += "OptStdDevThreshold should greater than or equal 0\r\n";
            }

            if (OptNoOfSitePerWafer <= 0)
            {
                errorMessage += "OptNoOfSitePerWafer should greater than 0\r\n";
            }
            if (OptMinPercentRemaining <= 0)
            {
                errorMessage += "OptMinPercentRemaining should greater than 0\r\n";
            }

            if (string.IsNullOrEmpty(errorMessage)) return true;
            else return false;

        }
    }
}
