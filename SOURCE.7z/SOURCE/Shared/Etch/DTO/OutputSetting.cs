﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AMAT.R2R.Shared.Base.DTO;

namespace AMAT.R2R.Shared.Etch.DTO
{
    public class OutputSetting : BaseDto
    {
        private List<PostMetrology> posts;
        public OutputSetting()
        {
            posts = new List<PostMetrology>();
        }
        public string ProcessKey { get; set; }

        public int OutputIndex { get; set; }

        public Parameter Parameter { get; set; }

        public decimal Target { get; set; }

        public decimal UpperLimit { get; set; }

        public decimal LowerLimit { get; set; }

        public string Unit { get; set; }

        public decimal QualityThreshold { get; set; }

        public string QualityItemName { get; set; }

        public List<PostMetrology> PostMetrologys
        {
            get { return posts; }
            set { posts = value ?? new List<PostMetrology>(); }
        }

        public bool OptUseOOLPostMetro { get; set; }

        public bool OptUseOOLRange { get; set; }

        public bool OptUseOOLStdDev { get; set; }

        public bool ZonalFlag { get; set; }

        public decimal OptStdDevThreshold { get; set; }

        public decimal OptRangeThreshold { get; set; }

        public int OptNoOfSitePerWafer { get; set; }

        public decimal OptMinPercentRemaining { get; set; }

        public bool OptLowerBetterFilt { get; set; }

        public string ZonalDefinition001_Output { get; set; }

        public string ZonalDefinition002_Output { get; set; }

        public string ZonalDefinition003_Output { get; set; }

        public string ZonalDefinition004_Output { get; set; }

        public string ZonalDefinition005_Output { get; set; }

        public string ZonalDefinition006_Output { get; set; }

        public string ZonalDefinition007_Output { get; set; }

        public string ZonalDefinition008_Output { get; set; }

        public string ZonalDefinition009_Output { get; set; }

        public string ZonalDefinition010_Output { get; set; }

        public int ProcessId { get; set; }

        public int PostMetroId { get; set; }

        public override CompareResult Compare(Object oldOutputSetting)
        {
            CompareResult cr = base.Compare(oldOutputSetting);
            OutputSetting oldOs = (OutputSetting)oldOutputSetting;
            if (!PostMetrologys[0].MetrologyKey.Equals(oldOs.PostMetrologys[0].MetrologyKey))
            {
                cr.Add(new CompareResult() { IsChange = true, ChangeContent = "PostMetrology:" + oldOs.PostMetrologys[0].MetrologyKey + "->" + PostMetrologys[0].MetrologyKey });
            }
            return cr;
        }



        public override bool Validate(out string errorMessage)
        {
            errorMessage = "";
            if (PostMetrologys == null || PostMetrologys.Count != 1)
            {
                errorMessage = "None PostMetrology Found\r\n";
            }

            if (Parameter == null || string.IsNullOrEmpty(Parameter.ParameterName))
            {
                errorMessage += "None Valid Paramter Found\r\n";
            }

            if (ZonalFlag &&
                string.IsNullOrEmpty(ZonalDefinition001_Output) &&
                string.IsNullOrEmpty(ZonalDefinition002_Output) &&
                string.IsNullOrEmpty(ZonalDefinition003_Output) &&
                string.IsNullOrEmpty(ZonalDefinition004_Output) &&
                string.IsNullOrEmpty(ZonalDefinition005_Output) &&
                string.IsNullOrEmpty(ZonalDefinition006_Output) &&
                string.IsNullOrEmpty(ZonalDefinition007_Output) &&
                string.IsNullOrEmpty(ZonalDefinition008_Output) &&
                string.IsNullOrEmpty(ZonalDefinition009_Output) &&
                string.IsNullOrEmpty(ZonalDefinition010_Output))
            {
                errorMessage += "None Zonal Definition found while ZonalFlag enabled\r\n";
            }

            //if (Target == null || UpperLimit == null || LowerLimit == null || QualityThreshold == null)
            //{
            //    errorMessage += "Limit,Taret,QualityThreshold cound be Empty\r\n";
            //}

            if (Target < LowerLimit || Target > UpperLimit)
            {
                errorMessage += "Target / LowerLimit / UpperLimit Conflit \r\n";
            }

            if (ProcessId <= 0)
            {
                errorMessage += "InValid Id Found\r\n";
            }

            if (string.IsNullOrEmpty(QualityItemName) || QualityThreshold <= 0)
            {
                errorMessage += "InValid QualityItemName or QualityThreshold(should > 0)\r\n";
            }

            if (string.IsNullOrEmpty(Unit))
            {
                errorMessage += "Unit could not be Empty\r\n";
            }

            if (OptUseOOLRange && OptRangeThreshold < 0)
            {
                errorMessage += "OptRangeThreshold should greater than or equal 0\r\n";
            }

            if (OptUseOOLStdDev && OptStdDevThreshold < 0)
            {
                errorMessage += "OptStdDevThreshold should greater than or equal 0\r\n";
            }

            if (OptNoOfSitePerWafer <= 0)
            {
                errorMessage += "OptNoOfSitePerWafer should greater than 0\r\n";
            }
            if (OptMinPercentRemaining <= 0)
            {
                errorMessage += "OptMinPercentRemaining should greater than  0\r\n";
            }

            if (string.IsNullOrEmpty(errorMessage)) return true;
            else return false;
        }
    }
}
