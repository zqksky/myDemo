﻿using System;
using System.Collections.Generic;

using System.Linq;
using System.Threading.Tasks;
using AMAT.R2R.Shared.Base.DTO;
using Newtonsoft.Json;

namespace AMAT.R2R.Shared.Etch.DTO
{
    public class RunHist : BaseDto
    {
        public RunHist()
        {

        }

        public string HznKey { get; set; }

        public DateTime? CalcTimesStamp { get; set; }

        public DateTime? UsedTimeStamp { get; set; }

        public DateTime? PostTimeStamp { get; set; }

        public string Tool { get; set; }

        public string ProductId { get; set; }

        public string Stage { get; set; }

        public string Recipe { get; set; }

        public string StepNumber { get; set; }

        public string StepName { get; set; }

        public string Fab { get; set; }

        public string ContextGroup { get; set; }

        public string Chamber { get; set; }

        public string R2RMode { get; set; }

        public int ContextId { get; set; }

        public string LotId { get; set; }

        public string WaferScribe { get; set; }

        public string WaferList { get; set; }

        public string PreMetrology { get; set; }

        public string FFDisb { get; set; }

        public string ChamberOffset { get; set; }

        public string DefaultRecSettings { get; set; }

        public string RecipeSettings { get; set; }

        public string FinalRecSettings { get; set; }

        public string PostMetrology { get; set; }

        public string NewRecSettingsFb { get; set; }

        public string States { get; set; }

        public string ModifiedBy { get; set; }

        public string Feedback { get; set; }

        public string Remark { get; set; }

        public string SpecifyLot { get; set; }

        public string PilotFlag { get; set; }

        public string RunCardId { get; set; }
        public override bool Validate(out string errorMessage)
        {
            errorMessage = "";
            return true;
        }
    }

}
