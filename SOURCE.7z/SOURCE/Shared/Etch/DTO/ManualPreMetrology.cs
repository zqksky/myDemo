﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AMAT.R2R.Shared.Base.DTO;

namespace AMAT.R2R.Shared.Etch.DTO
{
    public class ManualPreMetrology : BaseDto
    {
        public ManualPreMetrology()
        {
            ProcessPreMetrologys = new List<PreMetrology>();
            ManualPreMetrologyItems = new List<ManualPreMetrologyItem>();
        }

        public int ProcessId { get; set; }

        public List<PreMetrology> ProcessPreMetrologys { get; set; }

        public List<ManualPreMetrologyItem> ManualPreMetrologyItems;

        public override bool Validate(out string errorMessage)
        {
            errorMessage = "";
            return true;
        }
    }

    public class ManualPreMetrologyItem : BaseDto
    {
        public int ProcessId { get; set; }
        public string MetrologyKey { get; set; }
        public string uniqueId { get; set; }
        public string LotId { get; set; }
        public string WaferId { get; set; }

        public DateTime DcollTime { get; set; }

        public string Unit { get; set; }

        public string MeasureItem { get; set; }

        public double? MeasureValue { get; set; }

        public string QualityItem { get; set; }

        public double? QualityValue { get; set; }

        public override bool Validate(out string errorMessage)
        {
            errorMessage = "";
            if (string.IsNullOrEmpty(errorMessage)) return true;
            return false;
        }
    }
}
