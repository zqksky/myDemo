﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AMAT.R2R.Shared.Base.DTO;
using Newtonsoft.Json;

namespace AMAT.R2R.Shared.Etch.DTO
{
    /// <summary>
    /// The Constants of the context
    /// </summary>
    public class ContextInput : BaseDto
    {
        public ContextInput()
        {
            this.ContextInputParas = new List<ContextInputPara>();
            this.ContextMisc = new ContextMisc();
        }
        public string ContextKey { get; set; }

        public int ContextId { get; set; }

        public List<ContextInputPara> ContextInputParas { get; set; }

        public ContextMisc ContextMisc { get; set; }

        [JsonIgnore]
        public bool LinearConstraintEnabled
        {
            get
            {
                return ContextInputParas.Any(p => p.LinearConstraint1Coff != 0 || p.LinearConstraint2Coff != 0);
            }
        }

        public override CompareResult Compare(Object oldContextInput)
        {
            CompareResult cr = new CompareResult() { IsChange = false, ChangeContent = "" };
            ContextInput oldCi = (ContextInput)oldContextInput;
            for (int i = 0; i < this.ContextInputParas.Count(); i++)
            {
                ContextInputPara cii = oldCi.ContextInputParas.FirstOrDefault(t => t.ParameterName.Equals(this.ContextInputParas[i].ParameterName) && t.ContextId.Equals(this.ContextId));
                if (cii != null)
                {
                    cr.Add(this.ContextInputParas[i].Compare(cii));
                }
                else
                {
                    cr.Add(new CompareResult() { IsChange = true, ChangeContent = this.ContextInputParas[i].ParameterName + " Added" });
                }
            }
            for (int i = 0; i < oldCi.ContextInputParas.Count(); i++)
            {
                ContextInputPara cii = this.ContextInputParas.FirstOrDefault(t => t.ParameterName.Equals(oldCi.ContextInputParas[i].ParameterName) && t.ContextId.Equals(oldCi.ContextId));
                if (cii == null)
                {
                    cr.Add(new CompareResult() { IsChange = true, ChangeContent = oldCi.ContextInputParas[i].ParameterName + " Deleted" });
                }
            }

            //cr.Add(ContextMisc.Compare(oldCi.ContextMisc));

            return cr;
        }

        public override bool Validate(out string errorMessage)
        {
            errorMessage = "";
            if (ContextInputParas == null || ContextInputParas.Count() == 0)
            {
                errorMessage = "None Input found";
                return false;
            }

            for (int i = 0; i < this.ContextInputParas.Count(); i++)
            {
                if (!this.ContextInputParas[i].Validate(out errorMessage))
                {
                    break;
                }
            }
            if (!string.IsNullOrEmpty(errorMessage)) return false;

            if (!ContextMisc.Validate(out errorMessage)) return false;

            Matrix<double> LinearConstraint1Coff = new Matrix<double>(10, this.ContextInputParas.Select(t => t.LinearConstraint1Coff).ToList(), 0);
            Matrix<double> LinearConstraint2Coff = new Matrix<double>(10, this.ContextInputParas.Select(t => t.LinearConstraint2Coff).ToList(), 0);

            if (this.LinearConstraintEnabled && (LinearConstraint1Coff.IsZero() || LinearConstraint2Coff.IsZero()))
            {
                errorMessage = "LinearConstraint Enabled , and missing Coff";
                return false;
            }
            if (this.LinearConstraintEnabled && (ContextMisc.Linear1Max > ContextMisc.Linear1Max  || ContextMisc.Linear2Min > ContextMisc.Linear2Min ))
            {
                errorMessage = "LinearConstraint Enabled , and violation found for  Max/Min Limit";
                return false;
            }
            if (string.IsNullOrEmpty(errorMessage)) return true;
            return false;
        }
    }
}
