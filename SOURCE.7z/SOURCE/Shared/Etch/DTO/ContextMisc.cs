﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AMAT.R2R.Shared.Base.DTO;

namespace AMAT.R2R.Shared.Etch.DTO
{
    /// <summary>
    /// The Constants of the context
    /// </summary>
    public class ContextMisc : BaseDto
    {
        public ContextMisc()
        {
            Linear1Max = 99999;
            Linear2Max = 99999;
            Linear1Min = -99999;
            Linear2Min = -99999;

            ControllerQ = 1000000;
            ControllerR = 1;

            FFCoefficient = new Matrix<double>(1, 10, 0).RowArray(0);
        }
        public string ContextKey { get; set; }

        public int ContextId { get; set; }

        public double Linear1Min { get; set; }

        public double Linear1Max { get; set; }

        public double Linear2Min { get; set; }

        public double Linear2Max { get; set; }

        public double ControllerQ { get; set; }

        public double ControllerR { get; set; }

        public double[] FFCoefficient { get; set; }

        public override CompareResult Compare(Object oldContextMisc)
        {
            return base.Compare(oldContextMisc);
        }

        public override bool Validate(out string errorMessage)
        {
            errorMessage = "";
            if (ControllerQ <= 0 && ControllerR <= 0 && ControllerQ < ControllerR)
            {
                errorMessage = "Error of ControllerQ/R";
            }
            if (string.IsNullOrEmpty(errorMessage)) return true;
            return false;
        }
    }
}
