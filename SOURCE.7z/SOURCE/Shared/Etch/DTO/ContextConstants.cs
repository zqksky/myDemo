﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AMAT.R2R.Shared.Base.DTO;

namespace AMAT.R2R.Shared.Etch.DTO
{
    /// <summary>
    /// The Constants of the context
    /// </summary>
    public class ContextConstants : BaseDto
    {
        public ContextConstants()
        {

        }
        public string ContextKey { get; set; }

        public bool OptAllowMissingPreMetro { get; set; }

        public int OptLimitLotsWithoutMetro { get; set; }

        public int OptLimitNoConsecutiveMaxAdjust { get; set; }

        public bool OptLotHoldMissingPreMet { get; set; }

        public bool OptLotHoldPredicitonOOL { get; set; }

        public bool OptLotHoldRecommendedOOL { get; set; }

        public double OptLotStageWaferUseCalcualteOffset { get; set; }

        public bool OptLotStageWaferUseCalcualtePre { get; set; }

        public double OptMaxTimeLastEstDays { get; set; }

        public double OptPreLineAvgExpiredDay { get; set; }

        public bool OptUseTarget { get; set; }

        public bool OptHydraFlag { get; set; }

        public bool OptHydraAllowMissingData { get; set; }

        public double OptHydraAllowMissingDataNumber { get; set; }

        public bool OptHydraManualDataEntry { get; set; }

        public bool OptHydraUseWaferMean { get; set; }

        public bool OptHydraUseZoneMean { get; set; }

        public int ContextId { get; set; }

        public double OptPreMetrologyExpiredDay { get; set; }
        public int OptLimitMaxConsecutiveOos { get; set; }
        public int OptLimitMaxConsecutiveGof { get; set; }

        public override CompareResult Compare(Object oldContextConstants)
        {
            return base.Compare(oldContextConstants);
        }

        public override bool Validate(out string errorMessage)
        {
            errorMessage = "";
            if (OptMaxTimeLastEstDays <= 0)
            {
                errorMessage = "LastEstDays should be greater than 0\r\n";
            }
            if (OptLimitLotsWithoutMetro < 0)
            {
                errorMessage = "LimitLotsWithoutMetro should be greater or equal  0\r\n";
            }
            if (OptLimitNoConsecutiveMaxAdjust <= 0)
            {
                errorMessage = "LimitNoConsecutiveMaxAdjust should be greater or equal 0\r\n";
            }

            if (string.IsNullOrEmpty(errorMessage)) return true;
            return false;

        }
    }
}
