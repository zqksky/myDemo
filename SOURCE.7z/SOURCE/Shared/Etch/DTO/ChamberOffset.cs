﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AMAT.R2R.Shared.Base.DTO;

namespace AMAT.R2R.Shared.Etch.DTO
{
    public class ChamberOffset : BaseDto
    {
        public ChamberOffset()
        {
            this.ChamberOffsetItems = new List<ChamberOffsetItem>();
        }
        public string Tool { get; set; }

        public string Chamber { get; set; }

        public List<ChamberOffsetItem> ChamberOffsetItems { get; set; }

        public override bool Validate(out string errorMessage)
        {
            errorMessage = "";
            return true;
        }

    }

    public class ChamberOffsetItem : BaseDto
    {
        public string Tool { get; set; }

        public string Chamber { get; set; }

        public string ParameterName { get; set; }

        public decimal ParameterValue { get; set; }

        public DateTime LastModifiedTime { get; set; }

        public string LastModifiedBy { get; set; }

        public override bool Validate(out string errorMessage)
        {
            errorMessage = "";
            return true;
        }
    }
}
