﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AMAT.R2R.Shared.Base.Constants
{
    public class QueryWords
    {
        public const string Sort = "sort";
        public const string Skip = "skip";
        public const string Take = "take";
        public const string OrderAscending = "asc";
        public const string OrderDescending = "desc";
        public const string OperatorSeperator = ".";
        public const string OrderSeperator = ":";
        public const string ValueSeperator = ",";
        public const string ItemsCountEndpoint = "~count~";
        public const string ValueListEndpoint = "~valueList~";

    }
}
