﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AMAT.R2R.Shared.Base.Constants
{
    public class QueryOperators
    {
        public const string EqualsTo = "eq";
        public const string NotEqualsTo = "ne";
        public const string GreaterThanOrEqualsTo = "ge";
        public const string LessThanOrEqualsTo = "le";
        public const string GreaterThan = "gt";
        public const string LessThan = "lt";
        public const string In = "in";
        public const string NotIn = "ni";
        public const string StartsWith = "sw";
        public const string EndsWith = "ew";
        public const string Contains = "ct";
    }
}
