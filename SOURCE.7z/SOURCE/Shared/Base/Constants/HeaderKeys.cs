﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AMAT.R2R.Shared.Base.Constants
{
    public class HeaderKeys
    {
        public const string TxnId = "txnId";
        public const string SessionId = "sessionId";
        public const string UserName = "userName";
        public const string Fab = "fab";
        public const string Area = "area";
        public const string Comment = "comment";
        public const string ClientMachineName = "ClientMachineName";
        public const string ClientIp = "ClientIp";
        public const string ClientProcessId = "ClientProcessId";
        public const string ClientVersion = "ClientVersion";
        public const string Authorization = "Authorization";
    }
}
