﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace AMAT.R2R.Shared.Base.DTO
{
    public class LoginInfo
    {
        public LoginInfo()
        {
            AuthorityList = new List<string>();
        }

        public string SessionId { get; set; }

        public string UserName { get; set; }

        public string LoginDomain { get; set; }

        [JsonIgnore]
        public string FullUserName { get { return $"{LoginDomain}\\{UserName}"; } }

        public string LoginFab { get; set; }

        public string LoginArea { get; set; }

        public string ClientVersion { get; set; }

        public DateTime LoginTime { get; set; }

        public int ProcessId { get; set; }
        public string Password { get; set; }
        public string Token { get; set; }

        public string DBInfo { get; set; }
        public string ServerVersion { get; set; }

        public List<string> AuthorityList { get; set; }
    }
}
