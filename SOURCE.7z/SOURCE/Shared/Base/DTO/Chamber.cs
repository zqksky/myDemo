﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AMAT.R2R.Shared.Base.DTO
{
    public class Chamber
    {
        public string ToolId { get; set; }

        public string ChamberId { get; set; }

        //the prorcessType
        public string ProcessType { get; set; }

        public string UnitType { get; set; }
    }
}
