﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AMAT.R2R.Shared.Base.DTO
{
    public class Parameter
    {
        public string ParameterName { get; set; }

        public string ParameterType { get; set; }

        public int Precision { get; set; }

        public string AliasName { get; set; }

        public Tool Tool { get; set; }

        public Chamber Chamber { get; set; }
    }
}
