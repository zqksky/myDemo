﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AMAT.R2R.Shared.Base.DTO
{
    public class Product
    {
        public Product() { }

        public Product(string productId, string productType)
        {
            ProductId = productId;
            ProductType = productType;
        }

        public string ProductId { get; set; }

        public string ProductType { get; set; }
    }
}
