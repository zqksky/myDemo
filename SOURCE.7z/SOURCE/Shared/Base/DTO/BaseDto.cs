﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AMAT.R2R.Shared.Base.DTO
{
    public abstract class BaseDto
    {
        public virtual CompareResult Compare(Object oldObj)
        {
            CompareResult result = new CompareResult() { IsChange = false, ChangeContent = "" };
            System.Text.StringBuilder content = new System.Text.StringBuilder();
            System.Reflection.PropertyInfo[] beforeMembers = oldObj.GetType().GetProperties();
            System.Reflection.PropertyInfo[] afterMembers = this.GetType().GetProperties();
            for (int i = 0; i < beforeMembers.Length; i++)
            {
                if (beforeMembers[i].PropertyType.FullName.Equals("System.DateTime")) continue;

                if (!
                    (beforeMembers[i].PropertyType.FullName.StartsWith("System.String") ||
                    beforeMembers[i].PropertyType.FullName.StartsWith("System.Int32") ||
                    beforeMembers[i].PropertyType.FullName.StartsWith("System.Int64") ||
                    beforeMembers[i].PropertyType.FullName.StartsWith("System.Int16") ||
                    beforeMembers[i].PropertyType.FullName.StartsWith("System.Double") ||
                    beforeMembers[i].PropertyType.FullName.StartsWith("System.Decimal") ||
                    beforeMembers[i].PropertyType.BaseType.FullName.Equals("System.Enum") ||
                    beforeMembers[i].PropertyType.FullName.Equals("System.Boolean") ||
                    beforeMembers[i].PropertyType.FullName.Contains("[[System.Decimal") ||
                    beforeMembers[i].PropertyType.FullName.Contains("[[System.Double")
                    )) continue;


                if (beforeMembers[i].CanWrite)
                {
                    var beforeVal = TryGetValue(beforeMembers[i], oldObj);
                    var afterVal = TryGetValue(afterMembers[i], this);
                    //var afterVal = afterMembers[i].GetValue(newObj, null);
                    var beforeValue = beforeVal == null ? null : beforeVal.ToString();
                    var afterValue = afterVal == null ? null : afterVal.ToString();
                    if (beforeValue != afterValue)
                    {
                        result.IsChange = true;
                        content.Append(beforeMembers[i].Name + ":" + beforeValue + "->" + afterValue + "\r\n");
                    }
                }
            }
            result.ChangeContent = content.ToString().TrimEnd("\r\n".ToArray());
            return result;
        }

        public abstract bool Validate(out string errorMessage);

        private object TryGetValue(System.Reflection.PropertyInfo prop, Object obj)
        {
            try
            {
                return prop.GetValue(obj);
            }
            catch
            {

            }

            return null;
        }
    }

    public class CompareResult
    {
        public bool IsChange { get; set; }

        public string ChangeContent { get; set; }

        public void Add(CompareResult cr)
        {
            IsChange = IsChange || cr.IsChange;

            ChangeContent = ChangeContent + (string.IsNullOrEmpty(cr.ChangeContent) ? "" : cr.ChangeContent);

        }
    }
}
