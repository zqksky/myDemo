﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AMAT.R2R.Shared.Base.DTO
{
    public class Tool
    {
        public string ToolId { get; set; }

        public string ToolVendor { get; set; }

        public string ToolModel { get; set; }

        public string ToolType { get; set; }

        public string ToolProcessType { get; set; }

        public List<Chamber> Chambers { get; set; }
    }
}
