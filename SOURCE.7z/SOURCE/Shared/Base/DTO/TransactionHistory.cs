﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AMAT.R2R.Shared.Base.DTO
{
    public class TransactionHistory
    {
        public TransactionHistory()
        {
        }

        public DateTime ModifiedTime { get; set; }
        public string ModifiedBy { get; set; }
        public string Category { get; set; }
        public string Action { get; set; }
        public string Reason { get; set; }

        public string Status { get; set; }
        public string Comment { get; set; }
        public string Details { get; set; }
        public string Object { get; set; }
        public string SubObject { get; set; }

        public string TxId { get; set; }

        public string CrId { get; set; }
    }
}
