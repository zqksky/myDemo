﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AMAT.R2R.Shared.Base.DTO;

namespace AMAT.R2R.Shared.Litho.DTO
{
    public class XMLStructure
    {
        public XMLStructure()
        {
            LstProcess = new List<XMLProcess>();
            LstCDContext = new List<XMLCDContext>();
            LstOVLContext = new List<XMLOVLContext>();
            LstCDValues = new List<XMLCDValues>();
            LstOVLValues = new List<XMLOVLValues>();

        }

        public List<XMLProcess> LstProcess { get; set;}
        public List<XMLCDContext> LstCDContext { get; set; }
        public List<XMLOVLContext> LstOVLContext { get; set; }
        public List<XMLCDValues> LstCDValues { get; set; }
        public List<XMLOVLValues> LstOVLValues { get; set; }

   

    }

    public class VerifyResult
    {
        public string Process { get; set; }
        public string OVL { get; set; }
        public string CD { get; set; }

        public string Comment { get; set; }

        public string ProcessComment { get; set; }

        public string OVLComment { get; set; }

        public string CDComment { get; set; }

  
    }
 

    public class XMLProcess
    {
        public string Product { get; set; }

        public string Layer { get; set; }

        public bool Enabled { get; set; }

        public string CDFeature { get; set; }

        public string PreLayerX { get; set; }

        public string PreLayerY { get; set; }

        public string DedicationLayer { get; set; }

        public string PreLayersForOVLContext { get; set; }
        public string AlignLayer { get; set; }

        public bool NPWFlag { get; set; }

        public bool UseToolStatus { get; set; }
        public string CDFBStage { get; set; }
        public string OVLFBStage { get; set; }

    }


    public class XMLCDContext
    {
   
        public string Product { get; set; }

        public string Layer { get; set; }
        public string Tool { get; set; }


        public string Reticle { get; set; }

        public string Recipe { get; set; }

        public int FBEffectiveDays { get; set; }

        public int FBAllowCount { get; set; }


        public double GOFThreshold { get; set; }

        public double Target { get; set; }

        public double DoseSensitivity { get; set; }

        public double ReworkBias { get; set; }

    }

    public class XMLOVLContext
    {

        public string Product { get; set; }

        public string Layer { get; set; }
        public string Tool { get; set; }


        public string Reticle { get; set; }

        public string Recipe { get; set; }

        public string PreTool { get; set; }


        public string PreReticle { get; set; }

        public int FBEffectiveDays { get; set; }

        public int FBAllowCount { get; set; }


        public double GOFThreshold { get; set; }

        public string OVLModel      { get; set; }

        public bool ChuckControl   { get; set; }

        public int DedicationType    { get; set; }

        public bool TwoDMetrologyFlag { get; set; }

        public VerifyResult VerifyResult { get; set; }

    }

    public class XMLCDValues {

        public string Product { get; set; }

        public string Layer { get; set; }
        public string Tool { get; set; }


        public string Reticle { get; set; }

        public string Recipe { get; set; }

        public string ParameterName  { get; set; }

        public double FixedValue    { get; set; }
        public double Min        { get; set; }
        public double Max        { get; set; }
        public double Delta        { get; set; }
        public double Deadband        { get; set; }

        public double FBMin        { get; set; }
        public double FBMax        { get; set; }
        public double Lambda        { get; set; }
        public int MinPointForAvg    { get; set; }


    }

    public class XMLOVLValues
    {

        public string Product { get; set; }

        public string Layer { get; set; }
        public string Tool { get; set; }


        public string Reticle { get; set; }

        public string Recipe { get; set; }
        public string PreTool { get; set; }
        public string PreReticle { get; set; }

        public string ParameterName { get; set; }

        public double FixedValue_NA        { get; set; }
        public double FixedValue_C1 { get; set; }
        public double FixedValue_C2 { get; set; }

        public double Offset_NA { get; set; }
        public double Offset_C1 { get; set; }
        public double Offset_C2 { get; set; }


        public double Min { get; set; }
        public double Max { get; set; }
        public double Delta { get; set; }
        public double Deadband { get; set; }

        public double FBMin { get; set; }
        public double FBMax { get; set; }
        public double Lambda { get; set; }


    }
}
