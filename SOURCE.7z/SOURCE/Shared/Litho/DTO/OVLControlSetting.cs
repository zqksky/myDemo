﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AMAT.R2R.Shared.Litho.DTO
{
    // [Table("R2R_PH_CFG_OVL_CONTROL")]
    public class OVLControlSetting
    {

        private BasicContext basicContext;

        public OVLControlSetting()
        {
            basicContext = new BasicContext();
        }


        public BasicContext BasicContext { get { return this.basicContext; } set { this.basicContext = value; } }

        public string ContextKey { get { return string.Format("{0}:{1}:{2}:{3}:{4}:{5}:{6}:{7}", Fab, BasicContext.Tool, BasicContext.Product, BasicContext.Layer, BasicContext.Reticle, BasicContext.Recipe, PreTool, PreReticle); } }

        public string Fab { get; set; }

        public string PreTool { get; set; }

        public string PreReticle { get; set; }

        public string ControlFlag { get; set; }

        public double FBEffectiveDays { get; set; }

        public double FBAllowCount { get; set; }

        public int FBLotCounter { get; set; }

        public string FBLotList { get; set; }


        public string AssignPilot { get; set; }

        public int HitSpecAlertEnabled { get; set; }

        public string ModelName { get; set; }

        public int ChuckControlEnabled { get; set; }

        public int ChuckDedicationType { get; set; }

        public int TwoDMetrologyFlag { get; set; }

        public double GOFThreshold { get; set; }

        public string Comment { get; set; }

        public string LastModifyUser { get; set; }

        public DateTime LastModifyTime { get; set; }


        public List<OVLValues> LstOVLValues { get; set; }

        public List<Specs> LstOVLSpecs { get; set; }


    }



}
