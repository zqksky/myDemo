﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AMAT.R2R.Shared.Litho.DTO
{

    public class Specs
    {
        public string ContextKey { get; set; }

        public string ModelName { get; set; }


        public string Varname { get; set; }

        public string Unit { get; set; }

        public double? FixValueNA { get; set; }

        public double? FixValueC1 { get; set; }

        public double? FixValueC2 { get; set; }


        public double? OffsetValueNA { get; set; }

        public double? OffsetValueC1 { get; set; }

        public double? OffsetValueC2 { get; set; }

        public double Max { get; set; }

        public double Min { get; set; }
        public double MaxDelta { get; set; }
        public double Deadband { get; set; }

        public double Lambda { get; set; }

        public double LambdaForPirun { get; set; }

        public double MinPointsForAvg { get; set; }

        public double OutputMax { get; set; }

        public double OutputMin { get; set; }

        public int Precision { get; set; }

        public string LastModifyUser { get; set; }

        public DateTime LastModifyTime { get; set; }

        public string Comment { get; set; }
    }

}
