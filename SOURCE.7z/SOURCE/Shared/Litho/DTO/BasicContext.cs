﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AMAT.R2R.Shared.Litho.DTO
{

    public class BasicContext
    {

        public string Tool { get; set; }

        public string Product { get; set; }

        public string Layer { get; set; }

        public string Reticle { get; set; }

        public string Recipe { get; set; }

    }
}
