﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AMAT.R2R.Shared.Litho.DTO
{

    //[Table("R2R_PH_REC_TOOL_STATUS")]
    public class RecToolStatus
    {

        public string ToolId { get; set; }

        public string TransactionID { get; set; }

        public string ToolStatus { get; set; }

        public string ModelName { get; set; }

        public DateTime LastModifyDate { get; set; }

    }
}
