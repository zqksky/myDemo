﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AMAT.R2R.Shared.Base.DTO;

namespace AMAT.R2R.Shared.Litho.DTO
{

    public class SpecialJobParameter : BaseDto
    {
        public string JobId { get; set; }
        public string ParameterName { get; set; }
        public double? InputValueNA { get; set; }
        public double? InputValueC1 { get; set; }
        public double? InputValueC2 { get; set; }

        public double? Min { get; set; }
        public double? Max { get; set; }

        public string Unit { get; set; }

        public string ParameterType { get; set;}

        public override bool Validate(out string errorMessage)
        {
            errorMessage = "";
            return true;
        }
    }

    public class SpecialJob : BaseDto
    {
        public SpecialJob()
        {
            this.SpecialJobParameters = new List<SpecialJobParameter>();
        }


        public string JobKey { get { return string.Format("{0}:{1}:{2}:{3}:{4}:{5}:{6}:{7}:{8}", LotId, RunCardId, SplitId, FabId, Tool, Product, Layer, Reticle, Recipe); } }


        public string JobId { get; set; }
        public string RunCardId { get; set; }
        public string SplitId { get; set; }
        public string LotId { get; set; }

        public string FabId { get; set; }

        public string Tool { get; set; }

        public string Product { get; set; }

        public string Layer { get; set; }

        public string Reticle { get; set; }

        public string Recipe { get; set; }

        public string ControlModelName { get; set; }

        public string OVLModelName { get; set; }

        public bool JobCompleted { get; set; }

        public int C2C { get; set; }

        public int FEM { get; set; }

        public string LisOptiSubRecipeName { get; set; }

        public DateTime? UsedTime { get; set; }

        public bool IsValid { get; set; }

        public DateTime CreateTime { get; set; }

        public string UserId { get; set; }

        public string ContextKey { get; set; }

        public List<SpecialJobParameter> SpecialJobParameters { get; set; }

        public DateTime LastModifyDate { get; set; }
        public string LastModifiedBy { get; set; }

        public override CompareResult Compare(Object oldJob)
        {
            //CompareResult result = base.Compare(oldJob);
            CompareResult result1 = new CompareResult() { IsChange = false, ChangeContent = "" };
            SpecialJob osj = (SpecialJob)oldJob;

            List<string> InputParameters = new List<string>();
            InputParameters.AddRange(this.SpecialJobParameters.Select(t => t.ParameterName + "(NA)").ToList());
            InputParameters.AddRange(this.SpecialJobParameters.Select(t => t.ParameterName + "(C1)").ToList());
            InputParameters.AddRange(this.SpecialJobParameters.Select(t => t.ParameterName + "(C2)").ToList());

            List<double?> InputValues = new List<double?>();
            InputValues.AddRange(this.SpecialJobParameters.Select(t => t.InputValueNA).ToList());
            InputValues.AddRange(this.SpecialJobParameters.Select(t => t.InputValueC1).ToList());
            InputValues.AddRange(this.SpecialJobParameters.Select(t => t.InputValueC2).ToList());

            List<string> oldInputParameters = new List<string>();
            oldInputParameters.AddRange(osj.SpecialJobParameters.Select(t => t.ParameterName + "(NA)").ToList());
            oldInputParameters.AddRange(osj.SpecialJobParameters.Select(t => t.ParameterName + "(C1)").ToList());
            oldInputParameters.AddRange(osj.SpecialJobParameters.Select(t => t.ParameterName + "(C2)").ToList());

            List<double?> oldInputValues = new List<double?>();
            oldInputValues.AddRange(osj.SpecialJobParameters.Select(t => t.InputValueNA).ToList());
            oldInputValues.AddRange(osj.SpecialJobParameters.Select(t => t.InputValueC1).ToList());
            oldInputValues.AddRange(osj.SpecialJobParameters.Select(t => t.InputValueC2).ToList());


            for (int i = 0; i < InputParameters.Count(); i++)
            {
                int j = oldInputParameters.FindIndex(t => t.Equals(InputParameters[i]));
                if (i < 0)
                {
                    result1.IsChange = true;
                    result1.ChangeContent = result1.ChangeContent + InputParameters[i] + " Added\r\n";
                }
                else if (!InputValues[i].Equals(oldInputValues[j]))
                {
                    result1.IsChange = true;
                    result1.ChangeContent = result1.ChangeContent + InputParameters[i] + ":" + oldInputValues[j] + "->" + InputValues[i] + "\r\n";
                }
            }
            for (int i = 0; i < osj.SpecialJobParameters.Count(); i++)
            {
                int j = this.SpecialJobParameters.FindIndex(p=>p.ParameterName==osj.SpecialJobParameters[i].ParameterName);
                if (j < 0)
                {
                    result1.IsChange = true;
                    result1.ChangeContent = result1.ChangeContent + osj.SpecialJobParameters[i].ParameterName + " Delete\r\n";
                }
            }
            
            return result1;
        }

        public override bool Validate(out string errorMessage)
        {
            errorMessage = "";
            if (string.IsNullOrEmpty(this.FabId) ||
                string.IsNullOrEmpty(this.Tool) ||
                string.IsNullOrEmpty(this.Product) ||
                string.IsNullOrEmpty(this.Layer) ||
                string.IsNullOrEmpty(this.Reticle) ||
                string.IsNullOrEmpty(this.Recipe) ||
                string.IsNullOrEmpty(this.LotId) ||
                string.IsNullOrEmpty(this.RunCardId) ||
                string.IsNullOrEmpty(this.SplitId))

            {
                errorMessage += "Not Valid SpecialJob Key";
            }

            if ("NA".Equals(LotId) && "NA".Equals(RunCardId) && "NA".Equals(SplitId))
            {
                errorMessage += "Not Valid LotId or RunCardId";
            }

            if(SpecialJobParameters==null || SpecialJobParameters.Count <= 0)
            {
                errorMessage += "None Parameter defined";
            }

            foreach (DTO.SpecialJobParameter sjp in SpecialJobParameters)
            {
                if (string.IsNullOrEmpty(sjp.ParameterType))
                {
                    errorMessage += (sjp.ParameterName + " is not recognized!");
                }

                if (this.C2C == 1 && sjp.ParameterType == this.OVLModelName)
                {
                    if (sjp.InputValueC1 == null || sjp.InputValueC2 == null)
                    {
                        errorMessage += (sjp.ParameterName + " missing value");
                    }
                }
                else
                {
                    if(sjp.InputValueNA==null)
                    {
                        errorMessage += (sjp.ParameterName + " missing value");
                    }
                }
            }

            if (string.IsNullOrEmpty(errorMessage)) return true;
            else
                return false;
        }

    }

}
