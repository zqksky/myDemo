﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AMAT.R2R.Shared.Base.DTO;

namespace AMAT.R2R.Shared.Litho.DTO
{

    public class Material : BaseDto
    {

        public Material()
        {
            this.LstMaterialValue = new List<MaterialValue>();

        }

        public string ContextKey
        {
            get { return string.Format("{0}:{1}:{2}:{3}:{4}:{5}:{6}:{7}", Fab, Tool, Product, Layer, Reticle, Recipe, PreTool, PreReticle); }
        }


        public bool Enabled { get; set; }


        public string Fab { get; set; }

        public string Tool { get; set; }

        public string Product { get; set; }

        public string Layer { get; set; }

        public string Reticle { get; set; }

        public string Recipe { get; set; }


        public string PreTool { get; set; }

        public string PreReticle { get; set; }

        public int ChuckControl { get; set; }


        public string CDControlFlag { get; set; }

        public string CDAssignPilot { get; set; }

        public string CDFeature { get; set; }

        public int CDFBEffectDays { get; set; }

        public int CDFBAllowCount { get; set; }

        public string CDFBLotList { get; set; }

        public string CDTarget { get; set; }

        public string CDSlope { get; set; }

        public string CDIntercept { get; set; }

        public string CDRecommendValue { get; set; }


        public string CDLastEstTime  { get; set; }

        public string OVLModel { get; set; }

        public string OVLControlFlag { get; set; }

        public string OVLAssignPilot { get; set; }

        public string OVLPreLayerX { get; set; }

        public string OVLPreLayerY { get; set; }
        
        public int OVLFBEffectDays { get; set; }

        public int OVLFBAllowCount { get; set; }

        public string OVLFBLotList { get; set; }

        public string OVLIntercept { get; set; }

        public string OVLRecommendValue { get; set; }

        public string OVLLastEstTime { get; set; }


        public bool IsCDSpecConfig { get; set; }

        public bool IsOVLSpecConfig { get; set; }




        public List<MaterialValue> LstMaterialValue { get; set; }

        public override bool Validate(out string errorMessage)
        {
            errorMessage = "";
            Material material = (Material)this;


            if (string.IsNullOrEmpty(material.Fab) ||
                string.IsNullOrEmpty(material.Tool) ||
                string.IsNullOrEmpty(material.Product) ||
                string.IsNullOrEmpty(material.Layer) ||
                string.IsNullOrEmpty(material.Reticle) ||
                string.IsNullOrEmpty(material.Recipe) ||
                string.IsNullOrEmpty(material.PreTool) ||
                string.IsNullOrEmpty(material.PreReticle) ||
                material.Fab.StartsWith(" ") ||
                material.Tool.StartsWith(" ") ||
                material.Product.StartsWith(" ") ||
                material.Layer.StartsWith(" ") ||
                material.Reticle.StartsWith(" ") ||
                material.Recipe.StartsWith(" ") ||
                material.PreTool.StartsWith(" ") ||
                material.PreReticle.StartsWith(" "))
            {
                errorMessage = "Empty value found!";
            }
            if (string.IsNullOrEmpty(errorMessage)) return true;
            else return false;
        }
    }
}
