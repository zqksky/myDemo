﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AMAT.R2R.Shared.Litho.DTO
{

    //[Table("R2R_PH_CFG_PROCESS_SUB_CONFIG")]
    public class ProcessSubCfg
    {
        public ProcessSubCfg()
        {
            // List<ProcessSubConfig> LstPreLayer = new List<ProcessSubConfig>();
        }

        public string ProcessKey { get; set; }


        public string ItemName { get; set; }


        public int Index { get; set; }


        public string ItemValue { get; set; }



        public DateTime LastModifyDate { get; set; }

        public string LastModifyUser { get; set; }
    }

}
