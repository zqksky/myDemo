﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AMAT.R2R.Shared.Base.DTO;

namespace AMAT.R2R.Shared.Litho.DTO
{
    public class RunHist : BaseDto
    {
        public RunHist()
        {

        }


        public string ModelName { get; set; }
        public string HznKey { get; set; }

        public string Tool { get; set; }

        public string Product { get; set; }

        public string Layer { get; set; }

        public string Reticle { get; set; }

        public string Recipe { get; set; }

        public string PreTool { get; set; }

        public string PreReticle { get; set; }

        public string Fab { get; set; }

        public string LotId { get; set; }

        public string ReworkCnt { get; set; }

        public string WaferList { get; set; }

        public string SpecifyLot { get; set; }

        public string RunCardId { get; set; }
        public string SplitId { get; set; }


        public int ChuckControl { get; set; }

        public DateTime? CalcTimesStamp { get; set; }

        public DateTime? UsedTimeStamp { get; set; }

        public DateTime? CDPostTimeStamp { get; set; }
        public string CDFeature { get; set; }

        public string DoseDefaultRecSettings { get; set; }

        public string DoseRecipeSettings { get; set; }

        public string DoseFinalRecSettings { get; set; }

        public string DoseUsedSettings { get; set; }

        public string FocusUsedSettings { get; set; }

        public string CDPostMetrology { get; set; }

        public string DoseNewRecSettingsFb { get; set; }

        public string CDIntercept { get; set; }


        public string CDPilotFlag { get; set; }

        public string CDIsActive { get; set; }

        public DateTime? OVLPostTimeStamp { get; set; }



        public string FFDisb { get; set; }

        public string OvlOffset { get; set; }


        public string OvlDefaultRecSettings { get; set; }

        public string OvlRecipeSettings { get; set; }

        public string OvlFinalRecSettings { get; set; }

        public string OvlUsedSettings { get; set; }

        public string OVLNamesCsv { get; set; }

     
        public string OVLPostMetrologyCsv { get; set; }


        public string OVLNewRecSettingsFb { get; set; }


        public string OVLInterceptCsv { get; set; }

        public string ModifiedBy { get; set; }



        public string OVLPilotFlag { get; set; }

        public string OVLIsActive { get; set; }

        public string Remark { get; set; }



        public override bool Validate(out string errorMessage)
        {
            errorMessage = "";
            return true;
        }
    }

}
