﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AMAT.R2R.Shared.Base.DTO;

namespace AMAT.R2R.Shared.Litho.DTO
{

    //[Table("R2R_PH_CFG_PROCESS")]
    public class Process : BaseDto
    {
        public Process()
        {
        }

        public string ProcessKey
        {
            get { return string.Format("{0}:{1}:{2}", Fab, Product, Layer); }
        }

        public string Fab { get; set; }

        public string Product { get; set; }

        public string Layer { get; set; }

        public bool Enabled { get; set; }

        public string CDFeature { get; set; }

        public string PreLayerX { get; set; }

        public string PreLayerY { get; set; }

        public string AlignLayer { get; set; }

        public bool NPWFlag { get; set; }

        public bool UseToolStatus { get; set; }

        public bool/*1,0*/ IsFirstLayer { get; set; }

        public string DedicationLayer { get; set; }

        public string CDFBStage { get; set; }

        public string OVLFBStage { get; set; }

        public string PreLayers1 { get; set; }

        public string PreLayers2 { get; set; }

        public string PreLayers3 { get; set; }

        public string PreLayers4 { get; set; }

        public string PreLayers5 { get; set; }

        public string Comment { get; set; }

        public DateTime LastModifyDate { get; set; }

        public string LastModifyBy { get; set; }

        public override bool Validate(out string errorMessage)
        {
            errorMessage = "";
            Process process = (Process)this;


            if (string.IsNullOrEmpty(process.Fab) ||
                string.IsNullOrEmpty(process.Product) ||
                string.IsNullOrEmpty(process.Layer) ||
                string.IsNullOrEmpty(process.PreLayerX) ||
                string.IsNullOrEmpty(process.PreLayerY) ||
                string.IsNullOrEmpty(process.CDFeature) ||
                process.Fab.StartsWith(" ") ||
                process.Product.StartsWith(" ") ||
                process.Layer.StartsWith(" ") ||
                process.PreLayerX.StartsWith(" ") ||
                process.PreLayerY.StartsWith(" ") ||
                process.CDFeature.StartsWith(" "))
            {
                errorMessage = "Empty value found!";
            }
            if (string.IsNullOrEmpty(errorMessage)) return true;
            else return false;
        }

    }

}
