﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AMAT.R2R.Shared.Litho.DTO
{
    public class ParameterList
    {
        public BasicContext Basic_Context { get; set; }

        public List<Parameter> Parameters { get; set; }

    }
}
