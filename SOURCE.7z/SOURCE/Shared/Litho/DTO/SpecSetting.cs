﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AMAT.R2R.Shared.Base.DTO;

namespace AMAT.R2R.Shared.Litho.DTO
{

    public class SpecSetting : BaseDto
    {
        public SpecSetting()
        {
            Specs = new List<Specs>();
        }

        public List<Specs> Specs { get; set; }


        public string Comment { get; set; }

        public string LastModifyUser { get; set; }

        public DateTime LastModifyTime { get; set; }


        public override bool Validate(out string errorMessage)
        {
            errorMessage = "";
            SpecSetting specSetting = (SpecSetting)this;

            foreach (var spec in specSetting.Specs)
            {
                if (
               string.IsNullOrEmpty(spec.ContextKey) ||
               string.IsNullOrEmpty(spec.ModelName) ||
               string.IsNullOrEmpty(spec.Varname) ||
               double.IsNaN(spec.Deadband) ||
               double.IsNaN(spec.Lambda) ||
               double.IsNaN(spec.LambdaForPirun) ||
               double.IsNaN(spec.Max) ||
               double.IsNaN(spec.MaxDelta) ||
               double.IsNaN(spec.Min) ||
               double.IsNaN(spec.MinPointsForAvg) ||
               double.IsNaN(spec.OutputMax) ||
               double.IsNaN(spec.OutputMin) ||
               double.IsNaN(spec.Precision) ||
               spec.ContextKey.StartsWith(" ") ||
               spec.Varname.StartsWith(" ") ||
               spec.ModelName.StartsWith(" "))

                {
                    errorMessage = "Empty value found!";
                }
            }



            if (string.IsNullOrEmpty(errorMessage)) return true;
            else return false;
        }

    }

}
