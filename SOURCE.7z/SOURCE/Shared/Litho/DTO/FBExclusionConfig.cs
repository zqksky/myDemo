﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AMAT.R2R.Shared.Litho.DTO
{

    //[Table("R2R_PH_ADV_FB_EXCLUSION")]
    public class FBExclusionConfig
    {

        public string Fab { get; set; }

        public string Product { get; set; }

        public string ExclusionType { get; set; }

        public string Value { get; set; }


        public string Remark { get; set; }


        public string LastModifyUser { get; set; }

        public DateTime LastModifyTime { get; set; }

    }
}
