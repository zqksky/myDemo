﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AMAT.R2R.Shared.Litho.DTO
{

    //[Table("R2R_PH_CFG_DCD_VALUES")]
    public class DCDValues
    {

        public string ContextKey { get; set; }

        public double? DoseFixedValue { get; set; }


        public double? FocusFixedValue { get; set; }

        public double Target { get; set; }

        public double? DoseSensitivity { get; set; }

        public double ReworkBias { get; set; }

        public string Comment { get; set; }

        public string LastModifyUser { get; set; }

        public DateTime LastModifyTime { get; set; }

    }
}
