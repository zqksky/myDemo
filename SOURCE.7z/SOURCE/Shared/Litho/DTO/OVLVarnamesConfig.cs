﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AMAT.R2R.Shared.Litho.DTO
{
    // [Table("R2R_PH_INIT_OVL_VAR_CONFIG")]
    public class OVLVarnamesConfig
    {

        public string ModelName { get; set; }

        public string VarName { get; set; }

        public string ControlModelName { get; set; }

        public int Index { get; set; }

        public int DisplayIndex { get; set; }

        public string WaferOrShot { get; set; }


        public string LastModifyUser { get; set; }

        public DateTime LastModifyTime { get; set; }



    }



}
