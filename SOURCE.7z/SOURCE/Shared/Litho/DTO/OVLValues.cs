﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AMAT.R2R.Shared.Litho.DTO
{

    //[Table("R2R_PH_CFG_OVL_VALUES")]
    public class OVLValues
    {

        public string ContextKey { get; set; }

        public string ModelName { get; set; }

        public string Chuck { get; set; }

        public string Varname { get; set; }

        public double? FixedValue { get; set; }

        public double? OffsetValue { get; set; }

        public string Comment { get; set; }

        public string LastModifyUser { get; set; }

        public DateTime LastModifyTime { get; set; }

    }
}
