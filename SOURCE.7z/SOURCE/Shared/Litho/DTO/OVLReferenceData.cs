﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AMAT.R2R.Shared.Base.DTO;

namespace AMAT.R2R.Shared.Litho.DTO
{

    //[Table("R2R_PH_ADV_OVL_REFERENCE_DATA")]
    public class OVLReferenceData : BaseDto
    {
        public OVLReferenceData() { }

        public string Lot { get; set; }

        public string Product { get; set; }

        public string Layer { get; set; }

        public string Tool { get; set; }

        public string Reticle { get; set; }

        public string LastModifyUser { get; set; }

        public DateTime LastModifyTime { get; set; }
        public override bool Validate(out string errorMessage)
        {
            errorMessage = "";
            OVLReferenceData context = (OVLReferenceData)this;


            if (string.IsNullOrEmpty(context.Lot) ||
                string.IsNullOrEmpty(context.Tool) ||
                string.IsNullOrEmpty(context.Product) ||
                string.IsNullOrEmpty(context.Layer) ||
                string.IsNullOrEmpty(context.Reticle) ||
                context.Lot.StartsWith(" ") ||
                context.Tool.StartsWith(" ") ||
                context.Product.StartsWith(" ") ||
                context.Layer.StartsWith(" ") ||
                context.Reticle.StartsWith(" "))
            {
                errorMessage = "Empty value found!";
            }


            if (string.IsNullOrEmpty(errorMessage)) return true;
            else return false;
        }

    }

   
}
