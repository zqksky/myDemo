﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;

namespace AMAT.R2R.Shared.Litho.DTO
{
    public class Matrix<T>
    {
        public string Name { get; set; }

        public int Row { get; }

        public int Column { get; }

        public Matrix(int row, int column, T defaultValue)
        {
            Row = row;
            Column = column;
            cells = new T[row, column];
            for (int i = 0; i < row; i++)
            {
                for (int j = 0; j < column; j++)
                {
                    cells[row, column] = defaultValue;
                }
            }
        }

        private T[,] cells;

        public T this[int row, int column]
        {
            get { return cells[row, column]; }
            set { cells[row, column] = value; }
        }

        public string RowCSV(int row)
        {
            if (row >= Row || row < 0) return "";

            List<T> res = new List<T>();
            for (int j = 0; j < Column; j++)
            {
                res.Add(cells[row, j]);
            }
            return string.Join(",", res.ToArray());
        }

        public T[] RowArray(int row)
        {
            if (row >= Row || row < 0) return new T[Column];

            List<T> res = new List<T>();
            for (int j = 0; j < Column; j++)
            {
                res.Add(cells[row, j]);
            }
            return res.ToArray();
        }


    }
}
