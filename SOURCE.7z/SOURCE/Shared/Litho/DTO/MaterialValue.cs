﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AMAT.R2R.Shared.Litho.DTO
{

    public class MaterialValue
    {

        public string Varname { get; set; }

        public double? RecommendValueNA { get; set; }

        public double? FixedValueNA { get; set; }

        public double? OffsetValueNA { get; set; }

        public double? RecommendValueC1 { get; set; }

        public double? FixedValueC1 { get; set; }

        public double? OffsetValueC1 { get; set; }


        public double? RecommendValueC2 { get; set; }

        public double? FixedValueC2 { get; set; }

        public double? OffsetValueC2 { get; set; }


        public double? Max { get; set; }

        public double? Min { get; set; }

        public double? MaxDelta { get; set; }

        public double? Deadband { get; set; }

        public double? Lambda { get; set; }

        public string ParameterType { get; set; }

    }
}
