﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AMAT.R2R.Shared.Litho.DTO
{
    // [Table("R2R_PH_INIT_MES_VAR_MAPPING")]
    public class MESVarMapping
    {

        public string ServiceName { get; set; }

        public string MESVarname { get; set; }

        public string R2RVarname { get; set; }

        public string Unit { get; set; }

        public double Precision { get; set; }

        public int Index { get; set; }


        public string LastModifyUser { get; set; }

        public DateTime LastModifyTime { get; set; }



    }



}
