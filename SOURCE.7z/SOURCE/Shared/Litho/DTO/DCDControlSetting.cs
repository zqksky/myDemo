﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AMAT.R2R.Shared.Litho.DTO
{
    public enum ControlFlag { FIXED, ON, PIRUNON, PIRUNOFF, OFF }

    //[Table("R2R_PH_CFG_DCD_CONTROL")]
    public class DCDControlSetting
    {
        private BasicContext basicContext;
        public  DCDControlSetting()
        {
            basicContext = new BasicContext();
        }
        public BasicContext BasicContext { get { return this.basicContext; }set { this.basicContext = value; } }

        public string ContextKey { get { return string.Format("{0}:{1}:{2}:{3}:{4}:{5}", Fab, BasicContext.Tool, BasicContext.Product, BasicContext.Layer, BasicContext.Reticle, BasicContext.Recipe); } }

        public string Fab { get; set; }

        public string ControlFlag { get; set; }

        public double FBEffectiveDays { get; set; }

        public double FBAllowCount { get; set; }

        public int FBLotCounter { get; set; }

        public string FBLotList { get; set; }

        public double GOFThreshold { get; set; }

        public string AssignPilot { get; set; }

        public int HitSpecAlertEnabled { get; set; }


        public string Comment { get; set; }

        public string LastModifyUser { get; set; }

        public DateTime LastModifyTime { get; set; }


        public DCDValues DCDValues { get; set; }

        public Specs Specs { get; set; }

    }
}
