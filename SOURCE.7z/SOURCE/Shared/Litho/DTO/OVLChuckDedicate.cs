﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AMAT.R2R.Shared.Litho.DTO
{

    //[Table("R2R_PH_ADV_OVL_CHUCK_DEDICATE")]
    public class OVLChuckDedicate
    {

        public string Layer { get; set; }

        public string WaferId { get; set; }

        public string ChuckId { get; set; }

        public string LastModifyUser { get; set; }

        public DateTime LastModifyTime { get; set; }

    }
}
