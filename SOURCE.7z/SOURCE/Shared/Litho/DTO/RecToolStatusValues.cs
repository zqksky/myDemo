﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AMAT.R2R.Shared.Base.DTO;

namespace AMAT.R2R.Shared.Litho.DTO
{

    public class RecToolStatusValues : BaseDto
    {

        public RecToolStatusValues()
        {
        }

        public string ToolId { get; set; }

        public string[] Parameters { get; set; }

        public string[] Values { get; set; }


        public override bool Validate(out string errorMessage)
        {
            errorMessage = "";
            RecToolStatusValues ToolStatus = (RecToolStatusValues)this;


            if (ToolStatus.Values.Length==0)
            {
                errorMessage = "Empty value found!";
            }
            if (string.IsNullOrEmpty(errorMessage)) return true;
            else return false;
        }
    }
}
