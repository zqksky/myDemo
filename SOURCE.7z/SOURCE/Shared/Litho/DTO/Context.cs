﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AMAT.R2R.Shared.Base.DTO;

namespace AMAT.R2R.Shared.Litho.DTO
{
    public class Context : BaseDto
    {
        public Context()
        {
            LstOVLValues = new List<OVLValues>();
            DCDValues = new DCDValues();
            Process = new Process();
            LstSpecs = new List<Specs>();
        }

        public string Fab { get; set; }

        public string Tool { get; set; }

        public string Product { get; set; }

        public string Layer { get; set; }

        public string Reticle { get; set; }

        public string Recipe { get; set; }

        public string PreTool { get; set; }

        public string PreReticle { get; set; }

        #region CD Context

        public string CDContextKey { get { return string.Format("{0}:{1}:{2}:{3}:{4}:{5}", Fab, Tool, Product, Layer, Reticle, Recipe); } set { } }


        public string CDControlFlag { get; set; }

        public int CDFBEffectiveDays { get; set; }

        public int CDFBAllowLotCnt { get; set; }

        public int CDFBLotCounter { get; set; }

        public string CDFBLotList { get; set; }

        public string CDAssignPilot { get; set; }

        public double CDGOFThreshold { get; set; }

        public double CDMinPointLimit { get; set; }

        public DCDValues DCDValues { get; set; }

        public double? DoseFixedValue { get { return this.DCDValues.DoseFixedValue; } set { } }

        public double? FocusFixedValue { get { return this.DCDValues.FocusFixedValue; } set { } }

        public double Target { get { return this.DCDValues.Target; } set { } }

        public double? DoseSensitivity { get { return this.DCDValues.DoseSensitivity; } set { } }

        public double ReworkBias { get { return this.DCDValues.ReworkBias; } set { } }

        #endregion CD Context


        #region OVL Context

        public string OVLContextKey { get { return string.Format("{0}:{1}:{2}:{3}:{4}:{5}:{6}:{7}", Fab, Tool, Product, Layer, Reticle, Recipe, PreTool, PreReticle); } set { } }


        public string OVLControlFlag { get; set; }

        public int OVLFBEffectiveDays { get; set; }

        public int OVLFBAllowLotCnt { get; set; }

        public int OVLFBLotCounter { get; set; }

        public string OVLFBLotList { get; set; }

        public string OVLAssignPilot { get; set; }

        public double OVLGOFThreshold { get; set; }

        public string ModelName { get; set; }

        public int TwoDMetrologyEnabled { get; set; }

        public int ChuckControl { get; set; }

        public int ChuckDedicationType { get; set; }

        public List<OVLValues> LstOVLValues { get; set; }

        public List<Specs> LstSpecs { get; set; }


        #endregion OVL Context

        public string Comment { get; set; }

        public DateTime LastModifyTime { get; set; }

        public string LastModifyUser { get; set; }

        public Process Process { get; set; }

        public string CDFeature { get { return (Process == null ? "" : Process.CDFeature); } }
        public bool Enabled { get { return (Process == null ? false : Process.Enabled); } }
        public string PreLayerX { get { return (Process == null ? "" : Process.PreLayerX); } }
        public string PreLayerY { get { return (Process == null ? "" : Process.PreLayerY); } }


        public bool IsCDSpecConfig { get; set; }

        public bool IsOVLSpecConfig { get; set; }


        public override bool Validate(out string errorMessage)
        {
            errorMessage = "";
            Context context = (Context)this;


            if (string.IsNullOrEmpty(context.Fab) ||
                string.IsNullOrEmpty(context.Tool) ||
                string.IsNullOrEmpty(context.Product) ||
                string.IsNullOrEmpty(context.Layer) ||
                string.IsNullOrEmpty(context.Reticle) ||
                string.IsNullOrEmpty(context.Recipe) ||
                string.IsNullOrEmpty(context.PreTool) ||
                string.IsNullOrEmpty(context.PreReticle) ||
                context.Fab.StartsWith(" ") ||
                context.Tool.StartsWith(" ") ||
                context.Product.StartsWith(" ") ||
                context.Layer.StartsWith(" ") ||
                context.Reticle.StartsWith(" ") ||
                context.Recipe.StartsWith(" ") ||
                context.PreTool.StartsWith(" ") ||
                context.PreReticle.StartsWith(" "))
            {
                errorMessage = "Empty value found!";
            }

            else if ((context.PreTool == "NA" && context.PreReticle != "NA") || (context.PreTool != "NA" && context.PreReticle == "NA"))
            {
                errorMessage = "Wrong config with PreTool, PreReticle!";
            }



                if (string.IsNullOrEmpty(errorMessage)) return true;
            else return false;
        }
    }
}
