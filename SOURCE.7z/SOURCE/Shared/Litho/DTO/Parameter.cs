﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AMAT.R2R.Shared.Litho.DTO
{
    public class Parameter
    {
        public string ParameterName { get; set; }

        public string ParameterType { get; set; }

        public int Precision { get; set; }

        public double Parameter_Recommend_Value { get; set; }

        public string OVL_MODE { get; set; }

        public string CONTROLLER { get; set; }

        public int Index { get; set; }

        public Specs Specs { get; set; }

    }
}
