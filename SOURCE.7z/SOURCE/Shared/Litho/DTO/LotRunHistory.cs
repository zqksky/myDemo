﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AMAT.R2R.Shared.Base.DTO;

namespace AMAT.R2R.Shared.Litho.DTO
{
    public class LotRunHistory : BaseDto
    {
        public string LotId { get; set; }

        //csv string
        public string WaferId { get; set; }

        public string Tool { get; set; }

        public string Product { get; set; }

        public string Layer { get; set; }

        public string Recipe { get; set; }

        public string Reticle { get; set; }

        public string PreTool { get; set; }

        public string PreReticle { get; set; }

        public bool? IsActiveCd { get; set; }

        public bool? IsActiveOvl { get; set; }

        public int WaferQty { get; set; }

        public DateTime? ProcessStamp { get; set; }

        public List<LotHistoryParameter> ProcessVaues  { get;set;}

        public DateTime? PostTimeStamp { get; set; }
        public List<LotHistoryParameter> MetrologyValues { get; set; }

        public DateTime? EstiTimeStamp { get; set; }
        public List<LotHistoryParameter> EstimateValues { get; set; }

        public string MotherLot { get; set; }

        public string ReworkCnt { get; set; }

        public string OvlModel { get; set; }

        public bool? SpecifyLot { get; set; }

        public bool? PilotFlagCd { get; set; }

        public bool? PilotFlagOvl { get; set; }

        public string RunCardId { get; set; }

        public string SplitId { get; set; }

        public string Feedback { get; set; }

        public string Remark { get; set; }
        public override bool Validate(out string errorMessage)
        {
            errorMessage = "";

            return true;
        }

    }

    public class LotHistoryParameter
    {
        private string val;
        public string Name { get; set; }
        public string Value {
            get
            {
                if (string.IsNullOrEmpty(val)) return string.Empty;
                if (!IsNumeric) return val;
                //Decimal dData = 0.0M;
                
                if(Decimal.TryParse(val.ToString(), System.Globalization.NumberStyles.Any, null ,out decimal dData))
                {
                    return Math.Round(dData, 8).ToString();
                }
                else
                {
                    return "NaN";
                }
                /*
                if (val.Contains("E")||val.Contains("e"))
                {

                    dData = Convert.ToDecimal(Decimal.Parse(val.ToString(), System.Globalization.NumberStyles.Float));
                }
                else
                {
                    dData = Convert.ToDecimal(val);
                }
                return  Math.Round(dData, 8).ToString();
                */
            }
            set { val = value; }
        } 

        //number or string
        public bool IsNumeric { get; set; }

    }

}
