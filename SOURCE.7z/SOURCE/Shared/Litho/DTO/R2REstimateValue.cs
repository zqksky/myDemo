﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AMAT.R2R.Shared.Litho.DTO
{

    //[Table("EES_R2R_ESTIMATE_VALUE")]
    public class R2REstimateValue
    {

        public string ControlSysId { get; set; }

        public string RefContextGroupValue { get; set; }
        public string RefContextGroup { get; set; }

        public string ContextKeyOfRefRuns { get; set; }

        public string ReferenceRuns { get; set; }

        public string EstimateValue { get; set; }

        public string UCalculatedValue { get; set; }

        public string Flag { get; set; }

        public string TimeStamp { get; set; }

    }
}
