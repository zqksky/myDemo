﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;

namespace AMAT.R2R.Shared.Litho.DTO
{
    public class InputSetting
    {
        public string ContextKey { get; set; }

        public int InputIndex { get; set; }

        public Parameter Paramter { get; set; }

        public decimal? DefaultRecommandValue { get; set; }

        public decimal? UpperLimit { get; set; }

        public decimal? LowerLimit { get; set; }

        public decimal? Deadband { get; set; }

        public string Unit { get; set; }

        public double UsedConversion { get; set; }

        public double RecVsUsedLimit { get; set; }

        public List<SlaveInput> SlaveInputs { get; set; }
    }

    public class SlaveInput
    {
        public string ParameterName { get; set; }

        public double Coefficient { get; set; }

        public double Offset { get; set; }
    }
}
