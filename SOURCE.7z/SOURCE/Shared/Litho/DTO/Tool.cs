﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AMAT.R2R.Shared.Base.DTO;

namespace AMAT.R2R.Shared.Litho.DTO
{
    public class Tool : BaseDto
    {
        public string ToolId { get; set; }

        public string ToolVendor { get; set; }

        public string ToolModel { get; set; }

        public string ProcessType { get; set; }

        public string ProcessModel { get; set; }

        public string NameSpace { get; set; }

        public string Area { get; set; }

        public string Fab { get; set; }
         
        public override bool Validate(out string errorMessage)
        {
            errorMessage = "";
            Tool tool = (Tool)this;


            if (string.IsNullOrEmpty(tool.ToolId) ||
                string.IsNullOrEmpty(tool.ToolVendor) ||
                string.IsNullOrEmpty(tool.ToolModel) ||
                string.IsNullOrEmpty(tool.ProcessType) ||
                      string.IsNullOrEmpty(tool.ProcessModel) ||
                 // string.IsNullOrEmpty(tool.NameSpace) ||
                 // string.IsNullOrEmpty(tool.Area) ||
                   string.IsNullOrEmpty(tool.Fab))

            {
                errorMessage = "Empty value found!";
            }

            string toolVendor = tool.ToolVendor.ToUpper();

            if (toolVendor != "ASML" && toolVendor != "CANON" && toolVendor != "NIKON")
            {
                errorMessage = "ToolVendor only support ASML, CANON, NIKON.";
            }

            if (string.IsNullOrEmpty(errorMessage)) return true;
            else return false;
        }
    }
}
