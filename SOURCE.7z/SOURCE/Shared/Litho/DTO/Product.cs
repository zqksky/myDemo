﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AMAT.R2R.Shared.Base.DTO;

namespace AMAT.R2R.Shared.Litho.DTO
{
    public class Product : BaseDto
    {
        public string ProductId { get; set; }

        public string ProductType { get; set; }

        public string NameSpace { get; set; }

        public string Fab { get; set; }


        public override bool Validate(out string errorMessage)
        {
            errorMessage = "";
            Product product = (Product)this;


            if (string.IsNullOrEmpty(product.Fab) ||
                //string.IsNullOrEmpty(product.NameSpace) ||
                string.IsNullOrEmpty(product.ProductId) ||
                string.IsNullOrEmpty(product.ProductType))
            
            {
                errorMessage = "Empty value found!";
            }
            if (string.IsNullOrEmpty(errorMessage)) return true;
            else return false;
        }
    }


}
