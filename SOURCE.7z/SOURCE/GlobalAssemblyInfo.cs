﻿using System.Reflection;

// General Information about an assembly is controlled through the following
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyCompany("Applied Materials")]
[assembly: AssemblyProduct("Applied AMS")]
[assembly: AssemblyCopyright("Copyright © 2020 Applied Materials Inc. All rights reserved.")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

//Version information for an assembly consists of the following four values:

//      Major Version   -  Major Version, contain many breaking changes, new functions, require client/server/agent upgrade.
//      Minor Version   -  Minor Version, may contain breaking changes, may require client/server/agent upgrade.
//      Build Number    -  The date of build. The first digit implies Year, 1 = 2019, 2 = 2020... 
//                         the 2nd to the 4th digit implies Month and Day in the format of MMdd
//      Revision        -  3-digit number, the first digit is used for distinguishing different builds in a single day.
//                         The last two digits are always 0.

//                         ClickOnce deployment has to keep the Deployment Verison the same as the AssemblyVersion except the last
//                         two digits. It can increase the last two digits for slight upgrades (e.g. config update) based on 
//                         the same AssemblyVersion.
//
// Example: A released version for 2.1 GA can have a version number 2.1.20125.200
// From this version number, we know it's built at 2020/01/25, and it's the second build of the day.

// At depolyment stage, user may deploy this version multiple times due to config update. For each deployment (ClickOnce upgrade),
// user can only increase the last two digits.
// Example: the ClickOnce-deployed client may show a deployment version of 2.1.20125.200 , or 2.1.20125.201, or 2.1.20125.202...
//
//
//
// Keep the AssemblyFileVersion same of the AssemblyVersion.
[assembly: AssemblyVersion("2.4.20427.100")]
[assembly: AssemblyFileVersion("2.4.20427.100")]
[assembly: AssemblyInformationalVersion("2.4 SP1")]
